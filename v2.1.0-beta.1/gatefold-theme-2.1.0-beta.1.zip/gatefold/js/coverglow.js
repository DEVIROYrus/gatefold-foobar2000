/*
 * Gatefold · coverglow.js — the light of a cover around it: album grids (Library, an artist's page, Home), the
 * album page's cover and Now Playing.
 *
 * The glow is the cover's own colours where they are — the top of a yellow sky lights up above the cover, an orange
 * floor below it: a small picture made once per cover (the cover shrunk to 20×20, drawn twice with a blur into a
 * larger transparent square — a wide spill and a bright rim — with a touch of noise against banding), stretched
 * behind the cover so that its middle lies exactly under it. No CSS blur on dozens of tiles while scrolling,
 * nothing redrawn when the pointer moves; pictures are made in idle moments, a few at a time, kept for the session,
 * the same cover anywhere gets the same picture.
 *
 * In the grids the glows sit in a layer under every tile (see islands.css), so a glow never covers the next album.
 * Strength: Settings → Оформление → «Свечение» (0 — off), separately for the grids and for Now Playing.
 */
import { settings, onSettings } from './settings.js';

const GRID = '#libGrid .tile .cov img, .agrid .tile .cov img, .hm-tile .cov img';
const HERO = '#albumHero .album-cover img';
const NP = '#npImgA, #npImgB';

const cache = new Map();     // 'S|' / 'L|' + cover URL → object URL of its glow (or a promise of it)
const MAX = 800;          // ~20 kB each
let made = 0;

/* The geometry, shared with islands.css: the cover fills the middle FIT of the glow picture, and the page
   stretches the picture to 1 / FIT of the cover — the cover's own pixels sit right under it, its colours spill
   out of each edge (yellow at the top of a yellow sky, orange under an orange floor). */
export const FIT = { S: 0.64, L: 0.56 };

/** a glow picture for a loaded image */
async function make(img, size, fit) {
  // the colours, averaged down: no detail survives, no shimmer when the big picture is stretched
  const bmp = await createImageBitmap(img, { resizeWidth: 20, resizeHeight: 20, resizeQuality: 'high' });
  try {
    const c = typeof OffscreenCanvas !== 'undefined' ? new OffscreenCanvas(size, size) : Object.assign(document.createElement('canvas'), { width: size, height: size });
    const x = c.getContext('2d', { willReadFrequently: true });
    x.imageSmoothingQuality = 'high';
    const d = size * fit, o = (size - d) / 2;
    // a wide, soft spill: the cover a little larger, blurred far, colours lifted (a dark, dull cover still gives light)
    x.filter = `blur(${(size * 0.085).toFixed(1)}px) saturate(1.5) brightness(1.08)`;
    x.drawImage(bmp, o - d * 0.04, o - d * 0.04, d * 1.08, d * 1.08);
    // the bright rim right at the cover's edge
    x.filter = `blur(${(size * 0.035).toFixed(1)}px) saturate(1.35)`;
    x.globalAlpha = 0.8;
    x.drawImage(bmp, o, o, d, d);
    x.filter = 'none'; x.globalAlpha = 1;
    // the picture's own edge faded to nothing (no faint square around a bright cover), and a touch of noise: a smooth
    // gradient stretched five times over shows its 8-bit steps in the dark; ±1 level hides them
    const im = x.getImageData(0, 0, size, size), p = im.data, ramp = size * 0.14;
    const edge = new Float32Array(size);
    for (let i = 0; i < size; i++) { const k = Math.min(1, Math.min(i + 0.5, size - i - 0.5) / ramp); edge[i] = k * k * (3 - 2 * k); }
    for (let y = 0, i = 0; y < size; y++) for (let xx = 0; xx < size; xx++, i += 4) {
      if (!p[i + 3]) continue;
      const n = (Math.random() - 0.5) * 2.2;
      p[i] += n; p[i + 1] += n; p[i + 2] += n;
      p[i + 3] = p[i + 3] * edge[xx] * edge[y] + (Math.random() - 0.5) * 2.2;
    }
    x.putImageData(im, 0, 0);
    const blob = c.convertToBlob ? await c.convertToBlob({ type: 'image/png' }) : await new Promise((r) => c.toBlob(r, 'image/png'));
    return URL.createObjectURL(blob);
  } finally { bmp.close && bmp.close(); }
}

/* made in idle moments, a few at a time: a screen of new tiles never costs a frame while scrolling */
const queue = [];
let pumping = false;
const idle = (fn) => (window.requestIdleCallback ? requestIdleCallback(fn, { timeout: 250 }) : setTimeout(() => fn({ timeRemaining: () => 8 }), 16));
function pump() {
  if (pumping) return;
  pumping = true;
  idle(async (dl) => {
    const t0 = performance.now();
    while (queue.length && (performance.now() - t0 < 10) && (!dl || dl.timeRemaining() > 2 || dl.didTimeout)) {
      const job = queue.shift();
      if (!job.img.isConnected) { job.done(''); continue; }   // a tile scrolled away before its turn
      try { job.done(await make(job.img, job.size, job.fit)); } catch { job.done(''); }
    }
    pumping = false;
    if (queue.length) pump();
  });
}
function glowFor(img, big) {
  const key = (big ? 'L|' : 'S|') + img.currentSrc;
  const have = cache.get(key);
  if (have) return Promise.resolve(have);
  const p = new Promise((done) => { queue.push({ img, size: big ? 128 : 96, fit: big ? FIT.L : FIT.S, done }); pump(); }).then((u) => {
    if (!u) { cache.delete(key); return ''; }
    cache.set(key, u);
    if (++made % 100 === 0 && cache.size > MAX) {
      // the oldest go; a tile still showing one keeps its decoded picture
      let n = cache.size - MAX;
      for (const [k, v] of cache) { if (n-- <= 0) break; if (typeof v === 'string') URL.revokeObjectURL(v); cache.delete(k); }
    }
    return u;
  });
  cache.set(key, p);
  return p;
}
const usable = (img) => img.complete && img.naturalWidth > 1 && img.currentSrc;

async function attachGrid(img) {
  if (!(+settings.glowTiles > 0) || !usable(img)) return;
  const host = img.closest('.tile, .hm-tile'); if (!host) return;
  const src = img.currentSrc;
  const u = await glowFor(img, false);
  if (!u || img.currentSrc !== src || !host.isConnected) return;
  host.style.setProperty('--glow-img', `url("${u}")`);
  host.classList.add('has-glow');
}
async function attachHero(img) {
  const g = document.querySelector('#albumHero .cover-glow'); if (!g) return;
  if (!(+settings.glowNp > 0) || !usable(img)) return;
  const src = img.currentSrc;
  const u = await glowFor(img, true);
  if (!u || img.currentSrc !== src || !g.isConnected) return;
  g.style.aspectRatio = String(img.naturalWidth / img.naturalHeight);   // a 3:4 cover glows as a 3:4 box
  g.style.setProperty('--glow-img', `url("${u}")`); g.classList.add('on');
}
let npSrc = '';
async function attachNp(img) {
  if (!(+settings.glowNp > 0) || !usable(img)) return;
  const src = npSrc = img.currentSrc;
  const u = await glowFor(img, true);
  if (!u || npSrc !== src) return;
  const g = document.getElementById('npGlow'); if (!g) return;
  // two layers: the new glow fades in over the old one, as the cover itself does
  const [a, b] = g.children;
  const next = a.classList.contains('on') ? b : a, prev = next === a ? b : a;
  next.style.backgroundImage = `url("${u}")`;
  next.classList.add('on'); prev.classList.remove('on');
}
/** no cover on Now Playing: no glow from the last one */
export function npClear() { npSrc = ''; document.querySelectorAll('#npGlow > i').forEach((x) => x.classList.remove('on')); }

function route(img) {
  if (img.matches(NP)) attachNp(img);
  else if (img.matches(HERO)) attachHero(img);
  else if (img.matches(GRID)) attachGrid(img);
}
document.addEventListener('load', (e) => { const img = e.target; if (img instanceof HTMLImageElement) route(img); }, true);

/** strength from the settings: CSS variables, and the covers already on screen when it is switched on */
function apply(key) {
  const t = Math.max(0, Math.min(2, +settings.glowTiles || 0)), n = Math.max(0, Math.min(2, +settings.glowNp || 0));
  const r = document.documentElement;
  r.style.setProperty('--glow-t', String(t)); r.style.setProperty('--glow-n', String(n));
  document.body.classList.toggle('glow-tiles', t > 0);
  document.body.classList.toggle('glow-np', n > 0);
  if ((key === 'glowTiles' && t > 0) || (key === 'glowNp' && n > 0)) document.querySelectorAll(`${GRID}, ${HERO}, ${NP}`).forEach((img) => { if (!img.matches('#npImgA:not(.on), #npImgB:not(.on)')) route(img); });
}
apply('*');
onSettings((k) => { if (k === 'glowTiles' || k === 'glowNp' || k === '*') apply(k); });
