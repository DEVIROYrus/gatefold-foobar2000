/*
 * Gatefold · paletteslots.js — your own palettes: «Своя» (settings.customTheme) and five more slots
 * (settings.customSlots), each { name?, bg, accent, accent2 } as #rrggbb. A slot is a colour source like the
 * fixed themes: colorSource 'custom' | 'custom2' … 'custom6'. An album's palette (the Palette tab of Now
 * Playing, the album's own colours) can be saved into any of them.
 */
import { settings, setSetting } from './settings.js';
import { $t } from './i18n.js';
import { esc } from './bridge.js';

export const SLOT_IDS = ['custom', 'custom2', 'custom3', 'custom4', 'custom5', 'custom6'];
export const isCustom = (id) => SLOT_IDS.includes(id);
const indexOf = (id) => SLOT_IDS.indexOf(id);

/** the slot's colours, or null when it is empty */
export function themeOf(id) {
  const i = indexOf(id);
  if (i < 0) return null;
  const t = i === 0 ? settings.customTheme : (settings.customSlots || [])[i - 1];
  return t && t.accent && t.bg ? t : null;
}
export function setThemeOf(id, t) {
  const i = indexOf(id);
  if (i < 0) return;
  if (i === 0) { setSetting('customTheme', t); return; }
  const a = [...(settings.customSlots || [])];
  while (a.length < SLOT_IDS.length - 1) a.push(null);
  a[i - 1] = t;
  setSetting('customSlots', a);
}
/** «Своя», «Своя 2» … — or the name you gave it */
export function slotName(id, t = themeOf(id)) {
  const n = String((t && t.name) || '').trim();
  if (n) return n;
  const i = indexOf(id);
  return i <= 0 ? $t('Своя') : $t('Своя {0}', i + 1);
}
/** the colours a palette gives a slot */
export const fromPalette = (p, name = '') => ({ ...(name ? { name } : {}), bg: p.bg.hex, accent: p.accent.hex, accent2: p.accent2.hex });

/** «В свою палитру ▾»: the slots in a menu at (x, y); the chosen one gets the palette `p` (named `name`).
    Returns the slot's id, or null. Saving into the slot in use re-colours the window at once. */
export async function saveMenu(p, x, y, name = '') {
  if (!p) return null;
  const { popupMenu, toast } = await import('./ui.js');   // not at load: theme.js (and with it this file) also runs in the small windows
  const items = SLOT_IDS.map((id) => {
    const t = themeOf(id);
    return { id, label: t ? `${slotName(id, t)} · ${$t('заменить')}` : `${slotName(id, t)} · ${$t('пусто')}`, checked: settings.colorSource === id };
  });
  const id = await popupMenu(items, x, y);
  if (!id) return null;
  const old = themeOf(id);
  setThemeOf(id, fromPalette(p, name || (old && old.name) || ''));
  if (settings.colorSource === id) toast($t('Палитра «{0}» обновлена', esc(slotName(id))));
  else toast($t('Сохранено в «{0}»', esc(slotName(id))), { action: { label: $t('Включить'), fn: () => setSetting('colorSource', id) }, ms: 8000 });
  return id;
}
