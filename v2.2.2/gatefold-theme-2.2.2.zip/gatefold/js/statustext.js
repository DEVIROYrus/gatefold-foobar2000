/*
 * Gatefold · statustext.js — what foobar2000 and its components say in the interface's status bar (a library scan,
 * a conversion, «Scanning for ReplayGain…»), and its «Show now playing» command. foo_gatefold passed both on since
 * 2.0; nothing showed them before 2.2.2 (the status text went nowhere, the command did nothing).
 */
import { on, esc } from './bridge.js';
import { $ } from './ui.js';

let el = null, idle = 0;

function show(text) {
  clearTimeout(idle);
  if (!text) { hide(); return; }
  if (!el) {
    el = document.createElement('div');
    el.className = 'toast status-text';
    el.setAttribute('role', 'status');
    el.innerHTML = '<svg width="14" height="14" class="spin"><use href="#i-refresh"/></svg><div class="st-text"></div>';
    $('toasts').appendChild(el);
  }
  el.querySelector('.st-text').innerHTML = esc(String(text));
  // a component that never says «over»: the line goes after a minute without news
  idle = setTimeout(hide, 60000);
}

function hide() {
  if (!el) return;
  const e = el; el = null;
  e.classList.add('out');
  setTimeout(() => e.remove(), 260);
}

export function init({ showNowPlaying }) {
  on('player:statusText', (d) => show(d && d.text));
  on('player:showNowPlaying', () => showNowPlaying());
}
