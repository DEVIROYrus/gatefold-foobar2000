/*
 * Gatefold · notplaying.js — what Gatefold writes into a file by itself (ReplayGain values of the volume
 * levelling, lyrics saved to the tags) waits until that file is no longer playing.
 *
 * A write to the playing file reaches the decoder in the middle of the song: with the 2.2 component it stopped
 * playback and started the track again (a stutter, then a jump — #37), and even where foobar2000 handles it
 * gracefully it is a needless risk for something nobody is waiting for. What a person does themselves (the tag
 * editor, autotagging) is written at once, as asked.
 */
import { call, ok, on } from './bridge.js';

let now = new Set();          // the playing track's names: its path, its foobar2000 path, its handle — lower case
let wired = false;
const waiting = [];           // { keys:Set, fn, resolve, reject }

const keysOf = (...xs) => new Set(xs.filter(Boolean).map((x) => String(x).toLowerCase()).flatMap((x) => [x, x.replace(/^file:\/\//, '')]));
const hits = (keys) => [...keys].some((k) => now.has(k));

function wire() {
  if (wired) return;
  wired = true;
  const set = (d) => { now = d ? keysOf(d.handle, d.path, d.absolutePath, d.subsong > 0 && d.absolutePath ? `${d.absolutePath}|subsong:${d.subsong}` : '') : new Set(); };
  on('playback:trackChanged', (d) => { set(d); flushSoon(); });
  on('playback:stopped', (d) => { if (!/another|starting/i.test(String((d && d.reason) || ''))) { set(null); flushSoon(); } });
  call('playback.getCurrentTrack').then((r) => { const t = ok(r) && r.found !== false ? (r.track || r) : null; if (t && now.size === 0) set(t); }).catch(() => {});
}

let flushT = 0;
/* a moment after the change: the previous file is let go of only once the new one plays */
function flushSoon() {
  clearTimeout(flushT);
  flushT = setTimeout(() => {
    for (let i = 0; i < waiting.length;) {
      const w = waiting[i];
      if (hits(w.keys)) { i++; continue; }
      waiting.splice(i, 1);
      Promise.resolve().then(w.fn).then(w.resolve, w.reject);
    }
  }, 2500);
}

/** whether this file (any of its names) is the one playing */
export function isPlaying(...names) { wire(); return hits(keysOf(...names)); }

/** runs `fn` now, or — when the file is playing — once playback has left it; resolves with what `fn` gives */
export function whenFree(names, fn) {
  wire();
  const keys = keysOf(...[].concat(names));
  if (!hits(keys)) return Promise.resolve().then(fn);
  return new Promise((resolve, reject) => waiting.push({ keys, fn, resolve, reject }));
}

/** how many writes wait for playback to move on */
export const pending = () => waiting.length;
