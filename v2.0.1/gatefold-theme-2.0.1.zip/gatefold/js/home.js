/*
 * Gatefold · home.js — «Главная»: what to play now.
 *   continue   the album playing now, or the one you stopped at (history.js)
 *   mixes      mood mixes from the sound analysis (ml/sound-ui.js), one tile each
 *   new        recently added albums (foo_playcount's %added%), or a pick of the day without it
 *   remember   a year ago these days, favourites you haven't played for a while, this week's artist
 */
import { esc, albumKeyOf } from './bridge.js';
import { router, h, icon, $ } from './ui.js';
import { settings, setSetting, onSettings } from './settings.js';
import { $t, plural } from './i18n.js';
import * as Lib from './library.js';
import * as SORT from './sorting.js';
import * as History from './history.js';
import * as Sound from './ml/sound.js';
import * as SoundUI from './ml/sound-ui.js';
import { placeholder } from './ui.js';

const view = () => $('view-home');
const dpr = () => window.devicePixelRatio || 1;
const DAY = 864e5;
let now = null, token = 0, timer = 0;
/* Home is built again only when something it shows has changed (what plays, the library, the history, the sound
   analysis, a setting) or it is ten minutes old — not on every visit: coming back is then a switch of screens, not
   ~50 ms of building, layout and cover loading. The greeting and today's listening are brought up to date anyway. */
let dirty = true, builtAt = 0;
const stale = () => { dirty = true; };
function header(page, tk) {
  page.querySelector('.hm-date').textContent = dateLine();
  History.today().then(({ n, s }) => { if (n && tk === token) page.querySelector('.hm-date').textContent = `${dateLine()} · ${$t('сегодня {0} музыки', fmtListen(s))} · ${n} ${plural(n, 'трек', 'трека', 'треков')}`; });
  page.querySelector('h1').textContent = greeting();
}

export function setNow(t) { now = t; dirty = true; if (router.current === 'home') refreshSoon(400); }
export function refreshSoon(ms = 800) { clearTimeout(timer); timer = setTimeout(() => { if (router.current === 'home') render(); }, ms); }

function greeting(d = new Date()) {
  const hr = d.getHours();
  return hr < 5 ? $t('Доброй ночи') : hr < 12 ? $t('Доброе утро') : hr < 18 ? $t('Добрый день') : $t('Добрый вечер');
}
const agoDays = (t) => { const d = Math.floor((Date.now() - t) / DAY); return d <= 0 ? $t('сегодня') : d === 1 ? $t('вчера') : d < 30 ? $t('{0} дн. назад', d) : new Date(t).toLocaleDateString(document.documentElement.lang || undefined, d > 300 ? { day: 'numeric', month: 'short', year: 'numeric' } : { day: 'numeric', month: 'short' }); };
const fmtListen = (s) => (s >= 3600 ? $t('{0} ч {1} мин', Math.floor(s / 3600), Math.round((s % 3600) / 60)) : $t('{0} мин', Math.max(1, Math.round(s / 60))));
const dateLine = (d = new Date()) => {
  const s = d.toLocaleDateString(document.documentElement.lang || undefined, { weekday: 'long', day: 'numeric', month: 'long' });
  return s.charAt(0).toUpperCase() + s.slice(1);
};

function findAlbum(albums, artist, album) {
  if (!album) return null;
  const k = albumKeyOf(artist, album);
  return albums.find((a) => SORT.albumKey(a) === k) || albums.find((a) => a.name === album && (a.albumArtist === artist || a.artist === artist)) || null;
}

/** a seeded shuffle: the same picks all day, new ones tomorrow */
function dayPick(list, n) {
  let s = Math.floor(Date.now() / DAY) * 2654435761 % 2 ** 32;
  const rnd = () => ((s = (s * 1664525 + 1013904223) % 2 ** 32) / 2 ** 32);
  const a = list.slice();
  for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(rnd() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; }
  return a.slice(0, n);
}

function albumTile(a) {
  const ph = placeholder(a.name, a.albumArtist);
  const el = h(`<div class="hm-tile"><div class="cov"><div class="ph" style="background:${ph.bg}">${esc(ph.ini)}</div><img alt=""><button class="play" title="${$t('Слушать')}" aria-label="${esc($t('Слушать'))}">${icon('play', 18)}</button></div><button class="tt"></button><div class="ta"></div></div>`);
  el.querySelector('.tt').textContent = a.name;
  el.querySelector('.ta').textContent = [a.albumArtist || a.artist, a.year].filter(Boolean).join(' · ');
  el.title = `${a.albumArtist || a.artist} — ${a.name}`;
  el.onclick = (e) => { if (e.target.closest('.play')) { Lib.playAlbumRow(a); return; } Lib.openAlbumFrom(el, a); };
  el.oncontextmenu = (e) => { e.preventDefault(); Lib.albumMenu(a, e.clientX, e.clientY); };   // the same menu as in the Library
  return el;
}

async function paintCovers(root, sel, paths, px) {
  const want = paths.filter(Boolean);
  if (!want.length) return;
  const get = await Lib.coversFor([...new Set(want)], Math.round(px * dpr()));
  root.querySelectorAll(sel).forEach((img) => { const u = get(img.dataset.p); if (u) Lib.setImg(img, u); });
}

const section = (title, more = '', kind = '') => h(`<section class="hm-sec" data-kind="${kind}"><div class="hm-head"><h2>${esc(title)}</h2><span class="hm-head-r">${more}</span></div><div class="hm-body"></div></section>`);

/* every row of tiles has the same number of columns, worked out from the width of the page: the tiles
   fill the row edge to edge at any window size and scale, and what does not fit waits behind «Ещё N» */
const TILE = 170, GAP = 20;
let ro = null, lastCols = 0;
function layoutRows(page = view() && view().querySelector('.hm')) {
  if (!page) return;
  const w = page.querySelector('.hm-head')?.clientWidth || page.clientWidth - 64;
  const cols = Math.max(2, Math.min(9, Math.floor((w + GAP) / (TILE + GAP))));
  page.style.setProperty('--cols', cols);
  lastCols = cols;
  for (const row of page.querySelectorAll('.hm-row')) {
    const open = row.closest('.hm-sec').classList.contains('open');
    const items = [...row.children];
    items.forEach((el, i) => { el.hidden = !open && i >= cols; });
    const extra = items.length - cols;
    const tg = row.closest('.hm-sec').querySelector('.hm-toggle');
    if (tg) { tg.hidden = extra <= 0; tg.textContent = open ? $t('Свернуть') : $t('Ещё {0}', extra); }
  }
}
function toggleBtn(sec) {
  const b = h('<button class="hm-more hm-toggle" hidden></button>');
  b.onclick = () => { sec.classList.toggle('open'); layoutRows(); };
  return b;
}

// ------------------------------------------------------------------ continue
async function heroSection(albums, tk) {
  let t = now, live = !!now, entry = null;
  if (!t) { entry = await History.last(); if (!entry) return null; t = { title: entry.ti, artist: entry.ar, albumArtist: entry.aa, album: entry.al, year: entry.y, path: entry.p, handle: entry.h }; }
  const a = findAlbum(albums, t.albumArtist || t.artist, t.album);
  const tracks = a ? await Lib.albumTracks(a).catch(() => []) : [];
  if (tk !== token) return null;
  const hkey = String(t.handle || t.path || '').toLowerCase();
  const idx = tracks.findIndex((x) => String(x.handle || x.absolutePath || '').toLowerCase() === hkey || String(x.absolutePath || '').toLowerCase() === String(t.path || '').toLowerCase());
  const next = idx >= 0 ? tracks.slice(idx + 1) : [];
  const kicker = live ? $t('Сейчас играет') : $t('Продолжить');
  const pos = idx >= 0 && tracks.length ? ' · ' + $t('трек {0} из {1}', idx + 1, tracks.length) : '';
  const left = next.reduce((s, x) => s + (+x.duration || 0), 0);
  const name = a ? a.name : t.album || t.title;
  const sub = [t.albumArtist || t.artist, t.year || (a && a.year), a && a.genre].filter(Boolean).join(' · ');
  const ph = placeholder(name, t.albumArtist || t.artist);
  const el = h(`<section class="hm-hero">
    <div class="cov"><div class="ph" style="background:${ph.bg}">${esc(ph.ini)}</div><img alt="" data-p="${esc((a && a.firstTrackAbsolutePath) || t.path || '')}"></div>
    <div class="hm-hero-main">
      <div class="hm-kicker">${esc(kicker)}${esc(pos)}</div>
      <div class="hm-hero-title"></div>
      <div class="hm-hero-sub"></div>
      ${tracks.length && idx >= 0 ? `<div class="hm-progress"><div class="bar"><i style="width:${Math.round(((idx + (live ? 0.5 : 1)) / tracks.length) * 100)}%"></i></div><span>${next.length ? esc($t('осталось {0} мин', Math.max(1, Math.round(left / 60)))) : esc($t('последний трек'))}</span></div>` : ''}
      <div class="hm-actions"></div>
    </div>
    <div class="hm-next"></div>
  </section>`);
  el.querySelector('.hm-hero-title').textContent = name;
  el.querySelector('.hm-hero-sub').textContent = sub;
  const acts = el.querySelector('.hm-actions');
  const btn = (label, ic, primary, fn) => { const b = h(`<button class="hm-btn${primary ? ' primary' : ''}">${icon(ic, 16)}<span></span></button>`); b.querySelector('span').textContent = label; b.onclick = fn; acts.append(b); };
  if (live) btn($t('Открыть'), 'disc', true, () => router.go('now'));
  else btn($t('Продолжить'), 'play', true, () => (a && idx >= 0 ? Lib.playAlbumRow(a, Math.min(idx + 1, tracks.length - 1)) : a ? Lib.playAlbumRow(a) : null));
  if (a) btn($t('Альбом'), 'grid', false, () => router.go('album', a));
  const nx = el.querySelector('.hm-next');
  if (next.length) {
    nx.innerHTML = `<div class="hm-next-h">${esc($t('Дальше в альбоме'))}</div>`;
    for (const x of next.slice(0, 3)) {
      const r = h('<div class="hm-next-row"><span class="n"></span><span class="d num"></span></div>');
      r.querySelector('.n').textContent = x.title || String(x.absolutePath || '').split(/[\\/]/).pop();
      r.querySelector('.d').textContent = x.duration ? `${Math.floor(x.duration / 60)}:${String(Math.floor(x.duration % 60)).padStart(2, '0')}` : '';
      nx.append(r);
    }
    if (next.length > 3) nx.append(h(`<div class="hm-next-more">${esc($t('и ещё {0}', next.length - 3))}</div>`));
  } else nx.remove();
  paintCovers(el, 'img[data-p]', [el.querySelector('img').dataset.p], 180);
  return el;
}

// ------------------------------------------------------------------ mixes
const TINT = { energy: '#a3206e', calm: '#2a6a66', sad: '#2b3b72', happy: '#a0761c', party: '#7a2aa0', instrumental: '#2c3a48', acoustic: '#80561a' };
function mixesSection() {
  const sec = section($t('Миксы дня'), `<span class="hm-note">${esc(settings.mixDaily ? $t('по звучанию ваших треков · обновятся завтра') : $t('по звучанию ваших треков'))}</span>`, 'mixes');
  sec.querySelector('.hm-head-r').append(toggleBtn(sec));
  const body = sec.querySelector('.hm-body'); body.classList.add('hm-row');
  if (!Sound.ready()) {
    const card = h(`<button class="hm-cta">${icon('sparkle', 22)}<span><b></b><small></small></span></button>`);
    card.querySelector('b').textContent = $t('Миксы по настроению');
    card.querySelector('small').textContent = $t('Включите анализ звука — и здесь появятся подборки: спокойное, энергичное, для вечеринки…');
    card.onclick = () => SoundUI.openSettings();
    body.classList.remove('hm-row'); body.append(card);
    return sec;
  }
  const paths = [];
  for (const [kind, title] of SoundUI.MOOD_RECIPES()) {
    const pv = SoundUI.mixPreview(kind, 4);
    if (!pv) continue;
    const imgs = pv.albums.map((x) => { paths.push(x.path); return `<img alt="" data-p="${esc(x.path)}">`; }).join('');
    const el = h(`<button class="hm-mix" style="--tint:${TINT[kind] || '#334'}"><div class="cov n${pv.albums.length}">${imgs}<b></b></div><div class="ta"></div></button>`);
    el.querySelector('b').textContent = title;
    el.querySelector('.ta').textContent = pv.artists.join(', ');
    el.title = $t('{0} — плейлист из {1}', title, `${pv.count} ${plural(pv.count, 'трек', 'трека', 'треков')}`);
    el.onclick = () => SoundUI.moodPlaylist(kind, title);
    body.append(el);
  }
  if (!body.children.length) return null;
  paintCovers(body, 'img[data-p]', paths, 160);
  return sec;
}

// ------------------------------------------------------------------ new in the library
async function newSection(albums, tk) {
  const has = await SORT.ensure('added', albums).catch(() => false);
  if (tk !== token) return null;
  const list = has ? SORT.sortAlbums(albums, 'added').slice(0, 12) : dayPick(albums, 12);
  if (!list.length) return null;
  const more = has ? `<button class="hm-more">${esc($t('Все'))}</button>` : `<span class="hm-note">${esc($t('новые каждый день'))}</span>`;
  const sec = section(has ? $t('Недавно добавлено') : $t('Из вашей медиатеки'), more, 'albums');
  sec.querySelector('.hm-head-r').prepend(toggleBtn(sec));
  const body = sec.querySelector('.hm-body'); body.classList.add('hm-row');
  const b = sec.querySelector('.hm-more');
  if (b) b.onclick = () => { setSetting('librarySort', 'added'); router.go('library'); };
  for (const a of list) {
    const el = albumTile(a);
    // «Недавно добавлено»: how long ago instead of the year
    const t = has && SORT.addedAt(a);
    if (t > 1e11) el.querySelector('.ta').textContent = [a.albumArtist || a.artist, agoDays(t)].filter(Boolean).join(' · ');
    body.append(el);
  }
  Lib.coversFor(list.map((a) => a.firstTrackAbsolutePath).filter(Boolean), Math.round(240 * dpr())).then((get) => {
    body.querySelectorAll('.hm-tile').forEach((el, i) => { const u = get(list[i].firstTrackAbsolutePath); if (u) Lib.setImg(el.querySelector('img'), u); });
  });
  return sec;
}

// ------------------------------------------------------------------ remember
async function rememberSection(albums) {
  const cards = [];
  const yearAgo = Date.now() - 365 * DAY;
  const ya = await History.albumsBetween(yearAgo - 3 * DAY, yearAgo + 4 * DAY);
  if (ya[0]) cards.push({ label: $t('Год назад в эти дни'), e: ya[0].e });
  const fg = await History.forgotten(90, 8);
  if (fg[0]) cards.push({ label: $t('Давно не слушали'), e: fg[0].e });
  const top = await History.artistsSince(Date.now() - 7 * DAY);
  if (top[0] && top[0].n >= 5) cards.push({ label: $t('Чаще всего на этой неделе'), artist: top[0].name, n: top[0].n });
  const week = (await History.all()).filter((e) => e.ts >= Date.now() - 7 * DAY);
  if (week.length >= 10) cards.push({ label: $t('За 7 дней'), stats: `${fmtListen(week.reduce((n, e) => n + (e.d || 0), 0))} · ${week.length} ${plural(week.length, 'трек', 'трека', 'треков')}`, p: week[week.length - 1].p });
  if (!cards.length) return null;
  const sec = section($t('Вспомнить'), `<button class="hm-more" data-go="stats">${esc($t('Итоги года'))}</button>`, 'albums');
  sec.querySelector('[data-go=stats]').onclick = () => router.go('stats');
  const body = sec.querySelector('.hm-body'); body.classList.add('hm-cards');
  const paths = [];
  for (const c of cards) {
    const a = c.e ? findAlbum(albums, c.e.aa || c.e.ar, c.e.al) : c.artist ? albums.find((x) => (x.albumArtist || x.artist) === c.artist) : null;
    const p = (a && a.firstTrackAbsolutePath) || (c.e && c.e.p) || c.p || '';
    if (p) paths.push(p);
    const el = h(`<button class="hm-card"><img alt="" data-p="${esc(p)}"><span><small></small><b></b></span></button>`);
    el.querySelector('small').textContent = c.label;
    el.querySelector('b').textContent = c.stats || (c.artist ? `${c.artist} · ${c.n} ${plural(c.n, 'трек', 'трека', 'треков')}` : (a ? a.name : c.e.al));
    el.onclick = () => (c.stats ? router.go('stats') : c.artist ? router.go('artist', c.artist) : a ? router.go('album', a) : null);
    body.append(el);
  }
  paintCovers(body, 'img[data-p]', paths, 64);
  return sec;
}

// ------------------------------------------------------------------ what's new (once)
const WN = 'gatefold.whatsnew.2.0';
function whatsNew() {
  try { if (localStorage.getItem(WN)) return null; } catch { return null; }
  const items = [
    ['search', $t('Ctrl+K — поиск по всему: экраны, команды, альбомы, исполнители, треки')],
    ['sliders', $t('Масштаб интерфейса подстраивается под окно — Настройки → Окно и запуск')],
    ['heart', $t('Своя история прослушиваний: «Вспомнить», «Итоги года», «Чаще всего у вас»')],
    ['image', $t('«Обложки» теперь в Настройки → Здоровье коллекции')],
  ];
  const el = h(`<section class="hm-new"><div class="hm-new-h"><b></b><button class="hm-btn sm">${esc($t('Понятно'))}</button></div><ul></ul></section>`);
  el.querySelector('b').textContent = $t('Что нового в Gatefold 2.0');
  for (const [ic, t] of items) { const li = h(`<li>${icon(ic, 16)}<span></span></li>`); li.querySelector('span').textContent = t; el.querySelector('ul').append(li); }
  el.querySelector('button').onclick = () => { try { localStorage.setItem(WN, '1'); } catch {} el.remove(); };
  return el;
}

// ------------------------------------------------------------------ render
export async function render() {
  const root = view(); if (!root) return;
  const tk = ++token;
  dirty = false; builtAt = Date.now();
  const albums = await Lib.getAllAlbums().catch(() => []);
  if (tk !== token) return;
  const page = h(`<div class="hm"><header class="hm-top"><div><div class="hm-date"></div><h1></h1></div><div class="hm-tabs" role="tablist"></div></header></div>`);
  const tabs = page.querySelector('.hm-tabs');
  for (const [k, label] of [['', $t('Всё')], ['albums', $t('Альбомы')], ['mixes', $t('Миксы')]]) {
    const b = h(`<button role="tab" class="hm-tab" aria-selected="${tab === k}"></button>`);
    b.textContent = label;
    b.onclick = () => { tab = k; tabs.querySelectorAll('.hm-tab').forEach((x) => x.setAttribute('aria-selected', String(x === b))); applyTab(page); };
    tabs.append(b);
  }
  // arrows move between the tabs, as a tab list should
  tabs.onkeydown = (e) => {
    if (e.key !== 'ArrowLeft' && e.key !== 'ArrowRight') return;
    const all = [...tabs.querySelectorAll('.hm-tab')], i = all.indexOf(document.activeElement);
    if (i < 0) return;
    e.preventDefault(); e.stopPropagation();
    const n = all[(i + (e.key === 'ArrowRight' ? 1 : -1) + all.length) % all.length]; n.focus(); n.click();
  };
  header(page, tk);
  const wn = whatsNew(); if (wn) page.append(wn);
  const parts = await Promise.all([heroSection(albums, tk), mixesSection(), newSection(albums, tk), rememberSection(albums)]);
  if (tk !== token) return;
  for (const p of parts) if (p) page.append(p);
  if (!albums.length && !parts[0]) page.append(h(`<div class="hm-empty">${esc($t('Добавьте папку с музыкой — и здесь появятся ваши альбомы и подборки.'))}</div>`));
  if (!page.querySelector('.hm-mix')) tabs.hidden = true;
  const keep = root.scrollTop;
  root.replaceChildren(page);
  applyTab(page);
  root.scrollTop = keep;
  if (!ro) { ro = new ResizeObserver(() => layoutRows()); ro.observe(root); }
}

/* «Альбомы» / «Миксы»: only those sections, opened up to all their tiles */
let tab = '';
function applyTab(page) {
  for (const sec of page.querySelectorAll('.hm-sec')) {
    const kind = sec.dataset.kind;
    sec.hidden = !!tab && kind !== tab;
    sec.classList.toggle('open', !!tab && kind === tab);
  }
  const hero = page.querySelector('.hm-hero'); if (hero) hero.hidden = tab === 'mixes';
  layoutRows(page);
}

export function init() {
  router.on('home', () => {
    const page = view()?.querySelector(':scope > .hm');
    if (!page || dirty || Date.now() - builtAt > 10 * 60e3) { render(); return; }
    header(page, token);
    layoutRows(page);
  });
  Lib.libEvents.addEventListener('changed', () => { stale(); refreshSoon(1500); });
  History.events.addEventListener('change', () => { stale(); refreshSoon(3000); });
  Sound.events.addEventListener('change', () => { stale(); if (router.current === 'home' && Sound.ready() && !view().querySelector('.hm-mix')) refreshSoon(2000); });
  onSettings(stale);
}
