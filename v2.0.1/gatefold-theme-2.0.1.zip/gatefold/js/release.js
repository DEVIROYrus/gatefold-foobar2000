/*
 * Gatefold · release.js — an album, EP or single from the artist's discography that is not (or not all)
 * in your library: its full track list from MusicBrainz (artistinfo.js → release).
 *   · a track you have — on this release or any other album of the artist — plays from the disk;
 *   · a track you do not have plays through YouTube (youtube.js → playTracks), and the missing ones
 *     after it follow in order.
 * «Слушать» plays the whole release: from the disk when you have all of it, otherwise on YouTube.
 */
import { esc, fmtTime, fmtDuration, plural } from './bridge.js';
import { router, $, h, icon, toast, backButton, placeholder } from './ui.js';
import * as Lib from './library.js';
import * as Info from './artistinfo.js';
import { $t } from './i18n.js';

const same = Info.sameTrack;
const TYPE = { Album: () => $t('Альбом'), EP: () => 'EP', Single: () => $t('Сингл') };

/** the artist's tracks on disk: { title, path, album } (at most 40 albums, enough for any discography) */
async function localTracks(x) {
  const out = [];
  for (const a of (x.albums || []).slice(0, 40)) {
    for (const t of await Lib.albumTracks(a)) out.push({ title: t.title || '', path: t.handle || t.absolutePath, album: a.name, sec: t.duration || 0 });
  }
  return out;
}
/** the release's tracks, each with the matching track on disk (or none) */
async function joined(x, d) {
  const [rel, mine] = await Promise.all([Info.release(d.id), localTracks(x)]);
  const tracks = (rel && rel.tracks) || [];
  return { rel, rows: tracks.map((t) => ({ ...t, local: mine.find((m) => same(m.title, t.title)) || null })) };
}

/** «Слушать» from a tile: the whole release, from the disk when all of it is there, else YouTube */
export async function playRelease(x, d, from = 0) {
  const { rows } = await joined(x, d);
  if (!rows.length) { toast($t('Трек-лист не найден в MusicBrainz')); return; }
  if (rows.every((r) => r.local)) { Lib.playPaths(rows.map((r) => r.local.path), from, d.title); return; }
  router.go('youtube', { tracks: rows.map((r) => ({ artist: x.name, title: r.title, sec: r.sec })), index: from, album: d.title, from: fromOf(x, d) });
}
/** where YouTube leads back to: this release and its artist */
const fromOf = (x, d) => ({ album: d.title, artist: x.name, artistArg: x, route: ['release', { artist: x.name, d, x }] });

let token = 0, YT = null;
async function open(arg) {
  YT = await import('./youtube.js').catch(() => null);
  if (!arg || !arg.d) return;
  const { x, d } = arg, tk = ++token;
  const hero = $('relHero'), list = $('relTracks');
  hero.innerHTML = `
    <div class="album-cover rel-cover" style="background:${placeholder(d.title, x.name).bg}"><span class="rel-ini">${esc(placeholder(d.title, x.name).ini)}</span><img alt=""></div>
    <div style="min-width:0">
      <div class="kicker">${esc(TYPE[d.type] ? TYPE[d.type]() : $t('Альбом'))} · ${esc($t('нет в вашей медиатеке'))}</div>
      <h1></h1>
      <div class="album-meta"><b class="rel-artist"></b>${d.year ? ' · ' + d.year : ''}<span class="rel-sum"></span></div>
      <div class="rel-chips"></div>
      <div class="album-actions">
        <button class="hm-btn primary" id="relPlay" disabled>${icon('play', 16)}${esc($t('Слушать'))}</button>
        <button class="hm-btn" id="relMine" hidden>${icon('disc', 16)}<span></span></button>
      </div>
    </div>`;
  hero.prepend(backButton('artist'));
  hero.querySelector('h1').textContent = d.title;
  const ar = hero.querySelector('.rel-artist'); ar.textContent = x.name; ar.classList.add('more-link'); ar.onclick = () => router.go('artist', x);
  const img = hero.querySelector('img');
  img.onload = () => { if (img.naturalWidth > 1) { img.classList.add('on'); hero.querySelector('.rel-ini')?.remove(); } }; img.onerror = () => img.remove();
  img.src = Info.releaseCover(d, 500);
  list.innerHTML = `<div class="rel-note"><span class="spinner"></span>${esc($t('Загружаю трек-лист из MusicBrainz…'))}</div>`;
  $('releaseScroller').scrollTop = 0;

  const { rel, rows } = await joined(x, d);
  if (tk !== token) return;
  if (!rows.length) {
    list.innerHTML = `<div class="rel-note">${esc(rel ? $t('В MusicBrainz нет трек-листа этого релиза') : $t('MusicBrainz сейчас недоступен'))}</div>`;
    return;
  }
  const have = rows.filter((r) => r.local).length, total = rows.reduce((n, r) => n + (r.sec || 0), 0);
  hero.querySelector('.rel-sum').textContent = ` · ${rows.length} ${plural(rows.length, 'трек', 'трека', 'треков')}${total ? ' · ' + fmtDuration(total) : ''}`;
  if (have) hero.querySelector('.kicker').textContent = `${TYPE[d.type] ? TYPE[d.type]() : $t('Альбом')} · ${$t('у вас {0} из {1}', have, rows.length)}`;
  hero.querySelector('.rel-chips').innerHTML = have === rows.length ? '' : `<span class="chip">${icon('yt', 13)} ${esc(have ? $t('Остальные {0} — с YouTube', rows.length - have) : $t('Играет с YouTube'))}</span>`;

  const play = $('relPlay');
  play.disabled = false;
  play.lastChild.textContent = have === rows.length ? $t('Слушать') : $t('Слушать на YouTube');
  play.onclick = () => playRelease(x, d);
  const mine = $('relMine');
  if (have && have < rows.length) {
    mine.hidden = false; mine.querySelector('span').textContent = $t('Ваши треки · {0}', have);
    mine.onclick = () => Lib.playPaths(rows.filter((r) => r.local).map((r) => r.local.path), 0, d.title);
  }

  const multi = rows.some((r) => r.disc > 1);
  list.innerHTML = '';
  let disc = 0;
  rows.forEach((r, i) => {
    if (multi && r.disc !== disc) { disc = r.disc; list.append(h(`<div class="rel-disc">${esc($t('Диск {0}', disc))}</div>`)); }
    const el = h(`<button class="rel-row${r.local ? ' have' : ''}" data-i="${i}"><span class="n num"></span><span class="t"><b></b><small></small></span><span class="src"></span><span class="d num"></span></button>`);
    el.querySelector('.n').textContent = r.n;
    el.querySelector('b').textContent = r.title;
    el.querySelector('small').textContent = r.local && !same(r.local.album, d.title) ? $t('из «{0}»', r.local.album) : '';
    el.querySelector('.src').innerHTML = r.local ? `<span class="rel-disk" title="${esc($t('Есть на диске'))}">${icon('disc', 14)}</span>` : `<span class="rel-yt" title="${esc($t('Сыграет с YouTube'))}">${icon('yt', 14)} YouTube</span>`;
    el.querySelector('.d').textContent = r.sec ? fmtTime(r.sec) : '';
    el.title = r.local ? $t('Слушать с диска') : $t('Слушать на YouTube');
    if (!r.local && YT && YT.state.album === d.title && YT.state.cur && YT.state.cur.title === r.title) el.classList.add('now');
    el.onclick = () => {
      if (r.local) {
        const loc = rows.filter((q) => q.local);
        Lib.playPaths(loc.map((q) => q.local.path), loc.indexOf(r), d.title);
      } else {
        const miss = rows.filter((q) => !q.local);
        router.go('youtube', { tracks: miss.map((q) => ({ artist: x.name, title: q.title, sec: q.sec })), index: miss.indexOf(r), album: d.title, from: fromOf(x, d) });
      }
    };
    list.append(el);
  });
  list.append(h(`<div class="rel-src">${esc($t('Трек-лист: MusicBrainz{0}', rel && rel.date ? ' · ' + rel.date : ''))}</div>`));
}

router.on('release', open);
