/*
 * Gatefold · stats.js — «Итоги»: your year in music, from Gatefold's own history (history.js).
 * Time listened, tracks, artists and albums; the top artists, albums and tracks; the months; the
 * hours of the day. With foo_playcount installed, «За всё время» adds its play counts.
 */
import { call, ok, esc, fmtDuration, plural } from './bridge.js';
import { router, h, $ } from './ui.js';
import { $t, locale } from './i18n.js';
import * as History from './history.js';
import * as Lib from './library.js';

const view = () => $('view-stats');
let year = new Date().getFullYear();

function top(map, n) { return [...map.values()].sort((a, b) => b.n - a.n).slice(0, n); }

async function playcountTop() {
  const r = await call('library.query', { query: '%play_count% GREATER 0', sort: '$num(%play_count%,9)', limit: 2000, fields: ['handle', 'title', 'artist', 'album', 'albumArtist', 'absolutePath'] });
  if (!ok(r) || !(r.tracks || []).length) return null;
  const tracks = r.tracks.slice(-300).reverse();       // the most played last in an ascending order
  const ev = await call('titleformat.evalFieldsBatch', { paths: tracks.map((t) => t.handle || t.absolutePath), fields: { plays: '%play_count%' } });
  const rows = ok(ev) ? ev.results || [] : [];
  const artists = new Map();
  tracks.forEach((t, i) => { const n = +(rows[i] && rows[i].plays) || 0; if (!n) return; const a = t.albumArtist || t.artist; if (!a) return; const v = artists.get(a) || { name: a, n: 0 }; v.n += n; artists.set(a, v); });
  return { artists: top(artists, 8), total: r.total || tracks.length };
}

export async function render() {
  const root = view(); if (!root) return;
  const all = await History.all();
  const years = [...new Set(all.map((e) => new Date(e.ts).getFullYear()))].sort((a, b) => b - a);
  if (years.length && !years.includes(year)) year = years[0];
  const list = all.filter((e) => new Date(e.ts).getFullYear() === year);
  const secs = list.reduce((s, e) => s + (e.d || 0), 0);
  const artists = new Map(), albums = new Map(), tracks = new Map(), months = new Array(12).fill(0), hours = new Array(24).fill(0);
  for (const e of list) {
    const ar = e.aa || e.ar; if (ar) { const v = artists.get(ar) || { name: ar, n: 0 }; v.n++; artists.set(ar, v); }
    if (e.al) { const k = History.albumOf(e); const v = albums.get(k) || { e, n: 0 }; v.n++; albums.set(k, v); }
    const tk = (e.ti || '') + '\u0001' + (e.ar || ''); const tv = tracks.get(tk) || { e, n: 0 }; tv.n++; tracks.set(tk, tv);
    const d = new Date(e.ts); months[d.getMonth()] += e.d || 0; hours[d.getHours()]++;
  }
  const page = h(`<div class="st-page"><header class="st-top"><div><div class="kicker">${esc($t('Итоги'))}</div><h1>${esc($t('Ваш {0} в музыке', year))}</h1></div><div class="seg st-years"></div></header></div>`);
  const seg = page.querySelector('.st-years');
  for (const y of years.slice(0, 6)) { const b = h(`<button class="${y === year ? 'on' : ''}">${y}</button>`); b.onclick = () => { year = y; render(); }; seg.append(b); }
  if (!years.length) seg.remove();
  if (!list.length) {
    page.append(h(`<div class="st-empty">${esc($t('Здесь появятся ваши итоги: Gatefold записывает, что вы слушаете, начиная с версии 2.0.'))}</div>`));
  } else {
    const num = (v, label) => `<div class="st-num"><b>${v}</b><span>${esc(label)}</span></div>`;
    page.append(h(`<div class="st-nums">${num(Math.round(secs / 3600).toLocaleString(), $t('часов музыки'))}${num(list.length.toLocaleString(), plural(list.length, 'прослушивание', 'прослушивания', 'прослушиваний'))}${num(artists.size.toLocaleString(), plural(artists.size, 'исполнитель', 'исполнителя', 'исполнителей'))}${num(albums.size.toLocaleString(), plural(albums.size, 'альбом', 'альбома', 'альбомов'))}</div>`));
    // months
    const mx = Math.max(1, ...months);
    const mnames = [...Array(12)].map((_, i) => new Date(2000, i, 1).toLocaleDateString(locale, { month: 'short' }).replace('.', ''));
    page.append(h(`<section class="st-sec"><h2>${esc($t('По месяцам'))}</h2><div class="st-bars">${months.map((v, i) => `<div class="st-bar" title="${esc(mnames[i])}: ${esc(fmtDuration(v))}"><i style="height:${Math.round((v / mx) * 100)}%"></i><span>${esc(mnames[i])}</span></div>`).join('')}</div></section>`));
    // top artists and albums
    const ta = top(artists, 8), tal = top(albums, 8), tt = top(tracks, 10);
    const tops = h(`<div class="st-cols"><section class="st-sec"><h2>${esc($t('Исполнители'))}</h2><ol class="st-list ar"></ol></section><section class="st-sec"><h2>${esc($t('Треки'))}</h2><ol class="st-list tr"></ol></section></div>`);
    for (const a of ta) { const li = h('<li><button class="lnk"></button><span class="c num"></span></li>'); li.querySelector('button').textContent = a.name; li.querySelector('button').onclick = () => router.go('artist', a.name); li.querySelector('.c').textContent = a.n; tops.querySelector('.ar').append(li); }
    for (const t of tt) { const li = h('<li><span class="t"><b></b><small></small></span><span class="c num"></span></li>'); li.querySelector('b').textContent = t.e.ti || ''; li.querySelector('small').textContent = t.e.ar || ''; li.querySelector('.c').textContent = t.n; tops.querySelector('.tr').append(li); }
    page.append(tops);
    const alb = h(`<section class="st-sec"><h2>${esc($t('Альбомы'))}</h2><div class="st-albums"></div></section>`);
    const albumsAll = await Lib.getAllAlbums().catch(() => []);
    const rows = tal.map((x) => ({ x, a: albumsAll.find((a) => a.name === x.e.al && (a.albumArtist === (x.e.aa || x.e.ar) || a.artist === (x.e.aa || x.e.ar))) }));
    for (const { x, a } of rows) {
      const el = h('<button class="st-alb"><img alt=""><b></b><small></small></button>');
      el.querySelector('b').textContent = x.e.al; el.querySelector('small').textContent = `${x.e.aa || x.e.ar} · ${x.n}`;
      el.onclick = () => (a ? router.go('album', a) : null);
      el.dataset.p = (a && a.firstTrackAbsolutePath) || x.e.p || '';
      alb.querySelector('.st-albums').append(el);
    }
    page.append(alb);
    const paths = rows.map((r) => (r.a && r.a.firstTrackAbsolutePath) || r.x.e.p).filter(Boolean);
    if (paths.length) Lib.coversFor(paths, Math.round(140 * (window.devicePixelRatio || 1))).then((get) => alb.querySelectorAll('.st-alb').forEach((el) => { const u = get(el.dataset.p); if (u) Lib.setImg(el.querySelector('img'), u); }));
    // hours
    const hx = Math.max(1, ...hours), peak = hours.indexOf(Math.max(...hours));
    page.append(h(`<section class="st-sec"><h2>${esc($t('Когда вы слушаете'))}</h2><div class="st-hours">${hours.map((v, i) => `<i title="${i}:00 · ${v}" style="opacity:${(0.15 + 0.85 * v / hx).toFixed(2)}"></i>`).join('')}</div><div class="st-note">${esc($t('Чаще всего — около {0}:00', peak))}</div></section>`));
  }
  root.replaceChildren(page);
  // foo_playcount: counts for all time, if it is installed
  const pc = await playcountTop().catch(() => null);
  if (!pc || !pc.artists.length || router.current !== 'stats') return;
  const sec = h(`<section class="st-sec"><h2>${esc($t('За всё время'))} · foo_playcount</h2><ol class="st-list ar"></ol></section>`);
  for (const a of pc.artists) { const li = h('<li><button class="lnk"></button><span class="c num"></span></li>'); li.querySelector('button').textContent = a.name; li.querySelector('button').onclick = () => router.go('artist', a.name); li.querySelector('.c').textContent = a.n; sec.querySelector('ol').append(li); }
  page.append(sec);
}

export function init() { router.on('stats', () => render()); }
