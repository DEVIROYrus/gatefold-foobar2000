/*
 * Gatefold · import1x.js — the first start on Gatefold's own host takes along what Gatefold 1.x kept under
 * foo_ui_webview2: its settings (localStorage) and its history, lyrics and sound analysis (IndexedDB). The host
 * reads a copy of that browser profile (host.importOld); cover thumbnails stay behind (they are made again as
 * covers are shown). Only what this profile does not have yet is added — nothing here is overwritten — and the
 * page starts over once so that every module reads the settings it now has. Done once (the key below), also
 * when there was nothing to take; a failure is tried again on the next two starts.
 */
import * as IDB from './idb.js';
import { log } from './bridge.js';

const DONE = 'gatefold.import1x.v1';
const NOTE = 'gatefold.import1x.note';
const SKIP_KEYS = new Set(['aurora.update', 'gatefold.gf.write', DONE]);   // the old updater's state; this copy's own switch
const SKIP_STORES = ['thumbs'];

const unb64 = (s) => { const b = atob(s); const u = new Uint8Array(b.length); for (let i = 0; i < b.length; i++) u[i] = b.charCodeAt(i); return u; };
const TYPED = { Int8Array, Uint8Array, Uint8ClampedArray, Int16Array, Uint16Array, Int32Array, Uint32Array, Float32Array, Float64Array,
  BigInt64Array: globalThis.BigInt64Array, BigUint64Array: globalThis.BigUint64Array, DataView };
const SKIP = Symbol('skip');
const fields = (o) => { const out = {}; for (const k of Object.keys(o)) { const x = decode(o[k]); if (x !== SKIP) out[k] = x; } return out; };
/** the host's tagged values back into what IndexedDB held (host.importOld) */
export function decode(v) {
  if (v === null || typeof v !== 'object') return v;
  if (Array.isArray(v)) return v.map(decode);
  switch (v.$t) {
    case undefined: return fields(v);
    case 'obj': return fields(v.v);   // an object that had a $t of its own
    case 'undef': return undefined;
    case 'num': return Number(v.v);
    case 'big': return BigInt(v.v);
    case 'date': return new Date(v.v);
    case 'ab': return unb64(v.v).buffer;
    case 'ta': { const u = unb64(v.v); const T = TYPED[v.c] || Uint8Array; return T === DataView ? new DataView(u.buffer) : new T(u.buffer, 0, u.byteLength / (T.BYTES_PER_ELEMENT || 1)); }
    case 'map': return new Map(v.v.map(([a, b]) => [decode(a), decode(b)]));
    case 'set': return new Set(v.v.map(decode));
    case 'skip': return SKIP;
    default: return v;
  }
}

/** entries into a store where their key is free (add: an existing record makes that one fail, not the rest) */
function addAbsent(d, store, keyPath, entries) {
  return new Promise((res) => {
    let added = 0;
    try {
      const tx = d.transaction(store, 'readwrite');
      const os = tx.objectStore(store);
      for (const [k, v] of entries) {
        const value = decode(v);
        if (value === SKIP) continue;
        const rq = keyPath == null ? os.add(value, decode(k)) : os.add(value);
        rq.onsuccess = () => { added++; };
        rq.onerror = (e) => { e.preventDefault(); e.stopPropagation(); };
      }
      tx.oncomplete = () => res(added);
      tx.onerror = () => res(added);
      tx.onabort = () => res(added);
    } catch (e) { log('import 1.x: store', store, e.message); res(added); }
  });
}

const get = (k) => { try { return localStorage.getItem(k); } catch { return null; } };
const set = (k, v) => { try { localStorage.setItem(k, v); return true; } catch { return false; } };

/** true when the page is starting over with what was taken (the caller stops) */
export async function maybe() {
  const gf = window.gf;
  if (!gf || typeof gf.call !== 'function' || window.fb2k) return false;   // only on Gatefold's own host
  const done = get(DONE);
  let state = null; try { state = JSON.parse(done || 'null'); } catch {}
  if (state && (state.ok || (state.tries || 0) >= 3)) return false;
  const tries = ((state && state.tries) || 0) + 1;
  let r;
  try { r = await gf.call('host.importOld', { skipStores: SKIP_STORES }); }
  catch (e) {
    log('import from Gatefold 1.x failed:', e.code || '', e.message || e);
    set(DONE, JSON.stringify({ ok: e.code === 'UNSUPPORTED', tries, error: String(e.code || e.message || e), at: Date.now() }));
    return false;
  }
  if (!r.found) { set(DONE, JSON.stringify({ ok: true, none: true, at: Date.now() })); return false; }
  let keys = 0, entries = 0;
  for (const [k, v] of Object.entries(r.localStorage || {})) {
    if (SKIP_KEYS.has(k) || typeof v !== 'string' || get(k) !== null) continue;
    if (set(k, v)) keys++;
  }
  const d = await IDB.db();
  if (d) {
    for (const s of r.idb || []) {
      if (s.db !== 'aurora' || !d.objectStoreNames.contains(s.store) || !Array.isArray(s.entries) || !s.entries.length) continue;
      entries += await addAbsent(d, s.store, s.keyPath, s.entries);
    }
  }
  log(`import from Gatefold 1.x: ${keys} settings, ${entries} records (${Math.round((r.copiedBytes || 0) / 1048576)} MB read in ${Math.round(r.ms || 0)} ms)`);
  set(DONE, JSON.stringify({ ok: true, keys, entries, at: Date.now() }));
  if (!keys && !entries) return false;
  set(NOTE, JSON.stringify({ keys, entries }));
  location.reload();
  return true;
}

/** after the page started over: what was taken, said once */
export function announce(toast, $t) {
  const n = get(NOTE);
  if (!n) return;
  try { localStorage.removeItem(NOTE); } catch {}
  let j = {}; try { j = JSON.parse(n); } catch {}
  toast($t('Перенесено из Gatefold 1.x: настроек — {0}, записей истории и анализа — {1}', j.keys || 0, j.entries || 0), { ms: 7000 });
}
