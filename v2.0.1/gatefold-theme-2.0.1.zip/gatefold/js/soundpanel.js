/*
 * Gatefold · soundpanel.js — «Звук»: foobar2000's DSP from the player bar.
 *
 * foo_ui_webview2 lets a theme read the DSP chain and switch DSP presets, but not read or set the bands
 * of foobar2000's equalizer (its settings are private to the DSP). So the panel does what can be done
 * well today: one click between your DSP presets («Headphones», «Speakers», «Night» — saved in
 * foobar2000's DSP Manager), the chain that is playing now, and buttons that open foobar2000's own
 * equalizer and DSP Manager. Bands drawn in the theme need the component to expose DSP settings —
 * see docs/upstream/dsp-config-request.md.
 */
import { call, ok, on, esc, log } from './bridge.js';
import { h, icon, toast } from './ui.js';
import { $t } from './i18n.js';
import { settings } from './settings.js';
import * as Loud from './loudness.js';
import * as Eq from './eq.js';

const EQ = /equali[sz]er|эквалайзер|entzerrer|ecualizador|égaliseur|均衡/i;
const DSPM = /^dsp/i, PREFS = /pref|настро|einstell|config|ajust|параметр|设置|首选/i;
let pop = null, btn = null, menuCache = null;

/** the player-bar button: lit while a DSP chain is active */
export function init(button) {
  btn = button;
  btn.addEventListener('click', (e) => { e.stopPropagation(); if (pop) close(); else open(); });
  on('audio:dspPresetChanged', () => { paintButton(); if (pop) render(); });
  Loud.events.addEventListener('change', () => { const el = pop && pop.querySelector('.snd-lvl-st'); if (el) el.textContent = levelStatus(); });
  Eq.events.addEventListener('change', () => { paintButton(); const c = pop && pop.querySelector('.snd-eq canvas'); if (c) Eq.drawMini(c); });
  paintButton();
}
async function state() {
  const [c, p] = await Promise.all([call('dsp.getChain'), call('dsp.getPresets')]);
  return {
    ok: ok(c) || ok(p),
    chain: ok(c) ? c.dsps || [] : [],
    active: ok(c) ? c.activePreset : null,
    presets: ok(p) ? p.presets || [] : [],
    selected: ok(p) ? p.selectedIndex : -1,
  };
}
async function paintButton() {
  if (!btn) return;
  const s = await state();
  const eq = Eq.state();
  btn.classList.toggle('on', s.chain.some((d) => !/gatefold equalizer/i.test(d.name)) || !!settings.level || !!(eq && eq.enabled));
  const what = s.active || (s.chain.length ? s.chain.map((d) => d.name).join(' → ') : $t('без обработки'));
  btn.dataset.tip = `${$t('Звук')}: ${what}`;
  btn.setAttribute('aria-label', btn.dataset.tip);
}

export async function open() {
  close();
  if (Eq.available() && !Eq.state()) await Eq.load();
  pop = h(`<div class="menu snd-pop" role="dialog" aria-label="${$t('Звук')}"><div class="snd-body"><div class="spinner"></div></div></div>`);
  document.getElementById('layer').append(pop);
  place();
  setTimeout(() => { addEventListener('mousedown', outside, true); addEventListener('keydown', esc_, true); }, 0);
  await render();
}
export function close() {
  if (!pop) return;
  pop.remove(); pop = null;
  removeEventListener('mousedown', outside, true); removeEventListener('keydown', esc_, true);
}
const outside = (e) => { if (pop && !pop.contains(e.target) && !btn.contains(e.target)) close(); };
const esc_ = (e) => { if (e.key === 'Escape' && pop) { e.stopPropagation(); e.preventDefault(); close(); } };
function place() {
  const r = btn.getBoundingClientRect(), w = pop.offsetWidth, hh = pop.offsetHeight;
  pop.style.left = Math.max(8, Math.min(innerWidth - w - 8, r.right - w)) + 'px';
  pop.style.top = Math.max(8, r.top - hh - 8) + 'px';
}

async function render() {
  if (!pop) return;
  const s = await state();
  if (!pop) return;
  const body = pop.querySelector('.snd-body');
  if (!s.ok) { body.innerHTML = `<div class="snd-h">${$t('Звук')}</div><div class="snd-empty">${$t('DSP недоступен в этой версии компонента')}</div>`; place(); return; }
  const presets = s.presets.length
    ? s.presets.map((p) => `<button class="mi snd-p${p.active || p.index === s.selected ? ' on' : ''}" data-i="${p.index}" role="menuitemradio" aria-checked="${!!(p.active || p.index === s.selected)}"><span class="chk">${p.active || p.index === s.selected ? '✓' : ''}</span><span>${esc(p.name)}</span></button>`).join('')
    : `<div class="snd-empty">${$t('Пресетов пока нет. Соберите цепочку в менеджере DSP foobar2000 и сохраните её как пресет — он появится здесь.')}</div>`;
  const chain = s.chain.length
    ? `<div class="snd-chain">${s.chain.map((d) => `<span class="chip">${esc(d.name)}</span>`).join('<span class="snd-arr">→</span>')}</div>`
    : `<div class="snd-empty">${$t('Цепочка пуста — звук идёт без обработки')}</div>`;
  body.innerHTML = `
    <div class="snd-h">${$t('Звук')}${s.active ? '' : s.chain.length ? `<small>${$t('своя цепочка')}</small>` : ''}</div>
    ${Eq.available() ? Eq.panelHtml() : ''}
    ${levelHtml()}
    <div class="snd-sec">${$t('Пресет DSP')}</div>${presets}
    <div class="snd-sec">${$t('Сейчас играет через')}</div>${chain}
    <div class="ms"></div>
    ${Eq.available() ? '' : `<button class="mi" data-act="eq">${icon('sliders', 15)}<span>${$t('Эквалайзер foobar2000…')}</span></button>`}
    <button class="mi" data-act="dsp">${icon('gear', 15)}<span>${$t('Менеджер DSP…')}</span></button>`;
  body.querySelectorAll('.snd-p').forEach((b) => {
    b.onclick = async () => {
      const r = await call('dsp.applyPreset', { index: +b.dataset.i });
      if (!ok(r)) { toast(esc(r.error || $t('Не удалось включить пресет'))); return; }
      // the tick in the panel says it; no toast under the panel
      render(); paintButton();
    };
  });
  wireLevel(body);
  Eq.wirePanel(body, close);
  const eqb = body.querySelector('[data-act=eq]');
  if (eqb) eqb.onclick = () => { close(); openEqualizer(); };
  body.querySelector('[data-act=dsp]').onclick = () => { close(); openDspManager(); };
  place();
}

/* foobar2000's own windows, found in its main menu by name (the GUIDs differ between versions and
   components; the labels are matched in several languages) */
async function commands() {
  if (menuCache) return menuCache;
  const r = await call('menu.getMainMenu', { withAvailability: false });
  const out = [];
  const walk = (items, trail) => { for (const it of items || []) { if (it.type === 'submenu') walk(it.children, [...trail, it.label || '']); else if (it.type === 'command') out.push({ ...it, trail }); } };
  if (ok(r)) walk(r.items, []);
  return (menuCache = out);
}
async function run(cmd) {
  const r = cmd.guid ? await call('menu.runMainMenuCommand', { command: cmd.guid, ...(cmd.subGuid ? { subGuid: cmd.subGuid } : {}) }) : await call('menu.runMainMenuCommand', { command: cmd.path });
  return ok(r);
}
export async function openEqualizer() {
  const list = await commands();
  const eq = list.find((c) => EQ.test(c.label || '') || EQ.test(c.displayLabel || ''));
  if (eq && (await run(eq))) return;
  log('sound: no equalizer command in the main menu');
  toast($t('В меню foobar2000 нет команды эквалайзера — открываю менеджер DSP: добавьте «Equalizer» в цепочку и настройте его там.'), { ms: 8000 });
  openDspManager();
}
export async function openDspManager() {
  const list = await commands();
  const m = list.find((c) => c.trail.some((t) => DSPM.test(t)) && PREFS.test(c.label || ''));
  if (m && (await run(m))) return;
  call('misc.showPreferences');
}

/* ---- volume levelling (loudness.js): the switch, how, and the target — the same as in Settings */
const MODE_LABEL = () => [['album', $t('Альбомами')], ['auto', $t('Умно')], ['track', $t('По трекам')]];
const MODE_TIP = () => ({
  album: $t('Альбомы звучат одинаково громко, а тихие и громкие треки внутри альбома остаются такими, как их задумал артист'),
  auto: $t('Альбомами, когда альбом играет по порядку; по трекам — в случайном порядке'),
  track: $t('Каждый трек отдельно: ровно для сборников, но тихие интерлюдии станут такими же громкими, как всё остальное'),
});
const TARGET_TIP = () => ({ [-18]: $t('−18 LUFS — стандарт ReplayGain'), [-16]: $t('−16 LUFS — как Apple Music'), [-14]: $t('−14 LUFS — как Spotify и YouTube'), [-23]: $t('−23 LUFS — как радио и ТВ') });
function levelStatus() {
  const st = Loud.state;
  if (!settings.level) return $t('Выключено: громкость как в файлах');
  if (!settings.levelScan || st.phase === 'done') return $t('Включено — меняется сразу, без смены трека');
  if (st.phase === 'running' || st.phase === 'paused') return $t('Анализ: {0} из {1} альбомов без меток', (st.albumsDone || 0).toLocaleString(), (st.albums || 0).toLocaleString());
  return $t('Включено — меняется сразу, без смены трека');
}
function levelHtml() {
  const on = !!settings.level, mode = settings.levelMode || 'album', tgt = +settings.levelTarget || -18;
  const tips = MODE_TIP(), tt = TARGET_TIP();
  return `<div class="snd-lvl${on ? ' on' : ''}">
    <div class="snd-row"><div class="snd-lbl"><b>${$t('Выравнивание громкости')}</b><small class="snd-lvl-st">${esc(levelStatus())}</small></div>
      <label class="toggle"><input type="checkbox" class="snd-lvl-on"${on ? ' checked' : ''} aria-label="${$t('Выравнивать громкость')}"><i></i></label></div>
    <div class="snd-lvl-more">
      <div class="seg snd-seg">${MODE_LABEL().map(([v, t]) => `<button data-mode="${v}" title="${esc(tips[v])}"${v === mode ? ' class="on"' : ''}>${t}</button>`).join('')}</div>
      <div class="snd-tgt"><span>${$t('Цель')}</span>${Loud.TARGETS.slice().sort((a, b) => a - b).map((v) => `<button data-tgt="${v}" title="${esc(tt[v])}"${v === tgt ? ' class="on"' : ''}>${String(v).replace('-', '−')}</button>`).join('')}<span class="dim">LUFS</span></div>
    </div></div>`;
}
function wireLevel(body) {
  const box = body.querySelector('.snd-lvl');
  if (!box) return;
  const sw = box.querySelector('.snd-lvl-on');
  sw.onchange = async () => {
    sw.disabled = true;
    const done = sw.checked ? await Loud.enable() : (await Loud.disable(), true);
    if (sw.checked && !done) toast($t('foobar2000 не принял настройки ReplayGain'));
    sw.disabled = false;
    box.classList.toggle('on', !!settings.level);
    sw.checked = !!settings.level;
    box.querySelector('.snd-lvl-st').textContent = levelStatus();
    paintButton();
  };
  box.querySelectorAll('[data-mode]').forEach((b) => { b.onclick = () => { box.querySelectorAll('[data-mode]').forEach((x) => x.classList.toggle('on', x === b)); Loud.setMode(b.dataset.mode); }; });
  box.querySelectorAll('[data-tgt]').forEach((b) => { b.onclick = () => { box.querySelectorAll('[data-tgt]').forEach((x) => x.classList.toggle('on', x === b)); Loud.setTarget(+b.dataset.tgt); }; });
}
