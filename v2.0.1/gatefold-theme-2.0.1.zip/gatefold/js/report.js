/*
 * Gatefold · report.js — «Сообщить о проблеме»: versions, settings and the last lines of the log as
 * text to paste into a GitHub issue. Nothing is sent anywhere by the theme: you copy it yourself.
 * Keys and other private values (the YouTube API key, folder names) are left out.
 */
import { call, ok, logLines, esc } from './bridge.js';
import { h, icon, toast } from './ui.js';
import { settings } from './settings.js';
import { $t, lang } from './i18n.js';
import { VERSION } from './version.js';

const PRIVATE = /key|token|folder|dir|path|pattern|custom/i;

export async function build() {
  const v = await call('config.getVersionInfo');
  const lib = await call('config.getLibraryStatus');
  const safe = Object.fromEntries(Object.entries(settings).filter(([k]) => !PRIVATE.test(k)).map(([k, val]) => [k, typeof val === 'object' ? JSON.stringify(val) : val]));
  const lines = [
    `Gatefold ${VERSION}`,
    `foobar2000: ${ok(v) ? `${v.version} ${v.is64bit === false ? '32-bit' : '64-bit'}${v.isPortable ? ', portable' : ''}` : '?'}`,
    `foo_ui_webview2: ${ok(v) && v.plugin ? v.plugin.version : '?'}`,
    `WebView2: ${(navigator.userAgent.match(/Edg\/([\d.]+)/) || [])[1] || navigator.userAgent}`,
    `Screen: ${screen.width}×${screen.height} @${window.devicePixelRatio}x, window ${innerWidth}×${innerHeight}`,
    `Language: ${lang}, CPU threads: ${navigator.hardwareConcurrency || '?'}`,
    `Library: ${ok(lib) ? `${lib.enabled ? 'on' : 'off'}, ${lib.itemCount || 0} tracks` : '?'}`,
    '',
    '<details><summary>Settings</summary>',
    '',
    '```',
    ...Object.entries(safe).map(([k, val]) => `${k}: ${val}`),
    '```',
    '</details>',
    '',
    '<details><summary>Log</summary>',
    '',
    '```',
    ...logLines.slice(-80),
    '```',
    '</details>',
  ];
  return lines.join('\n');
}

export async function open() {
  const text = await build();
  const veil = h(`<div class="su-veil rp-veil" role="dialog" aria-modal="true" aria-labelledby="rpTitle"><div class="su-card rp-card">
    <h1 id="rpTitle">${esc($t('Сообщить о проблеме'))}</h1>
    <p class="su-lead">${esc($t('Опишите, что случилось, и вставьте этот текст в сообщение. Тема ничего не отправляет сама; ключи и пути к папкам сюда не попадают.'))}</p>
    <textarea class="st-input rp-text" spellcheck="false" readonly></textarea>
    <div class="su-foot"><button class="btn" data-rp="close">${esc($t('Закрыть'))}</button><span style="flex:1"></span>
      <button class="btn" data-rp="issue">${icon('link')}${esc($t('Открыть страницу проблем'))}</button>
      <button class="hm-btn primary" data-rp="copy"><span>${esc($t('Скопировать'))}</span></button></div>
  </div></div>`);
  const ta = veil.querySelector('textarea'); ta.value = text;
  ta.addEventListener('keydown', (e) => e.stopPropagation());
  const close = () => { veil.classList.remove('on'); setTimeout(() => veil.remove(), 200); };
  veil.querySelector('[data-rp=close]').onclick = close;
  veil.addEventListener('keydown', (e) => { if (e.key === 'Escape') close(); });
  veil.querySelector('[data-rp=copy]').onclick = async () => {
    try { await navigator.clipboard.writeText(text); } catch { ta.select(); document.execCommand('copy'); }
    toast($t('Скопировано'));
  };
  veil.querySelector('[data-rp=issue]').onclick = () => call('shell.openExternal', { url: 'https://github.com/DEVIROYrus/gatefold-foobar2000/issues/new' });
  document.body.append(veil);
  requestAnimationFrame(() => veil.classList.add('on'));
}
