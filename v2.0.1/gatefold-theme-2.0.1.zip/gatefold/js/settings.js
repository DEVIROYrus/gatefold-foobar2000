/* Gatefold · settings.js — persistent settings (WebView2 profile localStorage) */
const KEY = 'aurora.settings.v1';

export const DEFAULTS = {
  // appearance
  updateCheck: true,
  updateChannel: '',       // '' (stable for releases, beta for beta builds) | 'stable' | 'beta' (updater.js)       // look for a new Gatefold release on GitHub (at most every 12 h)
  taskbarButtons: true,    // ⏮ ⏯ ⏭ ♡ on the taskbar thumbnail (wininteg.js)
  taskbarProgress: true,   // playback progress drawn on the taskbar button
  trayIcon: false,         // an icon in the notification area with a player menu
  minimizeToTray: false,   // only with trayIcon
  closeToTray: false,      // only with trayIcon
  miniTopmost: true,       // the mini player stays above other windows (mini.js)
  language: 'auto',        // 'auto' (system) | 'ru' | 'en' — read by i18n.js before anything renders
  ytSearch: 'off',         // YouTube search: 'off' (links only) | 'api' (YouTube Data API v3, own key) | 'web' (unofficial, parses the results page)
  ytApiKey: '',
  colorSource: 'album',     // 'album' (colours of the playing cover) | fixed themes: 'dark' | 'light' | 'gray'
  themeMode: 'auto',        // 'auto' (follows cover lightness) | 'dark' | 'light'
  colorIntensity: 1,        // 0.4 … 1.5 — chroma multiplier for derived colours
  fontMode: 'hybrid',       // 'hybrid' (Segoe UI Variable text + Inter display) | 'inter' | 'system'
  baseSize: 14,             // integer px — integer sizes keep hinting on the pixel grid (1.4; 2.0 reads baseSize2 under this name)
  baseSize2: 14,            // 2.0: text size before the interface scale; 1.4's own baseSize stays for a rollback
  uiScale: 'auto',          // 2.0: 'auto' (fits the window: a bigger window, a bigger interface) | 0.9 … 1.5 — the WebView zoom
  crispText: true,          // opaque list panels → ClearType-quality text
  ambient: true,            // cover-derived aurora background
  ambientMotion: true,      // slow drift of the aurora blobs (compositor-only)
  beatReact: true,          // cover breathes with the bass
  visualizer: true,         // spectrum on the Now Playing screen
  spectrumStyle: 'bars',
  seekStyle: 'bars',        // the seek bar under the player: bars | peaks | smooth | dots | live | line (seekstyles.js)    // its look: bars | wave | line | dots | mirror | aurora (spectra.js)
  vuMeters: false,          // two VU meters instead of the spectrum (vu.js) — off unless turned on
  vuStyle: 'classic',       // 'classic' (ivory dial) | 'album' (the album's colours)
  vuLayout: 'pair',         // 'pair' (a meter per channel) | 'stereo' (one dial, two needles)
  vuCanvas: true,           // the meters in the Canvas too
  vuCal: 'auto',            // 0 VU: 'auto' (from the playing album's loudness) | dBFS of a sine: -18 (studio) | -14 | -10 (loud masters)
  waveformSeek: true,       // waveform seek bar coloured by the palette
  transitionMs: 1100,       // palette crossfade duration
  frameless: true,          // draw own title bar (standalone mode only)
  backdrop: 'none',         // 'none' | 'mica' — window material behind the UI
  sidebarCollapsed: false,
  // behaviour
  albumTarget: 'dedicated', // 'dedicated' (playlist "Gatefold") | 'active'
  librarySort: 'artist',
  startView: 'now',        // 1.4's start screen, kept as it was so going back to 1.4 still works
  start2: 'home',          // 2.0's start screen (2.0 knows screens 1.4 does not)
  onlineInfo: true,
  youtubeMenu: false,
  v2: 1,                   // settings seen by 2.0 (1.4 settings are taken over once, see load())
  mixDaily: true,
  showAdvanced: false,     // Settings: rare sections (Canvas, foobar2000, storage) shown          // mood playlists made by Gatefold get new tracks once a day (sound-ui.js)      // YouTube in the menu (2.0: off unless chosen in the first-run window or Settings)        // artist descriptions and related artists from the web (artistinfo.js)
  // cover fetcher
  coverAuto: true,          // fetch for the playing album when it has no art
  coverSweep: true,         // background sweep over the whole library
  coverMinSize: 600,        // reject images smaller than this (px, shortest side)
  coverMaxSize: 3000,       // downscale anything larger (0 = keep original)
  coverTarget: 'file',      // 'file' (cover.jpg next to tracks) | 'all' (file + embed into first track)
  coverThreshold: 0.82,     // auto-accept score; below → review queue
  coverSources: { itunes: true, deezer: true, musicbrainz: true },
  coverCountries: 'US,RU',
  coverSharedDir: 'embed',  // folder shared by several albums: 'embed' into that album's tracks | 'skip'
  // artist photos
  artistGuests: false,      // Artists also lists those with no album of their own (guests, compilation singers)
  artistAuto: true,         // download missing artist photos into %profile%\\aurora\\artists
  artistSort: 'name',
  // fun mode («экспериментальные функции»): its own data lives under aurora.fun.* and is wiped when off
  funMode: false,
  // cover quality
  qualityMinRes: 600,       // shortest side below this → "low resolution"
  qualityMinJpegQ: 55,      // estimated JPEG quality below this → "heavily compressed"
  qualityAuto: 'same',      // auto-replace only when the new image matches the old one visually: 'same' | 'never'
  // thumbnails
  thumbCache: true,         // persistent cover thumbnails (IndexedDB)
  thumbCacheMB: 400,
  // lyrics
  lyricsOnline: true,
  // LRCLIB is an open database; the others are reached through unofficial client APIs — off until the user opts in
  lyricsSources: { lrclib: true, musixmatch: false, netease: false, qq: false, kugou: false },       // LRCLIB when the track has no synced lyrics
  lyricsSave: 'none',       // what to do with downloaded lyrics: 'none' (Gatefold cache only) | 'file' (.lrc beside the track) | 'embedded'
  lyricsSize: 'm',          // 's' | 'm' | 'l'
  // canvas (fullscreen)
  tracksSort: 'artist',     // Library → Tracks: 'artist' | 'title' | 'album' | 'year' | 'genre' | 'duration' | 'added' | 'played' | 'plays'
  tracksDir: 1,             //   1 or -1 (the other way round)
  canvasLayout: 'cover',    // 'cover' | 'lyrics' | 'minimal'
  canvasMotion: true,       // slow Ken Burns drift of the cover
  canvasLyrics: true,
  canvasClock: false,
  canvasIdleMin: 5,         // enter Canvas after N idle minutes while playing and focused (0 = off)
  soundAI: false,          // sound analysis with a neural network (ml/sound.js): models downloaded on request
  soundPaused: false,
  soundGenresOnline: true,  // genres of artists and albums from MusicBrainz (ml/genres.js), only with soundAI on
  soundSpeed: 'normal',     // 'gentle' | 'normal' | 'fast' | 'max' — how hard the analysis may work (ml/sound.js)
  motionFps: 'max',         // 'max': animations at the monitor's refresh rate | 'eco': spectrum ≤ 60 fps, background 12 fps
  plViewDefault: 'auto',   // playlist view when the playlist has none of its own: auto | albums | covers | grid | compact
  fullscreenTopmost: false, // true: fullscreen stays above every other window (the component's default)
  coverPickTarget: 'gatefold', // the cover picker: where the last picture went ('gatefold' | 'embedded' | 'file')
  coverPickName: 'cover',   //   … and the file name, for 'file'
  coverPickDir: '',         //   … and the folder the file dialog opened last
  coverPattern: '',         // your covers by a path rule in title formatting, e.g. D:\Covers\%album artist% - %album%
  libMode: 'albums',        // Library: 'albums' (the grid) | 'folders' (folders.js)
  libFolder: '',            //   … the folder shown last ('' = where the tree starts)
  folderExtras: false,      //   … also list files of a folder that the library does not have
  splitEditions: true,      // one title by one artist in two releases (2014 and its 2016 reissue) is two albums
  artistSplit: [';'],       // separators that make one name several artists (also: '/', ',', '&', 'feat')
  artistKeep: [],           // names never split (AC/DC, Earth, Wind & Fire)
  albumColors: {},          // your colours of an album: key → { accent, glow }
  customTheme: null,        // «Своя тема»: { accent, bg, surface, text } or null
  albumDetails: false,      // album page: the details card and the extra columns (album-details.js)
  level: false,             // volume levelling (loudness.js): foobar2000's ReplayGain, set up and fed by Gatefold
  levelMode: 'album',       // 'album' (whole albums) | 'auto' (albums unless shuffling) | 'track'
  eqPresets: [],           // the equalizer's own presets: [{ name, mode, graphic, bands, preamp }] (eq.js)
  levelTarget: -18,         // target loudness, LUFS: -18 (ReplayGain 2.0) | -16 | -14 | -23
  levelScan: true,          // measure tracks without ReplayGain values and write the tags
  levelPaused: false,
};

let state = load();
const subs = new Set();

function load() {
  try {
    const raw = JSON.parse(localStorage.getItem(KEY) || '{}');
    if (raw.canvasLayout && !['cover', 'lyrics', 'minimal'].includes(raw.canvasLayout)) delete raw.canvasLayout;   // a layout that is gone (the visualiser)
    // an early 2.0 build stored «home» where 1.4 reads its start screen: 1.4 must still open
    if (raw.startView === 'home') { raw.startView = 'now'; raw.start2 = raw.start2 || 'home'; try { localStorage.setItem(KEY, JSON.stringify({ ...DEFAULTS, ...raw })); } catch {} }
    // settings saved by 1.4 (the same storage): YouTube stays in the menu for those who used it
    if (Object.keys(raw).length && !raw.v2) {
      raw.v2 = 1;
      if (raw.youtubeMenu === undefined) { let yt = raw.ytSearch && raw.ytSearch !== 'off'; try { yt = yt || Object.keys(localStorage).some((k) => k.startsWith('aurora.yt.')); } catch {} raw.youtubeMenu = !!yt; }
      try { localStorage.setItem(KEY, JSON.stringify({ ...DEFAULTS, ...raw })); } catch {}
    }
    return { ...DEFAULTS, ...raw, coverSources: { ...DEFAULTS.coverSources, ...(raw.coverSources || {}) }, lyricsSources: { ...DEFAULTS.lyricsSources, ...(raw.lyricsSources || {}) } };
  } catch { return { ...DEFAULTS }; }
}

// 2.0 keeps its text size apart from 1.4's (both share the storage): code asks for baseSize and gets 2.0's
const ALIAS = { baseSize: 'baseSize2' };
export const settings = new Proxy({}, { get: (_, k) => state[ALIAS[k] || k] });

export const allSettings = () => state;

export function setSetting(key, value) {
  const sk = ALIAS[key] || key;
  if (state[sk] === value) return;
  state = { ...state, [sk]: value };
  try { localStorage.setItem(KEY, JSON.stringify(state)); } catch {}
  for (const fn of subs) fn(key, value, state);
}

export function onSettings(fn) { subs.add(fn); return () => subs.delete(fn); }

/* Another Gatefold window (the Canvas popup) changed a setting → apply it here too. */
window.addEventListener('storage', (e) => {
  if (e.key !== KEY) return;
  const prev = state; state = load();
  for (const k of Object.keys(state)) if (JSON.stringify(prev[k]) !== JSON.stringify(state[k])) for (const fn of subs) fn(k === 'baseSize2' ? 'baseSize' : k, state[k], state);
});

export function resetSettings() {
  state = { ...DEFAULTS };
  try { localStorage.setItem(KEY, JSON.stringify(state)); } catch {}
  for (const fn of subs) fn('*', null, state);
}

const stores = new Set();
addEventListener('pagehide', () => { for (const st of stores) if (st._save) st.flush(); });

/** Small LRU-ish JSON store on localStorage, used for palette + cover caches. */
export class JsonStore {
  constructor(key, max = 800) { this.key = key; this.max = max; this.data = {}; this.order = [];
    try { const r = JSON.parse(localStorage.getItem(key) || '{}'); this.data = r.d || {}; this.order = r.o || Object.keys(this.data); } catch {}
    this._save = null;
  }
  get(k) { return this.data[k]; }
  set(k, v) {
    if (!(k in this.data)) this.order.push(k);
    this.data[k] = v;
    if (this.holes > 64) this.compact();
    while (this.order.length > this.max) delete this.data[this.order.shift()];
    this.persist();
  }
  delete(k) { if (!(k in this.data)) return; delete this.data[k]; this.holes = (this.holes || 0) + 1; this.persist(); } // order is compacted lazily: deleting in a loop stays O(n)
  /* localStorage is synchronous: serialising a 2000-entry store on every change
     during a scan stalled the page. Writes are coalesced (2 s), done in idle time,
     and flushed when the page goes away. */
  persist() {
    if (this._save) return;
    stores.add(this);
    this._save = setTimeout(() => {
      const run = () => this.flush();
      if (window.requestIdleCallback) requestIdleCallback(run, { timeout: 3000 }); else run();
    }, 2000);
  }
  compact() { const seen = new Set(); this.order = this.order.filter((x) => x in this.data && !seen.has(x) && seen.add(x)); this.holes = 0; }
  flush() {
    clearTimeout(this._save); this._save = null;
    if (this.holes) this.compact();
    try { localStorage.setItem(this.key, JSON.stringify({ d: this.data, o: this.order })); } catch {}
  }
}

/* ready-made sets: how much moves on screen and how much works in the background */
export const PRESETS = {
  calm: { ambient: true, ambientMotion: false, beatReact: false, visualizer: false, vuMeters: false, canvasMotion: false, motionFps: 'max', coverSweep: true, artistAuto: true },
  full: { ambient: true, ambientMotion: true, beatReact: true, visualizer: true, canvasMotion: true, canvasLyrics: true, motionFps: 'max', coverSweep: true, artistAuto: true },
  eco: { ambient: false, ambientMotion: false, beatReact: false, visualizer: false, vuMeters: false, canvasMotion: false, motionFps: 'eco', coverSweep: false, artistAuto: false },
};

