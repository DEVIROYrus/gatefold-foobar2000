/*
 * Gatefold · boot.js — the page's entry: which host is this?
 *
 *  foo_gatefold (window.gf)        → the app (app.js)
 *  foo_ui_webview2 (window.fb2k)   → Gatefold 1.x's host: 1.4's own update has just written 2.0 here. 2.0 lives in
 *                                    its own component, so this page is the one-button step to it (upgrade.js)
 *                                    (the tests' mock of foo_ui_webview2, fb2k.__mock, runs the app)
 *  neither within 3 s              → the app, which shows its own «no host» state (a browser preview)
 */
const t0 = performance.now();
(function wait() {
  if (window.gf && typeof window.gf.call === 'function' && !window.fb2k) { import('./app.js'); return; }
  if (window.fb2k && typeof window.fb2k.invoke === 'function') { import(window.fb2k.__mock ? './app.js' : './upgrade.js'); return; }
  if (performance.now() - t0 > 3000) { import('./app.js'); return; }
  setTimeout(wait, 10);
})();
