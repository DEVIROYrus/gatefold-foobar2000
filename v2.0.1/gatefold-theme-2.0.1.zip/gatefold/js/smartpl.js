/*
 * Gatefold · smartpl.js — smart playlists without the query language.
 *
 * foobar2000's autoplaylists are a library query kept live: new tracks that match appear by
 * themselves. Their syntax is powerful and nobody knows it, so Gatefold offers ready recipes
 * («recently added», «most played», «forgotten favourites», a genre, a decade, lossless, hi-res…),
 * each with one simple parameter, shows how many tracks match right now, and creates the
 * autoplaylist. «Your own query» is there for those who do know the syntax.
 * Play statistics (%added%, %play_count%, %last_played%, %rating%) come from foo_playcount.
 * «By sound» recipes use the neural sound analysis (ml/sound.js): moods and Discogs styles are not
 * tags foobar2000 can query, so those playlists are made once, from the analysis, not kept live.
 */
import { call, ok, esc, debounce, plural } from './bridge.js';
import { router, h, icon, toast } from './ui.js';
import { $t } from './i18n.js';
import * as Sound from './ml/sound.js';
import * as SoundUI from './ml/sound-ui.js';

const ALBUM_ORDER = '%album artist% | %date% | %album% | %discnumber% | %tracknumber%';
const q = (s) => '"' + String(s).replace(/"/g, '') + '"';
const DECADES = [1950, 1960, 1970, 1980, 1990, 2000, 2010, 2020];

/* every recipe: query(param) → { query, sort } — `sort` may be a SORT clause (tried first) */
const RECIPES = [
  { id: 'recent', g: 'listen', ic: 'inbox', stats: true, title: $t('Недавно добавленные'), desc: '' /* Новое в медиатеке, свежее сверху */,
    param: { kind: 'seg', label: $t('Период'), def: 30, opts: [[7, $t('7 дней')], [30, $t('30 дней')], [90, $t('3 месяца')]] },
    name: (n) => $t('Новое за {0} дн.', n), make: (n) => ({ query: `%added% DURING LAST ${n} DAYS`, sortDesc: '%added%' }) },
  { id: 'top', g: 'listen', ic: 'heart-f', stats: true, title: $t('Самое любимое'), desc: '' /* Чаще всего слушаете — по числу прослушиваний */,
    param: { kind: 'seg', label: $t('Сколько раз слушали'), def: 10, opts: [[5, $t('от 5 раз')], [10, $t('от 10')], [25, $t('от 25')]] },
    name: () => $t('Самое любимое'), make: (n) => ({ query: `%play_count% GREATER ${n - 1}`, sortDesc: '%play_count%' }) },
  { id: 'forgot', g: 'listen', ic: 'history', stats: true, title: $t('Забытые любимцы'), desc: '' /* Слушали много раз, но не включали полгода */,
    name: () => $t('Забытые любимцы'), make: () => ({ query: '%play_count% GREATER 4 AND NOT %last_played% DURING LAST 26 WEEKS', sort: '%last_played%' }) },
  { id: 'never', g: 'listen', ic: 'unheard', stats: true, title: $t('Ни разу не слушал'), desc: '' /* Всё, что лежит в медиатеке нетронутым */,
    name: () => $t('Ещё не слушал'), make: () => ({ query: 'NOT %play_count% GREATER 0', sort: ALBUM_ORDER }) },
  { id: 'rated', g: 'listen', ic: 'star', stats: true, title: $t('Высокая оценка'), desc: '' /* Оценка 4 и 5 звёзд */,
    name: () => $t('Высокая оценка'), make: () => ({ query: '%rating% GREATER 3', sortDesc: '%rating%' }) },
  { id: 'genre', g: 'tags', ic: 'tag', title: $t('Жанры'), desc: '' /* Один или несколько жанров из вашей медиатеки */,
    param: { kind: 'genre', label: $t('Жанры — можно несколько') }, name: (v) => genresName(v && v.list) || $t('Жанр'), make: (v) => genreQuery(v) },
  { id: 'decade', g: 'tags', ic: 'calendar', title: $t('Десятилетие'), desc: '' /* Музыка одного десятилетия по дате релиза */,
    param: { kind: 'seg', label: $t('Десятилетие'), def: 1990, opts: DECADES.map((d) => [d, `${String(d).slice(2)}-е`]) },
    name: (d) => $t('{0}-е', d), make: (d) => ({ query: `%date% GREATER ${d - 1} AND %date% LESS ${d + 10}`, sort: '%date% | ' + ALBUM_ORDER }) },
  { id: 'lossless', g: 'tags', ic: 'wave', title: $t('Без потерь'), desc: '' /* FLAC, ALAC, WavPack, APE, WAV… */,
    name: () => $t('Без потерь'), make: () => ({ query: '%__encoding% IS lossless', sort: ALBUM_ORDER }) },
  { id: 'hires', g: 'tags', ic: 'hd', title: 'Hi-Res', desc: '' /* Выше 48 кГц или глубже 16 бит */,
    name: () => 'Hi-Res', make: () => ({ query: '%samplerate% GREATER 48000 OR %__bitspersample% GREATER 16', sort: ALBUM_ORDER }) },
  { id: 'long', g: 'tags', ic: 'hourglass', title: $t('Длинные треки'), desc: '' /* Дольше 10 минут: сюиты, миксы, эпики */,
    name: () => $t('Длинные треки'), make: () => ({ query: '%length_seconds% GREATER 599', sort: ALBUM_ORDER }) },
  { id: 'rules', g: 'tags', ic: 'sliders', title: $t('Свои правила'), desc: '' /* Несколько условий без языка запросов */,
    param: { kind: 'rules', label: $t('Треки, у которых') }, name: () => $t('Умный плейлист'), make: (v) => rulesQuery(v) },
  { id: 'custom', g: 'tags', ic: 'code', title: $t('Свой запрос'), desc: '' /* Язык запросов foobar2000 — для тех, кто его знает */,
    param: { kind: 'text', label: $t('Запрос foobar2000') }, name: () => $t('Умный плейлист'), make: (s) => (s && s.trim() ? { query: s.trim() } : null) },
];
const MOOD_IC = { calm: 'moon', energy: 'bolt', sad: 'rain', happy: 'sun', party: 'party', instrumental: 'piano', acoustic: 'guitar' };
const SIZE = { kind: 'seg', label: $t('Треков в плейлисте'), def: 50, opts: [[25, '25'], [50, '50'], [100, '100']] };
const AI = [
  ...SoundUI.MOOD_RECIPES().map(([k, title, desc]) => ({ id: 'ai-' + k, g: 'ai', ai: true, ic: MOOD_IC[k] || 'sparkle', tone: k, title, desc, param: SIZE, name: () => title, make: (n) => ({ ai: k, n }) })),
  { id: 'ai-style', g: 'ai', ai: true, ic: 'radar', tone: 'style', title: $t('Жанр по звучанию'), desc: '' /* Жанры MusicBrainz и нейросети — и для треков без тегов */,
    param: { kind: 'style', label: $t('Жанры — можно несколько') }, name: (v) => genresName(v) || $t('Жанр'), make: (v) => (v && v.length ? { ai: 'style', style: v.join('|'), n: 100 } : null) },
];
RECIPES.push(...AI);
const GROUPS = [['listen', $t('По прослушиваниям')], ['tags', $t('По тегам')], ['ai', $t('По звучанию')]];

/* ---- genres: one or several at once («Thrash Metal + Death Metal»), exactly these or with their sub-genres */
function genresName(list) {
  const l = list || [];
  if (!l.length) return '';
  if (l.length <= 3) return l.join(' + ');
  return $t('{0}, {1} и ещё {2}', l[0], l[1], l.length - 2);
}
export function genreQuery(v) {
  const l = (v && v.list) || [];
  if (!l.length) return null;
  const one = (g) => (v.sub ? `genre HAS ${q(g)}` : `genre IS ${q(g)}`);
  return { query: l.length > 1 ? l.map((g) => `(${one(g)})`).join(' OR ') : one(l[0]), sort: ALBUM_ORDER };
}
/* a searchable list to tick genres in; the ticked ones stay on top as chips */
function genrePicker(all, picked, onChange, empty) {
  const box = h(`<div class="sp-gpick"><div class="sp-gsel"></div><input class="st-input sp-gfind" spellcheck="false" placeholder="${esc($t('Найти жанр…'))}" aria-label="${esc($t('Найти жанр…'))}"><div class="sp-glist" role="listbox" aria-multiselectable="true"></div></div>`);
  const sel = box.querySelector('.sp-gsel'), find = box.querySelector('.sp-gfind'), list = box.querySelector('.sp-glist');
  const draw = () => {
    sel.innerHTML = '';
    for (const g of picked) {
      const c = h(`<button class="chip accent sp-gchip" title="${esc($t('Убрать'))}"><span></span>${icon('x', 12)}</button>`);
      c.querySelector('span').textContent = g;
      c.onclick = () => { picked.splice(picked.indexOf(g), 1); draw(); onChange(); };
      sel.append(c);
    }
    sel.hidden = !picked.length;
    const f = find.value.trim().toLowerCase();
    const rows = all.filter((x) => !f || x.name.toLowerCase().includes(f)).slice(0, 300);
    list.innerHTML = rows.length ? '' : `<div class="sp-gnone">${esc(all.length ? $t('Нет такого жанра') : empty)}</div>`;
    for (const x of rows) {
      const on = picked.includes(x.name);
      const r = h(`<button class="sp-grow${on ? ' on' : ''}" role="option" aria-selected="${on}"><span class="ck">${icon('check', 12)}</span><span class="n"></span><span class="c num"></span></button>`);
      r.querySelector('.n').textContent = x.name;
      r.querySelector('.c').textContent = x.n.toLocaleString();
      r.onclick = () => { if (on) picked.splice(picked.indexOf(x.name), 1); else picked.push(x.name); draw(); onChange(); };
      list.append(r);
    }
  };
  find.addEventListener('keydown', (e) => e.stopPropagation());
  find.oninput = draw;
  draw();
  box.redraw = (l, e) => { all = l; if (e) empty = e; draw(); };
  return box;
}

/* ---- «Свои правила»: rows of field · condition · value, all or any of them, made into a foobar2000 query */
const FIELDS = () => [
  ['artist', $t('Исполнитель'), 'text', '%artist%'], ['album', $t('Альбом'), 'text', '%album%'], ['title', $t('Название'), 'text', '%title%'],
  ['genre', $t('Жанр'), 'text', 'genre'], ['codec', $t('Формат'), 'text', '%codec%'], ['year', $t('Год'), 'num', '%date%'],
  ['length', $t('Длительность, мин'), 'num', '%length_seconds%'], ['rating', $t('Оценка'), 'num', '%rating%'], ['plays', $t('Прослушиваний'), 'num', '%play_count%'],
  ['added', $t('Добавлен'), 'date', '%added%'], ['played', $t('Последнее прослушивание'), 'date', '%last_played%'],
];
const OPS = () => ({
  text: [['has', $t('содержит')], ['not', $t('не содержит')], ['is', $t('равно')]],
  num: [['gt', $t('больше')], ['lt', $t('меньше')], ['is', $t('равно')]],
  date: [['in', $t('за последние N дней')], ['out', $t('не за последние N дней')]],
});
export function rulesQuery(v) {
  if (!v || !v.rows) return null;
  const F = Object.fromEntries(FIELDS().map((f) => [f[0], f]));
  const parts = [];
  for (const r of v.rows) {
    const f = F[r.f]; const val = String(r.v ?? '').trim();
    if (!f || !val) continue;
    const [, , type, tf] = f;
    if (type === 'text') parts.push(r.op === 'not' ? `NOT ${tf} HAS ${q(val)}` : r.op === 'is' ? `${tf} IS ${q(val)}` : `${tf} HAS ${q(val)}`);
    else if (type === 'num') { let n = parseFloat(val.replace(',', '.')); if (!Number.isFinite(n)) continue; if (r.f === 'length') n = Math.round(n * 60); parts.push(`${tf} ${r.op === 'lt' ? 'LESS' : r.op === 'is' ? 'IS' : 'GREATER'} ${n}`); }
    else { const n = parseInt(val, 10); if (!(n > 0)) continue; parts.push(r.op === 'out' ? `NOT ${tf} DURING LAST ${n} DAYS` : `${tf} DURING LAST ${n} DAYS`); }
  }
  if (!parts.length) return null;
  return { query: parts.map((p) => (parts.length > 1 ? `(${p})` : p)).join(v.any ? ' OR ' : ' AND '), sort: ALBUM_ORDER };
}
function rulesUI(r) {
  val = { any: false, rows: [{ f: 'genre', op: 'has', v: '' }] };
  const box = h('<div class="sp-rules"></div>');
  const draw = () => {
    box.innerHTML = '';
    const head = h(`<div class="sp-rhead"><div class="seg"><button data-any="0">${$t('все условия')}</button><button data-any="1">${$t('любое условие')}</button></div></div>`);
    head.querySelectorAll('button').forEach((b) => { b.classList.toggle('on', +b.dataset.any === +val.any); b.onclick = () => { val.any = b.dataset.any === '1'; draw(); countFor(r); }; });
    box.append(head);
    val.rows.forEach((row, i) => {
      const f = FIELDS().find((x) => x[0] === row.f) || FIELDS()[0];
      const ops = OPS()[f[2]];
      if (!ops.some((o) => o[0] === row.op)) row.op = ops[0][0];
      const el = h(`<div class="sp-rule"><select class="st-input sp-f">${FIELDS().map((x) => `<option value="${x[0]}"${x[0] === row.f ? ' selected' : ''}>${esc(x[1])}</option>`).join('')}</select>
        <select class="st-input sp-op">${ops.map((o) => `<option value="${o[0]}"${o[0] === row.op ? ' selected' : ''}>${esc(o[1])}</option>`).join('')}</select>
        <input class="st-input sp-v" spellcheck="false" inputmode="${f[2] === 'text' ? 'text' : 'numeric'}"><button class="icon-btn sp-del" title="${$t('Убрать условие')}" aria-label="${$t('Убрать условие')}">${icon('x', 14)}</button></div>`);
      const inp = el.querySelector('.sp-v'); inp.value = row.v;
      inp.addEventListener('keydown', (e) => e.stopPropagation());
      inp.oninput = () => { row.v = inp.value; countFor(r); };
      el.querySelector('.sp-f').onchange = (e) => { row.f = e.target.value; row.v = ''; draw(); countFor(r); };
      el.querySelector('.sp-op').onchange = (e) => { row.op = e.target.value; countFor(r); };
      el.querySelector('.sp-del').onclick = () => { val.rows.splice(i, 1); if (!val.rows.length) val.rows.push({ f: 'genre', op: 'has', v: '' }); draw(); countFor(r); };
      box.append(el);
    });
    const add = h(`<button class="btn sm sp-add">${icon('plus')}${$t('Условие')}</button>`);
    add.onclick = () => { val.rows.push({ f: 'artist', op: 'has', v: '' }); draw(); box.querySelector('.sp-rule:last-of-type .sp-v')?.focus(); };
    box.append(add);
  };
  draw();
  return box;
}
let veil = null, cur = null, val = null, genres = null;

const tracksWord = (n) => plural(n, 'трек', 'трека', 'треков');
/* the live answer: how many tracks match, and a few of them */
const countFor = debounce(async (r) => {
  const out = veil && veil.querySelector('.sp-count'), pv = veil && veil.querySelector('.sp-preview');
  if (!out) return;
  const spec = r.make(val);
  const show = (n, top, bad) => {
    out.classList.toggle('none', !n);
    out.innerHTML = n ? `<b>${n.toLocaleString()}</b><span>${$t('{0} подходит сейчас', tracksWord(n))}</span>` : `<span class="sp-bad">${bad || $t('Пока ничего не подходит')}</span>`;
    pv.innerHTML = (top || []).filter((t) => t.title).slice(0, 5).map((t) => `<li><span class="t">${esc(t.title)}</span><span class="a">${esc(t.artist)}</span></li>`).join('');
  };
  if (!spec) { out.classList.add('none'); out.innerHTML = ''; pv.innerHTML = ''; return; }
  if (spec.ai) { const m = SoundUI.matching(spec.ai, spec.style); show(m.n, m.top); return; }
  out.innerHTML = '<span class="spinner"></span>';
  const res = await call('library.query', { query: spec.query, limit: 6, fields: ['title', 'artist'], sort: spec.sort || '' });
  if (cur !== r) return;
  if (!ok(res)) { show(0, [], $t('foobar2000 не понял запрос')); return; }
  show(res.total || 0, res.tracks || [], r.stats ? $t('Нужен foo_playcount') : '');
}, 250);

function paramUI(r) {
  const box = h('<div class="sp-param"></div>');
  const p = r.param;
  if (!p) return box;
  if (p.label) box.append(h(`<label class="sp-label">${p.label}</label>`));
  if (p.kind === 'seg') {
    val = p.def;
    const seg = h('<div class="seg"></div>');
    for (const [v, t] of p.opts) {
      const b = h(`<button class="${v === val ? 'on' : ''}">${t}</button>`);
      b.onclick = () => { val = v; seg.querySelectorAll('button').forEach((x) => x.classList.toggle('on', x === b)); syncName(); countFor(r); };
      seg.append(b);
    }
    box.append(seg);
  } else if (p.kind === 'genre') {
    val = { list: [], sub: false };
    const v = val;
    const changed = () => { syncName(); countFor(r); };
    const pk = genrePicker([], v.list, changed, $t('Загружаю жанры…'));
    // «Death Metal» alone, or also «Melodic Death Metal», «Death Metal/Thrash»…
    const seg = h(`<div class="seg sp-gmode"><button data-sub="0" class="on">${esc($t('Только эти'))}</button><button data-sub="1">${esc($t('И их поджанры'))}</button></div>`);
    seg.querySelectorAll('button').forEach((b) => { b.onclick = () => { v.sub = b.dataset.sub === '1'; seg.querySelectorAll('button').forEach((x) => x.classList.toggle('on', x === b)); changed(); }; });
    box.append(pk, seg);
    (genres ? Promise.resolve(genres) : call('library.getGenres').then((g) => (genres = ok(g) ? g.genres || [] : []))).then((list) => pk.redraw(list.map((g) => ({ name: g.name, n: g.trackCount || 0 })), $t('В тегах нет жанров')));
  } else if (p.kind === 'style') {
    val = [];
    box.append(genrePicker(SoundUI.libraryGenres().slice(0, 300), val, () => { syncName(); countFor(r); }, $t('Пока нет проанализированных треков')));
  } else if (p.kind === 'rules') {
    box.append(rulesUI(r));
  } else if (p.kind === 'text') {
    val = '';
    const ta = h(`<textarea class="st-input sp-query" rows="3" spellcheck="false" placeholder="genre HAS jazz AND %date% LESS 1970"></textarea>`);
    ta.addEventListener('keydown', (e) => e.stopPropagation());
    ta.oninput = () => { val = ta.value; countFor(r); };
    box.append(ta, h(`<a class="link sp-help" data-href="https://wiki.hydrogenaud.io/index.php?title=Foobar2000:Query_syntax">${$t('Справка по языку запросов')}</a>`));
  }
  return box;
}
let nameTouched = false;
function syncName() {
  const inp = veil && veil.querySelector('.sp-name');
  if (inp && !nameTouched && cur) inp.value = cur.name(val);
}

function pick(r) {
  cur = r; nameTouched = false;
  veil.querySelectorAll('.sp-card').forEach((c) => { c.classList.toggle('on', c.dataset.id === r.id); c.setAttribute('aria-selected', c.dataset.id === r.id); });
  const form = veil.querySelector('.sp-form');
  form.dataset.tone = r.tone || r.g;
  form.innerHTML = '';
  const hero = h(`<div class="sp-hero"><div class="sp-ic">${icon(r.ic, 26)}</div><div class="sp-hero-t"><div class="kicker">${GROUPS.find((x) => x[0] === r.g)[1]}</div><h4>${r.title}</h4></div></div>`);
  if (r.ai && !Sound.ready()) {
    form.append(hero, h(`<div class="sp-ai-off">${$t('Нужен анализ звука')} <button class="btn sm primary">${$t('Открыть настройки')}</button></div>`));
    form.querySelector('.sp-ai-off button').onclick = () => { close(); SoundUI.openSettings(); };
    return;
  }
  form.append(
    hero,
    h('<div class="sp-count none"></div>'),
    paramUI(r),
    h(`<div class="sp-pv"><div class="sp-label">${$t('Например')}</div><ol class="sp-preview"></ol></div>`),
    h(`<div class="sp-foot"><input class="st-input sp-name" spellcheck="false" placeholder="${$t('Название')}" aria-label="${$t('Название')}"><button class="btn primary sp-go">${icon('plus')}${$t('Создать')}</button></div>`),
  );
  const name = form.querySelector('.sp-name');
  name.value = r.name(val);
  name.addEventListener('keydown', (e) => { e.stopPropagation(); if (e.key === 'Enter') create(); });
  name.oninput = () => { nameTouched = true; };
  form.querySelector('.sp-go').onclick = create;
  countFor(r);
}

async function create() {
  const r = cur; if (!r) return;
  const spec = r.make(val);
  if (!spec) { toast(r.param && (r.param.kind === 'genre' || r.param.kind === 'style') ? $t('Выберите жанр') : $t('Введите запрос')); return; }
  const name = (veil.querySelector('.sp-name').value || r.name(val)).trim();
  if (spec.ai) { close(); await SoundUI.moodPlaylist(spec.ai, name, spec.n, spec.style); return; }
  // a descending order goes into the query as a SORT clause; if this foobar2000 refuses it there,
  // the playlist is made with the plain query (ascending order) rather than not at all
  let res = await call('playlist.createAutoplaylist', spec.sortDesc
    ? { name, query: `${spec.query} SORT DESCENDING BY ${spec.sortDesc}` }
    : { name, query: spec.query, sort: spec.sort || '' });
  if (!ok(res) && spec.sortDesc) res = await call('playlist.createAutoplaylist', { name, query: spec.query, sort: spec.sortDesc });
  if (!ok(res)) { toast($t('foobar2000 не создал плейлист: {0}', esc(res.error || res.code || '?'))); return; }
  close();
  
  await call('playlist.setActive', { playlistGuid: res.guid });
  router.go('playlist', res.guid);
}

export function open(preset) {
  if (!veil) {
    const list = GROUPS.map(([g, title]) => `<div class="sp-group" role="group" aria-label="${esc(title)}"><div class="sp-gh">${title}</div>${RECIPES.filter((r) => r.g === g)
      .map((r) => `<button class="sp-card${r.ai ? ' ai' : ''}" data-id="${r.id}" data-tone="${r.tone || r.g}" role="option" title="${esc(r.title)}"><span class="sp-ic">${icon(r.ic, 16)}</span><b>${r.title}</b></button>`).join('')}</div>`).join('');
    veil = h(`<div class="upd-veil sp-veil"><div class="upd-sheet sp-sheet" role="dialog" aria-modal="true" aria-label="${$t('Умный плейлист')}">
      <header class="sp-top"><div class="kicker">${$t('Умный плейлист')}</div><button class="icon-btn sp-x" title="${$t('Закрыть')}">${icon('x', 16)}</button></header>
      <div class="sp-body"><nav class="sp-list" role="listbox">${list}</nav><section class="sp-form"></section></div></div></div>`);
    document.body.append(veil);
    veil.addEventListener('click', (e) => {
      if (e.target === veil || e.target.closest('.sp-x')) return close();
      const c = e.target.closest('.sp-card'); if (c) pick(RECIPES.find((r) => r.id === c.dataset.id));
      const a = e.target.closest('a[data-href]'); if (a) { e.preventDefault(); call('shell.openExternal', { url: a.dataset.href }); }
    });
    // ↑/↓ walk the recipes
    veil.querySelector('.sp-list').addEventListener('keydown', (e) => {
      if (e.key !== 'ArrowDown' && e.key !== 'ArrowUp') return;
      e.preventDefault(); e.stopPropagation();
      const all = [...veil.querySelectorAll('.sp-card')]; const i = all.findIndex((c) => c.dataset.id === cur.id);
      const nx = all[Math.max(0, Math.min(all.length - 1, i + (e.key === 'ArrowDown' ? 1 : -1)))];
      pick(RECIPES.find((r) => r.id === nx.dataset.id)); nx.focus();
    });
    addEventListener('keydown', (e) => { if (veil && veil.classList.contains('on') && e.key === 'Escape') { e.stopPropagation(); close(); } }, true);
  }
  pick(RECIPES.find((r) => r.id === preset) || RECIPES[0]);
  requestAnimationFrame(() => { veil.classList.add('on'); const on = veil.querySelector('.sp-card.on'); on && on.scrollIntoView({ block: 'nearest' }); });
}
export function close() { veil && veil.classList.remove('on'); }
export const recipes = RECIPES;
