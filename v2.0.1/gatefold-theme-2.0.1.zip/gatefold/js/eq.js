/*
 * Gatefold · eq.js — Gatefold's own equalizer.
 *
 * The sound is the component's: a DSP of foo_gatefold in foobar2000's chain (eq.get / eq.set; a change is heard
 * within 20 ms, crossfaded, no clicks). This module is everything you see of it:
 *   graphic      ten bands an octave apart (31 Hz … 16 kHz, ±12 dB): sliders, or the points on the curve;
 *   parametric   up to twelve bands — bell, shelves, low and high cut — dragged on the curve (the wheel sets
 *                the width), or typed in exactly;
 *   the curve    the filters' real response (the same formulas as core/audio/Eq.cpp) over the music's own
 *                spectrum, live;
 *   presets      built-in ones for the graphic EQ, and your own (either kind) kept in the settings;
 *   compare      hold «A/B» to hear the music without the equalizer;
 *   no clipping  «Prevent clipping» lowers the gain by the curve's highest point (on by default).
 * Only on Gatefold's own host: on foo_ui_webview2 the «Sound» panel offers foobar2000's equalizer as before.
 */
import { esc, log } from './bridge.js';
import { h, icon, toast, popupMenu } from './ui.js';
import { $t } from './i18n.js';
import { settings, setSetting } from './settings.js';
import * as Viz from './viz.js';

export const FREQS = [31, 62, 125, 250, 500, 1000, 2000, 4000, 8000, 16000];
const GQ = 1.41, FS = 48000, MAXB = 12;
export const events = new EventTarget();
const emit = () => events.dispatchEvent(new Event('change'));
const clamp = (v, a, b) => Math.min(b, Math.max(a, v));

let st = null;
export const available = () => !!(window.gf && typeof window.gf.call === 'function' && !window.fb2k);
export const state = () => st;

export async function load() {
  if (!available()) return null;
  try { st = await window.gf.call('eq.get'); } catch (e) { log('eq.get', e.message || e); st = null; }
  emit();
  return st;
}
let wired = false;
export function init() {
  if (!available() || wired) return;
  wired = true;
  window.gf.on('eq.changed', (d) => { if (!pending && !inflight && d && d.state) { st = d.state; emit(); } });
  load();
}

/* changes go out at most every 30 ms while a slider moves; the last one always */
let pending = null, timer = 0, inflight = false;
export function set(patch, now = false) {
  if (!st) return;
  st = { ...st, ...patch };
  emit();
  pending = { ...(pending || {}), ...patch };
  if (now) flush();
  else if (!timer) timer = setTimeout(flush, 30);
}
async function flush() {
  clearTimeout(timer); timer = 0;
  if (!pending) return;
  if (inflight) { timer = setTimeout(flush, 30); return; }
  const p = pending; pending = null; inflight = true;
  try {
    const r = await window.gf.call('eq.set', p);
    if (!pending) { st = r; emit(); }
  } catch (e) { log('eq.set', e.message || e); toast(esc(e.message || $t('Эквалайзер не принял изменение'))); }
  finally { inflight = false; if (pending && !timer) timer = setTimeout(flush, 0); }
}

// ---------------------------------------------------------------- the filters (as core/audio/Eq.cpp)
function design(b, fs) {
  const f = clamp(b.freq, 10, fs * 0.49), q = clamp(b.q, 0.05, 40);
  const A = Math.pow(10, b.gain / 40), w = 2 * Math.PI * f / fs, c = Math.cos(w), s = Math.sin(w), al = s / (2 * q), sa = 2 * Math.sqrt(A) * al;
  let b0, b1, b2, a0, a1, a2;
  switch (b.type) {
    case 'lowshelf': b0 = A * ((A + 1) - (A - 1) * c + sa); b1 = 2 * A * ((A - 1) - (A + 1) * c); b2 = A * ((A + 1) - (A - 1) * c - sa); a0 = (A + 1) + (A - 1) * c + sa; a1 = -2 * ((A - 1) + (A + 1) * c); a2 = (A + 1) + (A - 1) * c - sa; break;
    case 'highshelf': b0 = A * ((A + 1) + (A - 1) * c + sa); b1 = -2 * A * ((A - 1) + (A + 1) * c); b2 = A * ((A + 1) + (A - 1) * c - sa); a0 = (A + 1) - (A - 1) * c + sa; a1 = 2 * ((A - 1) - (A + 1) * c); a2 = (A + 1) - (A - 1) * c - sa; break;
    case 'lowcut': b0 = (1 + c) / 2; b1 = -(1 + c); b2 = (1 + c) / 2; a0 = 1 + al; a1 = -2 * c; a2 = 1 - al; break;
    case 'highcut': b0 = (1 - c) / 2; b1 = 1 - c; b2 = (1 - c) / 2; a0 = 1 + al; a1 = -2 * c; a2 = 1 - al; break;
    default: b0 = 1 + al * A; b1 = -2 * c; b2 = 1 - al * A; a0 = 1 + al / A; a1 = -2 * c; a2 = 1 - al / A;
  }
  return [b0 / a0, b1 / a0, b2 / a0, a1 / a0, a2 / a0];
}
function bandDb(q, f, fs) {
  const w = 2 * Math.PI * f / fs, c1 = Math.cos(w), s1 = -Math.sin(w), c2 = Math.cos(2 * w), s2 = -Math.sin(2 * w);
  const nr = q[0] + q[1] * c1 + q[2] * c2, ni = q[1] * s1 + q[2] * s2, dr = 1 + q[3] * c1 + q[4] * c2, di = q[3] * s1 + q[4] * s2;
  return 10 * Math.log10(Math.max(1e-24, (nr * nr + ni * ni) / (dr * dr + di * di)));
}
export function bandsOf(s) {
  if (!s) return [];
  return s.mode === 'parametric' ? (s.bands || []) : FREQS.map((f, i) => ({ type: 'peak', freq: f, gain: (s.graphic || [])[i] || 0, q: GQ, on: Math.abs((s.graphic || [])[i] || 0) > 1e-6 }));
}
const active = (b) => b.on !== false && (b.type === 'lowcut' || b.type === 'highcut' || Math.abs(b.gain) > 1e-6);
export function curve(bands, freqs, fs = FS) {
  const qs = bands.filter(active).map((b) => design(b, fs));
  return freqs.map((f) => qs.reduce((a, q) => a + bandDb(q, f, fs), 0));
}
export function peakDb(bands, fs = FS) {
  const fr = []; for (let i = 0; i <= 240; i++) fr.push(20 * Math.pow(1000, i / 240));
  return Math.max(0, ...curve(bands, fr, fs));
}
const fmtHz = (f) => (f >= 1000 ? (f / 1000).toFixed(f >= 10000 || f % 1000 === 0 ? 0 : 1) + ' ' + $t('кГц') : Math.round(f) + ' ' + $t('Гц'));
const fmtDb = (v) => (v > 0 ? '+' : v < 0 ? '−' : '') + Math.abs(v).toFixed(1) + ' ' + $t('дБ');

// ---------------------------------------------------------------- presets
export const PRESETS = () => [
  ['flat', $t('Ровно'), [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]],
  ['bass', $t('Больше баса'), [6, 5.5, 4.5, 2.5, 0.5, 0, 0, 0, 0, 0]],
  ['bassless', $t('Меньше баса'), [-6, -5, -4, -2, -0.5, 0, 0, 0, 0, 0]],
  ['treble', $t('Больше высоких'), [0, 0, 0, 0, 0, 0.5, 1.5, 3.5, 5, 6]],
  ['vocal', $t('Голос'), [-2, -2, -1, 0.5, 2.5, 3.5, 3, 1.5, 0, -1]],
  ['rock', $t('Рок'), [4.5, 3.5, 2, 0, -1, -0.5, 1, 2.5, 3.5, 4]],
  ['pop', $t('Поп'), [-1, 0.5, 2.5, 3.5, 2.5, 0, -1, -1, 0.5, 1.5]],
  ['electronic', $t('Электроника'), [5, 4.5, 2, 0, -1.5, 0, 0.5, 2, 3.5, 4.5]],
  ['hiphop', $t('Хип-хоп'), [5.5, 4.5, 2, 2.5, -0.5, -1, 0.5, -0.5, 1.5, 2.5]],
  ['jazz', $t('Джаз'), [3, 2, 1, 1.5, -1, -1, 0, 1, 2, 3]],
  ['classical', $t('Классика'), [3.5, 3, 2, 1, -0.5, -0.5, 0, 1.5, 2.5, 3.5]],
  ['acoustic', $t('Акустика'), [3.5, 3, 2, 1, 1.5, 1.5, 2.5, 3, 2, 1]],
  ['loudness', $t('Тонкомпенсация'), [5, 3.5, 0.5, 0, -1, 0, -0.5, 0, 3, 4]],
  ['night', $t('Тихо, ночью'), [-3, -2, 0, 1, 1.5, 2, 1, 0, -2, -4]],
  ['speech', $t('Речь и подкасты'), [-6, -4, -2, 0.5, 2.5, 3.5, 3, 1, -1, -3]],
  ['phones', $t('Наушники'), [3, 2.5, 1, 0, -0.5, 0, 1, 2, 1, -1]],
];
const userPresets = () => (Array.isArray(settings.eqPresets) ? settings.eqPresets : []);
function presetName() {
  if (!st) return '';
  if (st.preset) {
    const b = PRESETS().find(([id]) => id === st.preset);
    if (b) return b[1];
    if (userPresets().some((p) => p.name === st.preset)) return st.preset;
  }
  return $t('Своя настройка');
}
export function applyPreset(id) {
  const b = PRESETS().find(([k]) => k === id);
  if (b) { set({ mode: 'graphic', graphic: b[2].slice(), preset: id }, true); return; }
  const u = userPresets().find((p) => p.name === id);
  if (u) set({ mode: u.mode, graphic: u.graphic.slice(), bands: u.bands.map((x) => ({ ...x })), preamp: u.preamp ?? 0, preset: u.name }, true);
}
function saveUserPreset() {
  const name = (window.prompt ? window.prompt($t('Название пресета'), '') : '')?.trim();
  if (!name) return;
  const list = userPresets().filter((p) => p.name !== name);
  list.push({ name: name.slice(0, 60), mode: st.mode, graphic: st.graphic.slice(), bands: st.bands.map((x) => ({ ...x })), preamp: st.preamp });
  setSetting('eqPresets', list);
  set({ preset: name }, true);
  toast($t('Пресет «{0}» сохранён', esc(name)));
}
function deleteUserPreset(name) {
  setSetting('eqPresets', userPresets().filter((p) => p.name !== name));
  if (st.preset === name) set({ preset: '' }, true);
}
async function presetMenu(anchor) {
  const r = anchor.getBoundingClientRect();
  const items = PRESETS().map(([id, name]) => ({ label: name, checked: st.preset === id, act: () => applyPreset(id) }));
  const mine = userPresets();
  const menu = [...items];
  if (mine.length) { menu.push({ sep: true }); for (const p of mine) menu.push({ label: p.name, checked: st.preset === p.name, act: () => applyPreset(p.name) }); }
  menu.push({ sep: true }, { label: $t('Сохранить как пресет…'), act: saveUserPreset });
  if (mine.some((p) => p.name === st.preset)) menu.push({ label: $t('Удалить пресет «{0}»', st.preset), act: () => deleteUserPreset(st.preset) });
  const pick = await popupMenu(menu.map((m, i) => (m.sep ? { type: 'sep' } : { id: String(i), label: m.label, checked: m.checked })), r.left, r.bottom + 6);
  if (pick != null && menu[+pick] && menu[+pick].act) menu[+pick].act();
}

// ---------------------------------------------------------------- the curve
const F0 = 20, F1 = 20000;
const xOf = (f, w) => (Math.log(f / F0) / Math.log(F1 / F0)) * w;
const fOf = (x, w) => F0 * Math.pow(F1 / F0, clamp(x / w, 0, 1));
const range = () => (st && st.mode === 'parametric' ? 18 : 12);
const yOf = (db, hh) => hh / 2 - (db / range()) * (hh / 2 - 14);
const dbOf = (y, hh) => ((hh / 2 - y) / (hh / 2 - 14)) * range();
const GRID_F = [50, 100, 200, 500, 1000, 2000, 5000, 10000];

function css(el, name, fallback) { const v = getComputedStyle(el).getPropertyValue(name).trim(); return v || fallback; }

class Graph {
  constructor(canvas, onPick) {
    this.c = canvas; this.ctx = canvas.getContext('2d'); this.sel = -1; this.hot = -1; this.drag = null; this.onPick = onPick;
    this.spec = null; this.raf = 0;
    canvas.addEventListener('pointerdown', (e) => this.down(e));
    canvas.addEventListener('pointermove', (e) => this.move(e));
    canvas.addEventListener('pointerup', (e) => this.up(e));
    canvas.addEventListener('pointercancel', (e) => this.up(e));
    canvas.addEventListener('pointerleave', () => { this.hot = -1; this.tip = null; this.draw(); });
    canvas.addEventListener('dblclick', (e) => this.dbl(e));
    canvas.addEventListener('wheel', (e) => this.wheel(e), { passive: false });
    this.ro = new ResizeObserver(() => this.size()); this.ro.observe(canvas);
    this.size();
    const loop = () => { this.raf = requestAnimationFrame(loop); this.live(); };
    this.raf = requestAnimationFrame(loop);
  }
  destroy() { cancelAnimationFrame(this.raf); this.ro.disconnect(); }
  size() {
    const r = this.c.getBoundingClientRect(), d = Math.min(2, devicePixelRatio || 1);
    this.w = r.width; this.h = r.height;
    this.c.width = Math.round(r.width * d); this.c.height = Math.round(r.height * d);
    this.ctx.setTransform(d, 0, 0, d, 0, 0);
    this.draw();
  }
  points() {
    return bandsOf(st).map((b, i) => ({ i, b, x: xOf(b.freq, this.w), y: b.type === 'lowcut' || b.type === 'highcut' ? yOf(0, this.h) : yOf(b.gain, this.h) }));
  }
  at(e) {
    const r = this.c.getBoundingClientRect(), x = e.clientX - r.left, y = e.clientY - r.top;
    let best = -1, bd = 18 * 18;
    for (const p of this.points()) { const d = (p.x - x) ** 2 + (p.y - y) ** 2; if (d < bd) { bd = d; best = p.i; } }
    return { x, y, i: best };
  }
  down(e) {
    if (!st) return;
    const a = this.at(e);
    if (a.i < 0) return;
    e.preventDefault();
    this.c.setPointerCapture(e.pointerId);
    this.sel = a.i; this.drag = { i: a.i }; this.onPick(a.i);
    this.move(e);
  }
  move(e) {
    if (!st) return;
    const a = this.at(e);
    if (!this.drag) { if (a.i !== this.hot) { this.hot = a.i; this.c.style.cursor = a.i >= 0 ? 'grab' : st.mode === 'parametric' ? 'crosshair' : 'default'; this.draw(); } return; }
    this.c.style.cursor = 'grabbing';
    const i = this.drag.i, gain = Math.round(clamp(dbOf(a.y, this.h), -range(), range()) * 2) / 2;
    if (st.mode === 'graphic') {
      const g = st.graphic.slice(); g[i] = clamp(gain, -12, 12);
      set({ graphic: g, preset: '' });
      this.tip = { i, text: `${fmtHz(FREQS[i])} · ${fmtDb(g[i])}` };
    } else {
      const bands = st.bands.map((x) => ({ ...x })), b = bands[i];
      b.freq = Math.round(clamp(fOf(a.x, this.w), 20, 20000));
      if (b.type !== 'lowcut' && b.type !== 'highcut') b.gain = clamp(gain, -24, 24);
      set({ bands, preset: '' });
      this.tip = { i, text: `${fmtHz(b.freq)}${b.type === 'lowcut' || b.type === 'highcut' ? '' : ' · ' + fmtDb(b.gain)}` };
    }
    this.draw();
  }
  up(e) { if (!this.drag) return; this.drag = null; this.tip = null; try { this.c.releasePointerCapture(e.pointerId); } catch {} flush(); this.draw(); }
  dbl(e) {
    if (!st) return;
    const a = this.at(e);
    if (st.mode === 'graphic') { if (a.i >= 0) { const g = st.graphic.slice(); g[a.i] = 0; set({ graphic: g, preset: '' }, true); } return; }
    if (a.i >= 0) { const bands = st.bands.map((x) => ({ ...x })); if (bands[a.i].type === 'peak') bands[a.i].gain = 0; else bands[a.i].on = !bands[a.i].on; set({ bands, preset: '' }, true); return; }
    if (st.bands.length >= MAXB) { toast($t('Не больше {0} полос', MAXB)); return; }
    const b = { type: 'peak', freq: Math.round(fOf(a.x, this.w)), gain: Math.round(clamp(dbOf(a.y, this.h), -18, 18) * 2) / 2, q: 1, on: true };
    const bands = [...st.bands.map((x) => ({ ...x })), b].sort((x, y) => x.freq - y.freq);
    set({ bands, preset: '' }, true);
    this.sel = bands.indexOf(b); this.onPick(this.sel);
  }
  wheel(e) {
    if (!st || st.mode !== 'parametric') return;
    const a = this.at(e), i = a.i >= 0 ? a.i : this.sel;
    if (i < 0 || !st.bands[i]) return;
    e.preventDefault();
    const bands = st.bands.map((x) => ({ ...x }));
    bands[i].q = Math.round(clamp(bands[i].q * Math.pow(1.12, e.deltaY > 0 ? -1 : 1), 0.1, 18) * 100) / 100;
    set({ bands, preset: '' });
    this.tip = { i, text: `Q ${bands[i].q.toFixed(2)}` }; this.draw();
    clearTimeout(this.tipT); this.tipT = setTimeout(() => { this.tip = null; this.draw(); }, 900);
  }
  live() {
    // the music's spectrum under the curve, eased so it breathes rather than flickers
    const bars = Viz.spectrumBars && Viz.spectrumBars();
    if (!bars || !bars.length) return;
    if (!this.spec || this.spec.length !== bars.length) this.spec = new Float32Array(bars.length);
    let moved = false;
    for (let i = 0; i < bars.length; i++) { const v = this.spec[i] + (bars[i] - this.spec[i]) * 0.25; if (Math.abs(v - this.spec[i]) > 0.002) moved = true; this.spec[i] = v; }
    if (moved) this.draw();
  }
  draw() {
    const g = this.ctx, w = this.w, hh = this.h;
    if (!w || !hh) return;
    g.clearRect(0, 0, w, hh);
    const root = this.c, text3 = css(root, '--text-3', '#888'), line = css(root, '--line', 'rgba(255,255,255,.08)'), accent = css(root, '--accent', '#8fb4ff');
    const on = st && st.enabled;
    // spectrum
    if (this.spec) {
      g.beginPath(); g.moveTo(0, hh);
      const n = this.spec.length;
      for (let i = 0; i < n; i++) { const f = 30 * Math.pow(16000 / 30, i / (n - 1)); g.lineTo(xOf(f, w), hh - this.spec[i] * hh * 0.85); }
      g.lineTo(w, hh); g.closePath();
      const gr = g.createLinearGradient(0, 0, 0, hh); gr.addColorStop(0, `color-mix(in oklab, ${accent} 22%, transparent)`); gr.addColorStop(1, 'transparent');
      g.fillStyle = gr; g.fill();
    }
    // grid
    g.strokeStyle = line; g.lineWidth = 1; g.fillStyle = text3; g.font = '500 10.5px Inter, Segoe UI, sans-serif'; g.textAlign = 'center';
    for (const f of GRID_F) { const x = Math.round(xOf(f, w)) + 0.5; g.beginPath(); g.moveTo(x, 0); g.lineTo(x, hh); g.stroke(); g.fillText(f >= 1000 ? f / 1000 + 'k' : String(f), x, hh - 6); }
    g.textAlign = 'left';
    for (const db of [-range(), -range() / 2, 0, range() / 2, range()]) {
      const y = Math.round(yOf(db, hh)) + 0.5;
      g.globalAlpha = db === 0 ? 1 : 0.6; g.beginPath(); g.moveTo(0, y); g.lineTo(w, y); g.stroke(); g.globalAlpha = 1;
      if (db !== 0) g.fillText((db > 0 ? '+' : '−') + Math.abs(db), 6, y - 4);
    }
    if (!st) return;
    // the curve
    const bands = bandsOf(st), N = Math.max(120, Math.round(w / 2)), fr = [];
    for (let i = 0; i <= N; i++) fr.push(fOf((i / N) * w, w));
    const db = curve(bands, fr);
    const y0 = yOf(0, hh);
    g.beginPath(); g.moveTo(0, y0);
    db.forEach((v, i) => g.lineTo((i / N) * w, yOf(clamp(v, -range() * 1.6, range() * 1.6), hh)));
    g.lineTo(w, y0); g.closePath();
    g.fillStyle = `color-mix(in oklab, ${accent} ${on ? 18 : 7}%, transparent)`; g.fill();
    g.beginPath();
    db.forEach((v, i) => { const x = (i / N) * w, y = yOf(clamp(v, -range() * 1.6, range() * 1.6), hh); if (i) g.lineTo(x, y); else g.moveTo(x, y); });
    g.lineWidth = 2.25; g.strokeStyle = on ? accent : text3; g.lineJoin = 'round'; g.stroke();
    // the points
    for (const p of this.points()) {
      const sel = p.i === this.sel && st.mode === 'parametric', hot = p.i === this.hot || (this.drag && this.drag.i === p.i);
      const off = p.b.on === false;
      g.beginPath(); g.arc(p.x, p.y, hot ? 8 : sel ? 7 : 5.5, 0, Math.PI * 2);
      g.fillStyle = off ? text3 : on ? accent : text3; g.globalAlpha = off ? 0.45 : 1; g.fill(); g.globalAlpha = 1;
      g.lineWidth = 2; g.strokeStyle = css(root, '--surface', '#111'); g.stroke();
      if (st.mode === 'parametric') { g.fillStyle = css(root, '--surface', '#111'); g.font = '700 9px Inter, sans-serif'; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText(String(p.i + 1), p.x, p.y + 0.5); g.textBaseline = 'alphabetic'; }
    }
    if (this.tip) {
      const p = this.points()[this.tip.i];
      if (p) {
        g.font = '600 11.5px Inter, Segoe UI, sans-serif';
        const tw = g.measureText(this.tip.text).width + 16, tx = clamp(p.x - tw / 2, 4, w - tw - 4), ty = p.y < 40 ? p.y + 16 : p.y - 34;
        g.fillStyle = css(root, '--surface-2', '#222'); g.beginPath(); g.roundRect(tx, ty, tw, 22, 7); g.fill();
        g.fillStyle = css(root, '--text', '#fff'); g.textAlign = 'left'; g.fillText(this.tip.text, tx + 8, ty + 15);
      }
    }
  }
}

/** the small curve in the «Sound» panel */
export function drawMini(canvas) {
  const r = canvas.getBoundingClientRect(), d = Math.min(2, devicePixelRatio || 1), w = r.width, hh = r.height;
  if (!w || !hh) return;
  canvas.width = Math.round(w * d); canvas.height = Math.round(hh * d);
  const g = canvas.getContext('2d'); g.setTransform(d, 0, 0, d, 0, 0); g.clearRect(0, 0, w, hh);
  const accent = css(canvas, '--accent', '#8fb4ff'), text3 = css(canvas, '--text-3', '#888'), line = css(canvas, '--line', 'rgba(255,255,255,.1)');
  g.strokeStyle = line; g.beginPath(); g.moveTo(0, hh / 2 + 0.5); g.lineTo(w, hh / 2 + 0.5); g.stroke();
  if (!st) return;
  const N = 80, fr = []; for (let i = 0; i <= N; i++) fr.push(fOf((i / N) * w, w));
  const db = curve(bandsOf(st), fr), R = st.mode === 'parametric' ? 18 : 12, y = (v) => hh / 2 - clamp(v / R, -1, 1) * (hh / 2 - 3);
  g.beginPath(); db.forEach((v, i) => (i ? g.lineTo((i / N) * w, y(v)) : g.moveTo(0, y(v))));
  g.lineWidth = 2; g.strokeStyle = st.enabled ? accent : text3; g.lineJoin = 'round'; g.stroke();
}

// ---------------------------------------------------------------- the editor
let sheet = null, graph = null, offChange = null;
const TYPES = () => [['peak', $t('Колокол')], ['lowshelf', $t('Полка НЧ')], ['highshelf', $t('Полка ВЧ')], ['lowcut', $t('Срез НЧ')], ['highcut', $t('Срез ВЧ')]];

export async function openEditor() {
  if (!available()) return;
  if (!st) await load();
  if (!st) { toast($t('Эквалайзер недоступен в этой версии компонента')); return; }
  if (sheet) return;
  sheet = h(`<div class="eq-veil" role="dialog" aria-modal="true" aria-label="${$t('Эквалайзер')}">
    <div class="eq-sheet">
      <div class="eq-head">
        <div class="eq-title"><b>${$t('Эквалайзер')}</b><small class="eq-st"></small></div>
        <div class="seg eq-mode"><button data-m="graphic">${$t('Графический')}</button><button data-m="parametric">${$t('Параметрический')}</button></div>
        <button class="btn eq-preset" aria-haspopup="menu"><span></span>${icon('chev', 14)}</button>
        <button class="btn icon eq-ab" title="${$t('Удерживайте, чтобы послушать без эквалайзера')}">A/B</button>
        <button class="btn icon eq-reset" title="${$t('Сбросить до ровного')}">${icon('refresh', 16)}</button>
        <label class="toggle eq-on" title="${$t('Включить эквалайзер')}"><input type="checkbox"><i></i></label>
        <button class="btn icon eq-close" aria-label="${$t('Закрыть')}">${icon('x', 18)}</button>
      </div>
      <div class="eq-graph"><canvas></canvas><div class="eq-hint"></div></div>
      <div class="eq-sliders"></div>
      <div class="eq-band"></div>
      <div class="eq-foot">
        <div class="eq-pre"><span>${$t('Предусиление')}</span><input type="range" min="-12" max="12" step="0.5" class="range"><b></b></div>
        <label class="eq-auto" title="${$t('Опускает общий уровень на высоту самого высокого подъёма кривой — громкие места не хрипят')}"><input type="checkbox"><span>${$t('Без перегрузки')}</span></label>
      </div>
    </div></div>`);
  document.getElementById('layer').append(sheet);
  const $s = (q) => sheet.querySelector(q);
  graph = new Graph($s('.eq-graph canvas'), (i) => renderBand(i));

  $s('.eq-close').onclick = closeEditor;
  sheet.addEventListener('mousedown', (e) => { if (e.target === sheet) closeEditor(); });
  sheet.addEventListener('keydown', (e) => { if (e.key === 'Escape') { e.stopPropagation(); closeEditor(); } });
  $s('.eq-on input').onchange = (e) => set({ enabled: e.target.checked }, true);
  sheet.querySelectorAll('.eq-mode button').forEach((b) => { b.onclick = () => { graph.sel = -1; set({ mode: b.dataset.m }, true); }; });
  $s('.eq-preset').onclick = (e) => presetMenu(e.currentTarget);
  $s('.eq-reset').onclick = () => (st.mode === 'graphic' ? set({ graphic: FREQS.map(() => 0), preset: 'flat', preamp: 0 }, true) : set({ bands: st.bands.map((b) => ({ ...b, gain: 0 })), preset: '', preamp: 0 }, true));
  // A/B: held, the equalizer is off; let go, back on
  const ab = $s('.eq-ab');
  let abWas = null;
  const abDown = (e) => { e.preventDefault(); if (abWas !== null || !st.enabled) return; abWas = true; ab.classList.add('on'); set({ enabled: false }, true); };
  const abUp = () => { if (abWas === null) return; abWas = null; ab.classList.remove('on'); set({ enabled: true }, true); };
  ab.addEventListener('pointerdown', abDown); ab.addEventListener('pointerup', abUp); ab.addEventListener('pointerleave', abUp);
  const pre = $s('.eq-pre input');
  pre.oninput = () => { set({ preamp: +pre.value }); pre.style.setProperty('--p', ((+pre.value + 12) / 24 * 100) + '%'); };
  pre.onchange = () => flush();
  $s('.eq-auto input').onchange = (e) => set({ autoGain: e.target.checked }, true);

  offChange = () => paint();
  events.addEventListener('change', offChange);
  Viz.vizState.extra.add('eq');
  import('./app.js').then((m) => m.refreshSpectrum && m.refreshSpectrum()).catch(() => {});
  paint(true);
  requestAnimationFrame(() => sheet && sheet.classList.add('in'));
  setTimeout(() => { const f = sheet && sheet.querySelector('.eq-on input'); if (f) f.focus({ preventScroll: true }); }, 50);
}

export function closeEditor() {
  if (!sheet) return;
  const s = sheet; sheet = null;
  if (graph) graph.destroy(); graph = null;
  events.removeEventListener('change', offChange);
  Viz.vizState.extra.delete('eq');
  import('./app.js').then((m) => m.refreshSpectrum && m.refreshSpectrum()).catch(() => {});
  flush();
  s.classList.remove('in'); s.classList.add('out');
  setTimeout(() => s.remove(), 220);
}

function status() {
  if (!st.enabled) return $t('Выключен');
  if (!st.inChain) return $t('Включается…');
  return st.playing ? $t('Работает') : $t('Включён — заработает со следующим звуком');
}

function paint(first = false) {
  if (!sheet || !st) return;
  const $s = (q) => sheet.querySelector(q);
  sheet.classList.toggle('off', !st.enabled);
  sheet.classList.toggle('param', st.mode === 'parametric');
  $s('.eq-st').textContent = status();
  $s('.eq-on input').checked = !!st.enabled;
  sheet.querySelectorAll('.eq-mode button').forEach((b) => b.classList.toggle('on', b.dataset.m === st.mode));
  $s('.eq-preset span').textContent = presetName();
  const pre = $s('.eq-pre input');
  if (document.activeElement !== pre) pre.value = st.preamp;
  pre.style.setProperty('--p', ((+st.preamp + 12) / 24 * 100) + '%');
  $s('.eq-pre b').textContent = fmtDb(+st.preamp) + (st.autoGain && peakDb(bandsOf(st)) > 0.05 ? ` (${fmtDb(+st.preamp - peakDb(bandsOf(st)))})` : '');
  $s('.eq-auto input').checked = !!st.autoGain;
  $s('.eq-hint').textContent = st.mode === 'parametric'
    ? $t('Перетаскивайте точки · колесо — ширина · двойной щелчок — новая полоса')
    : $t('Перетаскивайте точки или ползунки · двойной щелчок — в ноль');
  renderSliders(first);
  if (st.mode === 'parametric') renderBand(graph ? graph.sel : -1); else $s('.eq-band').innerHTML = '';
  if (graph) graph.draw();
}

function renderSliders(first) {
  const box = sheet.querySelector('.eq-sliders');
  if (st.mode !== 'graphic') { box.innerHTML = ''; return; }
  if (first || !box.children.length) {
    box.innerHTML = FREQS.map((f, i) => `<div class="eq-sl"><b></b><input type="range" min="-12" max="12" step="0.5" aria-label="${esc(fmtHz(f))}" data-i="${i}"><span>${f >= 1000 ? f / 1000 + 'k' : f}</span></div>`).join('');
    box.querySelectorAll('input').forEach((inp) => {
      inp.oninput = () => { const g = st.graphic.slice(); g[+inp.dataset.i] = +inp.value; set({ graphic: g, preset: '' }); };
      inp.onchange = () => flush();
      inp.ondblclick = () => { const g = st.graphic.slice(); g[+inp.dataset.i] = 0; set({ graphic: g, preset: '' }, true); };
    });
  }
  box.querySelectorAll('.eq-sl').forEach((el, i) => {
    const v = st.graphic[i] || 0, inp = el.querySelector('input');
    if (document.activeElement !== inp) inp.value = v;
    const at = (v + 12) / 24 * 100;
    inp.style.setProperty('--lo', Math.min(50, at).toFixed(1) + '%'); inp.style.setProperty('--hi', Math.max(50, at).toFixed(1) + '%');
    el.querySelector('b').textContent = (v > 0 ? '+' : v < 0 ? '−' : '') + Math.abs(v).toFixed(Math.abs(v) % 1 ? 1 : 0);
    el.classList.toggle('lit', Math.abs(v) > 0.01);
  });
}

function renderBand(i) {
  if (!sheet) return;
  const box = sheet.querySelector('.eq-band');
  if (st.mode !== 'parametric') { box.innerHTML = ''; return; }
  const chips = st.bands.map((b, k) => `<button class="eq-chip${k === i ? ' on' : ''}${b.on === false ? ' mute' : ''}" data-k="${k}">${k + 1}<small>${esc(fmtHz(b.freq))}</small></button>`).join('')
    + (st.bands.length < MAXB ? `<button class="eq-chip add" title="${$t('Добавить полосу')}">${icon('plus', 14)}</button>` : '');
  const b = st.bands[i];
  const ed = b ? `<div class="eq-ed">
      <select class="st-input eq-type">${TYPES().map(([v, t]) => `<option value="${v}"${b.type === v ? ' selected' : ''}>${t}</option>`).join('')}</select>
      <label><span>${$t('Частота')}</span><input class="st-input eq-num" data-f="freq" type="number" min="20" max="20000" step="1" value="${Math.round(b.freq)}"><em>${$t('Гц')}</em></label>
      <label class="${b.type === 'lowcut' || b.type === 'highcut' ? 'dis' : ''}"><span>${$t('Усиление')}</span><input class="st-input eq-num" data-f="gain" type="number" min="-24" max="24" step="0.5" value="${b.gain}"><em>${$t('дБ')}</em></label>
      <label><span>Q</span><input class="st-input eq-num" data-f="q" type="number" min="0.1" max="18" step="0.05" value="${b.q}"></label>
      <label class="toggle sm" title="${$t('Полоса включена')}"><input type="checkbox" class="eq-bon"${b.on === false ? '' : ' checked'}><i></i></label>
      <button class="btn icon eq-del" title="${$t('Удалить полосу')}">${icon('x', 15)}</button></div>` : `<div class="eq-ed none">${$t('Выберите точку на кривой или полосу ниже')}</div>`;
  box.innerHTML = `<div class="eq-chips">${chips}</div>${ed}`;
  box.querySelectorAll('.eq-chip[data-k]').forEach((c) => { c.onclick = () => { graph.sel = +c.dataset.k; renderBand(graph.sel); graph.draw(); }; });
  const add = box.querySelector('.eq-chip.add');
  if (add) add.onclick = () => {
    const used = st.bands.map((x) => x.freq);
    const freq = [1000, 3000, 300, 6000, 150, 600, 2000, 10000].find((f) => !used.some((u) => Math.abs(Math.log2(u / f)) < 0.4)) || 1000;
    const bands = [...st.bands.map((x) => ({ ...x })), { type: 'peak', freq, gain: 0, q: 1, on: true }].sort((x, y) => x.freq - y.freq);
    set({ bands, preset: '' }, true);
    graph.sel = bands.findIndex((x) => x.freq === freq); renderBand(graph.sel); graph.draw();
  };
  if (!b) return;
  const upd = (patch) => { const bands = st.bands.map((x) => ({ ...x })); Object.assign(bands[i], patch); set({ bands, preset: '' }, true); };
  box.querySelector('.eq-type').onchange = (e) => upd({ type: e.target.value, q: /shelf|cut/.test(e.target.value) ? 0.71 : 1 });
  box.querySelectorAll('.eq-num').forEach((inp) => { inp.onchange = () => { const v = +inp.value; if (Number.isFinite(v)) upd({ [inp.dataset.f]: clamp(v, +inp.min, +inp.max) }); }; });
  box.querySelector('.eq-bon').onchange = (e) => upd({ on: e.target.checked });
  box.querySelector('.eq-del').onclick = () => { const bands = st.bands.filter((_, k) => k !== i).map((x) => ({ ...x })); graph.sel = -1; set({ bands, preset: '' }, true); };
}

/* ---- the «Sound» panel: the switch, the preset and the curve; the editor opens from there */
export function panelHtml() {
  if (!st) return '';
  return `<div class="snd-eq${st.enabled ? ' on' : ''}">
    <div class="snd-row"><div class="snd-lbl"><b>${$t('Эквалайзер')}</b><small>${esc(st.enabled ? presetName() : $t('Выключен'))}</small></div>
      <label class="toggle"><input type="checkbox" class="snd-eq-on"${st.enabled ? ' checked' : ''} aria-label="${$t('Включить эквалайзер')}"><i></i></label></div>
    <button class="snd-eq-curve" title="${$t('Открыть эквалайзер')}"><canvas></canvas><span>${$t('Настроить')}${icon('chev', 14)}</span></button>
  </div>`;
}
export function wirePanel(body, onOpen) {
  const box = body.querySelector('.snd-eq');
  if (!box) return;
  const cv = box.querySelector('canvas');
  requestAnimationFrame(() => drawMini(cv));
  box.querySelector('.snd-eq-on').onchange = (e) => { set({ enabled: e.target.checked }, true); box.classList.toggle('on', e.target.checked); box.querySelector('.snd-lbl small').textContent = e.target.checked ? presetName() : $t('Выключен'); requestAnimationFrame(() => drawMini(cv)); };
  box.querySelector('.snd-eq-curve').onclick = () => { onOpen && onOpen(); openEditor(); };
}
