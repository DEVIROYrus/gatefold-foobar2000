/* Gatefold · fun/panel.js — the mode's settings: achievements. */
import { html, esc, cfg, setAchievements, setSetting } from './core.js';
import { modal } from './kit.js';
import * as Ach from './achievements.js';

import { $t } from '../i18n.js';
let open1 = null;
export function open() {
  if (open1) return;
  const body = html('<div class="fun-panel"></div>');

  const p = Ach.progress();
  const sec2 = html(`<section><h4>${$t('Достижения')}</h4>
    <label class="fun-row"><div><b>${$t('Собирать достижения')}</b><small>${$t('Тихо всплывают в углу на пять секунд. Без звука, без окон, воспроизведение не трогают.')}</small></div><span class="toggle"><input type="checkbox"><i></i></span></label>
    <div class="fun-row"><div><b>${$t('{0} из {1}', p.got, p.total)}</b><small>${$t('Часть условий скрыта до получения')}</small></div><button class="btn">${$t('Открыть все')}</button></div></section>`);
  const inp = sec2.querySelector('input'); inp.checked = cfg().ach;
  inp.onchange = () => setAchievements(inp.checked);
  sec2.querySelector('.btn').onclick = () => { m.close(); Ach.trophyRoom(); };
  body.appendChild(sec2);
  body.appendChild(html(`<p class="fun-hint">${$t('Это окно открывается правым щелчком по надписи «Gatefold» в заголовке. Десять щелчков по ней же включают и выключают режим.')}</p>`));

  const m = modal({ title: $t('Режим приколов'), body, cls: 'fun-panel-back', onClose: () => { open1 = null; },
    actions: [{ label: $t('Выключить режим и стереть данные'), fn: () => { setSetting('funMode', false); } }, { label: $t('Готово'), primary: true }] });
  open1 = m;
}
export const close = () => open1 && open1.close();
