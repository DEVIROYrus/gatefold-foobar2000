/*
 * Gatefold · history.js — Gatefold's own listening history, for Home.
 * A track counts as played after 30 s (or half of a shorter track). Kept in IndexedDB, newest
 * last, at most 20 000 plays (years of listening for most people). Works without foo_playcount.
 */
import * as IDB from './idb.js';
import { albumKeyOf } from './bridge.js';

const KEY = 'history.v1', MAX = 20000, AFTER = 30;
let list = null, loading = null, pending = null, timer = 0;
export const events = new EventTarget();

async function load() {
  if (list) return list;
  if (!loading) loading = IDB.kvGet(KEY, []).then((v) => (list = Array.isArray(v) ? v : [])).catch(() => (list = []));
  return loading;
}
const save = () => { clearTimeout(timer); timer = setTimeout(() => IDB.kvSet(KEY, list.slice(-MAX)).catch(() => {}), 1500); };

/** the playing track changed: it is recorded once it has played long enough */
export function nowPlaying(t) {
  pending = t && (t.path || t.handle) ? { t, need: Math.min(AFTER, (t.duration || AFTER * 2) / 2), heard: 0 } : null;
}
/** counts the time music actually plays (also while the window is hidden) */
export function init(isPlaying) {
  let prev = Date.now();
  setInterval(() => {
    const now = Date.now(), dt = (now - prev) / 1000; prev = now;
    const p = pending; if (!p || !isPlaying() || dt > 10) return;
    p.heard += dt;
    if (p.heard >= p.need) { pending = null; record(p.t); }
  }, 2000);
}
async function record(t) {
  await load();
  list.push({ h: t.handle || t.path, p: t.path, ti: t.title, ar: t.artist, aa: t.albumArtist, al: t.album, y: t.year, d: Math.round(t.duration || 0), ts: Date.now() });
  if (list.length > MAX * 1.1) list = list.slice(-MAX);
  save();
  events.dispatchEvent(new Event('change'));
}

export async function all() { return (await load()).slice(); }
/** today's listening: tracks and seconds since local midnight */
export async function today() {
  const l = await load(), from = new Date().setHours(0, 0, 0, 0);
  let n = 0, s = 0;
  for (let i = l.length - 1; i >= 0 && l[i].ts >= from; i--) { n++; s += l[i].d || 0; }
  return { n, s };
}
export const albumOf = (e) => albumKeyOf(e.aa || e.ar, e.al);

/** last played entry, or null */
export async function last() { const l = await load(); return l[l.length - 1] || null; }

/** albums played between two times, most plays first: [{ e, n }] */
export async function albumsBetween(from, to) {
  const m = new Map();
  for (const e of await load()) if (e.ts >= from && e.ts < to && e.al) { const k = albumOf(e); const x = m.get(k); if (x) x.n++; else m.set(k, { e, n: 1 }); }
  return [...m.values()].sort((a, b) => b.n - a.n);
}
/** artists played since a time, most plays first: [{ name, n }] */
export async function artistsSince(from) {
  const m = new Map();
  for (const e of await load()) if (e.ts >= from) { const a = e.aa || e.ar; if (a) m.set(a, (m.get(a) || 0) + 1); }
  return [...m].map(([name, n]) => ({ name, n })).sort((a, b) => b.n - a.n);
}
/** albums once played a lot but not for `quietDays` */
export async function forgotten(quietDays = 90, minPlays = 8) {
  const m = new Map(), cut = Date.now() - quietDays * 864e5;
  for (const e of await load()) { if (!e.al) continue; const k = albumOf(e); const x = m.get(k) || { e, n: 0, lastTs: 0 }; x.n++; x.lastTs = Math.max(x.lastTs, e.ts); x.e = e; m.set(k, x); }
  return [...m.values()].filter((x) => x.n >= minPlays && x.lastTs < cut).sort((a, b) => b.n - a.n);
}
