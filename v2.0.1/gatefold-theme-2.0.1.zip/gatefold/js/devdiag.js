/*
 * Gatefold · devdiag.js — development builds only (loaded by devreload.js when dev-stamp.txt exists).
 * Writes _dev/out/diag.json: window size and scaling, settings without private values, the active
 * screen, recent log lines and every label that is cut off or sticks out of its panel. Reads
 * _dev/cmd.txt ("<id> go <view>" | "<id> diag" | "<id> set <key> <json>") so a screen can be checked
 * on the real collection without touching the computer. Nothing here runs in a release.
 */
import { logLines } from './bridge.js';
import { allSettings, setSetting } from './settings.js';
import { router } from './ui.js';

const PRIVATE = /key|token|folder|dir|path|pattern|custom/i;
let base = '', lastCmd = '', evalOut;
const fb = () => window.fb2k;

const sel = (el) => {
  if (!el || el === document.body) return 'body';
  let s = el.tagName.toLowerCase();
  if (el.id) return s + '#' + el.id;
  if (el.classList.length) s += '.' + [...el.classList].slice(0, 3).join('.');
  const p = el.parentElement;
  return (p && p !== document.body ? sel(p) + ' > ' : '') + s;
};
const visible = (el) => { const r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0 && r.bottom > 0 && r.top < innerHeight && r.right > 0 && r.left < innerWidth && getComputedStyle(el).visibility !== 'hidden'; };
const rectOf = (el) => { if (!el) return null; const r = el.getBoundingClientRect(); return [Math.round(r.left), Math.round(r.top), Math.round(r.width), Math.round(r.height)]; };

function findProblems() {
  const cut = [], out = [], tiny = [];
  const islands = ['sidebar', 'main', 'playerbar'].map((id) => document.getElementById(id)).filter(Boolean);
  for (const el of document.querySelectorAll('body *')) {
    if (el.closest('svg, canvas, #bg, .tooltip, template, script, style')) continue;
    if (!visible(el)) continue;
    const cs = getComputedStyle(el);
    const text = (el.childElementCount === 0 ? el.textContent : [...el.childNodes].filter((n) => n.nodeType === 3).map((n) => n.textContent).join('')).trim();
    // a label cut with an ellipsis or clipped
    if (text && el.scrollWidth > el.clientWidth + 1 && (cs.textOverflow === 'ellipsis' || cs.overflowX === 'hidden' || cs.overflowX === 'clip')) {
      cut.push({ el: sel(el), text: text.slice(0, 60), w: el.clientWidth, need: el.scrollWidth });
    }
    // wraps where it should not (a segmented control, a button) — more than one line of a short label
    if (text && /^(BUTTON|LABEL)$/.test(el.tagName) && text.length < 30 && el.getClientRects().length === 1) {
      const lh = parseFloat(cs.lineHeight) || parseFloat(cs.fontSize) * 1.3;
      if (el.clientHeight > lh * 1.9 && cs.whiteSpace !== 'nowrap' && el.clientHeight < 200) tiny.push({ el: sel(el), text: text.slice(0, 40), h: el.clientHeight });
    }
    // sticks out of its island to the right
    const isl = islands.find((i) => i.contains(el));
    if (isl && el.childElementCount < 40) {
      const r = el.getBoundingClientRect(), ir = isl.getBoundingClientRect();
      if (r.right > ir.right + 2 && r.width < ir.width * 2) out.push({ el: sel(el), right: Math.round(r.right), island: isl.id, islandRight: Math.round(ir.right) });
    }
  }
  return { cut: cut.slice(0, 80), cutTotal: cut.length, wrapped: tiny.slice(0, 30), outside: out.slice(0, 40), outsideTotal: out.length };
}

async function snapshot(note = '') {
  if (!base) return;
  const z = await fb().invoke('window.getZoom').catch(() => null);
  const st = {};
  for (const [k, v] of Object.entries(allSettings())) if (!PRIVATE.test(k)) st[k] = v;
  const view = document.querySelector('.view.active');
  const diag = {
    at: new Date().toISOString(), note, cmd: lastCmd,
    window: { w: innerWidth, h: innerHeight, dpr: devicePixelRatio, screen: [screen.width, screen.height], zoom: z && z.success !== false ? { zoom: z.zoom, dpiScale: z.dpiScale, text: z.textScaleFactor } : null },
    route: [router.current, router.arg && typeof router.arg === 'object' ? Object.keys(router.arg) : router.arg],
    view: view ? view.id : '', bodyClass: document.body.className, rootStyle: document.documentElement.getAttribute('style') || '',
    rects: { sidebar: rectOf(document.getElementById('sidebar')), main: rectOf(document.getElementById('main')), player: rectOf(document.getElementById('playerbar')), view: rectOf(view) },
    font: { base: getComputedStyle(document.body).fontSize, family: getComputedStyle(document.body).fontFamily.slice(0, 60) },
    nav: [...document.querySelectorAll('#sidebar .nav-item')].filter(visible).map((n) => (n.dataset.view || n.className) + ':' + n.textContent.trim().replace(/\s+/g, ' ').slice(0, 30)),
    eval: evalOut,
    problems: findProblems(),
    settings: st,
    log: logLines.slice(-80),
    html: view ? view.outerHTML.replace(/src="data:[^"]{40,}"/g, 'src="data:…"').replace(/url\(&quot;data:[^)]{40,}\)/g, 'url(data:…)').slice(0, 400000) : '',
  };
  await fb().invoke('file.write', { path: base + '\\_dev\\out\\diag.json', content: JSON.stringify(diag, null, 1), atomic: true }).catch(() => {});
}

let primed = false;
async function poll() {
  try {
    const r = await fb().invoke('file.read', { path: base + '\\_dev\\cmd.txt' });
    const line = r && r.success !== false && typeof r.content === 'string' ? r.content.trim() : '';
    const [id, cmd, ...rest] = line.split(/\s+/);
    // a command left over from before this start is not run again: only new ones, written while Gatefold is open
    if (!primed) { primed = true; lastCmd = id || ''; }
    else if (id && id !== lastCmd) {
      lastCmd = id;
      if (cmd === 'go' && rest[0]) { router.go(rest[0], rest[1] ? JSON.parse(rest.slice(1).join(' ')) : null); await new Promise((ok) => setTimeout(ok, 2500)); }
      if (cmd === 'set' && rest[0]) { setSetting(rest[0], JSON.parse(rest.slice(1).join(' '))); await new Promise((ok) => setTimeout(ok, 1500)); }
      // a check run on the real collection: an async function body; its answer goes into diag.json
      if (cmd === 'eval' && rest.length) {
        let out;
        try { out = await new Function(`return (async () => { ${rest.join(' ')} })()`)(); } catch (e) { out = { error: String(e && e.stack || e) }; }
        evalOut = out;
      }
      if (cmd === 'scroll' && rest[0]) { const v = document.querySelector('.view.active'); const s = v && ([v, ...v.querySelectorAll('*')].find((e) => e.scrollHeight > e.clientHeight + 20 && /auto|scroll/.test(getComputedStyle(e).overflowY))); if (s) s.scrollTop = +rest[0]; await new Promise((ok) => setTimeout(ok, 800)); }
      await snapshot(line);
    }
  } catch {}
  setTimeout(poll, 2000);
}

export function startDiag(dir) {
  base = dir;
  setTimeout(() => snapshot('start'), 6000);
  setTimeout(poll, 7000);
  window.addEventListener('resize', () => { clearTimeout(startDiag.t); startDiag.t = setTimeout(() => snapshot('resize'), 1500); });
}
