/*
 * Gatefold · devreload.js — reloads the page when a development build is copied over it.
 * Only active when dev-stamp.txt sits in the template folder (development builds). It is looked
 * for on disk first, so release builds never request a missing file.
 */
const URL_ = 'dev-stamp.txt', EVERY = 1500;
let last = null, timer = 0;

async function stamp() {
  try {
    const r = await fetch(`${URL_}?t=${Date.now()}`, { cache: 'no-store' });
    return r.ok ? (await r.text()).trim() : null;
  } catch { return null; }
}

async function tick() {
  const s = await stamp();
  // missing for a moment (a new build being copied over): keep looking — stopping here left the page on the old build
  if (s == null) { timer = setTimeout(tick, EVERY * 2); return; }
  if (last != null && s !== last) {
    // wait a moment so a copy still in progress can finish, then reload
    setTimeout(() => location.reload(), 400);
    return;
  }
  last = s;
  timer = setTimeout(tick, EVERY);
}

async function isDevBuild() {
  try {
    const fb = window.fb2k;
    if (!fb || !fb.invoke) return false;
    const src = await fb.invoke('webview.getSource');
    const dir = src && src.success !== false && src.templatesDirectory && src.templateName ? `${src.templatesDirectory}\\${src.templateName}\\${URL_}` : '';
    if (!dir) return false;
    const ex = await fb.invoke('file.exists', { path: dir });
    const dev = !!(ex && ex.success !== false && (ex.exists ?? ex.result));
    if (dev) import('./devdiag.js').then((m) => m.startDiag(`${src.templatesDirectory}\\${src.templateName}`)).catch(() => {});
    return dev;
  } catch { return false; }
}

let checking = false;
export function startDevReload() { if (timer || checking || last != null) return; checking = true; isDevBuild().then((dev) => { checking = false; if (dev && !timer) tick(); }); }
// the bridge may arrive a moment after the page
setTimeout(startDevReload, 1500); setTimeout(startDevReload, 6000);
