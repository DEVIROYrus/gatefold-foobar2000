/* Gatefold · panels.js — Settings and Covers screens */
import * as LYS from './lyrics-sources.js';
import { esc, fmtTime, plural, call, ok, debounce } from './bridge.js';
import { settings, setSetting, resetSettings, DEFAULTS, PRESETS } from './settings.js';
import { router, $, h, icon, toast, backButton } from './ui.js';
import { current, FIXED, customPalette } from './theme.js';
import * as CF from './coverfetch.js';
import * as AA from './artistart.js';
import { openFolder as openArtistFolder, loadArtists, artistsState, jobOf as artistJob } from './artists.js';
import * as Q from './coverquality.js';
import { artDiag } from './artbytes.js';
import * as Lib from './library.js';
import * as TC from './thumbcache.js';
import * as Canvas from './canvas.js';

import { $t, lang, LANGS } from './i18n.js';
import { VERSION } from './version.js';
import { settingsSection as updatesSection } from './update-ui.js';
import { fb2kGroups } from './fb2kprefs.js';
import * as SoundUI from './ml/sound-ui.js';
import { albumKey } from './sorting.js';
import * as Loud from './loudness.js';
import * as Sound from './ml/sound.js';
import * as LoudUI from './loudness-ui.js';
import * as Cx from './columns.js';
import * as CoverPick from './coverpick.js';
import * as Own from './ownart.js';
import * as Names from './artistnames.js';
import * as Spectra from './spectra.js';
import * as Seek from './seekstyles.js';
const CF_pl = (n) => plural(n, 'файл', 'файла', 'файлов');

// ---------------------------------------------------------------- control builders
/* settings rows: a label, a short explanation where it helps, and the control (Islands 2) */
const aria = (label) => esc(String(label).replace(/<[^>]+>/g, '').trim());
const lbl = (label, hint) => `<div class="lbl"><b>${label}</b>${hint ? `<small>${hint}</small>` : ''}</div>`;
function toggle(key, label, hint, onChange) {
  const el = h(`<div class="row">${lbl(label, hint)}<label class="toggle"><input type="checkbox" aria-label="${aria(label)}"><i></i></label></div>`);
  const inp = el.querySelector('input');
  inp.checked = !!settings[key];
  inp.onchange = () => { setSetting(key, inp.checked); onChange && onChange(inp.checked); };
  return el;
}
function seg(key, label, hint, options, onChange) {
  const el = h(`<div class="row">${lbl(label, hint)}<div class="seg"></div></div>`);
  const box = el.querySelector('.seg');
  for (const [val, text] of options) {
    const b = h(`<button>${text}</button>`);
    if (String(settings[key]) === String(val)) b.classList.add('on');
    b.onclick = () => { box.querySelectorAll('button').forEach((x) => x.classList.remove('on')); b.classList.add('on'); setSetting(key, val); onChange && onChange(val); };
    box.appendChild(b);
  }
  return el;
}
/* one choice for what moves under the track on «Сейчас играет»: nothing, the spectrum or the VU meters */
function vizRow() {
  const el = h(`<div class="row"><div class="lbl"><b>${$t('Под треком')}</b></div><div class="seg"></div></div>`);
  const box = el.querySelector('.seg');
  const now = settings.vuMeters ? 'vu' : settings.visualizer ? 'spectrum' : 'none';
  for (const [v, text] of [['none', $t('Ничего')], ['spectrum', $t('Спектр')], ['vu', $t('VU-метры')]]) {
    const b = h(`<button class="${v === now ? 'on' : ''}">${text}</button>`);
    b.onclick = () => { setSetting('visualizer', v === 'spectrum'); setSetting('vuMeters', v === 'vu'); setTimeout(renderSettings, 30); };
    box.append(b);
  }
  return el;
}
/* the spectrum's look: a card per style, each a small live preview in the interface's colours */
let specPreview = 0;
function spectrumStyleRow() {
  const names = { bars: $t('Столбики'), wave: $t('Волна'), line: $t('Линия'), dots: $t('Точки'), mirror: $t('Отражение'), aurora: $t('Сияние') };
  const el = h(`<div class="row st-src st-spec"><div class="lbl"><b>${$t('Стиль спектра')}</b></div><div class="spec-cards" role="radiogroup"></div></div>`);
  const box = el.querySelector('.spec-cards');
  const cur = settings.spectrumStyle || 'bars';
  const cards = Spectra.STYLES.map((id) => {
    const b = h(`<button class="spec-card${id === cur ? ' on' : ''}" role="radio" aria-checked="${id === cur}"><canvas></canvas><span class="nm">${names[id]}</span></button>`);
    b.onclick = () => { setSetting('spectrumStyle', id); box.querySelectorAll('.spec-card').forEach((x) => { x.classList.toggle('on', x === b); x.setAttribute('aria-checked', String(x === b)); }); };
    box.append(b);
    return [id, b.querySelector('canvas')];
  });
  cancelAnimationFrame(specPreview);
  const born = performance.now();
  const tick = (t) => {
    if (!el.isConnected && t - born > 1500) return;   // the settings page was left (or redrawn)
    const cs = getComputedStyle(document.documentElement);
    const col = { a: current.palette ? current.palette.accent.hex : cs.getPropertyValue('--accent').trim() || '#8fb4ff', b: current.palette ? current.palette.accent2.hex : '#c49bff', dim: current.palette && !current.palette.dark ? 'rgba(0,0,0,.12)' : 'rgba(255,255,255,.12)' };
    for (const [id, cv] of cards) {
      const r = cv.getBoundingClientRect(); if (!r.width) continue;
      const d = Math.min(2, devicePixelRatio || 1), w = Math.round(r.width * d), hh = Math.round(r.height * d);
      if (cv.width !== w || cv.height !== hh) { cv.width = w; cv.height = hh; }
      const c = cv.getContext('2d'); c.clearRect(0, 0, w, hh);
      const [bars, peaks] = Spectra.sample(id === 'dots' ? 40 : 48, t);
      Spectra.paint(id, c, w, hh, bars, peaks, d, col, t);
    }
    specPreview = requestAnimationFrame(tick);
  };
  specPreview = requestAnimationFrame(tick);
  return el;
}
/* the seek bar's look: a card per style, each a small seek bar half played (the live one moving) */
let seekPreview = 0;
function seekStyleRow() {
  const names = { bars: $t('Столбики'), peaks: $t('Пики'), smooth: $t('Контур'), dots: $t('Точки'), live: $t('Живой спектр'), line: $t('Линия') };
  const el = h(`<div class="row st-src st-spec"><div class="lbl"><b>${$t('Полоса перемотки')}</b><small>${$t('Волна трека строится foobar2000 в фоне и кэшируется')}</small></div><div class="spec-cards seek-cards" role="radiogroup"></div></div>`);
  const box = el.querySelector('.spec-cards');
  const cur = settings.waveformSeek === false ? 'line' : (settings.seekStyle || 'bars');
  const cards = Seek.STYLES.map((id) => {
    const b = h(`<button class="spec-card${id === cur ? ' on' : ''}" role="radio" aria-checked="${id === cur}"><canvas></canvas><span class="nm">${names[id]}</span></button>`);
    b.onclick = () => {
      setSetting('waveformSeek', id !== 'line');
      setSetting('seekStyle', id);
      box.querySelectorAll('.spec-card').forEach((x) => { x.classList.toggle('on', x === b); x.setAttribute('aria-checked', String(x === b)); });
    };
    box.append(b);
    return [id, b.querySelector('canvas')];
  });
  // a made-up track: louder in the middle, with some rhythm
  const wav = (n) => Float32Array.from({ length: n }, (_, i) => { const x = i / n; return Math.min(1, 0.25 + 0.55 * Math.sin(Math.PI * x) ** 0.6 * (0.6 + 0.4 * Math.abs(Math.sin(i * 0.9) * Math.cos(i * 0.37)))); });
  cancelAnimationFrame(seekPreview);
  const born = performance.now();
  const tick = (t) => {
    if (!el.isConnected && t - born > 1500) return;
    const cs = getComputedStyle(document.documentElement);
    const a = current.palette ? current.palette.accent.hex : cs.getPropertyValue('--accent').trim() || '#8fb4ff';
    const b2 = current.palette ? current.palette.accent2.hex : '#c49bff';
    const dim = current.palette && !current.palette.dark ? 'rgba(0,0,0,.16)' : 'rgba(255,255,255,.18)';
    for (const [id, cv] of cards) {
      const r = cv.getBoundingClientRect(); if (!r.width) continue;
      const d = Math.min(2, devicePixelRatio || 1), w = Math.round(r.width * d), hh = Math.round(r.height * d);
      if (cv.width !== w || cv.height !== hh) { cv.width = w; cv.height = hh; }
      const c = cv.getContext('2d'); c.clearRect(0, 0, w, hh);
      const bh = Math.round(hh * 0.42), y0 = Math.round((hh - bh) / 2), x = Math.round(w * 0.45);
      c.save(); c.translate(0, y0);
      if (id === 'line') {
        c.fillStyle = dim; c.beginPath(); c.roundRect(0, bh / 2 - 2 * d, w, 4 * d, 2 * d); c.fill();
        c.fillStyle = a; c.beginPath(); c.roundRect(0, bh / 2 - 2 * d, x, 4 * d, 2 * d); c.fill();
        c.beginPath(); c.arc(x, bh / 2, 6 * d, 0, Math.PI * 2); c.fill();
      } else {
        const G = Seek.geometry(id), step = Math.round(G.step * d), bw = Math.max(1, Math.round(G.bw * d)), n = Math.floor(w / step);
        let vals = wav(n);
        if (id === 'live') { const [bars] = Spectra.sample(48, t); vals = Seek.spread(bars, n, new Float32Array(n)); }
        const kind = id === 'live' ? 'bars' : id;
        for (const [col, from, to] of [[dim, x, w], [a, 0, x]]) {
          c.save(); c.beginPath(); c.rect(from, 0, to - from, bh); c.clip();
          if (col === a) { const g = c.createLinearGradient(0, 0, w, 0); g.addColorStop(0, b2); g.addColorStop(1, a); c.fillStyle = g; } else c.fillStyle = col;
          Seek.shape(kind, c, w, bh, vals, d, step, bw);
          c.restore();
        }
      }
      c.restore();
    }
    seekPreview = requestAnimationFrame(tick);
  };
  seekPreview = requestAnimationFrame(tick);
  return el;
}
function range(key, label, hint, min, max, step, fmt) {
  const el = h(`<div class="row"><div class="lbl"><b>${label} <span class="num" style="color:var(--text-3);font-weight:500"></span></b>${hint ? `<small>${hint}</small>` : ''}</div><input class="range" type="range" min="${min}" max="${max}" step="${step}"></div>`);
  const inp = el.querySelector('input'), out = el.querySelector('.num');
  const paint = () => { inp.style.setProperty('--p', ((inp.value - min) / (max - min) * 100) + '%'); out.textContent = fmt(+inp.value); };
  inp.value = settings[key]; paint();
  inp.oninput = () => { paint(); setSetting(key, +inp.value); };
  return el;
}
const card = (title, desc, wide) => h(`<div class="card${wide ? ' wide' : ''}"><h3>${title}</h3>${desc ? `<div class="desc">${desc}</div>` : ''}</div>`);

// ---------------------------------------------------------------- settings
/* Two panes: sections on the left (with search), one readable column of grouped rows on the
   right. No masonry: every group is as tall as its content, nothing leaves holes. */
const ytGet = (k, d) => { try { const v = localStorage.getItem('aurora.yt.' + k); return v == null ? d : JSON.parse(v); } catch { return d; } };
const ytSet = (k, v) => { try { localStorage.setItem('aurora.yt.' + k, JSON.stringify(v)); } catch {} dispatchEvent(new Event('aurora:yt-pref')); };
function lsSeg(label, hint, options, get, set) {
  const el = h(`<div class="row">${lbl(label, hint)}<div class="seg"></div></div>`);
  const box = el.querySelector('.seg');
  for (const [val, text] of options) {
    const b = h(`<button>${text}</button>`);
    if (String(get()) === String(val)) b.classList.add('on');
    b.onclick = () => { box.querySelectorAll('button').forEach((x) => x.classList.remove('on')); b.classList.add('on'); set(val); };
    box.appendChild(b);
  }
  return el;
}
function lsToggle(label, hint, get, set) {
  const el = h(`<div class="row">${lbl(label, hint)}<label class="toggle"><input type="checkbox" aria-label="${aria(label)}"><i></i></label></div>`);
  const inp = el.querySelector('input'); inp.checked = !!get(); inp.onchange = () => set(inp.checked);
  return el;
}
/* «A; B» is two artists. «;» and multi-value tags by default; «/ , & feat.» on demand, after a look at
   every name in the library they would split — with a «never split» mark for AC/DC and its kind. */
function artistSplitRows() {
  const draft = { ids: [...(settings.artistSplit || [';'])], keep: [...(settings.artistKeep || [])] };
  const chips = h(`<div class="row"><div class="lbl"><b>${$t('Разделители')}</b></div><div class="seg multi" role="group"></div></div>`);
  // your own separators («x», «vs.», «+»…): typed in, shown as chips that a click removes
  const own = h(`<div class="row sep-own"><div class="lbl"><b>${$t('Свои разделители')}</b><small class="dim">${$t('Например «x», «vs.» или «+». Слово разделяет имя, только когда стоит между пробелами.')}</small></div><div class="sep-own-box"><span class="sep-own-l"></span><input class="filter sep-own-in" type="text" maxlength="12" spellcheck="false" placeholder="${$t('Добавить…')}" aria-label="${$t('Свои разделители')}"></div></div>`);
  const ownIn = own.querySelector('.sep-own-in');
  const addOwn = () => {
    const t = Names.customText(ownIn.value); ownIn.value = '';
    if (!t) return;
    const lt = t.toLowerCase();
    const built = Names.SEPARATORS.find((sp) => sp.id === lt || sp.label === lt || (sp.id === 'feat' && /^(feat\.?|ft\.?|featuring)$/.test(lt)));
    const id = built ? built.id : Names.CUSTOM + t;
    if (!draft.ids.some((x) => x.toLowerCase() === id.toLowerCase())) draft.ids.push(id);
    paint();
  };
  ownIn.onkeydown = (e) => { if (e.key === 'Enter') { e.preventDefault(); e.stopPropagation(); addOwn(); } };
  ownIn.onchange = addOwn;
  const note = h(`<div class="row st-note"><div class="lbl"><small>${$t('Значения многозначного тега (несколько полей «album artist») — всегда разные исполнители. Альбом «A; B» появится и у A, и у B.')}</small></div></div>`);
  const list = h(`<div class="row sep-pv"><div class="lbl"><div class="sep-pv-h"><b class="sep-pv-t"></b><input class="filter sep-pv-q" type="search" placeholder="${$t('Фильтр…')}" spellcheck="false" aria-label="${$t('Фильтр…')}" hidden></div><div class="sep-pv-l"></div></div></div>`);
  // every name can be reached: a filter for long lists, and «Show more» instead of a silent cut at 80
  const PAGE = 80, q = list.querySelector('.sep-pv-q');
  let shown = PAGE;
  q.oninput = debounce(() => { shown = PAGE; list.querySelector('.sep-pv-l').scrollTop = 0; paint(); }, 150);
  const acts = actions();
  const apply = button($t('Применить'), async () => {
    setSetting('artistSplit', draft.ids); setSetting('artistKeep', draft.keep);
    apply.disabled = true;
    await Lib.rebuildLibrary(); await loadArtists(true);
    apply.disabled = false; paint();
    toast($t('Исполнители пересобраны'));
  }, 'primary');
  acts.append(apply);
  const same = () => JSON.stringify([draft.ids.slice().sort(), draft.keep.slice().sort()]) === JSON.stringify([(settings.artistSplit || [';']).slice().sort(), (settings.artistKeep || []).slice().sort()]);
  const box = chips.querySelector('.seg');
  for (const sp of Names.SEPARATORS) {
    const b = h(`<button aria-pressed="false">${esc(sp.label)}</button>`);
    b.onclick = () => { const i = draft.ids.indexOf(sp.id); if (i >= 0) draft.ids.splice(i, 1); else draft.ids.push(sp.id); paint(); };
    b.dataset.id = sp.id; box.append(b);
  }
  function paint() {
    box.querySelectorAll('button').forEach((b) => { const on = draft.ids.includes(b.dataset.id); b.classList.toggle('on', on); b.setAttribute('aria-pressed', String(on)); });
    const ol = own.querySelector('.sep-own-l'); ol.innerHTML = '';
    for (const id of draft.ids.filter((x) => String(x).startsWith(Names.CUSTOM))) {
      const b = h(`<button class="sep-own-c" title="${$t('Убрать')}"><span></span>${icon('x', 12)}</button>`);
      b.querySelector('span').textContent = id.slice(Names.CUSTOM.length);
      b.onclick = () => { draft.ids = draft.ids.filter((x) => x !== id); paint(); };
      ol.append(b);
    }
    const pv = Names.preview(Lib.artistNamesSeen(), draft.ids, draft.keep);
    const split = pv.filter((x) => !draft.keep.some((k) => k.toLowerCase() === x.name.toLowerCase()));
    list.querySelector('.sep-pv-t').textContent = pv.length ? $t('Будут разделены: {0}', split.length) : $t('В медиатеке нет имён, которые эти разделители разделят');
    q.hidden = pv.length <= PAGE;
    const f = q.hidden ? '' : q.value.trim().toLowerCase();
    const rows = f ? pv.filter((x) => x.name.toLowerCase().includes(f) || x.parts.some((p) => p.toLowerCase().includes(f))) : pv;
    const l = list.querySelector('.sep-pv-l'), top = l.scrollTop; l.innerHTML = '';
    for (const x of rows.slice(0, shown)) {
      const kept = draft.keep.some((k) => k.toLowerCase() === x.name.toLowerCase());
      const it = h(`<label class="sep-pv-i${kept ? ' kept' : ''}"><input type="checkbox"${kept ? '' : ' checked'}><span class="nm"></span><span class="arrow">→</span><span class="parts"></span></label>`);
      it.querySelector('.nm').textContent = x.name;
      it.querySelector('.parts').textContent = x.parts.join(' · ');
      it.title = $t('Снимите флажок, чтобы это имя никогда не разделялось');
      it.querySelector('input').onchange = (e) => { draft.keep = draft.keep.filter((k) => k.toLowerCase() !== x.name.toLowerCase()); if (!e.target.checked) draft.keep.push(x.name); paint(); };
      l.append(it);
    }
    if (rows.length > shown) {
      const more = h(`<button class="btn sm sep-pv-more">${$t('Показать ещё ({0})', rows.length - shown)}</button>`);
      more.onclick = () => { shown += 400; paint(); };
      l.append(more);
    }
    if (f && !rows.length) l.append(h(`<small class="dim sep-pv-none">${$t('Ничего не найдено')}</small>`));
    l.scrollTop = top;
    apply.disabled = same();
  }
  paint();
  // the names of every track arrive with the library: paint again once it is read
  if (!Lib.artistNamesSeen().length) Lib.getAllAlbums().then(paint);
  return [chips, own, note, list, acts];
}
/* «Своя тема»: your background and accents; the palette builder keeps text readable and moves an accent
   that would vanish on the background (and says so). Export / import as a small .json file. */
const seedTheme = () => { const p = current.palette; return p ? { bg: p.bg.hex, accent: p.accent.hex, accent2: p.accent2.hex } : { bg: '#1c1f2b', accent: '#8f9cff', accent2: '#6cc4d8' }; };
function customThemeRows() {
  const t = settings.customTheme || seedTheme();
  const p = customPalette(t);
  const rows = [];
  const color = (key, label) => {
    const v = t[key] || '';
    const el = h(`<div class="row ct-row"><div class="lbl"><b>${label}</b></div><div class="ct-in"><span class="ct-hex">${esc(v || '—')}</span><label class="ct-sw" style="--c:${esc(v || 'transparent')}"><input type="color" value="${esc(v || p.accent2.hex)}"></label></div></div>`);
    const inp = el.querySelector('input'); let tm = 0;
    inp.oninput = () => {
      el.querySelector('.ct-sw').style.setProperty('--c', inp.value); el.querySelector('.ct-hex').textContent = inp.value;
      clearTimeout(tm); tm = setTimeout(() => { setSetting('customTheme', { ...(settings.customTheme || t), [key]: inp.value }); }, 80);
    };
    inp.onchange = () => setTimeout(renderSettings, 120);
    return el;
  };
  rows.push(color('bg', $t('Фон')), color('accent', $t('Акцент')), color('accent2', $t('Второй акцент')));
  if (p && p.adjusted > 0.02) rows.push(h(`<div class="row st-note"><div class="lbl"><small>${$t('Акцент чуть изменён, чтобы оставаться заметным на фоне')} · ${$t('Контраст {0}:1', p.accentContrast.toFixed(1))}</small></div></div>`));
  rows.push(actions(
    button($t('Экспорт…'), async () => {
      const r = await call('dialog.saveFile', { defaultName: 'gatefold-theme.json', filters: [{ name: 'Gatefold theme', extensions: ['json'] }] });
      if (!ok(r) || r.canceled || !r.filePath) return;
      const w = await call('file.write', { path: r.filePath, content: JSON.stringify({ gatefoldTheme: 1, ...(settings.customTheme || t) }, null, 2) });
      toast(ok(w) ? $t('Тема сохранена') : esc(w.error || ''));
    }),
    button($t('Импорт…'), async () => {
      const r = await call('dialog.openFile', { filters: [{ name: 'Gatefold theme', extensions: ['json'] }] });
      const path = ok(r) && !r.canceled && (r.filePath || (r.filePaths || [])[0]);
      if (!path) return;
      const f = await call('file.read', { path });
      const x = parseTheme(ok(f) ? f.content : '');
      if (!x) { toast($t('Это не файл темы Gatefold')); return; }
      setSetting('customTheme', x); setSetting('colorSource', 'custom'); setTimeout(renderSettings, 60);
      toast($t('Тема загружена'));
    }),
    button($t('Сбросить'), () => { setSetting('customTheme', seedTheme()); setTimeout(renderSettings, 60); })));
  return rows;
}
/** a theme file (or text): { bg, accent, accent2? } as #rrggbb, or null */
export function parseTheme(text) {
  let o; try { o = JSON.parse(text); } catch { return null; }
  if (!o || typeof o !== 'object') return null;
  const hex = (v) => (typeof v === 'string' && /^#[0-9a-f]{6}$/i.test(v.trim()) ? v.trim().toLowerCase() : '');
  const t = { bg: hex(o.bg), accent: hex(o.accent), accent2: hex(o.accent2) };
  if (!t.accent || !t.bg) return null;
  if (!t.accent2) delete t.accent2;
  return t;
}
/* «Здоровье коллекции»: what needs care in the library, each with a way to fix it */
function healthRows() {
  const box = h('<div class="hl-list"><div class="row"><div class="lbl"><small>…</small></div></div></div>');
  Lib.getAllAlbums().then((albums) => {
    albums = albums || [];
    const noYear = albums.filter((a) => !/\d{4}/.test(String(a.year || a.date || '')));
    const noGenre = albums.filter((a) => !String(a.genre || '').trim());
    const groups = new Map(); for (const a of albums) { const k = albumKey(a); groups.set(k, (groups.get(k) || []).concat(a)); }
    const dups = [...groups.values()].filter((g) => g.length > 1).flat();
    const cs = CF.getStats(), rev = CF.getReview().length;
    const ls = Loud.state, ss = Sound.state;
    const pick = (list) => async (e) => {
      const r = e.currentTarget.getBoundingClientRect();
      const { popupMenu } = await import('./ui.js');
      const id = await popupMenu(list.slice(0, 40).map((a, i) => ({ id: i, label: `${a.albumArtist || a.artist} — ${a.name}` })), r.left, r.bottom + 4);
      if (id != null) router.go('album', list[id]);
    };
    const count = (n) => (n ? `${n} ${plural(n, 'альбом', 'альбома', 'альбомов')}` : $t('всё в порядке'));
    const row = (ic, title, value, good, act) => { const el = h(`<div class="row hl-row"><span class="hl-ic${good ? ' ok' : ''}">${icon(ic, 16)}</span><div class="lbl"><b></b><small></small></div></div>`); el.querySelector('b').textContent = title; el.querySelector('small').textContent = value; if (act) el.append(act); return el; };
    box.replaceChildren(
      row('image', $t('Обложки'), rev ? $t('{0} ждут проверки', rev) : $t('найдено {0}, не найдено {1}', cs.ok || 0, cs.nf || 0), !rev, button($t('Открыть'), () => router.go('covers'))),
      row('sliders', $t('Громкость'), settings.level ? $t('измерено {0} из {1} альбомов', ls.albumsDone || 0, ls.albums || 0) : $t('выравнивание выключено'), settings.level && ls.albumsDone >= ls.albums, button($t('Настроить'), () => { const el = document.getElementById('st-level') || document.querySelector('[id^=st-level]'); el && el.scrollIntoView({ behavior: 'smooth' }); })),
      row('sparkle', $t('Анализ звука'), Sound.ready() ? $t('проанализировано {0}', Sound.count().toLocaleString()) : $t('выключен'), Sound.ready(), button($t('Настроить'), () => SoundUI.openSettings())),
      row('calendar', $t('Альбомы без года'), count(noYear.length), !noYear.length, noYear.length ? button($t('Показать'), pick(noYear)) : null),
      row('tag', $t('Альбомы без жанра'), count(noGenre.length), !noGenre.length, noGenre.length ? button($t('Показать'), pick(noGenre)) : null),
      row('list', $t('Возможные дубликаты'), count(dups.length), !dups.length, dups.length ? button($t('Показать'), pick(dups)) : null),
    );
  });
  return box;
}
const presetNow = () => Object.keys(PRESETS).find((k) => Object.entries(PRESETS[k]).every(([key, v]) => settings[key] === v)) || '';
function presetRow() {
  const names = { calm: [$t('Спокойный'), $t('Цвет обложки, без мельтешения')], full: [$t('Полный'), $t('Всё движется под музыку')], eco: [$t('Экономный'), $t('Для слабых компьютеров и ноутбука от батареи')] };
  const el = h('<div class="row st-presets"></div>');
  const now = presetNow();
  for (const k of Object.keys(PRESETS)) {
    const b = h(`<button class="st-preset${k === now ? ' on' : ''}" aria-pressed="${k === now}"><b></b><small></small></button>`);
    b.querySelector('b').textContent = names[k][0]; b.querySelector('small').textContent = names[k][1];
    b.onclick = () => { for (const [key, v] of Object.entries(PRESETS[k])) setSetting(key, v); toast($t('Набор «{0}»', names[k][0])); setTimeout(renderSettings, 30); };
    el.append(b);
  }
  if (!now) el.append(h(`<div class="st-preset-note">${$t('Сейчас — свои настройки')}</div>`));
  return el;
}
const group = (title, ...rows) => { const g = h(`<div class="card st-group">${title ? `<div class="st-gt">${title}</div>` : ''}</div>`); g.append(...rows.filter(Boolean)); return g; };
const actions = (...btns) => { const r = h('<div class="row st-acts"></div>'); r.append(...btns.filter(Boolean)); return r; };
const button = (html, fn, cls = '') => { const b = h(`<button class="btn sm ${cls}">${html}</button>`); b.onclick = fn; return b; };
let stSection = '';
/* interface language: applied by reloading the page (i18n.js reads it before anything renders) */
function langRow() {
  const el = h(`<div class="row"><div class="lbl"><b>${$t('Язык')} · Language</b></div><div class="seg"></div></div>`);
  const box = el.querySelector('.seg');
  const cur = settings.language || 'auto';
  for (const [v, txt] of [['auto', $t('Авто')], ...Object.entries(LANGS)]) {
    const b = h(`<button>${txt}</button>`); if (cur === v) b.classList.add('on');
    b.onclick = () => { if (cur === v) return; setSetting('language', v); const target = v === 'auto' ? '' : v; if (target !== lang || v === 'auto') setTimeout(() => location.reload(), 150); else renderSettings(); };
    box.append(b);
  }
  return el;
}

/* Texts that used to explain the settings in the interface (kept for whoever reads the code):
 * · «Авто» — как в Windows. Интерфейс перезагрузится
 * · Из обложки играющего альбома — или постоянная тема, которая не меняется от трека к треку
 * · Доли цветов текущего альбома
 * · Сбросить выбранный вручную вид у всех плейлистов
 * · Коды стран через запятую. RU находит кириллические релизы
 * · 'Источники с пометкой «неофициально» используют закрытые интерфейсы сервисов без их разрешения. Включайте их на свой риск; тексты песен защищены авторским правом и годятся только для личного прослушивания.
 * · ('Бесплатно в Google Cloud Console → YouTube Data API v3 → Credentials → API key. Около 100 поисков в день
 * · Сохранение идёт штатным механизмом foobar2000 (cover.jpg рядом с треками) — его сразу видят все компоненты.
 * · Порядок: iTunes (до 3000 px) → Deezer (1000 px) → MusicBrainz/CAA (1200 px). Лимиты запросов соблюдаются автоматически.
 * · Ищет уже установленные обложки в низком разрешении, сильно пережатые JPEG и не квадратные сканы. Новая картинка ставится автоматически, только если она <b>визуально совпадает</b> с текущей и крупнее; прежняя сохраняется в резервную копию, любую замену можно вернуть.
 * · Совпадение ниже порога автопринятия. Выберите обложку или пропустите альбом.
 * · 'Ещё не проверялось. Проверка идёт в фоне и уступает foobar каждый раз, когда вы работаете с окном, — интерфейс не тормозит. Обычно несколько минут на 2000 альбомов; если обложки читаются «через foobar», дольше.
 */
export function renderSettings() {
  const body = $('settingsBody');
  const scroller = body.parentElement;
  const keepScroll = scroller.scrollTop;
  body.innerHTML = '';
  const secs = [];
  const section = (id, ic, title, sub, ...groups) => {
    const el = h(`<section class="st-sec" id="st-${id}" data-sec="${id}"><header><div class="st-ic">${icon(ic)}</div><div><h3>${title}</h3></div></header></section>`);
    el.append(...groups); secs.push({ id, ic, title, el }); return el;
  };

  // ---- Оформление
  const albumColors = !FIXED[settings.colorSource] && settings.colorSource !== 'custom';
  /* colour source: the playing cover, or one of three calm fixed themes; each card is a tiny live preview */
  const sourcePicker = () => {
    const el = h(`<div class="row st-src"><div class="lbl"><b>${$t('Цвета интерфейса')}</b></div><div class="src-cards" role="radiogroup"></div></div>`);
    const box = el.querySelector('.src-cards');
    const pv = (k) => { const d = FIXED[k]; const c = (v) => `oklch(${v[0] * 100}% ${v[1]} ${v[2]})`; return `--pv-bg:${c(d.bg)};--pv-s:${c(d.surface2)};--pv-t:${c(d.text)};--pv-t3:${c(d.text3)};--pv-a:${c(d.accent)}`; };
    const cp = customPalette(settings.customTheme || seedTheme());
    const pvc = cp ? `--pv-bg:${cp.bg.css};--pv-s:${cp.surface2.css};--pv-t:${cp.text.css};--pv-t3:${cp.text3.css};--pv-a:${cp.accent.css}` : '';
    const items = [['album', $t('Из обложки'), ''], ...Object.keys(FIXED).map((k) => [k, FIXED[k].name, pv(k)]), ['custom', $t('Своя'), pvc]];
    for (const [id, name, style] of items) {
      const on = (settings.colorSource || 'album') === id;
      const b = h(`<button class="src-card${on ? ' on' : ''}${id === 'album' ? ' album' : ''}" role="radio" aria-checked="${on}" style="${style}">
        <span class="pv"><i class="pv-side"></i><i class="pv-l1"></i><i class="pv-l2"></i><i class="pv-btn"></i></span><span class="nm">${name}</span></button>`);
      if (id === 'album' && current.palette && !current.palette.fixed) b.style.cssText = `--pv-bg:${current.palette.bg.css};--pv-s:${current.palette.surface2.css};--pv-t:${current.palette.text.css};--pv-t3:${current.palette.text3.css};--pv-a:${current.palette.accent.css}`;
      b.onclick = () => { if (on) return; if (id === 'custom' && !settings.customTheme) setSetting('customTheme', seedTheme()); setSetting('colorSource', id); setTimeout(renderSettings, 60); };
      box.append(b);
    }
    return el;
  };
  const sw = h(`<div class="row"><div class="lbl"><b>${$t('Палитра обложки')}</b></div><div class="swatches"></div></div>`);
  if (current.palette) for (const c of current.palette.swatches) sw.querySelector('.swatches').appendChild(h(`<i style="background:${c.hex}" title="${c.hex} · ${Math.round(c.share * 100)}%"></i>`));
  section('preset', 'sliders', $t('Набор'), '', group('', presetRow()));
  section('look', 'sparkle', $t('Оформление'), '' /* albumColors ? $t('Интерфейс окрашивается в цвета обложки играющего альбома') : $t('Постоянная тема «{0}» — цвета не зависят от альбома', FIXED[settings.colorSource].name) */,
    group($t('Цвет'),
      sourcePicker(),
      ...(albumColors ? [
        seg('themeMode', $t('Яркость'), $t('«Авто» — светлая только для светлых обложек'), [['auto', $t('Авто')], ['dark', $t('Тёмная')], ['light', $t('Светлая')]]),
        range('colorIntensity', $t('Насыщенность'), $t('Насколько сильно цвет альбома окрашивает интерфейс'), 0.4, 1.5, 0.05, (v) => Math.round(v * 100) + '%'),
        range('transitionMs', $t('Смена цветов'), $t('Плавность перехода к новому альбому'), 200, 2600, 100, (v) => (v / 1000).toFixed(1) + $t(' с')),
        sw] : []),
      ...(settings.colorSource === 'custom' ? customThemeRows() : [])),
    group($t('Текст'),
      seg('fontMode', $t('Шрифт'), $t('«Гибрид»: Segoe UI для текста, Inter для заголовков'), [['hybrid', $t('Гибрид')], ['system', 'Segoe UI'], ['inter', 'Inter']]),
      seg('baseSize', $t('Размер текста'), $t('Вместе с масштабом интерфейса; строки списков растут вместе с текстом'), [[13, $t('Мельче')], [14, $t('Обычный')], [15, $t('Крупнее')], [16, $t('Крупный')]]),
      toggle('crispText', $t('Максимальная чёткость списков'), $t('ClearType вместо серого сглаживания'))),
    group($t('Фон и движение'),
      toggle('ambient', $t('Живой фон из обложки'), $t('Размытая обложка и цветовые пятна')),
      toggle('ambientMotion', $t('Движение фона'), $t('Медленный дрейф пятен')),
      seg('motionFps', $t('Плавность анимаций'), '' /* settings.motionFps === 'eco' ? $t('Спектр до 60 кадров в секунду, фон 12 — меньше работы видеокарте, разницы почти не видно') : $t('Спектр, обложка и фон — с частотой вашего монитора (120, 144, 240 Гц…)') */, [['max', $t('Как у монитора')], ['eco', $t('Экономно')]], () => setTimeout(renderSettings, 30)),
      toggle('beatReact', $t('Реакция на бас'), $t('Обложка «дышит» под низкие частоты'))),
    group($t('Визуализация'),
      seekStyleRow(),
      vizRow(),
      ...(settings.visualizer && !settings.vuMeters ? [spectrumStyleRow()] : []),
      ...(settings.vuMeters ? [
        seg('vuStyle', $t('Вид'), '', [['classic', $t('Классика')], ['album', $t('Цвета альбома')]]),
        seg('vuLayout', $t('Приборы'), '', [['pair', $t('Два')], ['stereo', $t('Один, две стрелки')]]),
        toggle('vuCanvas', $t('Показывать в «Холсте»'), ''),
        seg('vuCal', $t('0 VU соответствует'), $t('«Авто» — по громкости играющего альбома; иначе уровень синусоиды, при котором стрелка стоит на 0'), [['auto', $t('Авто')], [-18, '−18 dBFS'], [-14, '−14 dBFS'], [-10, '−10 dBFS']]),
      ] : [])),
  );

  // ---- Плеер и окно
  section('window', 'monitor2', $t('Окно и запуск'), '',
    group('',
      langRow(),
      seg('uiScale', $t('Масштаб интерфейса'), $t('«Авто» подгоняет всё под размер окна: в большом окне крупнее текст, обложки и отступы'), [['auto', $t('Авто')], [0.9, '90%'], [1, '100%'], [1.1, '110%'], [1.25, '125%'], [1.5, '150%']]),
      seg('start2', $t('Стартовый экран'), '', [['home', $t('Главная')], ['now', $t('Сейчас играет')], ['playlist', $t('Плейлист')], ['artists', $t('Исполнители')], ['library', $t('Медиатека')]]),
      seg('albumTarget', $t('Куда отправлять альбомы'), $t('При «Слушать» в медиатеке'), [['dedicated', $t('Плейлист «Gatefold»')], ['active', $t('Активный плейлист')]]),
      toggle('fullscreenTopmost', $t('Полный экран поверх всех окон'), $t('Выключено — другие программы можно открывать поверх полноэкранной Gatefold')),
      toggle('frameless', $t('Собственная рамка окна'), $t('Заголовок в стиле темы, Snap Layouts сохраняются · после перезагрузки'), () => toast(`${$t('Перезагрузите интерфейс:')} <b>Ctrl+R</b>`)),
      seg('backdrop', $t('Материал окна'), $t('Mica — системная подложка Windows 11'), [['none', $t('Нет')], ['mica', 'Mica']])),
    group($t('Панель задач и трей'),
      toggle('taskbarButtons', $t('Кнопки в миниатюре на панели задач'), $t('Назад, пауза, вперёд и ♡ — при наведении на значок Gatefold')),
      toggle('taskbarProgress', $t('Прогресс трека на значке'), $t('Полоска на кнопке в панели задач, жёлтая на паузе')),
      toggle('trayIcon', $t('Значок в области уведомлений'), $t('Меню с обложкой, управлением и лайком; щелчок — открыть окно'), () => setTimeout(renderSettings, 30)),
      ...(settings.trayIcon ? [
        toggle('minimizeToTray', $t('Сворачивать в трей'), $t('Свёрнутое окно прячется с панели задач')),
        toggle('closeToTray', $t('Закрывать в трей'), $t('Крестик прячет окно, музыка играет дальше. Выйти — «Выход» в меню значка')),
      ] : []),
      toggle('miniTopmost', $t('Мини-плеер поверх всех окон'), $t('Открывается кнопкой рядом с Холстом или из меню значка в трее'))),
  );

  // ---- Плейлисты
  section('playlists', 'list', $t('Плейлисты'), $t('Вид переключается кнопками в заголовке плейлиста и запоминается для каждого'),
    group('',
      seg('plViewDefault', $t('Вид по умолчанию'), $t('«Авто» — по альбомам, если плейлист из альбомов; иначе с обложками'), [['auto', $t('Авто')], ['albums', $t('Альбомы')], ['covers', $t('С обложками')], ['grid', $t('Плитки')], ['compact', $t('Компактно')]]),
      h(`<div class="row"><div class="lbl"><b>${$t('Свой вид у плейлистов')}</b></div></div>`)),
    // your own columns: any tag or title formatting, in playlists and on album pages (columns.js)
    group($t('Колонки'),
      h(`<div class="row st-note"><div class="lbl"><small class="dim">${$t('Любой тег или шаблон title formatting foobar2000 — как свои колонки в Default UI. Колонки видны в списочных видах плейлистов и на странице альбома; правый щелчок по заголовку списка включает и выключает их.')}</small></div></div>`),
      Cx.editor()),
  );
  const pr = secs[secs.length - 1].el.querySelector('.st-group .row:last-child');
  pr.append(button($t('Сбросить'), () => { Lib.resetPlaylistViews(); toast($t('Вид плейлистов сброшен')); }));

  // ---- Медиатека: editions and artist names (library.js, artistnames.js)
  section('library', 'grid', $t('Медиатека'), '',
    group($t('Альбомы'),
      toggle('splitEditions', $t('Разные издания — отдельными альбомами'), $t('Альбом 2014 года и его переиздание 2016-го с другими треками — две плитки с подписью издания'), () => Lib.rebuildLibrary().then(() => loadArtists(true)))),
    group($t('Исполнители'),
      toggle('artistGuests', $t('Исполнители без своих альбомов'), $t('Гости и исполнители сборников — тоже плитками в «Исполнителях»; их альбомы — в разделе «Участие в альбомах»'), () => { artistsState.src = null; artistsState.loaded = false; if (router.current === 'artists') loadArtists(true); }),
      h(`<div class="row st-note"><div class="lbl"><small class="dim">${$t('Гости и исполнители сборников появятся в «Исполнителях». Их песни на чужих альбомах всегда видны на странице исполнителя, в разделе «Участие в альбомах».')}</small></div></div>`)),
    group($t('Несколько исполнителей в одном имени'), ...artistSplitRows()),
  );

  // ---- Здоровье коллекции: обложки, исправления, фото исполнителей (раздел «Обложки»)
  section('health', 'image', $t('Здоровье коллекции'), '', group('', healthRows()),
    group('', actions(button($t('{0}Сообщить о проблеме', icon('info')), () => import('./report.js').then((m) => m.open())))));

  // ---- Онлайн-данные
  section('online', 'link', $t('Онлайн-данные'), '',
    group($t('Исполнители'),
      toggle('onlineInfo', $t('Описания и похожие исполнители'), $t('Начало статьи из Википедии и похожие исполнители с Deezer на странице исполнителя. Хранятся у вас 30 дней.'))),
  );

  // ---- Текст песен
  const provs = settings.lyricsOnline ? LYS.PROVIDERS.map((p) => {
    const el = h(`<div class="row sub-row"><div class="lbl"><b>${p.name}${p.official ? '' : ` <span class="tag-unof" title="${$t('Неофициальный клиентский интерфейс сервиса: работает без ключа, но не одобрен им и может перестать работать')}">${$t('неофициально')}</span>`}</b></div><label class="toggle"><input type="checkbox" aria-label="${aria(p.name)}"><i></i></label></div>`);
    const inp = el.querySelector('input'); inp.checked = (settings.lyricsSources || {})[p.id] === true;
    inp.onchange = () => setSetting('lyricsSources', { ...(settings.lyricsSources || {}), [p.id]: inp.checked });
    return el;
  }) : [];
  section('lyrics', 'quote', $t('Текст песен'), $t('Сначала теги и .lrc рядом с файлом, затем онлайн. <kbd>[</kbd> <kbd>]</kbd> — сдвиг тайминга, щелчок по источнику над текстом — другие варианты'),
    group($t('Поиск'),
      toggle('lyricsOnline', $t('Искать в интернете'), $t('Все источники сразу, побеждает лучшее совпадение'), () => setTimeout(renderSettings, 30)),
      ...provs,
      ...(settings.lyricsOnline ? [h(`<div class="row st-note"><small>${$t('Неофициальные источники — на ваш риск')}</small></div>`)] : [])),
    group($t('Показ и сохранение'),
      seg('lyricsSave', $t('Найденный текст'), $t('«Gatefold» — только в кэше темы, папки с музыкой не трогаются'), [['none', 'Gatefold'], ['file', $t('.lrc рядом')], ['embedded', $t('В теги')]]),
      seg('lyricsSize', $t('Размер на «Сейчас играет»'), '', [['s', $t('Мелкий')], ['m', $t('Средний')], ['l', $t('Крупный')]])),
  );

  // ---- Холст
  section('canvas', 'canvas', $t('Холст'), $t('Полноэкранный «Сейчас играет»: <kbd>F</kbd> — открыть, <kbd>L</kbd> раскладка, <kbd>T</kbd> текст, <kbd>C</kbd> часы'),
    group('',
      seg('canvasLayout', $t('Раскладка'), '', [['cover', $t('Обложка + текст')], ['lyrics', $t('Крупный текст')], ['minimal', $t('Только обложка')]]),
      toggle('canvasMotion', $t('Движение'), $t('Медленный наезд камеры и дрейф фона')),
      toggle('canvasClock', $t('Часы'), ''),
      seg('canvasIdleMin', $t('Включаться самому'), $t('Как заставка, если окно не трогают'), [[0, $t('Нет')], [2, $t('2 мин')], [5, '5'], [10, '10'], [20, '20']]),
      actions(button($t('{0}Открыть Холст', icon('canvas')), () => Canvas.open(), 'primary'), button($t('{0}На другом мониторе', icon('monitor2')), () => Canvas.openOnOtherScreen()))),
  );

  // ---- YouTube
  const ytMode = settings.ytSearch || 'off';
  const keyRow = h(`<div class="row"><div class="lbl"><b>${$t('Ключ YouTube Data API')}</b><small>Google Cloud Console → YouTube Data API v3</small></div><input class="st-input" type="password" spellcheck="false" autocomplete="off" placeholder="AIza…"></div>`);
  const kin = keyRow.querySelector('input'); kin.value = settings.ytApiKey || '';
  kin.addEventListener('keydown', (e) => e.stopPropagation());
  kin.addEventListener('change', () => { setSetting('ytApiKey', kin.value.trim()); dispatchEvent(new Event('aurora:yt-pref')); toast(kin.value.trim() ? $t('Ключ сохранён') : $t('Ключ удалён')); });
  section('youtube', 'yt', 'YouTube', $t('Ссылки на видео и плейлисты играют всегда; поиск включается отдельно'),
    group($t('Меню'),
      toggle('youtubeMenu', $t('YouTube в меню'), $t('Музыка и клипы с YouTube рядом с вашей медиатекой'))),
    group($t('Поиск'),
      seg('ytSearch', $t('Поиск видео'), '' /* ytMode === 'web' ? $t('Неофициально: разбор страницы результатов YouTube без ключа. Нарушает условия YouTube и может сломаться при изменении сайта') : ytMode === 'api' ? $t('Официальный способ: ваш собственный ключ, запросы идут напрямую в Google') : $t('Только ссылки') */, [['off', $t('Выключен')], ['api', $t('Ключ API')], ['web', $t('Неофициальный')]], () => { dispatchEvent(new Event('aurora:yt-pref')); setTimeout(renderSettings, 30); }),
      ...(ytMode === 'api' ? [keyRow] : [])),
    group($t('Плеер'),
      lsSeg($t('Качество видео'), $t('YouTube выбирает поток по размеру плеера — Gatefold задаёт его под нужное качество. Скорость сети может ограничить'), [['auto', $t('Авто')], ['hd720', '720p'], ['hd1080', '1080p'], ['hd1440', '1440p'], ['hd2160', '4K']], () => ytGet('quality', 'auto'), (v) => ytSet('quality', v)),
      lsToggle($t('Видео без встраивания — сразу в окне YouTube'), $t('Иначе сначала спросит'), () => ytGet('autoWindow', false), (v) => ytSet('autoWindow', v)),
      lsToggle($t('Автовоспроизведение'), $t('Следующее видео очереди начинается само'), () => ytGet('auto', true), (v) => ytSet('auto', v)),
      actions(button($t('{0}Очистить историю', icon('history')), () => { ytSet('history', []); toast($t('История YouTube очищена')); }))),
  );

  // ---- Хранилище
  const t = TC.tstate;
  const thumbs = h(`<div class="row"><div class="lbl"><b>${$t('Кэш миниатюр')}</b><small id="tcInfo">${$t('{0} шт. · {1} МБ', t.count, (t.bytes / 1048576).toFixed(1))}</small></div></div>`);
  thumbs.append(button($t('Очистить'), async () => { await TC.clear(); toast($t('Кэш миниатюр очищен')); renderSettings(); }));
  LoudUI.settingsSection({ section, group, actions, button, rerender: renderSettings });
  SoundUI.settingsSection({ section, group, actions, button, rerender: renderSettings });

  section('foobar', 'disc', 'foobar2000', $t('Настройки самого плеера — те же, что в его окне Preferences: изменения видны и там'), ...fb2kGroups(group, actions, button));

  section('updates', 'download', $t('Обновления'), '', group('', updatesSection()));

  section('storage', 'folder', $t('Хранилище и сброс'), '',
    group('',
      toggle('thumbCache', $t('Миниатюры обложек на диске'), $t('Медиатека открывается мгновенно и после перезапуска')),
      seg('thumbCacheMB', $t('Предел кэша'), '', [[200, $t('200 МБ')], [400, $t('400 МБ')], [800, $t('800 МБ')], [1500, $t('1,5 ГБ')]]),
      thumbs,
      actions(
        button($t('{0}Перезагрузить интерфейс', icon('refresh')), () => location.reload()),
        button($t('Очистить кэш палитр'), () => { localStorage.removeItem('aurora.clusters.v2'); toast($t('Кэш палитр очищен')); }),
        button($t('Сбросить все настройки'), () => { resetSettings(); renderSettings(); toast($t('Настройки сброшены')); }, 'danger'))),
  );

  // rare sections stay out of sight until «Расширенные настройки» is on
  const ADV = ['canvas', 'foobar', 'storage'];
  const hidden = secs.filter((x) => ADV.includes(x.id)).length;
  if (!settings.showAdvanced) secs.splice(0, secs.length, ...secs.filter((x) => !ADV.includes(x.id)));
  // ---- layout: nav + column
  const nav = h(`<nav class="st-nav"><h2 class="st-title">${$t('Настройки')}</h2><label class="st-search">${icon('search')}<input type="search" placeholder="${$t('Найти настройку')}" aria-label="${$t('Найти настройку')}" spellcheck="false"></label><div class="st-links"></div></nav>`);
  const links = nav.querySelector('.st-links');
  for (const sct of secs) {
    const a = h(`<button class="st-link" data-sec="${sct.id}">${icon(sct.ic)}<span>${sct.title}</span></button>`);
    a.onclick = () => { stSection = sct.id; scroller.scrollTo({ top: sct.el.offsetTop - 8, behavior: 'smooth' }); mark(sct.id); };
    links.append(a);
  }
  if (hidden) {
    const adv = h(`<button class="st-link st-adv">${icon(settings.showAdvanced ? 'chev-up' : 'more')}<span>${settings.showAdvanced ? $t('Скрыть расширенные') : $t('Расширенные настройки')}</span></button>`);
    adv.onclick = () => { setSetting('showAdvanced', !settings.showAdvanced); setTimeout(renderSettings, 30); };
    links.append(adv);
  }
  const main = h('<div class="st-main"></div>');
  main.append(...secs.map((x) => x.el), h(`<div class="st-empty">${$t('Ничего не нашлось')}</div>`), h(`<div class="st-foot">${'Gatefold ' + VERSION}</div>`));
  // the sections list stands beside the scroller, not sticky inside it: a sticky element is a
  // compositor layer, and everything scrolling past it would lose ClearType (ambient.js)
  $('settingsNav').replaceChildren(nav);
  body.append(main);
  // every switch, slider and field is named after its row, for screen readers
  const nameRows = () => main.querySelectorAll('input:not([aria-label]), select:not([aria-label]), textarea:not([aria-label])').forEach((i) => {
    if (i.labels && i.labels.length && i.labels[0].textContent.trim()) return;
    const r = i.closest('.row, .st-group, section'); if (!r) return;
    const name = ((r.querySelector('.lbl b, .lbl, b, .st-gt, h3') || {}).textContent || '').trim().split('\n')[0];
    if (name) i.setAttribute('aria-label', name);
  });
  nameRows(); setTimeout(nameRows, 1200); setTimeout(nameRows, 4000);

  const mark = (id) => links.querySelectorAll('.st-link').forEach((b) => b.classList.toggle('on', b.dataset.sec === id));
  // scroll-spy
  const spy = () => {
    const y = scroller.scrollTop + 80;
    let cur = secs[0].id;
    for (const sct of secs) if (sct.el.offsetTop <= y) cur = sct.id;
    if (scroller.scrollTop + scroller.clientHeight >= scroller.scrollHeight - 4) cur = secs[secs.length - 1].id;
    mark(cur);
  };
  scroller.onscroll = () => requestAnimationFrame(spy);
  // search
  const q = nav.querySelector('input');
  q.addEventListener('keydown', (e) => e.stopPropagation());
  q.addEventListener('input', () => {
    const s = q.value.trim().toLowerCase();
    let any = false;
    for (const sct of secs) {
      let secHit = !s || sct.title.toLowerCase().includes(s);
      for (const g of sct.el.querySelectorAll('.st-group')) {
        let gHit = false;
        for (const r of g.querySelectorAll('.row')) { const hit = !s || secHit || r.textContent.toLowerCase().includes(s); r.hidden = !hit; gHit ||= hit; }
        g.hidden = !gHit; secHit ||= gHit;
      }
      sct.el.hidden = !secHit; any ||= secHit;
      links.querySelector(`[data-sec="${sct.id}"]`).classList.toggle('dim', !secHit);
    }
    main.querySelector('.st-empty').classList.toggle('on', !any);
  });
  scroller.scrollTop = keepScroll;
  mark(stSection || secs[0].id); spy();
  TC.remeasure().then((m) => { const i = $('tcInfo'); if (i) i.textContent = $t('{0} шт. · {1} МБ на диске', m.n, (m.bytes / 1048576).toFixed(1)); });
}

// ---------------------------------------------------------------- covers
let manual = null; // { job, cands, loading }

/* Covers view is re-rendered on every progress event of three background engines.
   Rebuilding the whole view each time re-created hundreds of nodes and reloaded
   every thumbnail. Now it is built off-document and only cards whose markup
   actually changed are swapped (signature = markup as built, before runtime
   changes such as image load classes). */
function morph(live, next) {
  const kids = [...next.children];
  kids.forEach((n, i) => {
    const sig = n.outerHTML;
    const old = live.children[i];
    if (old && old.__sig === sig) return;          // unchanged: keep node, its images and listeners
    n.__sig = sig;
    if (old) live.replaceChild(n, old); else live.appendChild(n);
  });
  while (live.children.length > kids.length) live.lastElementChild.remove();
}

export function renderCovers(arg) {
  if (arg && arg.manual) startManual(arg.manual);
  const live = $('coversBody');
  const body = document.createElement('div');
  const st = CF.getStats();
  const s = CF.state;

  // manual search card
  if (manual) {
    const c = card($t('Ручной поиск: {0}', esc(manual.job.album)), esc(manual.job.artist) + $t(' · все источники, отсортировано по совпадению'), true);
    if (manual.loading) c.append(h(`<div class="row"><div class="spinner"></div><div class="lbl">${$t('Опрашиваю iTunes, Deezer, MusicBrainz…')}</div></div>`));
    else if (!manual.cands.length) c.append(h(`<div class="empty"><b>${$t('Ничего не найдено')}</b></div>`));
    else {
      const grid = h('<div class="cands"></div>');
      manual.cands.slice(0, 18).forEach((cd) => grid.appendChild(candEl(manual.job, cd)));
      c.append(grid);
    }
    c.append(h(`<div class="row"><button class="btn sm" id="manClose">${$t('Закрыть')}</button></div>`));
    body.append(c);
    c.querySelector('#manClose').onclick = () => { manual = null; renderCovers(); };
  }

  // damage from 1.1: covers written into folders shared by several albums
  const d = CF.diag;
  if (s.diagRunning || s.repairing) {
    body.append(h(`<div class="card wide"><div class="row" style="border:0"><div class="spinner"></div><div class="lbl"><b>${s.repairing ? $t('Исправляю…') : $t('Проверяю папки, общие для нескольких альбомов…')}</b></div></div></div>`));
  } else if (d && (d.files.length || d.foreign.length)) {
    const rc = card(d.files.length ? $t('⚠ Обложки, записанные в общие папки') : $t('Общие папки с обложками'), '', true);
    rc.classList.add('warn');
    rc.append(h(`<div class="desc">${$t('foobar2000 ищет обложку <b>по папке</b>: файл cover.jpg применяется ко <b>всем</b> трекам в ней и перекрывает встроенные обложки. Ранняя версия темы записала такой файл в папки, где лежат несколько альбомов, — поэтому у них у всех стала одна обложка. Музыкальные файлы не изменялись.')}</div>`));
    if (d.files.length) {
      rc.append(h(`<div class="desc">${$t('Найдено <b>{0}</b> {1} темы в {2} общих папках (из {3} папок с несколькими альбомами). Исправление переместит их в <b>Корзину</b> (можно восстановить), после чего встроенные обложки вернутся, а затронутые альбомы получат правильные обложки — встроенные в их собственные треки.', d.files.length, CF_pl(d.files.length), d.files.length, d.sharedDirs)}</div>`));
      const list = h('<div class="log" style="max-height:180px"></div>');
      for (const f of d.files.slice(0, 40)) list.append(h(`<div class="log-row" style="grid-template-columns:1fr auto"><div class="s">${esc(f.path)}</div><div class="s">${f.albums} ${$t('альб.')}</div></div>`));
      rc.append(list);
    }
    if (d.foreign.length) rc.append(h(`<div class="desc" style="margin-top:8px">${$t('Ещё {0} файлов обложек в общих папках появились <b>до</b> установки темы — они не трогаются.', d.foreign.length)} ${d.files.length ? '' : $t('Если это тоже ошибка — можно убрать их в Корзину.')}</div>`));
    const act = h('<div class="row" style="gap:8px;flex-wrap:wrap;border:0"></div>');
    const ab = (txt, fn, cls = '') => { const e = h(`<button class="btn ${cls}">${txt}</button>`); e.onclick = fn; act.append(e); };
    if (d.files.length) ab($t('{0}Исправить: убрать в Корзину и пересканировать', icon('refresh')), async () => {
      const r = await CF.repairSharedCovers();
      toast($t('Исправлено: {0} {1} в Корзине', r.moved, CF_pl(r.moved)) + (r.failed ? $t(', не удалось: {0}', r.failed) : '') + $t('. Перепроверяю медиатеку…'), { ms: 8000 });
      CF.sweepLibrary(true);
    }, 'primary');
    if (d.foreign.length) ab($t('Убрать в Корзину и их тоже'), async () => { if (!confirm($t('Переместить в Корзину ещё {0} файлов обложек из общих папок?', d.foreign.length))) return; const r = await CF.repairSharedCovers({ includeForeign: true }); toast($t('В Корзине: {0}', r.moved)); CF.sweepLibrary(true); });
    ab($t('Проверить заново'), () => CF.diagnoseSharedCovers());
    rc.append(act);
    body.append(rc);
  } else if (d) {
    body.append(h(`<div class="card wide"><div class="desc" style="margin:0">${$t('✓ Проверка общих папок: ошибочно записанных обложек нет (папок с несколькими альбомами: {0}). Новые обложки для таких папок встраиваются в треки альбома.', d.sharedDirs)}</div></div>`));
  }

  // status
  const stc = card($t('Состояние'), s.busy ? `${$t('Сейчас:')} <b>${esc(s.busy.artist)} — ${esc(s.busy.album)}</b>` : (s.paused ? $t('Пауза') : (s.queue.length ? $t('В очереди…') : $t('Ожидание'))), true);
  stc.append(h(`<div class="stat-grid"><div class="stat"><b class="status-ok">${st.ok}</b><span>${$t('установлено')}</span></div><div class="stat"><b class="status-rev">${st.rev}</b><span>${$t('на проверке')}</span></div><div class="stat"><b>${st.nf}</b><span>${$t('не найдено')}</span></div><div class="stat"><b class="status-err">${st.err}</b><span>${$t('ошибки')}</span></div></div>`));
  if (s.total && (s.sweeping || s.sweepDone || s.scanned)) {
    const phase = s.sweeping ? $t('Проверка медиатеки') : s.sweepDone ? $t('Проверка завершена') : $t('Проверка остановлена');
    stc.append(
      h(`<div class="desc"><b>${phase}:</b> ${$t('{0} из {1} альбомов · с обложкой <b>{2}</b> · <b class="status-rev">без обложки {3}</b>', s.scanned, s.total, s.withArt, s.missing)}${s.skipped ? $t(' · пропущено (уже обработаны) {0}', s.skipped) : ''} ${$t('· в очереди поиска <b>{0}</b>', s.queue.length)}</div>`),
      h(`<div class="progress"><i style="width:${(s.scanned / s.total * 100).toFixed(1)}%"></i></div>`));
  } else stc.append(h(`<div class="desc">${$t('Проверка медиатеки ещё не запускалась в этой сессии.')}</div>`));
  const actions = h(`<div class="row" style="gap:8px;flex-wrap:wrap;border:0"></div>`);
  const b = (txt, fn, cls = '') => { const e = h(`<button class="btn ${cls}">${txt}</button>`); e.onclick = fn; actions.append(e); };
  b(`${icon('search')}${s.sweeping ? $t('Идёт проверка…') : $t('Проверить медиатеку')}`, () => { if (s.sweeping) return; CF.sweepLibrary(true); toast($t('Проверяю каждый альбом на наличие обложки')); }, 'primary');
  b(s.paused ? $t('Продолжить') : $t('Приостановить'), () => CF.setPaused(!s.paused));
  b($t('Повторить «не найдено» и ошибки'), () => { CF.resetStatus('nf'); CF.resetStatus('err'); CF.sweepLibrary(true); });
  b($t('Сбросить историю'), () => { if (confirm($t('Сбросить все статусы обложек?'))) CF.resetStatus(); });
  stc.append(actions);
  if (s.lastError) stc.append(h(`<div class="desc">${$t('Последняя ошибка:')} ${esc(s.lastError)}</div>`));
  body.append(stc);

  // quality of existing covers
  body.append(qualityCard());

  // artist photos
  const as = AA.stats(), ast = AA.astate;
  const ac = card($t('Фото исполнителей'), '' /* Deezer (1000 px) → MusicBrainz/Wikidata; an artist is accepted only when its discography contains your album */, true);
  ac.append(h(`<div class="stat-grid"><div class="stat"><b class="status-ok">${as.files}</b><span>${$t('фото в папке')}</span></div><div class="stat"><b>${as.queue + (ast.busy ? 1 : 0)}</b><span>${$t('в очереди')}${ast.busy ? ' · ' + esc(ast.busy.name) : ''}</span></div><div class="stat"><b>${as.nf}</b><span>${$t('не найдено')}</span></div><div class="stat"><b class="status-err">${as.err}</b><span>${$t('ошибки')}</span></div></div>`));
  if (ast.lastError) ac.append(h(`<div class="desc">${$t('Последняя ошибка:')} ${esc(ast.lastError)}</div>`));
  const aact = h('<div class="row" style="gap:8px;flex-wrap:wrap;border:0"></div>');
  const ab = (txt, fn, cls = '') => { const e = h(`<button class="btn ${cls}">${txt}</button>`); e.onclick = fn; aact.append(e); };
  ab($t('{0}Скачать для всех', icon('search')), async () => { await loadArtists(false); for (const x of artistsState.list) AA.want(artistJob(x)); toast($t('Ищу фото для всех исполнителей')); renderCovers(); }, 'primary');
  ab(ast.paused ? $t('Продолжить') : $t('Приостановить'), () => AA.setPaused(!ast.paused));
  ab($t('Повторить ненайденные'), () => { AA.resetNotFound(); toast($t('Статусы сброшены — откройте «Исполнители» или нажмите «Скачать для всех»')); });
  ab($t('{0}Открыть папку', icon('folder')), () => openArtistFolder());
  ac.append(aact, toggle('artistAuto', $t('Скачивать автоматически'), $t('При открытии «Исполнителей» — сначала видимые, затем все остальные')));
  body.append(ac);

  // review queue
  const rev = CF.getReview();
  if (rev.length) {
    const rc = card($t('Требуют подтверждения · {0}', rev.length), '', true);
    for (const item of rev.slice(0, 12)) {
      const box = h(`<div style="padding:10px 0;border-top:1px solid var(--line)"><div style="display:flex;align-items:center;gap:10px"><div style="flex:1;min-width:0"><b>${esc(item.job.album)}</b> <span style="color:var(--text-3)">· ${esc(item.job.artist)}</span></div><button class="btn sm" data-a="more">${$t('Искать ещё')}</button><button class="btn sm" data-a="skip">${$t('Пропустить')}</button></div><div class="cands"></div></div>`);
      const grid = box.querySelector('.cands');
      item.cands.slice(0, 6).forEach((cd) => grid.appendChild(candEl(item.job, cd)));
      box.querySelector('[data-a=skip]').onclick = () => { CF.skipReview(item.key); renderCovers(); };
      box.querySelector('[data-a=more]').onclick = () => { startManual(item.job); };
      rc.append(box);
    }
    body.append(rc);
  }

  // settings
  const sc = card($t('Параметры поиска'), '');
  sc.append(
    toggle('coverAuto', $t('Искать для играющего альбома'), $t('Сразу при старте трека без обложки')),
    toggle('coverSweep', $t('Фоновая проверка медиатеки'), $t('Обходит все альбомы при запуске, с паузами — не мешает воспроизведению')),
    seg('coverMinSize', $t('Минимальный размер'), $t('Отбраковка мелких картинок'), [[500, '500'], [600, '600'], [800, '800'], [1000, '1000']]),
    seg('coverMaxSize', $t('Максимальный размер'), $t('Крупнее — уменьшается (JPEG 93%)'), [[0, $t('Оригинал')], [3000, '3000'], [2000, '2000'], [1400, '1400']]),
    seg('coverThreshold', $t('Строгость совпадения'), $t('Ниже порога — в «Требуют подтверждения»'), [[0.78, $t('Мягко')], [0.82, $t('Норма')], [0.88, $t('Строго')]]),
    seg('coverTarget', $t('Куда сохранять найденные'), $t('«Только в Gatefold» — файлы и папки с музыкой не меняются'), [['gatefold', $t('Только в Gatefold')], ['file', 'cover.jpg'], ['embedded', $t('В теги')], ['all', $t('cover.jpg + теги')]]),
    seg('coverSharedDir', $t('Папка с несколькими альбомами'), $t('cover.jpg там нельзя — он лёг бы на все альбомы папки. Встраивание пишет обложку (до 1400 px) только в треки нужного альбома'), [['embed', $t('Встраивать в треки')], ['skip', $t('Пропускать')]]),
  );
  const src = card($t('Источники'), '');
  const srcToggle = (k, label, hint) => {
    const el = h(`<div class="row"><div class="lbl"><b>${label}</b></div><label class="toggle"><input type="checkbox" aria-label="${aria(label)}"><i></i></label></div>`);
    const inp = el.querySelector('input'); inp.checked = !!settings.coverSources[k];
    inp.onchange = () => setSetting('coverSources', { ...settings.coverSources, [k]: inp.checked });
    return el;
  };
  const ctry = h(`<div class="row"><div class="lbl"><b>${$t('Витрины iTunes')}</b></div><input class="filter" style="width:120px" aria-label="${$t('Витрины iTunes')}" value="${esc(settings.coverCountries)}"></div>`);
  ctry.querySelector('input').onchange = (e) => setSetting('coverCountries', e.target.value.toUpperCase());
  src.append(srcToggle('itunes', 'iTunes / Apple Music', $t('Лучшее качество, мейджоры и инди')), srcToggle('deezer', 'Deezer', $t('Широкий каталог, СНГ')), srcToggle('musicbrainz', 'MusicBrainz + Cover Art Archive', $t('Редкие издания, винил, бутлеги')), ctry);
  body.append(sc, src);

  // your own covers: kept by Gatefold, and a path rule for libraries that keep covers elsewhere
  const own = card($t('Ваши обложки'), '');
  const nOwn = Own.all().length;
  own.append(h(`<div class="row st-note"><div class="lbl"><small class="dim">${$t('Обложку альбома можно выбрать на его странице: «Обложка…» — с компьютера, перетаскиванием, из буфера, из папки или тегов альбома, из интернета. Выбранную вами Gatefold не заменит.')}${nOwn ? ' ' + $t('Сейчас ваших обложек: {0}.', nOwn) : ''}</small></div></div>`));
  const rule = h(`<div class="row cx-rule"><div class="lbl"><b>${$t('Правило пути')}</b><small class="snd-status dim cp-rule-pv"></small></div><input class="st-input" spellcheck="false" placeholder="D:\\Covers\\%album artist% - %album%" aria-label="${$t('Правило пути')}"></div>`);
  const ri = rule.querySelector('input'), pv = rule.querySelector('.cp-rule-pv');
  ri.value = settings.coverPattern || '';
  const preview = async () => {
    const t = (await call('playback.getCurrentTrack')); const tr = ok(t) && t.found !== false ? (t.track || t) : null;
    if (!ri.value.trim()) { pv.textContent = $t('Например: D:\\Covers\\%album artist% - %album% — расширение подбирается само (.jpg, .png, .webp…)'); return; }
    const p = tr ? await CoverPick.patternFor(tr.absolutePath || tr.path, ri.value.trim()) : '';
    pv.textContent = p ? $t('Для играющего альбома: {0}.*', p) : $t('Включите трек, чтобы увидеть путь');
  };
  ri.oninput = () => { setSetting('coverPattern', ri.value.trim()); preview(); };
  preview();
  const scanRow = h(`<div class="row"><div class="lbl"><small class="snd-status dim cp-scan"></small></div></div>`);
  const paint = () => { const s = CoverPick.scanState; scanRow.querySelector('.cp-scan').textContent = s.running ? $t('Ищу по правилу: {0} из {1}, найдено {2}', s.done, s.total, s.found) : s.error ? s.error : s.total ? $t('Готово: найдено обложек — {0}', s.found) : ''; };
  paint();
  scanRow.append(button($t('Применить к медиатеке'), async () => { if (!settings.coverPattern) { toast($t('Сначала задайте правило пути')); return; } CoverPick.patternScan(await Lib.getAllAlbums(), { onProgress: paint }); paint(); }));
  own.append(rule, scanRow);
  body.append(own);

  // log
  const lg = card($t('Журнал'), '', true);
  const list = h('<div class="log"></div>');
  const label = { ok: $t('установлена'), nf: $t('не найдена'), err: $t('ошибка'), rev: $t('на проверке') };
  for (const e of CF.getLog().slice(0, 60)) {
    list.append(h(`<div class="log-row">${e.thumb ? `<img class="th" src="${esc(e.thumb)}" alt="" loading="lazy">` : '<div class="th"></div>'}<div style="min-width:0"><div class="t">${esc(e.album)} <span style="color:var(--text-3);font-weight:400">· ${esc(e.artist)}</span></div><div class="s"><span class="status-${e.s}">${label[e.s] || e.s}</span>${e.src ? ' · ' + esc(e.src) : ''}${e.w ? ` · ${e.w}×${e.h}` : ''}${e.sc ? $t(' · совпадение {0}%', Math.round(e.sc * 100)) : ''}${e.err ? ' · ' + esc(e.err) : ''}</div></div><div class="s num">${new Date(e.t).toLocaleTimeString().slice(0, 5)}</div></div>`));
  }
  if (!CF.getLog().length) list.append(h(`<div class="desc">${$t('Пока пусто')}</div>`));
  lg.append(list);
  body.append(lg);
  $('coverBadge').textContent = rev.length || '';
  morph(live, body);
}

// ---------------------------------------------------------------- quality card
let qShow = 40, qOpen = '';
function qualityCard() {
  if (!Q.qstate.loaded) { Q.load(); }
  const qs = Q.qstate, sum = Q.summary();
  const c = card($t('Качество обложек'), '', true);
  if (qs.scanning) {
    c.append(h(`<div class="desc">${$t('<b>Проверка:</b> {0} из {1} альбомов · с обложкой {2} · найдено слабых {3}', qs.scanned, qs.total || '…', qs.withArt, Q.rows.filter((r) => r.flags.length).length)}</div>`),
      h(`<div class="progress"><i style="width:${qs.total ? (qs.scanned / qs.total * 100).toFixed(1) : 2}%"></i></div>`));
  } else if (qs.scannedAt) {
    c.append(h(`<div class="stat-grid"><div class="stat"><b>${qs.withArt}</b><span>${$t('проверено обложек')}</span></div><div class="stat"><b class="status-rev">${sum.lowres}</b><span>${$t('низкое разрешение')}</span></div><div class="stat"><b class="status-rev">${sum.jpegq}</b><span>${$t('сильно сжаты')}</span></div><div class="stat"><b>${sum.aspect}</b><span>${$t('не квадратные')}</span></div><div class="stat"><b class="status-ok">${sum.upgraded}</b><span>${$t('улучшено')}</span></div></div>`));
    c.append(h(`<div class="desc">${$t('Последняя проверка:')} ${new Date(qs.scannedAt).toLocaleString([], { dateStyle: 'short', timeStyle: 'short' })}${sum.review ? ` · <b class="status-rev">${$t('ждут решения:')} ${sum.review}</b>` : ''}${sum.todo ? $t(' · не обработано: {0}', sum.todo) : ''}</div>`));
  } else c.append(h(`<div class="desc">${$t('Ещё не проверялось')}</div>`));
  const act = h('<div class="row" style="gap:8px;flex-wrap:wrap;border:0"></div>');
  const b = (txt, fn, cls = '') => { const e = h(`<button class="btn ${cls}">${txt}</button>`); e.onclick = fn; act.append(e); return e; };
  b(`${icon('search')}${qs.scanning ? $t('Идёт проверка…') : qs.scannedAt ? $t('Проверить заново') : $t('Проверить качество')}`, () => { if (!qs.scanning) Q.scan(); }, qs.scannedAt ? '' : 'primary');
  if (qs.scannedAt && sum.todo) b(`${icon('sparkle')}${qs.auto ? $t('Остановить') : $t('Улучшить автоматически ({0})', sum.todo)}`, () => (qs.auto ? Q.stopAll() : Q.upgradeAll()), qs.auto ? '' : 'primary');
  if (qs.scanning || qs.auto) b(qs.paused ? $t('Продолжить') : $t('Приостановить'), () => Q.setPaused(!qs.paused));
  c.append(act);
  c.append(
    seg('qualityMinRes', $t('Низкое разрешение — меньше'), $t('По короткой стороне'), [[500, '500'], [600, '600'], [800, '800'], [1000, '1000']]),
    seg('qualityAuto', $t('Автозамена'), $t('«Если совпадает» — только та же картинка, крупнее и с высокой оценкой совпадения альбома'), [['same', $t('Если совпадает')], ['never', $t('Всегда спрашивать')]]),
  );
  if (artDiag.mode) c.append(h(`<div class="desc">${$t('Чтение обложек:')} ${{ fb2k: $t('напрямую (fb2k://)'), same: $t('напрямую (локальный адрес)'), bridge: $t('через foobar — медленнее, но работает всегда'), plain: $t('напрямую') }[artDiag.mode] || artDiag.mode}</div>`));
  if (qs.lastError) c.append(h(`<div class="desc">${$t('Последняя ошибка:')} ${esc(qs.lastError)}</div>`));

  const list = Q.rows.filter((r) => r.flags.length || r.st === 'upgraded');
  if (list.length) {
    const box = h('<div class="qlist"></div>');
    const label = { flag: '', busy: $t('ищу замену…'), review: $t('нужно решение'), nobetter: $t('лучше не найдено'), err: $t('ошибка'), kept: $t('оставлена'), upgraded: $t('улучшена'), ok: $t('в порядке') };
    const shown = list.slice(0, qShow);
    for (const r of shown) {
      const el = h(`<div class="qrow st-${r.st}"><div class="th"><img alt=""></div><div class="qi"><div class="t">${esc(r.album)} <span>· ${esc(r.artist)}</span></div><div class="s">${Q.flagText(r).map((x) => `<span class="chip">${esc(x)}</span>`).join('')}${r.fmt && !r.flags.includes('jpegq') && r.fmt !== 'JPEG' ? `<span class="chip">${r.fmt}</span>` : ''}<span class="qst">${r.st === 'busy' ? '<span class="spinner"></span>' : ''}${esc(label[r.st] || '')}${r.note ? ' · ' + esc(r.note) : ''}</span></div></div><div class="qa"></div></div>`);
      const qa = el.querySelector('.qa');
      const qb = (txt, fn, cls = 'btn sm') => { const e = h(`<button class="${cls}">${txt}</button>`); e.onclick = async (ev) => { ev.stopPropagation(); e.disabled = true; try { await fn(); } catch (err) { toast(esc(err.message)); } e.disabled = false; }; qa.append(e); };
      if (r.st === 'flag' || r.st === 'err' || r.st === 'nobetter' || r.st === 'kept') qb($t('Найти лучше'), () => Q.upgrade(Q.rows.find((x) => x.key === r.key) || r));
      if (r.st === 'review') qb(qOpen === r.key ? $t('Скрыть') : $t('Выбрать'), () => { qOpen = qOpen === r.key ? '' : r.key; renderCovers(); }, 'btn sm primary');
      if (r.st === 'upgraded' && r.jid) qb($t('Вернуть прежнюю'), async () => { await Q.undo(r.jid); toast($t('Прежняя обложка возвращена')); });
      box.append(el);
      if (r.st === 'review' && qOpen === r.key && r.cands) {
        const grid = h('<div class="cands qcands"></div>');
        for (const cd of r.cands) {
          const v = { same: [$t('совпадает с текущей'), 'ok'], similar: [$t('похожа'), 'rev'], different: [$t('другая картинка'), 'err'] }[cd.verdict] || ['', ''];
          const ce = h(`<div class="cand"><img src="${esc(Q.previewFor(r.key, cd))}" alt="" loading="lazy"><div class="ct">${cd.w}×${cd.h} · ${esc(cd.src)}</div><div class="cs"><span class="status-${v[1]}">${v[0]}</span> ${$t('· альбом')} ${Math.round(cd.score * 100)}%</div><div class="cs">${esc(cd.title || '')}</div></div>`);
          ce.onclick = async () => { ce.style.opacity = '.5'; ce.style.pointerEvents = 'none'; await Q.applyCandidate(r.key, cd); qOpen = ''; };
          grid.append(ce);
        }
        const keep = h(`<div class="row" style="border:0;gap:8px"><button class="btn sm">${$t('Оставить текущую')}</button></div>`);
        keep.querySelector('button').onclick = () => { Q.keep(r.key); qOpen = ''; };
        box.append(grid, keep);
      }
    }
    if (list.length > qShow) { const more = h(`<button class="btn sm" style="margin-top:8px">${$t('Показать ещё ({0})', list.length - qShow)}</button>`); more.onclick = () => { qShow += 60; renderCovers(); }; box.append(more); }
    c.append(box);
    Lib.coversFor(shown.map((r) => r.path), 96).then((get) => {
      box.querySelectorAll('.qrow').forEach((el, i) => { const u = get(shown[i].path); const im = el.querySelector('img'); if (u) { im.onload = () => { im.classList.add('on'); Lib.coverLoaded(u); }; im.src = u; } });
    });
  }
  const jr = Q.getJournal().slice(0, 12);
  if (jr.length) {
    const jl = h('<div class="log" style="max-height:220px;margin-top:10px"></div>');
    jl.append(h(`<div class="desc" style="margin:0 0 4px"><b>${$t('История замен')}</b> ${$t('· резервные копии: {0}', '%profile%\\aurora\\backup\\covers')}</div>`));
    for (const e of jr) {
      const row = h(`<div class="log-row" style="grid-template-columns:1fr auto auto"><div style="min-width:0"><div class="t">${esc(e.album)} <span style="color:var(--text-3);font-weight:400">· ${esc(e.artist)}</span></div><div class="s">${esc(e.from)} → ${esc(e.to)} · ${esc(e.src || '')} · ${e.mode === 'embed' ? $t('встроена в {0} тр.', (e.tracks || []).length) : e.mode === 'add-file' ? $t('cover.jpg добавлен') : $t('файл заменён')}${e.undone ? ` · <b>${$t('возвращено')}</b>` : ''}</div></div><div class="s num">${new Date(e.t).toLocaleDateString()}</div><div></div></div>`);
      if (!e.undone) { const ub = h(`<button class="btn sm">${$t('Вернуть')}</button>`); ub.onclick = async () => { ub.disabled = true; try { await Q.undo(e.id); toast($t('Возвращено')); } catch (err) { toast(esc(err.message)); ub.disabled = false; } }; row.lastChild.append(ub); }
      jl.append(row);
    }
    c.append(jl);
  }
  return c;
}
Q.events.addEventListener('change', () => { if (router.current === 'covers') scheduleCovers(); });

function candEl(job, cd) {
  const el = h(`<div class="cand"><img src="${esc(cd.thumb)}" alt="" loading="lazy"><div class="ct">${esc(cd.title)}</div><div class="cs">${esc(cd.artist || '')}${cd.year ? ' · ' + cd.year : ''}</div><div class="cs">${esc(cd.src)} · ${$t('до {0}px', cd.res)} · ${Math.round((cd.score || 0) * 100)}%</div></div>`);
  el.onclick = async () => {
    el.style.opacity = '.5'; el.style.pointerEvents = 'none';
    try {
      await CF.applyCandidate(job, cd, { manual: true });
      if (manual && manual.job.key === job.key) manual = null;
      renderCovers();
    } catch (e) { toast($t('Не подошла: ') + esc(e.message)); el.style.opacity = ''; el.style.pointerEvents = ''; }
  };
  return el;
}

async function startManual(job) {
  if (!job) { toast($t('Этот альбом не на локальном диске — сохранить обложку некуда')); return; }
  manual = { job, cands: [], loading: true };
  if (router.current === 'covers') renderCovers();
  const cands = await CF.findCandidates(job, { exhaustive: true });
  if (!manual || manual.job.key !== job.key) return;
  manual.cands = cands; manual.loading = false;
  if (router.current === 'covers') renderCovers();
}

CF.events.addEventListener('repaired', () => { if (router.current === 'covers') renderCovers(); });
CF.events.addEventListener('change', () => { if (router.current === 'covers') scheduleCovers(); else $('coverBadge').textContent = CF.getReview().length || ''; });
AA.events.addEventListener('change', () => { if (router.current === 'covers') scheduleCovers(); });
let covT = 0;
/* at most ~1 render per 800 ms while engines report progress; none while the window is hidden */
let covLast = 0, covPending = false;
function scheduleCovers() {
  if (covT) return;
  if (document.visibilityState === 'hidden') { covPending = true; return; }
  covT = setTimeout(() => {
    covT = 0; covLast = performance.now();
    if (router.current !== 'covers') return;
    const sc = $('view-covers').querySelector('.scroller'); const y = sc.scrollTop; renderCovers(); sc.scrollTop = y;
  }, Math.max(120, 800 - (performance.now() - covLast)));
}
document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible' && covPending) { covPending = false; scheduleCovers(); } });

router.on('settings', renderSettings);
router.on('covers', (arg) => { const b = $('coversBack'); if (b) b.replaceChildren(backButton('settings')); renderCovers(arg); });
