/*
 * Gatefold · artistinfo.js — what the web knows about an artist, for the artist page.
 *   disco    everything the artist released (albums, EPs, singles), oldest first
 *   about    the opening of the Wikipedia article, in the interface language (English as a fallback)
 *   similar  related artists from Deezer
 *
 * The discography should always be there, so it is asked for from three places, each of which has to prove it
 * means the same artist (one of your own albums must be in its list, as for photos in artistart.js):
 *   1. MusicBrainz — the most complete and exact (release groups, with ids for track lists and covers);
 *   2. Deezer      — when MusicBrainz is busy, offline or does not know the artist;
 *   3. Apple Music — the last resort (the iTunes catalogue).
 * A request that gets no answer or a «busy» is tried again after a pause before a source is given up.
 *
 * Kept on disk (IndexedDB) — every artist ever opened, without the ~5 MB limit of localStorage — and shown at
 * once on the next visit. After 30 days the kept copy is still shown while a fresh one is fetched in the
 * background, and a fetch that fails never replaces a discography found before. Off with Settings → online data.
 */
import { JsonStore, settings } from './settings.js';
import { similarity, cleanAlbum } from './match.js';
import { getJSON, fetchJSON } from './coverfetch.js';
import { lang } from './i18n.js';
import { sleep, log } from './bridge.js';
import * as IDB from './idb.js';

const TTL = 30 * 864e5, MISS_TTL = 2 * 864e5, FAIL_TTL = 20 * 60e3;
const enc = encodeURIComponent;
const unq = (s) => String(s || '').replace(/["\\]/g, ' ').trim();
const key = (n) => String(n || '').trim().toLowerCase() + '|' + lang;
const inflight = new Map();

/* ------------------------------------------------------------------ the disk cache
   Artists in IndexedDB under «ai:<name>|<lang>», read into memory once (the artist page asks synchronously).
   Before 2.0 they were in localStorage (gatefold.artistinfo.v2): moved over on the first start, then dropped. */
const old = new JsonStore('gatefold.artistinfo.v2', 3000);   // also the album info («al:…»), which stays there
const MEM = new Map();
let loaded = false;
const loading = (async () => {
  await sleep(1200);   // after the first screen is drawn
  const rows = await IDB.kvPrefix('ai:');
  for (const [k, v] of rows) MEM.set(k.slice(3), v);
  const moved = [];
  for (const k of Object.keys(old.data)) {
    if (k.startsWith('al:')) continue;
    if (!MEM.has(k)) { MEM.set(k, old.data[k]); moved.push(k); }
    delete old.data[k];
  }
  for (const k of moved) await IDB.kvSet('ai:' + k, MEM.get(k));
  if (moved.length) { old.compact(); old.flush(); log('artistinfo: moved', moved.length, 'artists to IndexedDB'); }
  loaded = true;
})().catch(() => { loaded = true; });
const peek = (k) => MEM.get(k) ?? (loaded ? undefined : old.get(k));
function keep(k, v) { MEM.set(k, v); IDB.kvSet('ai:' + k, v); }

/* ------------------------------------------------------------------ asking more than once */
/** JSON from a URL; no answer or «busy» is tried again after 1.5 s and 5 s. `bad.no` is set when none came */
async function ask(url, bad, tries = 3) {
  for (let i = 0; i < tries; i++) {
    const r = await fetchJSON(url);
    if (r.data) return r.data;
    if (r.status >= 400 && r.status !== 429 && r.status !== 503) return null;   // a real «no»: not asked again
    if (i < tries - 1) await sleep(i ? 5000 : 1500);
  }
  if (bad) bad.no = true;
  return null;
}

function verifies(local, titles) {
  if (!local.length || !titles.length) return false;
  return local.some((a) => titles.some((t) => similarity(cleanAlbum(a), cleanAlbum(t)) >= 0.86));
}
const yearOf = (d) => +(String(d || '').slice(0, 4)) || 0;
const byYear = (p, q) => (p.year || 9999) - (q.year || 9999) || String(p.title).localeCompare(String(q.title));
/** one entry per title and type (explicit and clean editions, re-releases): the earliest is kept */
function dedupe(list) {
  const seen = new Map();
  for (const d of [...list].sort(byYear)) { const k = d.type + '|' + cleanAlbum(d.title).toLowerCase(); if (!seen.has(k)) seen.set(k, d); }
  return [...seen.values()];
}

/* ------------------------------------------------------------------ Deezer: related artists, and a discography */
async function deezer(a, bad) {
  const j = await ask(`https://api.deezer.com/search/artist?q=${enc(a.name)}&limit=8`, bad);
  const cands = ((j && j.data) || []).map((d) => ({ id: d.id, sim: similarity(a.name, d.name), fans: d.nb_fan || 0 })).filter((d) => d.sim >= 0.86).sort((x, y) => (y.sim - x.sim) || (y.fans - x.fans));
  for (const d of cands.slice(0, 3)) {
    const all = [];
    for (let i = 0, url = `https://api.deezer.com/artist/${d.id}/albums?limit=100`; url && i < 4; i++) {
      const al = await ask(url, bad);
      all.push(...((al && al.data) || []));
      url = al && al.next ? String(al.next).replace(/^http:/, 'https:') : '';
    }
    if (!verifies(a.albums, all.map((x) => x.title))) continue;
    const rel = await ask(`https://api.deezer.com/artist/${d.id}/related?limit=12`, null, 2);
    const T = { album: 'Album', ep: 'EP', single: 'Single' };
    const disco = dedupe(all.filter((x) => T[x.record_type]).map((x) => ({
      id: 'dz:' + x.id, title: x.title, year: yearOf(x.release_date), type: T[x.record_type],
      cover: x.cover_medium ? String(x.cover_medium).replace(/\/\d+x\d+-/, '/{s}x{s}-') : '',
    })));
    return { similar: ((rel && rel.data) || []).map((x) => x.name).filter(Boolean).slice(0, 10), disco };
  }
  return { similar: [], disco: [] };
}

/* ------------------------------------------------------------------ Apple Music (iTunes): the last resort */
async function itunes(a, bad) {
  const country = String(settings.coverCountries || 'US').split(/[,\s]+/).filter(Boolean)[0] || 'US';
  const j = await ask(`https://itunes.apple.com/search?term=${enc(a.name)}&entity=musicArtist&limit=6&country=${enc(country)}`, bad, 2);
  const cands = ((j && j.results) || []).filter((x) => x.artistId && similarity(a.name, x.artistName || '') >= 0.88);
  for (const x of cands.slice(0, 2)) {
    const l = await ask(`https://itunes.apple.com/lookup?id=${x.artistId}&entity=album&limit=200&country=${enc(country)}`, bad, 2);
    const typed = ((l && l.results) || []).filter((r) => r.wrapperType === 'collection' && r.collectionName).map((r) => {
      const name = String(r.collectionName);
      const type = / - Single$/i.test(name) ? 'Single' : / - EP$/i.test(name) ? 'EP' : 'Album';
      return { id: 'it:' + r.collectionId, title: name.replace(/ - (Single|EP)$/i, ''), year: yearOf(r.releaseDate), type,
        cover: r.artworkUrl100 ? String(r.artworkUrl100).replace(/\/\d+x\d+bb\./, '/{s}x{s}bb.') : '' };
    });
    if (!verifies(a.albums, typed.map((d) => d.title))) continue;
    return dedupe(typed);
  }
  return [];
}

/* ------------------------------------------------------------------ MusicBrainz */
/** the verified MusicBrainz artist: its studio albums, EPs and singles, and the opening of its Wikipedia article */
async function musicbrainz(a, bad) {
  const j = await ask(`https://musicbrainz.org/ws/2/artist/?query=${enc(`artist:"${unq(a.name)}"`)}&fmt=json&limit=5`, bad);
  if (!j) return { about: null, disco: [], mbid: '' };
  const cands = (j.artists || []).filter((x) => similarity(a.name, x.name) >= 0.9 || (x.aliases || []).some((al) => similarity(a.name, al.name) >= 0.92));
  for (const x of cands.slice(0, 3)) {
    // albums and EPs page by page (a long career has hundreds of release groups: singles, live, bootlegs…),
    // singles separately — otherwise the albums you have may not be on the first page and the artist is missed
    const groups = [];
    for (let off = 0; off < 400; off += 100) {
      const rg = await ask(`https://musicbrainz.org/ws/2/release-group?artist=${x.id}&type=album|ep&fmt=json&limit=100&offset=${off}`, bad);
      const page = (rg && rg['release-groups']) || [];
      groups.push(...page);
      if (!rg || page.length < 100 || groups.length >= (rg['release-group-count'] || 0)) break;
    }
    if (!verifies(a.albums, groups.map((r) => r.title))) continue;
    const sg = await ask(`https://musicbrainz.org/ws/2/release-group?artist=${x.id}&type=single&fmt=json&limit=100`, null);
    groups.push(...((sg && sg['release-groups']) || []));
    // studio albums, EPs and singles, oldest first (no compilations, live albums, remixes, soundtracks)
    const disco = groups.filter((g) => ['Album', 'EP', 'Single'].includes(g['primary-type']) && !(g['secondary-types'] || []).length)
      .map((g) => ({ id: g.id, title: g.title, year: yearOf(g['first-release-date']), type: g['primary-type'] }))
      .sort(byYear);
    const rel = await ask(`https://musicbrainz.org/ws/2/artist/${x.id}?inc=url-rels&fmt=json`, null, 2);
    const wd = ((rel && rel.relations) || []).find((r) => r.type === 'wikidata' && r.url && r.url.resource);
    // the article never holds up the discography: what is not there in 5 s is added to the kept copy when it comes
    const aboutP = wd ? summaryFor(wd.url.resource.split('/').pop()).catch(() => null) : Promise.resolve(null);
    const about = await Promise.race([aboutP, sleep(5000).then(() => undefined)]);
    return { about: about || null, aboutLater: about === undefined ? aboutP : null, disco, mbid: x.id };
  }
  return { about: null, disco: [], mbid: '' };
}

export const sameTitle = (a, b) => similarity(cleanAlbum(a), cleanAlbum(b)) >= 0.86;
/** one song under two spellings: «(feat. …)», «(Remastered)», punctuation and case do not count */
const normTrack = (t) => String(t || '').toLowerCase()
  .replace(/\s*[([](feat|ft|with|prod|remaster|remastered|bonus|explicit|clean|radio edit|album version)[^)\]]*[)\]]/g, '')
  .replace(/\s+-\s+(\d{4}\s+)?remaster(ed)?.*$/, '')
  .replace(/[^\p{L}\p{N}]+/gu, ' ').trim();
export const sameTrack = (a, b) => { const x = normTrack(a), y = normTrack(b); return !!x && !!y && (x === y || similarity(x, y) >= 0.9); };

/* ------------------------------------------------------------------ an album of yours → its release group
   Used to show the tracks of an album you have only in part. The artist's discography answers when it is
   known; otherwise one MusicBrainz search (the album title and the artist must both match). */
const gstore = new JsonStore('gatefold.rgid.v1', 2000);
export async function releaseGroupFor(artist, album) {
  if (settings.onlineInfo === false || !artist || !album) return '';
  const k = key(artist + '\u0001' + album);
  const c = gstore.get(k);
  if (c && Date.now() - c.t < (c.id ? 3 * TTL : MISS_TTL)) return c.id;
  const ci = cached(artist);
  const d = ci && (ci.disco || []).find((x) => x.id && sameTitle(x.title, album));
  if (d) { gstore.set(k, { t: Date.now(), id: d.id }); return d.id; }
  if (inflight.has('rg:' + k)) return inflight.get('rg:' + k);
  const p = (async () => {
    const j = await getJSON(`https://musicbrainz.org/ws/2/release-group/?query=${enc(`releasegroup:"${unq(cleanAlbum(album) || album)}" AND artist:"${unq(artist)}"`)}&fmt=json&limit=8`);
    if (!j) return '';   // MusicBrainz did not answer: asked again next time, nothing kept
    const cands = (j['release-groups'] || []).filter((g) => sameTitle(album, g.title)
      && (g['artist-credit'] || []).some((cr) => similarity(artist, (cr.artist && cr.artist.name) || cr.name || '') >= 0.88));
    // a studio release before a compilation or a live recording of the same name
    cands.sort((p, q) => (p['secondary-types'] || []).length - (q['secondary-types'] || []).length);
    const id = cands[0] ? cands[0].id : '';
    gstore.set(k, { t: Date.now(), id });
    return id;
  })().catch(() => '').finally(() => inflight.delete('rg:' + k));
  inflight.set('rg:' + k, p);
  return p;
}
/** which of the artist's releases you have: [{ title, year, type, own }] (titles compared loosely) */
export function discography(info, localTitles) {
  return ((info && info.disco) || []).map((d) => ({ ...d, own: localTitles.some((t) => sameTitle(t, d.title)) }));
}

/** the opening of a Wikipedia article for a Wikidata item, in the interface language or English */
async function summaryFor(q) {
  const e = await getJSON(`https://www.wikidata.org/wiki/Special:EntityData/${q}.json`);
  const links = (e && e.entities && e.entities[q] && e.entities[q].sitelinks) || {};
  for (const l of [lang, 'en']) {
    const s = links[l + 'wiki']; if (!s || !s.title) continue;
    const sum = await getJSON(`https://${l}.wikipedia.org/api/rest_v1/page/summary/${enc(s.title.replace(/ /g, '_'))}`);
    if (sum && sum.extract) return { text: shorten(sum.extract), url: (sum.content_urls && sum.content_urls.desktop && sum.content_urls.desktop.page) || `https://${l}.wikipedia.org/wiki/${enc(s.title)}`, lang: l };
  }
  return null;
}

/* MusicBrainz roles worth showing, in this order; the rest are left out */
const ROLES = ['producer', 'instrument', 'vocal', 'performer', 'mix', 'recording', 'engineer', 'mastering', 'arranger', 'composer', 'lyricist'];
async function albumWiki(artist, album) {
  const j = await getJSON(`https://musicbrainz.org/ws/2/release-group/?query=${enc(`releasegroup:"${unq(album)}" AND artist:"${unq(artist)}"`)}&fmt=json&limit=5`);
  const cands = ((j && j['release-groups']) || []).filter((g) => similarity(cleanAlbum(album), cleanAlbum(g.title)) >= 0.9
    && (g['artist-credit'] || []).some((c) => similarity(artist, (c.artist && c.artist.name) || c.name || '') >= 0.88));
  const g = cands[0];
  if (!g) return { about: null, label: '', credits: [] };
  const rel = await getJSON(`https://musicbrainz.org/ws/2/release-group/${g.id}?inc=url-rels&fmt=json`);
  const wd = ((rel && rel.relations) || []).find((r) => r.type === 'wikidata' && r.url && r.url.resource);
  const about = wd ? await summaryFor(wd.url.resource.split('/').pop()) : null;
  // the earliest official release: its label and the people credited on it
  const rl = await getJSON(`https://musicbrainz.org/ws/2/release?release-group=${g.id}&status=official&fmt=json&limit=10`);
  const first = ((rl && rl.releases) || []).sort((p, q) => String(p.date || '9999').localeCompare(String(q.date || '9999')))[0];
  let label = '', credits = [];
  if (first) {
    const d = await getJSON(`https://musicbrainz.org/ws/2/release/${first.id}?inc=labels+artist-rels&fmt=json`);
    const li = ((d && d['label-info']) || []).find((x) => x.label && x.label.name);
    label = li ? li.label.name : '';
    const seen = new Map();
    for (const r of (d && d.relations) || []) {
      if (!r.artist || !ROLES.includes(r.type)) continue;
      const role = r.type === 'instrument' && r.attributes && r.attributes.length ? r.attributes.join(', ') : r.type;
      const k = r.artist.name;
      const v = seen.get(k) || { name: k, roles: [] }; if (!v.roles.includes(role)) v.roles.push(role); seen.set(k, v);
    }
    credits = [...seen.values()].sort((p, q) => ROLES.indexOf(p.roles[0]) - ROLES.indexOf(q.roles[0])).slice(0, 12);
  }
  return { about, label, credits };
}

/** the opening of the album's Wikipedia article (cached like artists); null when off or not found */
export function albumCached(artist, album) {
  const c = old.get('al:' + key(artist + '\u0001' + album));
  return c && Date.now() - c.t < (c.about || c.label || (c.credits && c.credits.length) ? TTL : MISS_TTL) ? c : null;
}
export async function album(artist, album) {
  if (settings.onlineInfo === false || !artist || !album) return null;
  const c = albumCached(artist, album); if (c) return c;
  const k = 'al:' + key(artist + '\u0001' + album);
  if (inflight.has(k)) return inflight.get(k);
  const p = albumWiki(artist, album).catch(() => ({})).then((x) => { const v = { t: Date.now(), about: x.about || null, label: x.label || '', credits: x.credits || [] }; old.set(k, v); return v; }).finally(() => inflight.delete(k));
  inflight.set(k, p);
  return p;
}

/* ------------------------------------------------------------------ a release's track list
   One release group (an album, EP or single) → the tracks of its earliest official release:
   [{ n, disc, title, sec }]. Kept for 90 days; the artist page opens it for albums you do not have
   (or have only in part) — present tracks play from the disk, the rest through YouTube. */
const rstore = new JsonStore('gatefold.releases.v1', 600);
export function releaseCached(id) { const c = rstore.get(id); return c && Date.now() - c.t < (c.tracks && c.tracks.length ? 90 * 864e5 : MISS_TTL) ? c : null; }
export async function release(id) {
  if (!id) return null;
  const c = releaseCached(id); if (c) return c;
  const k = 'rel:' + id;
  if (inflight.has(k)) return inflight.get(k);
  const p = (async () => {
    const v = id.startsWith('dz:') ? await deezerTracks(id.slice(3)) : id.startsWith('it:') ? await itunesTracks(id.slice(3)) : await mbTracks(id);
    if (!v) return null;   // no answer: nothing kept, asked again next time
    v.t = Date.now();
    rstore.set(id, v);
    return v;
  })().catch(() => null).finally(() => inflight.delete(k));
  inflight.set(k, p);
  return p;
}
async function mbTracks(id) {
  const j = await ask(`https://musicbrainz.org/ws/2/release?release-group=${enc(id)}&status=official&inc=recordings+media&fmt=json&limit=25`, null);
  if (!j) return null;
  const rels = (j.releases || []).filter((r) => (r.media || []).some((m) => (m.tracks || []).length));
  // the earliest official release; at the same date the one with the most tracks (a deluxe edition comes later)
  rels.sort((p, q) => String(p.date || '9999').localeCompare(String(q.date || '9999')) || count(q) - count(p));
  const r = rels[0];
  const tracks = [];
  if (r) for (const [di, m] of (r.media || []).entries()) for (const t of m.tracks || []) tracks.push({ n: tracks.length + 1, disc: di + 1, title: t.title || (t.recording && t.recording.title) || '', sec: Math.round((t.length || (t.recording && t.recording.length) || 0) / 1000) });
  return { tracks, date: (r && r.date) || '', discs: r ? (r.media || []).length : 0 };
}
async function deezerTracks(n) {
  const al = await ask(`https://api.deezer.com/album/${enc(n)}`, null);
  if (!al) return null;
  const list = ((al.tracks && al.tracks.data) || []);
  const tracks = list.map((t, i) => ({ n: i + 1, disc: t.disk_number || 1, title: t.title || '', sec: t.duration || 0 }));
  return { tracks, date: al.release_date || '', discs: Math.max(1, ...tracks.map((t) => t.disc)) };
}
async function itunesTracks(n) {
  const l = await ask(`https://itunes.apple.com/lookup?id=${enc(n)}&entity=song&limit=200`, null, 2);
  if (!l) return null;
  const songs = (l.results || []).filter((r) => r.wrapperType === 'track').sort((p, q) => (p.discNumber || 1) - (q.discNumber || 1) || (p.trackNumber || 0) - (q.trackNumber || 0));
  const col = (l.results || []).find((r) => r.wrapperType === 'collection');
  const tracks = songs.map((t, i) => ({ n: i + 1, disc: t.discNumber || 1, title: t.trackName || '', sec: Math.round((t.trackTimeMillis || 0) / 1000) }));
  return { tracks, date: col ? String(col.releaseDate || '').slice(0, 10) : '', discs: Math.max(1, ...tracks.map((t) => t.disc)) };
}
const count = (r) => (r.media || []).reduce((n, m) => n + (m.tracks || []).length, 0);
/** the cover of a release (a discography entry, or a MusicBrainz release-group id) at 250 or 500 px:
    the Cover Art Archive for MusicBrainz, the catalogue's own picture for Deezer and Apple Music */
export function releaseCover(d, size = 250) {
  if (d && typeof d === 'object') { if (d.cover) return d.cover.replace(/\{s\}/g, size); d = d.id; }
  if (!d || /^(dz|it):/.test(d)) return '';
  return `https://coverartarchive.org/release-group/${d}/front-${size}`;
}

/** the first two or three sentences, at most ~420 characters */
export function shorten(t) {
  const s = String(t || '').replace(/\s+/g, ' ').trim();
  if (s.length <= 420) return s;
  const parts = s.match(/[^.!?。]+[.!?。]+(\s|$)/g) || [s];
  let out = '';
  for (const p of parts) { if ((out + p).length > 420 && out) break; out += p; }
  return (out || s.slice(0, 400) + '…').trim();
}

/** cached info right away (or null). A discography is returned even when it is old (the page shows it while
    `revalidate` fetches a fresh one); one saved before 2.0 (no release ids, no singles) is fetched again. */
export function cached(name) {
  const c = peek(key(name));
  if (!c) return null;
  const n = (c.disco && c.disco.length) || 0;
  if (n && c.disco.some((d) => !d.id)) return null;
  if ((c.v || 0) < 5 && !n) return null;          // «not found» from before failed requests were told apart: try again
  if (n >= 2) return c;
  if (c.failed) return Date.now() - c.t < FAIL_TTL ? c : null;   // nobody answered: again after 20 minutes
  return Date.now() - c.t < MISS_TTL ? c : null;                 // not found: again in two days
}
const stale = (c) => !c || Date.now() - c.t >= TTL;

/** forget what is kept about an artist (the «try again» of the artist page) */
export function forget(name) { const k = key(name); MEM.delete(k); IDB.kvDel('ai:' + k); }

/** info for { name, albums: [titles] }; null when online data is off */
export async function get(a) {
  if (settings.onlineInfo === false || !a || !a.name) return null;
  if (!loaded) await loading;
  const c = cached(a.name);
  if (c && c.mbid && !c.about) aboutLater(key(a.name), c);
  if (c && !stale(c)) return c;
  if (c && c.disco && c.disco.length >= 2) { revalidate(a); return c; }   // the old copy now, a fresh one in the background
  return fetchInfo(a);
}
/** a fresh copy in the background when the kept one is older than 30 days (nothing when it is fresh) */
export function revalidate(a) {
  if (settings.onlineInfo === false || !a || !a.name) return;
  const c = cached(a.name);
  if (c && stale(c) && !inflight.has(key(a.name))) fetchInfo(a).catch(() => {});
}

/* the article of a kept artist that has none (Wikipedia refused requests before 2.0 beta 2): asked again, at most
   once a week per artist, in the background */
function aboutLater(k, c) {
  if (inflight.has('ab:' + k) || Date.now() - (c.aboutTried || 0) < 7 * 864e5) return;
  const p = (async () => {
    const rel = await ask(`https://musicbrainz.org/ws/2/artist/${c.mbid}?inc=url-rels&fmt=json`, null, 2);
    const wd = ((rel && rel.relations) || []).find((r) => r.type === 'wikidata' && r.url && r.url.resource);
    const about = wd ? await summaryFor(wd.url.resource.split('/').pop()).catch(() => null) : null;
    const cur = peek(k);
    if (cur) keep(k, { ...cur, about: cur.about || about, aboutTried: Date.now() });
  })().catch(() => {}).finally(() => inflight.delete('ab:' + k));
  inflight.set('ab:' + k, p);
}

function fetchInfo(a) {
  const k = key(a.name);
  if (inflight.has(k)) return inflight.get(k);
  const p = (async () => {
    const bad = {};
    const [mb, dz] = await Promise.all([musicbrainz(a, bad).catch(() => ({ disco: [], failed: true })), deezer(a, {}).catch(() => ({ similar: [], disco: [] }))]);
    let disco = mb.disco || [], src = 'musicbrainz';
    if (disco.length < 2 && dz.disco.length >= 2) { disco = dz.disco; src = 'deezer'; }
    if (disco.length < 2) {
      const it = await itunes(a, {}).catch(() => []);
      if (it.length >= 2) { disco = it; src = 'itunes'; }
    }
    const failed = disco.length < 2 && (bad.no || mb.failed);
    const v = { v: 6, t: Date.now(), about: mb.about || null, disco, src: disco.length ? src : '', mbid: mb.mbid || '', similar: dz.similar || [], ...(failed ? { failed: true } : {}) };
    // a discography found before is never replaced by nothing: kept, and asked again in a day
    const prev = peek(k);
    if (disco.length < 2 && prev && prev.disco && prev.disco.length >= 2) {
      const kept = { ...prev, t: Date.now() - TTL + 864e5, about: prev.about || v.about, similar: (prev.similar && prev.similar.length) ? prev.similar : v.similar };
      keep(k, kept);
      return kept;
    }
    keep(k, v);
    if (mb.aboutLater) mb.aboutLater.then((ab) => { const cur = ab && peek(k); if (cur && !cur.about) keep(k, { ...cur, about: ab }); });
    log('artistinfo:', a.name, '→', src && disco.length ? `${disco.length} releases from ${src}` : failed ? 'no answer' : 'not found');
    return v;
  })().finally(() => inflight.delete(k));
  inflight.set(k, p);
  return p;
}
