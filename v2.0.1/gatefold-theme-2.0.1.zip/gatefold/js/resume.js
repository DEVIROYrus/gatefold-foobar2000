/*
 * Gatefold · resume.js — the song that played when the program was closed is there when it opens again.
 *
 * While music plays, the track, where it sits (playlist and position in it) and how far it got are written down
 * every few seconds. At the next start, when foobar2000 itself has nothing playing, the player shows that track,
 * stopped at that moment; Play (the button, Space, the media key, the taskbar) starts it from there. Anything
 * else started first simply replaces it. If the playlist changed meanwhile, the track is found by its file.
 */
import { call, ok } from './bridge.js';

const KEY = 'gatefold.resume.v1';
let lastSave = 0;

function read() { try { return JSON.parse(localStorage.getItem(KEY) || 'null'); } catch { return null; } }
function write(v) { try { localStorage.setItem(KEY, JSON.stringify(v)); } catch { /* full or blocked: not kept */ } }
const same = (a, b) => !!a && !!b && (a.handle || a.path) === (b.handle || b.path);

/** a new track plays: remember it and where it sits */
export async function started(t) {
  if (!t || !(t.path || t.handle)) return;
  const ci = await call('playback.getCurrentTrackIndex');
  const place = ok(ci) && ci.found !== false && ci.playlistGuid ? { guid: ci.playlistGuid, index: ci.index } : null;
  write({ t, pos: 0, dur: t.duration || 0, place, at: Date.now() });
  lastSave = Date.now();
}

/** how far it got (called often while playing; written every 4 s, or at once with `now`) */
export function progress(t, pos, now = false) {
  if (!t || (!now && Date.now() - lastSave < 4000)) return;
  const v = read();
  if (!v || !same(v.t, t)) return;
  lastSave = Date.now();
  v.pos = Math.max(0, +pos || 0); v.at = Date.now();
  write(v);
}

/** what to show at start: { t, pos, dur, place } or null */
export function saved() {
  const v = read();
  return v && v.t && (v.t.path || v.t.handle) ? v : null;
}

/** start the remembered track from where it stopped */
export async function play(v) {
  let started = false;
  if (v.place && v.place.guid) {
    const r = await call('playlist.getTracks', { playlistGuid: v.place.guid, start: v.place.index, count: 1, fields: ['path', 'absolutePath', 'handle', 'subsong'] });
    const x = ok(r) && r.tracks && r.tracks[0];
    if (x && [x.handle, x.absolutePath, x.path].some((p) => p && (p === v.t.handle || p === v.t.path))) {
      started = ok(await call('playlist.playTrack', { playlistGuid: v.place.guid, index: v.place.index }));
    }
  }
  if (!started) {
    const { playPaths } = await import('./library.js');
    await playPaths([v.t.handle || v.t.path], 0, v.t.title);
  }
  // then on to the moment it stopped (not for the last seconds: those start the track over)
  const pos = +v.pos || 0, dur = +v.dur || +v.t.duration || 0;
  if (pos < 3 || (dur && pos > dur - 5)) return;
  // foobar2000 says «playing» a moment before the track can be moved: asked again until it is there (up to 4 s)
  const wait = (ms) => new Promise((r) => setTimeout(r, ms));
  for (let i = 0; i < 40; i++) {
    const s = await call('playback.getState');
    if (ok(s) && s.isPlaying) {
      await call('playback.setPosition', { position: pos });
      await wait(120);
      const p = await call('playback.getPosition');
      if (ok(p) && Math.abs((+p.position || 0) - pos) < 3) return;
    }
    await wait(100);
  }
}
