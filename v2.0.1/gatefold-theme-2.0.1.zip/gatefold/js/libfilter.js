/*
 * Gatefold · libfilter.js — filter chips over the album grid: genre, decade, quality.
 * One choice per kind; the chips say what is on and a × takes it off. Quality (lossless / Hi-Res /
 * lossy) comes from each album's first track, asked of foobar2000 once, in the background.
 */
import { esc, call } from './bridge.js';
import { h, icon, popupMenu } from './ui.js';
import { $t } from './i18n.js';
import { yearOf, albumKey } from './sorting.js';
import { albumKeyOf } from './bridge.js';
import * as Sound from './ml/sound.js';
import * as SoundUI from './ml/sound-ui.js';

export const F = { genre: '', decade: 0, quality: '', mood: '' };
let moodA = null, moodT = null;          // the chosen mood: albums by share, track keys
let onChange = () => {}, getAlbums = () => [];
const quality = new Map();          // first track path → 'hires' | 'lossless' | 'lossy'
let qLoading = null;

const QUAL = () => ({ lossless: $t('Без потерь'), hires: 'Hi-Res', lossy: $t('С потерями') });
const genresOf = (a) => String(a.genre || '').split(/\s*[;/,]\s*/).map((g) => g.trim()).filter(Boolean);

export const active = () => !!(F.genre || F.decade || F.quality || F.mood);
const LOSSLESS = /^(flac|alac|wavpack|monkey's audio|ape|pcm|wav|aiff?|tak|tta|dsd|dsf|dff|mlp|true audio|optimfrog)/i;
/** quality of one track from the library's fields (no bit depth there: Hi-Res = lossless above 48 kHz) */
const trackQuality = (t) => (LOSSLESS.test(String(t.codec || '')) ? (+t.sampleRate > 48000 ? 'hires' : 'lossless') : t.codec ? 'lossy' : '');
function setMood(kind) {
  F.mood = kind; moodA = kind ? SoundUI.moodAlbums(kind, albumKeyOf) : null; moodT = kind ? SoundUI.moodKeys(kind) : null;
}

export function filter(list) {
  if (!active()) return list;
  const g = F.genre.toLowerCase();
  return list.filter((a) => (!F.genre || genresOf(a).some((x) => x.toLowerCase() === g))
    && (!F.decade || Math.floor(yearOf(a) / 10) * 10 === F.decade)
    && (!F.quality || quality.get(a.firstTrackAbsolutePath) === F.quality || (F.quality === 'lossless' && quality.get(a.firstTrackAbsolutePath) === 'hires'))
    && (!F.mood || (moodA && (moodA.get(albumKey(a)) || 0) >= 0.4)));
}
/** the same choices for one track of «Tracks» (tracks.js): its genre text, year and fields */
export function matchTrack(t, genre, year) {
  if (F.genre && !String(genre || '').split(/\s*[;/,]\s*/).some((x) => x.trim().toLowerCase() === F.genre.toLowerCase())) return false;
  if (F.decade && Math.floor((year || 0) / 10) * 10 !== F.decade) return false;
  if (F.quality) { const q = trackQuality(t); if (!(q === F.quality || (F.quality === 'lossless' && q === 'hires'))) return false; }
  if (F.mood && !(moodT && moodT.has(Sound.keyOf(t)))) return false;
  return true;
}

async function loadQuality() {
  if (qLoading) return qLoading;
  qLoading = (async () => {
    const paths = getAlbums().map((a) => a.firstTrackAbsolutePath).filter((p) => p && !quality.has(p));
    for (let i = 0; i < paths.length; i += 400) {
      const part = paths.slice(i, i + 400);
      const r = await call('titleformat.evalFieldsBatch', { paths: part, fields: { enc: '%__encoding%', bits: '%__bitspersample%', sr: '%samplerate%' } });
      const rows = (r && r.success !== false && r.results) || [];
      part.forEach((p, k) => {
        const v = rows[k];
        if (!v || v.success === false) return;
        const enc = String(v.enc || '').toLowerCase();
        if (!enc || enc === '?') return;
        quality.set(p, enc === 'lossless' ? ((+v.bits > 16 || +v.sr > 48000) ? 'hires' : 'lossless') : 'lossy');
      });
    }
  })().finally(() => { qLoading = null; });
  return qLoading;
}

function counts(key) {
  const m = new Map();
  for (const a of getAlbums()) for (const k of key(a)) if (k) m.set(k, (m.get(k) || 0) + 1);
  return [...m].sort((x, y) => y[1] - x[1]);
}

async function pick(kind, btn) {
  const r = btn.getBoundingClientRect();
  let items = [];
  if (kind === 'genre') items = counts(genresOf).slice(0, 30).map(([g, n]) => ({ id: g, label: `${g} · ${n}`, checked: F.genre === g }));
  if (kind === 'decade') items = counts((a) => { const y = yearOf(a); return y ? [Math.floor(y / 10) * 10] : []; }).sort((x, y) => y[0] - x[0]).map(([d, n]) => ({ id: d, label: `${$t('{0}-е', d)} · ${n}`, checked: F.decade === d }));
  if (kind === 'quality') {
    btn.classList.add('busy'); await loadQuality(); btn.classList.remove('busy');
    const c = { lossless: 0, hires: 0, lossy: 0 };
    for (const a of getAlbums()) { const q = quality.get(a.firstTrackAbsolutePath); if (q) { c[q]++; if (q === 'hires') c.lossless++; } }
    items = Object.entries(QUAL()).filter(([k]) => c[k]).map(([k, label]) => ({ id: k, label: `${label} · ${c[k]}`, checked: F.quality === k }));
  }
  if (kind === 'mood') {
    const recipes = SoundUI.MOOD_RECIPES();
    items = recipes.map(([k, title]) => { const m = SoundUI.moodAlbums(k, albumKeyOf); const n = m ? [...m.values()].filter((v) => v >= 0.4).length : 0; return { id: k, label: `${title} · ${n}`, checked: F.mood === k, n }; }).filter((x) => x.n);
  }
  if (!items.length) return;
  const id = await popupMenu(items, r.left, r.bottom + 4);
  if (id == null) return;
  if (kind === 'mood') setMood(F.mood === id ? '' : id);
  else F[kind] = F[kind] === id ? (kind === 'decade' ? 0 : '') : id;
  render(); onChange();
}

let bar = null;
export function render() {
  if (!bar) return;
  const moodName = F.mood ? ((SoundUI.MOOD_RECIPES().find((x) => x[0] === F.mood) || [])[1] || F.mood) : '';
  const label = { genre: F.genre, decade: F.decade ? $t('{0}-е', F.decade) : '', quality: F.quality ? QUAL()[F.quality] : '', mood: moodName };
  const names = { genre: $t('Жанр'), decade: $t('Десятилетие'), quality: $t('Качество'), mood: $t('Настроение') };
  bar.innerHTML = '';
  for (const k of ['genre', 'decade', 'quality', ...(Sound.ready() ? ['mood'] : [])]) {
    const on = !!label[k];
    const b = h(`<button class="lf-chip${on ? ' on' : ''}" data-k="${k}"><span></span>${on ? `<i class="x" role="button" aria-label="${esc($t('Сбросить'))}">${icon('x', 12)}</i>` : icon('chev', 12)}</button>`);
    b.querySelector('span').textContent = on ? label[k] : names[k];
    b.onclick = (e) => { if (e.target.closest('.x')) { if (k === 'mood') setMood(''); else F[k] = k === 'decade' ? 0 : ''; render(); onChange(); return; } pick(k, b); };
    bar.append(b);
  }
  if (active()) { const c = h(`<button class="lf-clear">${esc($t('Сбросить всё'))}</button>`); c.onclick = () => { F.genre = ''; F.decade = 0; F.quality = ''; setMood(''); render(); onChange(); }; bar.append(c); }
}

const listeners = new Set();
/** «Tracks» re-filters too when a chip changes */
export const onFilter = (fn) => listeners.add(fn);
export function init({ mount, albums, changed }) {
  bar = mount; getAlbums = albums; onChange = () => { changed(); for (const f of listeners) f(); };
  render();
  Sound.events.addEventListener('change', () => { if (!bar.querySelector('[data-k=mood]') && Sound.ready()) render(); });
}
