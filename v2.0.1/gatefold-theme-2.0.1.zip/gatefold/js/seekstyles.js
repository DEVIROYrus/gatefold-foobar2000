/*
 * Gatefold · seekstyles.js — the looks of the seek bar under the player (Settings → Player → Seek bar).
 *
 *   bars     the track's waveform as thin rounded columns, mirrored around the middle (the default)
 *   peaks    columns rising from the bottom, as on SoundCloud
 *   smooth   one smooth filled outline of the whole track
 *   dots     columns of dots, like an LED meter
 *   live     the music as it sounds right now: the spectrum, coloured up to where the track is
 *   line     a plain thin line with a knob (no waveform)
 *
 * The first four draw the whole track's waveform once into layers (viz.js colours the played part); «live» is
 * drawn every frame from the spectrum while music plays.
 */
export const STYLES = ['bars', 'peaks', 'smooth', 'dots', 'live', 'line'];
export const isWave = (s) => s !== 'line';
export const isLive = (s) => s === 'live';
/** column spacing and width in CSS px for a style */
export const geometry = (s) => (s === 'smooth' ? { step: 2, bw: 2 } : s === 'dots' ? { step: 4, bw: 3 } : s === 'live' ? { step: 5, bw: 3 } : { step: 3, bw: 2 });

/** one waveform (vals 0…1 per column) in one colour: the shape of a style */
export function shape(style, c, w, h, vals, d, step, bw) {
  const n = vals.length, mid = h / 2;
  if (style === 'peaks') {
    c.beginPath();      // one path, one fill: the same picture in one draw call
    for (let i = 0; i < n; i++) {
      const v = Math.max(d * 1.5, vals[i] * h * 0.94);
      c.roundRect(i * step, h - v, bw, v, [bw / 2, bw / 2, 0, 0]);
    }
    c.fill();
  } else if (style === 'smooth') {
    const top = [];
    for (let i = 0; i < n; i++) top.push([i * step + bw / 2, mid - Math.max(d, vals[i] * h * 0.46)]);
    c.beginPath(); c.moveTo(0, mid);
    for (const [x, y] of top) c.lineTo(x, y);
    c.lineTo(w, mid);
    for (let i = n - 1; i >= 0; i--) c.lineTo(top[i][0], h - top[i][1]);
    c.closePath(); c.fill();
  } else if (style === 'dots') {
    const r = bw / 2, rows = Math.max(1, Math.floor(h / step));
    c.beginPath();
    for (let i = 0; i < n; i++) {
      const k = Math.max(1, Math.round(vals[i] * rows));
      const y0 = mid - ((k - 1) * step) / 2;
      for (let j = 0; j < k; j++) { const x = i * step + r, y = y0 + j * step; c.moveTo(x + r, y); c.arc(x, y, r, 0, Math.PI * 2); }
    }
    c.fill();
  } else {   // bars (and live: drawn the same way, from the spectrum)
    c.beginPath();
    for (let i = 0; i < n; i++) {
      const v = Math.max(d * 1.5, vals[i] * h * 0.9);
      c.roundRect(i * step, mid - v / 2, bw, v, bw / 2);
    }
    c.fill();
  }
}

/** the spectrum spread over `n` columns (bass on the left), softened at both ends */
export function spread(bars, n, out) {
  const m = bars.length || 1;
  for (let i = 0; i < n; i++) {
    const x = i / Math.max(1, n - 1);
    const k = Math.min(m - 1, Math.floor(x * m));
    const v = bars[k] || 0, w = bars[Math.min(m - 1, k + 1)] || 0, f = x * m - k;
    out[i] = Math.min(1, Math.pow(v + (w - v) * f, 0.75) * (0.8 + 0.25 * Math.sin(Math.PI * x)));   // quiet passages still show
  }
  return out;
}
