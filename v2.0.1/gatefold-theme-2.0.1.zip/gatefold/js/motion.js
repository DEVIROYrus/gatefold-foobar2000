/*
 * Gatefold · motion.js — the small movements that make the interface feel made by hand.
 * Only transform and opacity (the compositor does the work, nothing is laid out again), short and eased,
 * and none at all when Windows asks for less motion (Settings → Accessibility → Animation effects).
 *
 *   glide      the highlight of the sidebar slides from item to item instead of jumping
 *   swapText   a title that changes (a new track) rises into place instead of blinking
 *   pop        the play button answers a press with a soft bounce of its icon
 *   morph      an album cover grows from its tile into the album page (View Transitions), and back
 *   direction  going back slides the page in from the left, going forward from below
 */
import { router, onRoute } from './ui.js';

const mq = window.matchMedia ? window.matchMedia('(prefers-reduced-motion: reduce)') : { matches: false };
export const reduced = () => mq.matches;
const EASE = 'cubic-bezier(.2,.8,.2,1)';

// ---------------------------------------------------------------- a changed text rises into place
const lastText = new WeakMap();
/** call after setting an element's text: it eases in when the text really changed */
export function swapText(el, { dy = 6, ms = 380, delay = 0 } = {}) {
  if (!el) return;
  const t = el.textContent;
  if (lastText.get(el) === t) return;
  const first = !lastText.has(el);
  lastText.set(el, t);
  if (first || reduced() || !el.animate) return;
  el.animate([{ opacity: 0, transform: `translateY(${dy}px)` }, { opacity: 1, transform: 'none' }], { duration: ms, delay, easing: EASE, fill: 'backwards' });
}

// ---------------------------------------------------------------- the play button
export function pop(el) {
  if (!el || reduced() || !el.animate) return;
  el.animate([{ transform: 'scale(.72) rotate(-8deg)', opacity: 0.4 }, { transform: 'scale(1.08)', opacity: 1, offset: 0.6 }, { transform: 'none' }], { duration: 320, easing: EASE });
}

// ---------------------------------------------------------------- the sidebar highlight
let glideEl = null, side = null;
function placeGlide(animate = true) {
  if (!glideEl) return;
  const act = side.querySelector('.nav-item.active[data-view]');
  if (!act || act.hidden || !act.offsetParent) { glideEl.classList.remove('on'); side.classList.remove('has-glide'); return; }
  const s = side.getBoundingClientRect(), r = act.getBoundingClientRect();
  if (!animate || reduced() || !glideEl.classList.contains('on')) glideEl.style.transition = 'none';
  glideEl.style.transform = `translate(${r.left - s.left - side.clientLeft}px, ${r.top - s.top - side.clientTop + side.scrollTop}px)`;
  glideEl.style.width = r.width + 'px'; glideEl.style.height = r.height + 'px';
  glideEl.offsetWidth;   // the jump above is applied before the transition comes back
  glideEl.style.transition = '';
  glideEl.classList.add('on'); side.classList.add('has-glide');
}
function initGlide() {
  side = document.getElementById('sidebar');
  if (!side) return;
  glideEl = document.createElement('div');
  glideEl.className = 'nav-glide'; glideEl.setAttribute('aria-hidden', 'true');
  side.prepend(glideEl);
  onRoute(() => requestAnimationFrame(() => placeGlide(true)));
  new ResizeObserver(() => placeGlide(false)).observe(side);
  // items appearing or disappearing above the active one (YouTube, Queue) move it
  new MutationObserver(() => requestAnimationFrame(() => placeGlide(false))).observe(side, { subtree: true, attributes: true, attributeFilter: ['hidden'] });
  requestAnimationFrame(() => placeGlide(false));
}

// ---------------------------------------------------------------- back and forward
function initDirection() {
  const back = router.back.bind(router), fwd = router.forward.bind(router), go = router.go.bind(router);
  let dir = '';
  router.back = (...a) => { dir = 'back'; try { return back(...a); } finally { dir = ''; } };
  router.forward = (...a) => { dir = 'fwd'; try { return fwd(...a); } finally { dir = ''; } };
  router.go = (view, arg, opt) => { document.body.dataset.nav = dir || 'go'; return go(view, arg, opt); };
}

// ---------------------------------------------------------------- a cover grows into its page
/**
 * Open a page so that `from` (the cover box of a tile) grows into the page's own cover box (`target()`, found
 * once `open()` has drawn the page). The page's cover shows the tile's picture at once, so the morph ends on
 * the right image; the sharper one replaces it when it arrives. Plain `open()` without View Transitions.
 */
export function morph(from, open, target) {
  const img = from && from.querySelector('img');
  const loaded = img && img.complete && img.naturalWidth > 1 && getComputedStyle(img).opacity !== '0';
  if (!from || !loaded || !document.startViewTransition || reduced() || busy) { open(); return; }
  busy = true;
  from.style.viewTransitionName = 'gf-cover';
  let vt;
  try {
    vt = document.startViewTransition(async () => {
      from.style.viewTransitionName = '';
      await open();
      let t = target();
      for (let i = 0; !t && i < 6; i++) { await new Promise((r) => setTimeout(r, 16)); t = target(); }
      if (!t) return;
      const im = t.querySelector('img');
      if (im && (im.style.display === 'none' || !im.getAttribute('src'))) { im.src = img.currentSrc || img.src; im.style.display = ''; }
      t.style.viewTransitionName = 'gf-cover';
    });
  } catch { from.style.viewTransitionName = ''; busy = false; open(); return; }
  vt.finished.finally(() => { const t = target(); if (t) t.style.viewTransitionName = ''; from.style.viewTransitionName = ''; busy = false; });
}
let busy = false;

export function init() {
  initGlide();
  initDirection();
}
