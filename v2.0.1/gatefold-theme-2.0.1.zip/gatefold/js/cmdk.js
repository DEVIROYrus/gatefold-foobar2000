/*
 * Gatefold · cmdk.js — Ctrl+K: one box for everything.
 * Type a few letters: screens and actions («холст», «вперемешку», «спокойное»), albums and artists
 * from the library (instantly, from memory) and tracks (asked of foobar2000). ↑ ↓ choose, Enter runs,
 * Esc closes. With nothing typed it shows the screens and a few handy actions.
 */
import { esc } from './bridge.js';
import { router, h, icon } from './ui.js';
import { $t } from './i18n.js';
import * as Lib from './library.js';
import * as SoundUI from './ml/sound-ui.js';
import * as Sound from './ml/sound.js';
import * as Smart from './smartsearch.js';
import * as SB from './searchbox.js';

let veil = null, items = [], sel = 0, token = 0, actions = {};

/** app.js passes the actions that live there (canvas, mini player, play/pause…) */
export function init(a) {
  actions = a || {};
  document.addEventListener('keydown', (e) => {
    if ((e.ctrlKey || e.metaKey) && !e.altKey && (e.key.toLowerCase() === 'k' || e.key.toLowerCase() === 'л')) { e.preventDefault(); e.stopPropagation(); toggle(); }
  }, true);
}

function commands() {
  const go = (v, arg) => () => router.go(v, arg);
  const list = [
    { ic: 'home', label: $t('Главная'), run: go('home') },
    { ic: 'disc', label: $t('Сейчас играет'), run: go('now') },
    { ic: 'grid', label: $t('Медиатека'), run: go('library', { albums: true }) },
    { ic: 'mic', label: $t('Исполнители'), run: go('artists') },
    { ic: 'list', label: $t('Плейлист'), run: go('playlist') },
    { ic: 'queue', label: $t('Очередь'), run: go('queue') },
    { ic: 'calendar', label: $t('Итоги'), run: go('stats') },
    { ic: 'gear', label: $t('Настройки'), run: go('settings') },
    { ic: 'image', label: $t('Обложки'), run: go('covers') },
    { ic: 'yt', label: 'YouTube', run: go('youtube') },
  ];
  if (actions.canvas) list.push({ ic: 'canvas', label: $t('Холст'), hint: 'F', run: actions.canvas });
  if (actions.mini) list.push({ ic: 'pip', label: $t('Мини-плеер'), run: actions.mini });
  if (actions.playPause) list.push({ ic: 'play', label: $t('Воспроизведение / пауза'), hint: $t('Пробел'), run: actions.playPause });
  if (actions.next) list.push({ ic: 'next', label: $t('Следующий трек'), run: actions.next });
  if (actions.shuffle) list.push({ ic: 'shuffle', label: $t('Вперемешку'), run: actions.shuffle });
  if (actions.like) list.push({ ic: 'heart', label: $t('В понравившиеся'), hint: 'L', run: actions.like });
  if (Sound.ready()) for (const [k, title] of SoundUI.MOOD_RECIPES()) list.push({ ic: 'sparkle', label: $t('Микс: {0}', title), run: () => SoundUI.moodPlaylist(k, title) });
  return list;
}

/* commands: the same forgiving match as the library (typos, layout, translit) */
const cmdScore = (label, q) => { const a = Smart.score(Smart.prepare(q), Smart.prepare(label)).s; const sw = Smart.swapLayout(q); return Math.max(a, sw ? Smart.score(Smart.prepare(sw), Smart.prepare(label)).s : 0); };

async function search(q) {
  const tk = ++token;
  const text = String(q || '').trim();
  const out = [];
  const cmds = commands();
  if (!text) { paint(cmds.slice(0, 9).map((c) => ({ ...c, group: $t('Команды') }))); return; }
  out.push(...cmds.map((c) => ({ c, s: cmdScore(c.label, text) })).filter((x) => x.s >= 50).sort((a, b) => b.s - a.s).slice(0, 5).map((x) => ({ ...x.c, group: $t('Команды') })));
  const r = await Smart.search(text, { artists: 5, albums: 6, tracks: 8 }).catch(() => null);
  if (tk !== token) return;
  if (r && r.suggestion) out.unshift({ group: $t('Возможно, вы имели в виду'), ic: 'search', label: r.suggestion, keep: true, run: () => { const inp = veil && veil.querySelector('input'); if (inp) { inp.value = r.suggestion; search(r.suggestion); } } });
  if (r) {
    out.push(...r.artists.map(({ item: x }) => ({ group: $t('Исполнители'), ic: 'mic', label: x.name, sub: `${x.albums.length || (x.appears || []).length} ${$t('альб.')}`, run: () => router.go('artist', x), cover: SB.firstCover(x), artist: x.name })));
    out.push(...r.albums.map(({ item: a }) => ({ group: $t('Альбомы'), ic: 'grid', label: a.name, sub: [a.albumArtist || a.artist, a.year].filter(Boolean).join(' · '), run: () => router.go('album', a), alt: () => Lib.playAlbumRow(a), cover: a.firstTrackAbsolutePath })));
    out.push(...r.tracks.map(({ item: t }) => ({ group: $t('Треки'), ic: 'music', label: t.title, sub: [t.artist, t.album].filter(Boolean).join(' · '), run: () => Lib.playPaths([t.handle || t.absolutePath], 0, t.title), cover: t.absolutePath || '' })));
  }
  paint(out);
}

function paint(list) {
  items = list; sel = Math.min(sel, Math.max(0, list.length - 1));
  const box = veil.querySelector('.ck-list');
  if (!list.length) { box.innerHTML = `<div class="ck-empty">${esc($t('Ничего не найдено'))}</div>`; return; }
  let g = '', html = '';
  list.forEach((it, i) => {
    if (it.group !== g) { g = it.group; html += `<div class="ck-g">${esc(g)}</div>`; }
    html += `<div class="ck-it${i === sel ? ' on' : ''}" data-i="${i}" role="option" aria-selected="${i === sel}">${it.cover || it.artist ? `<span class="ck-cov${it.artist ? ' round' : ''}">${icon(it.ic, 16)}<img alt=""${it.cover ? ` data-p="${esc(it.cover)}"` : ''}${it.artist ? ` data-a="${esc(it.artist)}"` : ''}></span>` : icon(it.ic, 18)}<span class="l"><b></b>${it.sub ? '<small></small>' : ''}</span>${it.hint ? `<kbd>${esc(it.hint)}</kbd>` : ''}</div>`;
  });
  box.innerHTML = html;
  box.querySelectorAll('.ck-it').forEach((el) => { const it = list[+el.dataset.i]; el.querySelector('b').textContent = it.label; const s = el.querySelector('small'); if (s) s.textContent = it.sub; });
  // album covers instead of a generic icon: easier to spot the one you mean
  SB.fillPictures(box, 36);
}
function move(d) {
  if (!items.length) return;
  sel = (sel + d + items.length) % items.length;
  veil.querySelectorAll('.ck-it').forEach((el) => { const on = +el.dataset.i === sel; el.classList.toggle('on', on); el.setAttribute('aria-selected', String(on)); if (on) el.scrollIntoView({ block: 'nearest' }); });
}
function run(i, alt = false) {
  const it = items[i]; if (!it) return;
  if (it.keep) { it.run(); return; }
  close();
  (alt && it.alt ? it.alt : it.run)();
}

export function open() {
  if (veil) return;
  veil = h(`<div class="ck-veil" role="dialog" aria-modal="true" aria-label="${esc($t('Поиск и команды'))}"><div class="ck-box">
    <label class="ck-in">${icon('search', 18)}<input type="text" spellcheck="false" autocomplete="off" placeholder="${esc($t('Альбом, исполнитель, трек или команда'))}"><kbd>Esc</kbd></label>
    <div class="ck-list" role="listbox"></div>
    <div class="ck-foot"><span><kbd>↑</kbd><kbd>↓</kbd> ${esc($t('выбор'))}</span><span><kbd>Enter</kbd> ${esc($t('открыть'))}</span><span><kbd>Shift</kbd>+<kbd>Enter</kbd> ${esc($t('слушать альбом'))}</span></div>
  </div></div>`);
  const inp = veil.querySelector('input');
  let t = 0;
  inp.addEventListener('input', () => { sel = 0; clearTimeout(t); t = setTimeout(() => search(inp.value), 90); });
  inp.addEventListener('keydown', (e) => {
    e.stopPropagation();
    if (e.key === 'ArrowDown') { e.preventDefault(); move(1); }
    else if (e.key === 'ArrowUp') { e.preventDefault(); move(-1); }
    else if (e.key === 'Enter') { e.preventDefault(); run(sel, e.shiftKey); }
    else if (e.key === 'Escape') { e.preventDefault(); close(); }
  });
  veil.addEventListener('pointerdown', (e) => { if (e.target === veil) close(); });
  veil.querySelector('.ck-list').addEventListener('click', (e) => { const el = e.target.closest('.ck-it'); if (el) run(+el.dataset.i, e.shiftKey); });
  document.body.append(veil);
  requestAnimationFrame(() => veil && veil.classList.add('on'));
  inp.focus();
  search('');
}
export function close() { if (!veil) return; const v = veil; veil = null; token++; v.classList.remove('on'); setTimeout(() => v.remove(), 160); }
export function toggle() { if (veil) close(); else open(); }
export const isOpen = () => !!veil;
