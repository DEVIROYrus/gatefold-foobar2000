/*
 * Gatefold · upgrade.js — from Gatefold 1.x to 2.0 in one button.
 *
 * Gatefold 1.4 updates itself: it writes the release's theme over its own folder in foo_ui_webview2 and reloads.
 * That theme is 2.0, which runs in its own component (foo_gatefold), so on foo_ui_webview2 the page is only this:
 *   1. checks that this foobar2000 can take the component (64-bit: its components live in user-components-x64),
 *   2. downloads foo_gatefold-<v>.fb2k-component from the same release and checks its SHA-256 against
 *      SHA256SUMS.txt (nothing is written otherwise),
 *   3. writes it and upgrade.ps1 to <profile>\gatefold\upgrade-2.0, starts the script and asks foobar2000 to exit;
 *      the script, with foobar2000 closed, installs the component, makes Gatefold the interface and starts
 *      foobar2000 again — straight into 2.0, which brings the 1.x likes, history, playlists and settings over.
 * Anything that fails changes nothing (or is put back by the script), and «Stay on 1.4» puts 1.4 back from the
 * copy 1.4's update kept.
 * A package already beside it (upgrade-2.0\local.json: { "package": path, "sha256": hex, "auto": bool }) is
 * used instead of a download: an offline machine, and the tests.
 */
import { call, ok, httpGet, waitForBridge, log } from './bridge.js';
import { VERSION, REPO } from './version.js';
import { $t } from './i18n.js';

const DONE = 'aurora.updated', KEY = 'aurora.update';
const UA = { 'User-Agent': 'Gatefold-updater', Accept: 'application/vnd.github+json', 'X-GitHub-Api-Version': '2022-11-28' };
const trim = (p) => String(p || '').replace(/[\\/]+$/, '');
const hex = (buf) => [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, '0')).join('');
const b64ToBytes = (b64) => { const s = atob(b64); const u = new Uint8Array(s.length); for (let i = 0; i < s.length; i++) u[i] = s.charCodeAt(i); return u; };
const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
/* every step also goes to upgrade-2.0\\upgrade.log (the page is all a person sees otherwise) */
const trace = (m) => { log('upgrade:', m); if (paths) call('file.write', { path: `${paths.dir}\\upgrade.log`, content: `${new Date().toISOString()} ${m}\r\n`, append: true }); };
const pathOf = async (m) => { const r = await call(m); return ok(r) ? trim(r.path || r.value) : ''; };

const S = { busy: false, step: '', progress: 0, error: '', fatal: '', installedNoSwitch: false };
let root = null, paths = null;

function css() {
  const st = document.createElement('style');
  st.textContent = `
  #gf-up { position: fixed; inset: 0; z-index: 2147483000; display: grid; place-items: center; padding: 32px;
    background: radial-gradient(1200px 700px at 30% 20%, #3a1418 0%, #160b0d 55%, #0d0a0b 100%); color: #f4ecec;
    font: 15px/1.5 'Inter', 'Segoe UI Variable Text', 'Segoe UI', system-ui, sans-serif; -webkit-font-smoothing: antialiased; }
  #gf-up .card { width: min(560px, 100%); padding: 36px 36px 28px; border-radius: 22px; background: rgba(255,255,255,.045);
    border: 1px solid rgba(255,255,255,.08); box-shadow: 0 30px 80px rgba(0,0,0,.45); }
  #gf-up img { width: 56px; height: 56px; display: block; margin-bottom: 18px; }
  #gf-up h1 { margin: 0 0 10px; font-size: 30px; line-height: 1.15; letter-spacing: -.02em; font-weight: 700; }
  #gf-up p { margin: 0 0 16px; color: #d9cccc; }
  #gf-up ul { margin: 0 0 22px; padding: 0; list-style: none; display: flex; flex-wrap: wrap; gap: 8px; }
  #gf-up li { padding: 5px 11px; border-radius: 999px; background: rgba(229,72,77,.14); color: #ffb3b5; font-size: 13px; font-weight: 600; }
  #gf-up .go { width: 100%; height: 48px; border: 0; border-radius: 14px; background: #e5484d; color: #fff; font: inherit;
    font-size: 16px; font-weight: 700; cursor: pointer; transition: background .15s, transform .15s; }
  #gf-up .go:hover:not(:disabled) { background: #f05a5f; } #gf-up .go:active:not(:disabled) { transform: scale(.985); }
  #gf-up .go:disabled { opacity: .55; cursor: default; }
  #gf-up .note { margin: 12px 0 0; font-size: 13px; color: #a99a9a; text-align: center; }
  #gf-up .bar { height: 4px; border-radius: 4px; background: rgba(255,255,255,.08); overflow: hidden; margin: 18px 0 8px; }
  #gf-up .bar i { display: block; height: 100%; width: 0; background: #e5484d; transition: width .3s; }
  #gf-up .step { font-size: 13px; color: #d9cccc; min-height: 20px; }
  #gf-up .err { margin: 0 0 16px; padding: 12px 14px; border-radius: 12px; background: rgba(229,72,77,.12); border: 1px solid rgba(229,72,77,.35); color: #ffd0d1; font-size: 14px; }
  #gf-up .alt { display: block; margin: 16px auto 0; border: 0; background: none; color: #a99a9a; font: inherit; font-size: 13px; cursor: pointer; text-decoration: underline; text-underline-offset: 3px; }
  #gf-up .alt:hover { color: #f4ecec; }
  @media (prefers-reduced-motion: reduce) { #gf-up * { transition: none !important; } }`;
  document.head.append(st);
}

function render() {
  if (!root) return;
  const feats = [$t('Свой эквалайзер'), $t('Поиск с опечатками'), $t('Полные дискографии'), $t('Светлая тема'), $t('Быстрее и легче')];
  const err = S.fatal || S.error;
  root.innerHTML = `<div class="card" role="dialog" aria-labelledby="gf-up-h">
    <img src="icon.svg" alt="">
    <h1 id="gf-up-h">${esc($t('Gatefold {0} готов', VERSION.replace(/\.0$/, '')))}</h1>
    <p>${esc(S.installedNoSwitch
      ? $t('Компонент Gatefold 2.0 уже установлен. Осталось выбрать его интерфейсом: Настройки → Display → User interface module → Gatefold.')
      : $t('Теперь Gatefold — отдельный компонент foobar2000. Одна кнопка: он установится, foobar2000 откроется уже в новой версии, а лайки, история, плейлисты и настройки переедут вместе с вами.'))}</p>
    ${S.installedNoSwitch ? '' : `<ul>${feats.map((f) => `<li>${esc(f)}</li>`).join('')}</ul>`}
    ${err ? `<div class="err" role="alert">${esc(err)}</div>` : ''}
    ${S.fatal ? '' : S.installedNoSwitch
      ? `<button class="go" data-x="prefs">${esc($t('Открыть настройки'))}</button>`
      : `<button class="go" data-x="go" ${S.busy ? 'disabled' : ''}>${esc(S.busy ? $t('Устанавливаю…') : S.error ? $t('Попробовать ещё раз') : $t('Установить Gatefold 2.0'))}</button>`}
    ${S.busy ? `<div class="bar"><i style="width:${Math.round(S.progress * 100)}%"></i></div><div class="step" aria-live="polite">${esc(S.step)}</div>`
      : S.fatal || S.installedNoSwitch ? '' : `<p class="note">${esc($t('foobar2000 закроется на несколько секунд и откроется снова.'))}</p>`}
    ${S.busy ? '' : `<button class="alt" data-x="stay">${esc($t('Остаться на 1.4'))}</button>`}
  </div>`;
  root.querySelector('[data-x=go]')?.addEventListener('click', install);
  root.querySelector('[data-x=prefs]')?.addEventListener('click', () => call('misc.showPreferences', {}));
  root.querySelector('[data-x=stay]')?.addEventListener('click', stay);
}
const step = (text, progress) => { S.step = text; if (progress != null) S.progress = progress; trace(text); render(); };

async function readJson(path) {
  const r = await call('file.read', { path });
  if (!ok(r) || typeof r.content !== 'string') return null;
  try { return JSON.parse(r.content.replace(/^﻿/, '')); } catch { return null; }
}

/** the component's file and its SHA-256: from upgrade-2.0\local.json, or the release of this version */
async function source() {
  const local = await readJson(`${paths.dir}\\local.json`);
  if (local && local.package && /^[0-9a-f]{64}$/i.test(local.sha256 || '')) return { local: true, path: local.package, sha256: local.sha256.toLowerCase(), auto: !!local.auto };
  const r = await httpGet({ url: `https://api.github.com/repos/${REPO}/releases/tags/v${VERSION}`, headers: UA, timeout: 20000 });
  if (!ok(r) || (r.status && r.status >= 400)) throw new Error($t('Не удалось узнать о релизе {0}: {1}', VERSION, r.error || r.status || 'network'));
  const j = typeof r.body === 'string' ? JSON.parse(r.body) : r.body;
  const asset = (re) => (j.assets || []).find((a) => re.test(a.name));
  const comp = asset(/^foo_gatefold-.+\.fb2k-component$/i), sums = asset(/^SHA256SUMS\.txt$/i);
  if (!comp || !sums) throw new Error($t('В релизе {0} нет компонента — скачайте его со страницы релиза', VERSION));
  const s = await httpGet({ url: sums.browser_download_url, timeout: 30000, responseType: 'text', headers: { 'User-Agent': 'Gatefold-updater' } });
  if (!ok(s) || (s.status && s.status >= 400)) throw new Error($t('не удалось скачать {0}', 'SHA256SUMS.txt'));
  const line = String(s.body).split(/\r?\n/).find((l) => l.trim().endsWith(comp.name));
  const sha256 = line && line.trim().split(/\s+/)[0].toLowerCase();
  if (!/^[0-9a-f]{64}$/.test(sha256 || '')) throw new Error($t('В SHA256SUMS.txt нет строки для {0}', comp.name));
  return { url: comp.browser_download_url, name: comp.name, size: comp.size, sha256 };
}

async function install() {
  if (S.busy) return;
  S.busy = true; S.error = ''; step($t('Скачиваю компонент…'), 0.05);
  try {
    const src = await source();
    let pkg = src.path;
    if (!src.local) {
      const d = await httpGet({ url: src.url, timeout: 180000, responseType: 'base64', headers: { 'User-Agent': 'Gatefold-updater' } });
      if (!ok(d) || (d.status && d.status >= 400)) throw new Error($t('не удалось скачать {0}', src.name) + (d.error ? ' — ' + d.error : d.status ? ' — ' + d.status : ''));
      step($t('Проверяю контрольную сумму…'), 0.55);
      const bytes = b64ToBytes(d.body);
      if (hex(await crypto.subtle.digest('SHA-256', bytes)) !== src.sha256) throw new Error($t('Контрольная сумма компонента не совпала — ничего не изменено'));
      pkg = `${paths.dir}\\${src.name}`;
      const w = await call('file.write', { path: pkg, content: 'base64:' + d.body, encoding: 'binary', atomic: true });
      if (!ok(w)) throw new Error($t('Не удалось записать {0}: {1}', src.name, w.error || w.code));
    } else {
      step($t('Проверяю контрольную сумму…'), 0.55);
      const r = await call('file.read', { path: pkg, encoding: 'binary' });
      if (!ok(r)) throw new Error($t('Не удалось прочитать {0}', pkg));
      if (hex(await crypto.subtle.digest('SHA-256', b64ToBytes(r.content))) !== src.sha256) throw new Error($t('Контрольная сумма компонента не совпала — ничего не изменено'));
    }

    step($t('Готовлю установку…'), 0.75);
    const script = await (await fetch('upgrade/upgrade.ps1', { cache: 'no-store' })).text();
    if (!/upgrade\.ps1/.test(script)) throw new Error('upgrade.ps1');
    const ps1 = `${paths.dir}\\upgrade.ps1`, status = `${paths.dir}\\status.json`;
    let w = await call('file.write', { path: ps1, content: script, atomic: true });
    if (!ok(w)) throw new Error($t('Не удалось записать {0}: {1}', 'upgrade.ps1', w.error || w.code));
    w = await call('file.write', { path: status, content: JSON.stringify({ state: 'starting', at: new Date().toISOString() }), atomic: true });

    step($t('Перезапускаю foobar2000…'), 0.9);
    const sp = await call('shell.spawn', {
      executable: 'powershell.exe',
      args: ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-WindowStyle', 'Hidden', '-File', ps1,
        '-ProfileDir', paths.profile, '-Exe', paths.exe, '-Package', pkg, '-Status', status],
      hidden: true,
    });
    if (!ok(sp)) throw new Error($t('Не удалось запустить установку: {0}', (sp && sp.error) || '?'));
    // the script says it runs (status «waiting») before foobar2000 is asked to close
    let started = false;
    for (let i = 0; i < 40 && !started; i++) { await new Promise((r) => setTimeout(r, 200)); const st = await readJson(status); started = !!st && st.state !== 'starting'; }
    if (!started) throw new Error($t('Не удалось запустить установку: {0}', 'powershell'));
    try { localStorage.setItem('gatefold.upgrade2', JSON.stringify({ at: Date.now(), version: VERSION })); } catch {}
    trace('the script runs, foobar2000 exits');
    step($t('foobar2000 перезапускается…'), 1);
    setTimeout(() => call('misc.exit', {}), 400);
  } catch (e) {
    trace('failed: ' + ((e && e.message) || e));
    S.busy = false; S.error = (e && e.message) || String(e); render();
  }
}

/** back to 1.4: the copy 1.4's own update kept before it wrote this version */
async function stay() {
  let backup = '';
  try { const d = JSON.parse(localStorage.getItem(DONE) || 'null'); if (d && d.backup) backup = d.backup; } catch {}
  if (!backup) {
    const l = await call('file.list', { path: `${paths.profile}\\gatefold\\backup` });
    const dirs = ok(l) && Array.isArray(l.directories) ? l.directories.map((d) => String(d).split(/[\\/]/).pop()) : [];
    const one = dirs.filter((n) => /^1\./.test(n)).sort((a, b) => a.localeCompare(b, undefined, { numeric: true })).pop();
    if (one) backup = `${paths.profile}\\gatefold\\backup\\${one}`;
  }
  const src = await call('webview.getSource');
  const dir = ok(src) && src.directory;
  if (!backup || !dir) { S.error = $t('Не нашлась копия 1.4 — установите её заново со страницы релизов.'); render(); return; }
  const r = await call('file.copy', { source: backup, destination: dir, overwrite: true });
  if (!ok(r)) { S.error = $t('Не удалось вернуть 1.4: {0}', r.error || r.code); render(); return; }
  try { localStorage.removeItem(DONE); localStorage.removeItem(KEY); } catch {}
  location.reload();
}

async function start() {
  css();
  root = document.createElement('div'); root.id = 'gf-up';
  document.body.append(root);
  render();
  if (!(await waitForBridge(10000))) { S.fatal = $t('foobar2000 не отвечает.'); render(); return; }
  call('window.setFrameless', { frameless: false });           // 1.x drew its own title bar: give the window its own back
  call('window.setBackgroundTransparency', { transparent: false });
  call('window.setTitle', { title: 'Gatefold' });
  const [profile, fb, comp] = await Promise.all([pathOf('misc.getProfilePath'), pathOf('misc.getFoobarPath'), pathOf('misc.getComponentPath')]);
  paths = { profile, exe: fb ? `${fb}\\foobar2000.exe` : '', dir: `${profile}\\gatefold\\upgrade-2.0` };
  trace(`page ${VERSION}: ${JSON.stringify(paths)}, component in ${comp}`);
  if (!profile || !fb) { S.fatal = $t('Не удалось узнать папки foobar2000 — установите компонент вручную со страницы релиза.'); render(); return; }
  if (!/[\\/]user-components-x64[\\/]/i.test(comp + '\\')) {
    S.fatal = $t('Gatefold 2.0 работает в 64-битном foobar2000 2.x, а этот — другой. Можно остаться на 1.4 или поставить 64-битный foobar2000 с foobar2000.org.');
    render(); return;
  }
  await call('file.mkdir', { path: paths.dir });
  // how the last try went (the script leaves status.json; foobar2000 is back on foo_ui_webview2 only if it failed
  // or the interface could not be switched)
  const st = await readJson(`${paths.dir}\\status.json`);
  if (st && st.state === 'failed') S.error = $t('Прошлая попытка не удалась: {0}. Всё вернулось как было.', st.error || '?');
  else if (st && st.state === 'done') S.installedNoSwitch = true;
  render();
  const local = await readJson(`${paths.dir}\\local.json`);
  if (local && local.auto && !S.error && !S.installedNoSwitch) install();
}

start();
