/*
 * Gatefold · plname.js — how playlists Gatefold makes are named, and how service playlists are shown.
 *   nameFor(tracks)    a name from what is in it: «Artist — Album», «Artist», «A, B и ещё 3»
 *   shownName(name)    foobar2000's own service playlists under a human name («[WebView Queue]» → «Очередь»)
 *   isService(name)    a playlist the sidebar does not list (the queue has its own screen)
 *   GROUP_TF           the album groups of a playlist: «Artist featuring X» stays with the artist's album
 *   queuePaths(paths)  queue tracks in the given order (foobar2000's Add Files would sort them)
 */
import { call, ok } from './bridge.js';
import { $t } from './i18n.js';
import { cleanArtist, isVarious } from './match.js';

export const QUEUE_PL = '[WebView Queue]';
export const isService = (name) => name === QUEUE_PL;
export const shownName = (name) => (name === QUEUE_PL ? $t('Очередь') : name);

/* the main artist of «A featuring B», «A feat. B», «A ft. B», «A (feat. B)» — the album belongs to A */
export function mainArtist(s) {
  return String(s || '').replace(/\s*[([]?\s*\b(featuring|feat\.?|ft\.?|with)\s.+$/i, '').trim() || String(s || '').trim();
}
/* the same in titleformat, for playlist.getGroupRuns: the album artist without its featured guests */
const CUT = (w) => `$puts(p,$strstr($lower($get(a)),'${w}'))$if($greater($get(p),0),$puts(a,$left($get(a),$sub($get(p),1))))`;
export const GROUP_TF = `$puts(a,%album artist%)${CUT(' feat')}${CUT(' ft.')}${CUT(' (feat')}$trim($get(a)) | %album%`;

/** a name for a playlist from its tracks: [{ artist, albumArtist, album }] */
export function nameFor(tracks) {
  const list = (tracks || []).filter(Boolean);
  if (!list.length) return '';
  const who = (t) => mainArtist(t.albumArtist && !isVarious(t.albumArtist) ? t.albumArtist : t.artist || '');
  const albums = new Map(), artists = new Map();
  for (const t of list) {
    const a = who(t), k = a.toLowerCase();
    if (a) artists.set(k, { name: a, n: ((artists.get(k) || {}).n || 0) + 1 });
    if (t.album) { const ak = (k + '\u0001' + String(t.album).toLowerCase()); albums.set(ak, { artist: a, album: t.album, n: ((albums.get(ak) || {}).n || 0) + 1 }); }
  }
  const byN = (m) => [...m.values()].sort((x, y) => y.n - x.n);
  const al = byN(albums), ar = byN(artists);
  // one album (a few strays aside): «Artist — Album»; a compilation keeps just its title
  if (al.length && al[0].n >= list.length * 0.8) return al[0].artist && !isVarious(al[0].artist) ? `${al[0].artist} — ${al[0].album}` : al[0].album;
  // one artist: their name
  if (ar.length === 1 || (ar.length && ar[0].n >= list.length * 0.8)) return ar[0].name;
  if (ar.length === 2) return `${ar[0].name}, ${ar[1].name}`;
  if (ar.length > 2) return $t('{0}, {1} и ещё {2}', ar[0].name, ar[1].name, ar.length - 2);
  return '';
}
/** «12 нояб.» — when nothing in the tracks gives a name */
export const dayName = () => new Date().toLocaleDateString(undefined, { day: 'numeric', month: 'short' });

/** the guid of foobar2000's queue playlist, made when missing */
async function queuePlaylist() {
  const all = await call('playlist.getAll');
  const p = ok(all) && (all.playlists || []).find((x) => x.name === QUEUE_PL);
  if (p) return p.guid;
  const c = await call('playlist.create', { name: QUEUE_PL });
  return ok(c) ? c.guid : '';
}
/** queue tracks in this order; { success, addedCount } like queue.addPaths */
export async function queuePaths(paths) {
  if (!paths || !paths.length) return { success: false, error: 'nothing to queue' };
  const guid = await queuePlaylist();
  if (guid) {
    const r = await call('playlist.addHandles', { playlistGuid: guid, handles: paths });
    if (ok(r) && r.addedCount) {
      const from = r.countBefore != null ? r.countBefore : (r.totalCount || 0) - r.addedCount;
      const q = await call('queue.add', { playlistGuid: guid, tracks: Array.from({ length: r.addedCount }, (_, i) => from + i) });
      if (ok(q)) return { success: true, addedCount: q.addedCount != null ? q.addedCount : r.addedCount };
    }
  }
  return call('queue.addPaths', { paths });   // the component's own way (its order) when the above did not work
}
