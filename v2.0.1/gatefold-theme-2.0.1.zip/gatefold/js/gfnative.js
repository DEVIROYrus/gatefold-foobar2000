/*
 * Gatefold · gfnative.js
 * Gatefold's own host (foo_gatefold) speaks a different protocol (window.gf). This module makes it look like
 * the `fb2k` object Gatefold was written against: invoke(method, params) → an envelope { success, … } in the
 * shapes Gatefold reads, and on(event, fn) with the old event names. Only used when window.gf is there and
 * window.fb2k is not — on foo_ui_webview2 nothing here runs.
 *
 * What the host cannot do yet answers { success:false, code:'UNSUPPORTED' } (logged once per method).
 * Changes to playlists and files are on. localStorage['gatefold.gf.write'] = '0' turns them off (code 'READONLY'):
 * for a second, test Gatefold beside the user's own, which must not edit their playlists.
 */

const FIELD_TF = {
  title: '[%title%]', artist: '[%artist%]', album: '[%album%]', albumArtist: '[%album artist%]', date: '[%date%]',
  genre: '[%genre%]', trackNumber: '[%tracknumber%]', discNumber: '[%discnumber%]', duration: '[%length_seconds_fp%]',
  codec: '[%codec%]', bitrate: '[%bitrate%]', sampleRate: '[%samplerate%]', channels: '[%channels%]',
  rating: '[%rating%]', playCount: '[%play_count%]',
};

const fileOf = (p) => String(p || '').replace(/^file:\/\//i, '');
/** an old-style handle or path (D:\x.flac, D:\x.cue|subsong:2, file://…) → the host's { path, subsong } */
export function refOf(h) {
  if (h && typeof h === 'object') return refOf(h.handle || (h.subsong ? `${h.absolutePath || h.path}|subsong:${h.subsong}` : h.absolutePath || h.path));
  let s = String(h || ''), subsong = 0;
  const m = /\|subsong:(\d+)$/i.exec(s);
  if (m) { subsong = +m[1]; s = s.slice(0, m.index); }
  if (/^[a-z]:[\\/]/i.test(s) || /^\\\\/.test(s)) s = 'file://' + s;
  return subsong ? { path: s, subsong } : { path: s };
}
/** the host's Track → the old track shape (normTrack and friends read it) */
export function oldTrack(t, extra) {
  if (!t) return null;
  const abs = fileOf(t.path), sub = t.subsong || 0;
  return {
    ...t, absolutePath: abs, path: t.path, subsong: sub, handle: sub ? `${abs}|subsong:${sub}` : abs,
    artists: t.artist ? [t.artist] : [], albumArtists: t.albumArtist ? [t.albumArtist] : [],
    year: ((t.date || '').match(/\d{4}/) || [''])[0], length: t.duration, ...extra,
  };
}
const oldWin = (w) => ({ ...w, isFocused: w.focused, isMinimized: w.minimized, isMaximized: w.maximized, isFullscreen: w.fullscreen });
const ORDER_KEYS = ['default', 'repeat-playlist', 'repeat-track', 'random', 'shuffle-tracks', 'shuffle-albums', 'shuffle-folders'];
const pct = (db) => (db <= -100 ? 0 : Math.max(0, Math.min(100, 100 * Math.pow(10, db / 40))));
/** a few fixed sizes, rounded up: a tile that grows by a pixel while the window is resized keeps the same
 *  URL, so the picture comes from the cache instead of being made again */
const SIZES = [64, 128, 192, 256, 384, 512, 768, 1024, 1536, 2048];
const sizeStep = (n) => (n > 0 ? SIZES.find((s) => s >= n) || 0 : 0);
const artPath = (ref, type = 'front', size = 0) => artPathExact(ref, type, sizeStep(size));
const artPathExact = (ref, type = 'front', size = 0) => `/~art/track?path=${encodeURIComponent(ref.path)}${ref.subsong ? '&subsong=' + ref.subsong : ''}&type=${encodeURIComponent(type || 'front')}${size > 0 ? '&size=' + Math.round(size) : ''}`;

/** Gatefold's title bar as the window's drag area (its buttons, search and logo stay clickable) */
function dragCss(on) {
  if (typeof document === 'undefined') return;
  let el = document.getElementById('gf-drag');
  if (!on) { if (el) el.remove(); return; }
  if (el) return;
  el = document.createElement('style');
  el.id = 'gf-drag';
  // the main window's title bar, and the whole mini player except its controls (the old host's window.startDrag)
  el.textContent = '#titlebar, #mini { app-region: drag; -webkit-app-region: drag; } '
    + '#titlebar button, #titlebar input, #titlebar a, #titlebar .search, #titlebar .brand, #titlebar [role=button], '
    + '#mini button, #mini input, #mini a, #mini .mi-seek, #mini [role=button] { app-region: no-drag; -webkit-app-region: no-drag; }';
  document.head.appendChild(el);
}

export function gfNative(gf, opts = {}) {
  const log = opts.log || (() => {});
  // on unless switched off: 2.0.0 had it the other way round (off unless '1'), which left a real install unable to
  // play from a list, make a playlist or queue anything ("changes are off in this test host")
  const writable = () => { try { return localStorage.getItem('gatefold.gf.write') !== '0'; } catch { return true; } };
  const told = new Set();
  const unsupported = (m) => {
    if (!told.has(m)) { told.add(m); log('gf: not in this host yet:', m); }
    return { success: false, code: 'UNSUPPORTED', error: m + ' is not available in this host yet' };
  };
  const readonly = (m) => {
    if (!told.has('ro:' + m)) { told.add('ro:' + m); log('gf: read-only, refused:', m); }
    return { success: false, code: 'READONLY', error: 'changes are switched off in this copy of Gatefold' };
  };
  const fail = (e) => ({ success: false, code: (e && e.code) || 'EXCEPTION', error: String((e && e.message) || e) });

  // ---------------------------------------------------------------- caches
  let albums = null, albumsAt = 0;            // the host's library.albums, until library.changed
  let lists = null;                           // playlist.list, until playlist.changed
  let lastDrop = null;                        // { paths, at } from window.filesDropped
  let trayOn = false, hide = { minimize: false, close: false };   // the tray icon, and hiding the window to it
  let nowTrack = null, volumeDb = 0, lastVolumeDb = 0, state = 'stopped';
  const allAlbums = async () => {
    if (!albums) { const r = await gf.call('library.albums', { limit: 100000 }); albums = r.albums; albumsAt = Date.now(); }
    return albums;
  };
  const playlists = async () => lists || (lists = (await gf.call('playlist.list')).playlists);
  const guidOf = async (p) => {
    if (p.playlistGuid) return p.playlistGuid;
    if (typeof p.playlist === 'string' && p.playlist.startsWith('{')) return p.playlist;
    const ls = await playlists();
    if (typeof p.playlist === 'number') return (ls[p.playlist] || {}).guid;
    return (ls.find((x) => x.isActive) || {}).guid;
  };
  const oldList = (p, index) => ({ ...p, index, locked: p.isLocked, itemCount: p.trackCount });
  const oldAlbum = (a) => {
    const abs = fileOf(a.firstTrack.path);
    return {
      key: a.key, name: a.name, albumArtist: a.albumArtist, artist: a.albumArtist, date: a.date || '', year: ((a.date || '').match(/\d{4}/) || [''])[0],
      genre: a.genre || '', trackCount: a.trackCount, duration: a.duration, length: a.duration,
      firstTrackAbsolutePath: abs, firstTrackPath: a.firstTrack.path, firstTrackSubsong: a.firstTrack.subsong || 0,
      artworkUrl: a.art,
    };
  };
  /** the fields a caller asked for, through title formatting, for tracks the host gave as Track */
  const withFields = async (tracks, fields) => {
    const extra = (fields || []).filter((f) => FIELD_TF[f] && !(f in (tracks[0] || {})));
    if (!extra.length || !tracks.length) return tracks.map((t) => oldTrack(t));
    const r = await gf.call('titleformat.evalBatch', { tracks: tracks.map((t) => ({ path: t.path, subsong: t.subsong })), fields: Object.fromEntries(extra.map((f) => [f, FIELD_TF[f]])) });
    return tracks.map((t, i) => oldTrack(t, r.rows[i]));
  };

  // ---------------------------------------------------------------- methods
  const M = {
    // playback
    'playback.getState': async () => { const s = await gf.call('playback.getState'); state = s.state; return { state: s.state, position: s.position, duration: s.duration, isPlaying: s.state === 'playing', isPaused: s.state === 'paused' }; },
    'playback.getCurrentTrack': async () => { const s = await gf.call('playback.getState'); nowTrack = s.track || null; return s.track ? { found: true, track: oldTrack(s.track) } : { found: false }; },
    'playback.getPosition': async () => { const s = await gf.call('playback.getState'); return { position: s.position, duration: s.duration, hostTime: performance.now() }; },
    'playback.getVolume': async () => { const s = await gf.call('playback.getState'); volumeDb = s.volumeDb; return { volume: pct(s.volumeDb), volumeDb: s.volumeDb, isMuted: s.volumeDb <= -100 }; },
    'playback.setVolume': async (p) => { const r = await gf.call('playback.setVolume', { percent: Math.max(0, Math.min(100, +p.volume || 0)) }); volumeDb = r.volumeDb; return { volume: pct(r.volumeDb) }; },
    'playback.toggleMute': async () => {
      const s = await gf.call('playback.getState');
      if (s.volumeDb > -100) { lastVolumeDb = s.volumeDb; await gf.call('playback.setVolume', { db: -100 }); return { isMuted: true }; }
      await gf.call('playback.setVolume', { db: lastVolumeDb || 0 }); return { isMuted: false };
    },
    'playback.getPlaybackOrder': async () => { const o = await gf.call('playback.orders'); const i = o.orders.indexOf(o.active); return { order: i, orderIndex: i, name: o.active, orders: o.orders }; },
    'playback.setPlaybackOrder': async (p) => {
      const o = await gf.call('playback.orders');
      const i = p.order != null && Number.isFinite(+p.order) ? +p.order : ORDER_KEYS.indexOf(String(p.name || ''));
      const name = o.orders[i] ?? (typeof p.name === 'string' ? p.name : '');
      if (!name) return { success: false, code: 'NOT_FOUND', error: 'no such playback order' };
      const r = await gf.call('playback.setOrder', { order: name });
      return { order: o.orders.indexOf(r.order), orderIndex: o.orders.indexOf(r.order), name: r.order };
    },
    'playback.getStopAfterCurrent': async () => { const s = await gf.call('playback.getState'); return { enabled: s.stopAfterCurrent }; },
    'playback.setStopAfterCurrent': async (p) => { await gf.call('playback.setStopAfterCurrent', { enabled: !!p.enabled }); return { enabled: !!p.enabled }; },
    'playback.toggleStopAfterCurrent': async () => { const s = await gf.call('playback.getState'); await gf.call('playback.setStopAfterCurrent', { enabled: !s.stopAfterCurrent }); return { enabled: !s.stopAfterCurrent }; },
    'playback.play': () => gf.call('playback.play'),
    'playback.pause': (p) => gf.call('playback.pause', p && p.paused != null ? { paused: !!p.paused } : {}),
    'playback.playOrPause': () => gf.call('playback.playPause'),
    'playback.playPause': () => gf.call('playback.playPause'),
    'playback.stop': () => gf.call('playback.stop'),
    'playback.next': () => gf.call('playback.next'),
    'playback.previous': () => gf.call('playback.previous'),
    'playback.setPosition': (p) => gf.call('playback.seek', { position: Math.max(0, +p.position || 0) }),
    'playback.getCurrentTrackIndex': async () => {
      const s = await gf.call('playback.getState');
      if (!s.playing) return { found: false };
      const i = (await playlists()).findIndex((x) => x.guid === s.playing.playlist);
      return { found: true, playlist: i, playlistGuid: s.playing.playlist, index: s.playing.index };
    },

    // playlists
    'playlist.getAll': async () => ({ playlists: (await playlists()).map(oldList) }),
    'playlist.getActive': async () => { const ls = await playlists(); const i = ls.findIndex((x) => x.isActive); return i < 0 ? { found: false } : { found: true, ...oldList(ls[i], i) }; },
    'playlist.getPlaying': async () => { const ls = await playlists(); const i = ls.findIndex((x) => x.isPlaying); return i < 0 ? { found: false } : { found: true, ...oldList(ls[i], i) }; },
    'playlist.getTracks': async (p) => {
      const guid = await guidOf(p); if (!guid) return { success: false, code: 'NOT_FOUND', error: 'no such playlist' };
      const start = Math.max(0, +p.start || 0), count = Math.max(1, Math.min(2000, +p.count || 200));
      const r = await gf.call('playlist.getTracks', { playlist: guid, start, count });
      const tracks = (await withFields(r.tracks, p.fields)).map((t, i) => ({ ...t, index: start + i }));
      return { tracks, totalCount: r.total, total: r.total, playlistGuid: guid };
    },
    'playlist.playTrack': async (p) => { const guid = await guidOf(p); if (!guid) return { success: false, code: 'NOT_FOUND' }; return gf.call('playlist.play', { playlist: guid, index: Math.max(0, +p.index || 0) }); },
    'playlist.setActive': async (p) => { const guid = await guidOf(p); return guid ? gf.call('playlist.setActive', { playlist: guid }) : { success: false, code: 'NOT_FOUND' }; },
    'playlist.create': async (p) => { if (!writable()) return readonly('playlist.create'); const r = await gf.call('playlist.create', { name: String(p.name || ''), ...(p.position != null ? { index: +p.position } : {}) }); return { guid: r.guid, playlistGuid: r.guid }; },
    'playlist.rename': async (p) => (writable() ? gf.call('playlist.rename', { playlist: await guidOf(p), name: String(p.name || '') }) : readonly('playlist.rename')),
    'playlist.remove': async (p) => (writable() ? gf.call('playlist.remove', { playlist: await guidOf(p) }) : readonly('playlist.remove')),
    'playlist.addHandles': async (p) => {
      if (!writable()) return readonly('playlist.addHandles');
      const r = await gf.call('playlist.addTracks', { playlist: await guidOf(p), tracks: (p.handles || []).map(refOf), ...(p.position != null ? { at: +p.position } : {}) });
      return { addedCount: r.added, countBefore: r.first, totalCount: r.total };
    },
    // tracks by path, in exactly this order (what library.addToPlaylist and playlist.addPathsSequential were for)
    'library.addToPlaylist': (p) => M['playlist.addHandles']({ ...p, handles: p.handles || p.paths }),
    'playlist.addPathsSequential': (p) => M['playlist.addHandles']({ ...p, handles: p.handles || p.paths }),
    // files, folders, archives and playlist files, read by the player itself (it walks and sorts them)
    'playlist.addPaths': async (p) => {
      if (!writable()) return readonly('playlist.addPaths');
      const guid = await guidOf(p);
      if (!guid) return { success: false, code: 'NOT_FOUND', error: 'no such playlist' };
      const r = await gf.call('playlist.addPaths', { playlist: guid, paths: (p.paths || []).map(String), ...(p.position != null ? { at: +p.position } : {}) });
      if (!r.added) return { success: false, code: 'NOT_FOUND', error: 'nothing playable there', addedCount: 0, countBefore: r.first, totalCount: r.total };
      return { addedCount: r.added, countBefore: r.first, totalCount: r.total };
    },
    'playlist.removeTracks': async (p) => {
      if (!writable()) return readonly('playlist.removeTracks');
      const r = await gf.call('playlist.removeTracks', { playlist: await guidOf(p), indexes: (p.items || p.indexes || []).map(Number) });
      return { removedCount: r.removed, totalCount: r.total };
    },
    'queue.add': async (p) => {
      if (!writable()) return readonly('queue.add');
      let refs = (p.handles || p.paths || []).map(refOf);
      if (!refs.length && Array.isArray(p.tracks)) {
        const guid = await guidOf(p);
        for (const i of p.tracks) { const r = await gf.call('playlist.getTracks', { playlist: guid, start: +i, count: 1 }); if (r.tracks[0]) refs.push({ path: r.tracks[0].path, subsong: r.tracks[0].subsong }); }
      }
      const r = await gf.call('queue.add', { tracks: refs });
      return { addedCount: r.added, totalCount: r.total };
    },
    'queue.getContents': async () => ({ items: (await gf.call('queue.list')).items.map((q) => ({ ...oldTrack(q.track), playlistGuid: q.playlist, index: q.index })) }),
    'queue.get': async () => {
      const [q, ls] = await Promise.all([gf.call('queue.list'), playlists()]);
      const items = q.items.map((it) => { const pi = it.playlist ? ls.findIndex((x) => x.guid === it.playlist) : -1; return { ...oldTrack(it.track), playlist: pi >= 0 ? pi : null, playlistGuid: it.playlist || null, playlistItem: it.index ?? null }; });
      return { items, tracks: items, count: items.length };
    },
    'playcount.getBatch': async (p) => {
      const paths = p.paths || [];
      const r = await gf.call('titleformat.evalBatch', { tracks: paths.map(refOf), fields: { added: '[%added%]', playCount: '[%play_count%]', firstPlayed: '[%first_played%]', lastPlayed: '[%last_played%]' } });
      return { results: r.rows.map((x, i) => ({ path: paths[i], added: x.added, playCount: +x.playCount || 0, firstPlayed: x.firstPlayed, lastPlayed: x.lastPlayed })) };
    },
    'window.getMode': async () => ({ mode: 'standalone', panelMode: false }),
    'window.getState': async () => oldWin(await gf.call('window.getState')),
    'window.setTitle': (p) => gf.call('window.setTitle', { title: String(p.title || '') }),
    'window.getZoom': async () => ({ zoom: (await gf.call('window.getState')).zoom }),
    'window.setZoom': async (p) => ({ zoom: (await gf.call('window.setZoom', { zoom: Math.max(0.25, Math.min(5, +p.zoom || 1)) })).zoom }),
    'window.setFullscreen': async (p) => oldWin(await gf.call('window.setFullscreen', { on: !!(p.enabled ?? p.fullscreen ?? p.on) })),
    'window.minimize': () => gf.call('window.minimize'),
    'window.maximize': async () => { const s = await gf.call('window.getState'); return oldWin(s.maximized ? s : await gf.call('window.toggleMaximize')); },
    'window.restore': async () => { const s = await gf.call('window.getState'); return oldWin(s.maximized ? await gf.call('window.toggleMaximize') : s); },
    'window.focus': (p) => gf.call('window.focus', p && p.windowId ? { name: String(p.windowId) } : {}),
    // the theme's other windows (the mini player): one name per page, «mini.html» → "mini"
    'window.createPopup': async (p) => {
      const page = String(p.url || '').replace(/^\.?\//, '');
      const name = (page.replace(/\.html?$/i, '').toLowerCase().replace(/[^a-z0-9-]+/g, '-').replace(/^-+|-+$/g, '') || 'popup').slice(0, 40);
      const dpr = (typeof devicePixelRatio === 'number' && devicePixelRatio) || 1;
      const q = { name: name === 'main' ? 'popup' : name, page, width: Math.max(120, Math.round((+p.width || 400) / dpr)), height: Math.max(60, Math.round((+p.height || 120) / dpr)),
        customFrame: p.frame === false, topmost: !!p.alwaysOnTop, resizable: p.resizable !== false, taskbar: p.profile !== 'miniPlayer' && p.taskbar !== false };
      if (Number.isFinite(+p.x) && Number.isFinite(+p.y) && p.x != null && p.y != null) { q.x = Math.round(+p.x); q.y = Math.round(+p.y); }
      const r = await gf.call('window.open', q);
      return { windowId: r.name, created: r.opened };
    },
    'window.getAllWindows': async () => { const r = await gf.call('window.list'); const items = r.windows.map((w) => ({ windowId: w.name, id: w.name, url: w.page, focused: w.focused, minimized: w.minimized })); return { items, windows: items }; },
    'window.closePopup': async (p) => ({ closed: (await gf.call('window.close', { name: String(p.windowId || '') })).closed }),
    'window.setAlwaysOnTop': (p) => gf.call('window.setTopmost', { on: !!(p.enabled ?? p.on) }),
    'window.startDrag': async () => ({}),   // dragging is CSS app-region here (see dragCss)

    // the taskbar button and the notification area
    'taskbar.setThumbnailButtons': async (p) => {
      await gf.call('taskbar.setButtons', { buttons: (p.buttons || []).slice(0, 7).map((b) => ({ id: String(b.id), icon: String(b.icon || ''), tooltip: String(b.tooltip || '').slice(0, 259), enabled: b.enabled !== false, visible: b.visible !== false })) });
      return {};
    },
    'taskbar.updateButton': (p) => gf.call('taskbar.updateButton', { id: String(p.id), ...(p.icon ? { icon: String(p.icon) } : {}), ...(p.tooltip != null ? { tooltip: String(p.tooltip).slice(0, 259) } : {}), ...(p.enabled != null ? { enabled: !!p.enabled } : {}), ...(p.visible != null ? { visible: !!p.visible } : {}) }),
    'taskbar.setProgress': (p) => gf.call('taskbar.setProgress', { state: ['none', 'normal', 'paused', 'error', 'indeterminate'].includes(p.state) ? p.state : 'none', value: Math.max(0, Math.min(1, +p.value || 0)) }),
    'tray.create': async (p) => { await gf.call('tray.show', { icon: String(p.icon || ''), tooltip: String(p.tooltip || '').slice(0, 127) }); trayOn = true; return {}; },
    'tray.destroy': async () => { trayOn = false; hide = { minimize: false, close: false }; await gf.call('tray.hide'); return {}; },
    'tray.setTooltip': (p) => gf.call('tray.setTooltip', { tooltip: String(p.tooltip || '').slice(0, 127) }),
    // Gatefold's menu zones become the host's native menu; rows with a playbackAction (and «show», «exit») run in the host
    'tray.setMenuZones': async (p) => {
      const items = [];
      const ACT = { 'play-pause': 'play-pause', previous: 'previous', next: 'next', stop: 'stop' };
      for (const zone of [p.top, p.playback, p.bottom]) for (const it of zone || []) {
        if (it.type === 'separator') { if (items.length && items[items.length - 1].type !== 'separator') items.push({ type: 'separator' }); continue; }
        if (it.type === 'nowplaying') { items.push({ type: 'title', label: [it.title, it.subtitle].filter(Boolean).join(' — ').slice(0, 200) }); continue; }
        const action = it.playbackAction ? ACT[it.playbackAction] || 'none' : it.id === '_sys_show' ? 'show' : it.id === '_sys_exit' ? 'exit' : 'none';
        items.push({ id: String(it.id || '').slice(0, 32), label: String(it.label || '').slice(0, 200), checked: !!it.checked, enabled: it.enabled !== false, action });
      }
      while (items.length && items[items.length - 1].type === 'separator') items.pop();
      await gf.call('tray.setMenu', { items: items.slice(0, 40) });
      return { render: 'native' };
    },
    'tray.setMenuItemState': (p) => gf.call('tray.updateItem', { id: String(p.id), ...(p.checked != null ? { checked: !!p.checked } : {}), ...(p.enabled != null ? { enabled: !!p.enabled } : {}) }),
    'tray.setMinimizeToTray': async (p) => { hide.minimize = !!p.enabled && trayOn; await gf.call('tray.setHide', hide); return {}; },
    'tray.setCloseToTray': async (p) => { hide.close = !!p.enabled && trayOn; await gf.call('tray.setHide', hide); return {}; },
    // the real paths of what was just dropped: the host sends them (window.filesDropped) before the page's drop event
    // tags, ReplayGain values, pictures and lyrics in the files
    'metadata.writeBatch': async (p) => {
      if (!writable()) return readonly('metadata.writeBatch');
      const items = (p.items || []).filter((it) => it && it.path && it.tags && typeof it.tags === 'object').map((it) => ({ track: refOf(it.path), set: it.tags }));
      if (!items.length) return { successCount: 0 };
      const r = await gf.call('tags.write', { items });
      // the old component told each file's end as an event (the loudness tool waits for it); here the call ends when all did
      const ok = r.status === 'done';
      setTimeout(() => { for (const it of p.items || []) if (it && it.path) emit('metadata:writeComplete', { path: it.path, success: ok, status: r.status }); }, 0);
      return ok ? { successCount: items.length } : { success: false, code: r.status === 'aborted' ? 'CANCELLED' : 'IO', error: 'tags ' + r.status, successCount: 0 };
    },
    'replaygain.get': async (p) => {
      const paths = (p.paths || []).map(String);
      const r = await gf.call('tags.replayGain', { tracks: paths.map(refOf) });
      return { results: r.items.map((x, i) => ({ success: true, path: paths[i], trackGainRaw: x.trackGain ?? null, albumGainRaw: x.albumGain ?? null, trackPeak: x.trackPeak ?? null, albumPeak: x.albumPeak ?? null, hasReplayGain: x.trackGain != null || x.albumGain != null })) };
    },
    'replaygain.clear': async (p) => {
      if (!writable()) return readonly('replaygain.clear');
      const items = (p.paths || []).map((x) => ({ track: refOf(x), set: {}, clearReplayGain: true }));
      if (!items.length) return {};
      const r = await gf.call('tags.write', { items });
      return r.status === 'done' ? {} : { success: false, code: 'IO', error: 'tags ' + r.status };
    },
    'metadata.embedArtwork': async (p) => {
      if (!writable()) return readonly('metadata.embedArtwork');
      const image = String(p.imageData || '').replace(/^data:[^,]*,/, '');
      const target = Array.isArray(p.target) ? p.target : [p.target || 'tags'];
      const out = {};
      if (target.includes('file')) out.file = (await gf.call('art.saveFile', { track: refOf(p.path), image, name: String(p.filename || 'cover.jpg') })).path;
      if (target.some((t) => t !== 'file')) { await gf.call('art.embed', { track: refOf(p.path), image, type: ['front', 'back', 'disc', 'artist'].includes(p.type) ? p.type : 'front' }); out.embedded = true; }
      return out;
    },
    'artwork.getForTrack': (p) => artBytes(p.path, p.type || 'front'),
    'artwork.getByPath': (p) => artBytes(p.path, p.type || 'front'),
    'artwork.getAvailableArtwork': async (p) => {
      const have = [];
      for (const type of ['front', 'back', 'disc', 'artist']) { try { const r = await fetch(artPath(refOf(p.path), type, 0)); if (r.ok) have.push(type); } catch { /* none */ } }
      return { types: have, sources: [] };
    },
    'lyrics.get': async (p) => {
      const r = (await gf.call('titleformat.evalBatch', { tracks: [refOf(p.path)], fields: { s: '[%syncedlyrics%]', l: '[%lyrics%]', u: '[%unsyncedlyrics%]' } })).rows[0] || {};
      const text = p.type === 'synced' ? r.s || (/^\s*\[\d+:\d/m.test(r.l) ? r.l : '') : r.s || r.l || r.u;
      return text ? { available: true, lyrics: text, source: 'embedded', tagName: r.s ? 'SYNCEDLYRICS' : r.l ? 'LYRICS' : 'UNSYNCEDLYRICS' } : { available: false };
    },
    'artwork.getLyrics': (p) => M['lyrics.get'](p),
    'lyrics.save': async (p) => {
      if (!writable()) return readonly('lyrics.save');
      const target = Array.isArray(p.target) ? p.target[0] : p.target;
      if (target === 'file') return unsupported('lyrics.save into a file beside the track');
      const r = await gf.call('tags.write', { items: [{ track: refOf(p.path), set: { LYRICS: String(p.lyrics || '') } }] });
      return r.status === 'done' ? { saved: true, tagName: 'LYRICS' } : { success: false, code: 'IO', error: 'tags ' + r.status };
    },
    'library.getGenres': async () => {
      const count = new Map();
      for (const a of await allAlbums()) for (const g of String(a.genre || '').split(/\s*[;/,]\s*/).filter(Boolean)) count.set(g, (count.get(g) || 0) + a.trackCount);
      return { genres: [...count].sort((a, b) => b[1] - a[1]).map(([name, trackCount]) => ({ name, trackCount })) };
    },

    // foobar2000's menus: the host lists them flat (with levels), Gatefold draws them as trees
    'menu.getContextMenu': async (p) => {
      const src = await menuSource(p);
      if (src.error) return src.error;
      const r = await gf.call('menu.context', src);
      ctxToken = r.token;
      return { items: menuTree(r.items, (it) => ({ commandId: it.id })) };
    },
    'menu.runContextCommandById': (p) => gf.call('menu.runContext', { token: ctxToken, id: Math.max(1, +p.id || 0) }),
    'menu.getMainMenu': async () => {
      const r = await gf.call('menu.main');
      mainMenu = { token: r.token, items: menuTree(r.items, (it) => ({ guid: `gf:${r.token}:${it.id}`, commandId: it.id })) };
      return { items: mainMenu.items };
    },
    'menu.runMainMenuCommand': async (p) => {
      let c = String(p.command || '');
      if (!c.startsWith('gf:')) {
        // by path («File/Add folder...»): the last listing, matched label by label
        if (!mainMenu) await M['menu.getMainMenu']({});
        const want = c.split('/').map(menuNorm);
        let level = mainMenu.items, found = null;
        for (let i = 0; i < want.length && level; i++) {
          const it = level.find((x) => menuNorm(x.label) === want[i]);
          if (!it) { found = null; break; }
          if (i === want.length - 1) found = it; else level = it.children;
        }
        if (!found || !found.guid) return { success: false, code: 'NOT_FOUND', error: 'no such command: ' + c };
        c = found.guid;
      }
      const [, token, id] = c.split(':');
      return gf.call('menu.runMain', { token: +token, id: +id });
    },
    'menu.showNativePopup': async (p) => {
      const src = await menuSource(p);
      if (src.error) return src.error;
      const r = await gf.call('menu.popup', src);
      return { chosen: r.chosen };
    },

    // editing playlists and the queue
    'playlist.clear': async (p) => (writable() ? gf.call('playlist.clear', { playlist: await guidOf(p) }) : readonly('playlist.clear')),
    'playlist.duplicate': async (p) => { if (!writable()) return readonly('playlist.duplicate'); const r = await gf.call('playlist.duplicate', { playlist: await guidOf(p), ...(p.name ? { name: String(p.name) } : {}) }); return { guid: r.guid, playlistGuid: r.guid }; },
    'playlist.reorder': async (p) => (writable() ? gf.call('playlist.reorder', { playlist: await guidOf(p), order: (p.newOrder || p.order || []).map(Number) }) : readonly('playlist.reorder')),
    'playlist.reorderPlaylists': async (p) => (writable() ? gf.call('playlist.move', { playlists: (p.newOrderGuids || []).map(String) }) : readonly('playlist.reorderPlaylists')),
    'playlist.setSelection': async (p) => gf.call('playlist.setSelection', { playlist: await guidOf(p), indexes: (p.indices || p.indexes || []).map(Number) }),
    'playlist.focusTrack': async (p) => gf.call('playlist.setFocus', { playlist: await guidOf(p), index: Math.max(0, +p.index || 0) }),
    'playlist.getTrackCount': async (p) => { const g = await guidOf(p); const pl = (await playlists()).find((x) => x.guid === g); return pl ? { count: pl.trackCount, trackCount: pl.trackCount } : { success: false, code: 'NOT_FOUND' }; },
    'playlist.createAutoplaylist': async (p) => { if (!writable()) return readonly('playlist.createAutoplaylist'); const r = await gf.call('playlist.createAuto', { name: String(p.name || 'Autoplaylist'), query: String(p.query || ''), sort: String(p.sort || '') }); return { guid: r.guid, playlistGuid: r.guid }; },
    // the old asynchronous form: answered at once with an id, finished as the event playlist:addComplete
    'playlist.addPathsAsync': async (p) => {
      if (!writable()) return readonly('playlist.addPathsAsync');
      const guid = await guidOf(p);
      const operationId = 'gf' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
      gf.call('playlist.addPaths', { playlist: guid, paths: (p.paths || []).map(String) })
        .then((r) => emit('playlist:addComplete', { operationId, playlistGuid: guid, addedCount: r.added, countBefore: r.first, totalCount: r.total }),
              (e) => emit('playlist:addComplete', { operationId, playlistGuid: guid, addedCount: 0, error: e.message, code: e.code }));
      return { operationId };
    },
    'queue.addPaths': async (p) => { if (!writable()) return readonly('queue.addPaths'); const r = await gf.call('queue.add', { tracks: (p.paths || p.handles || []).map(refOf) }); return { addedCount: r.added, totalCount: r.total }; },
    'queue.remove': async (p) => (writable() ? gf.call('queue.remove', { indexes: [Math.max(0, +p.index || 0)] }) : readonly('queue.remove')),
    'queue.moveToTop': async (p) => {
      if (!writable()) return readonly('queue.moveToTop');
      const n = (await gf.call('queue.list')).items.length, i = Math.max(0, +p.index || 0);
      if (i >= n) return { success: false, code: 'NOT_FOUND' };
      return gf.call('queue.reorder', { order: [i, ...Array.from({ length: n }, (_, k) => k).filter((k) => k !== i)] });
    },
    'queue.playNow': async (p) => { const r = await M['queue.moveToTop'](p); if (r && r.success === false) return r; return gf.call('playback.next'); },
    'misc.showConsole': () => gf.call('player.showConsole'),
    'misc.showPreferences': () => gf.call('player.showPreferences', { page: 'main' }),
    'host.log': (p) => gf.call('host.log', { level: ['debug', 'info', 'warn', 'error'].includes(p.level) ? p.level : 'info', message: String(p.message || '').slice(0, 65536) }),

    // foobar2000's own settings (Gatefold's «foobar2000» settings screen and the loudness tool)
    'config.getOutputDevices': async () => {
      const r = await gf.call('player.outputs');
      return { devices: r.devices.map((d) => ({ name: d.name, outputId: d.output, deviceId: d.device, isCurrent: d.output === r.output && d.device === r.device })) };
    },
    'config.getOutputConfig': async () => {
      const r = await gf.call('player.outputs');
      const cur = r.devices.find((d) => d.output === r.output && d.device === r.device);
      return { outputId: r.output, deviceId: r.device, outputName: cur ? cur.name : '', deviceName: '', bufferLength: r.bufferMs / 1000 };
    },
    'config.setOutputDevice': (p) => gf.call('player.setOutput', { output: String(p.outputId), device: String(p.deviceId) }),
    'config.setOutputBuffer': (p) => gf.call('player.setBuffer', { ms: Math.max(50, Math.min(20000, Math.round(+p.milliseconds || 1000))) }),
    'replaygain.getSettings': async () => { const r = await gf.call('player.replayGain'); return oldRg(r); },
    'replaygain.setMode': async (p) => oldRg(await gf.call('player.setReplayGain', { ...(p.sourceMode ? { source: p.sourceMode } : {}), ...(p.processingMode ? { processing: p.processingMode } : {}) })),
    'replaygain.setPreamp': async (p) => {
      const clamp = (v) => Math.max(-24, Math.min(24, +v || 0));
      return oldRg(await gf.call('player.setReplayGain', { ...(p.withRg != null ? { preampWithRg: clamp(p.withRg) } : {}), ...(p.withoutRg != null ? { preampWithoutRg: clamp(p.withoutRg) } : {}) }));
    },
    'config.getDspPresets': async () => ({ presets: (await gf.call('player.dspPresets')).presets.map((name, index) => ({ index, name })) }),
    'config.getActiveDspPreset': async () => { const r = await gf.call('player.dspPresets'); return r.active >= 0 ? { isActive: true, index: r.active, name: r.presets[r.active] } : { isActive: false }; },
    'config.setActiveDspPreset': (p) => gf.call('player.setDspPreset', { index: Math.max(0, Math.round(+p.index || 0)) }),
    'dsp.getChain': async () => {
      const [c, p] = await Promise.all([gf.call('player.dspChain'), gf.call('player.dspPresets')]);
      return { dsps: c.items.map((d) => ({ name: d.name, guid: d.guid })), activePreset: p.active >= 0 ? p.presets[p.active] : null };
    },
    'dsp.getPresets': async () => {
      const p = await gf.call('player.dspPresets');
      return { presets: p.presets.map((name, index) => ({ index, name, active: index === p.active })), selectedIndex: p.active };
    },
    'dsp.applyPreset': async (p) => { await gf.call('player.setDspPreset', { index: Math.max(0, Math.round(+p.index || 0)) }); return { applied: true }; },
    // foobar2000's Advanced page: the host gives it flat, the settings screen walks a tree
    'config.getAdvancedConfig': async () => {
      const r = await gf.call('player.advanced');
      const kids = new Map();
      for (const i of r.items) { if (!kids.has(i.parent)) kids.set(i.parent, []); kids.get(i.parent).push(i); }
      const tree = (parent, depth) => (kids.get(parent) || []).sort((a, b) => a.order - b.order || a.name.localeCompare(b.name)).map((i) => ({
        guid: i.guid, name: i.name, type: i.kind,
        ...(i.kind === 'branch' ? { children: depth < 20 ? tree(i.guid, depth + 1) : [] } : { value: i.value, ...(i.defaultValue !== undefined ? { defaultValue: i.defaultValue } : {}) }),
      }));
      return { entries: tree(r.root, 0) };
    },
    'config.getAdvancedConfigValue': async (p) => {
      const r = await gf.call('player.advanced');
      const i = r.items.find((x) => x.guid.toLowerCase() === String(p.guid).toLowerCase());
      return i ? { value: i.value, type: i.kind } : { success: false, code: 'NOT_FOUND', error: 'no such setting' };
    },
    'config.setAdvancedConfigValue': async (p) => {
      let value = p.value;
      if (typeof value === 'string' && /^-?\d+$/.test(value.trim())) {
        const all = await gf.call('player.advanced');
        const i = all.items.find((x) => x.guid.toLowerCase() === String(p.guid).toLowerCase());
        if (i && i.kind === 'integer') value = parseInt(value, 10);
      }
      return { value: (await gf.call('player.setAdvanced', { guid: String(p.guid), value })).value };
    },
    'config.resetAdvancedConfig': async (p) => ({ value: (await gf.call('player.resetAdvanced', { guid: String(p.guid) })).value }),
    // the library's folders, as the host works them out from the tracks
    'library.getRoots': async () => ({ roots: (await gf.call('library.folders')).folders.map((f) => ({ absolutePath: f.path, displayName: f.path.replace(/\\$/, '').split('\\').pop() || f.path, trackCount: f.trackCount })) }),
    'config.getComponents': async () => ({ components: (await gf.call('host.components')).components.map((c) => ({ name: c.name, version: c.version, filename: c.file })) }),
    'config.getPlaybackFollowCursor': async () => ({ enabled: (await gf.call('player.follow')).playbackFollowsCursor }),
    'config.getCursorFollowPlayback': async () => ({ enabled: (await gf.call('player.follow')).cursorFollowsPlayback }),
    'config.setPlaybackFollowCursor': async (p) => ({ enabled: (await gf.call('player.setFollow', { playbackFollowsCursor: !!p.enabled })).playbackFollowsCursor }),
    'config.setCursorFollowPlayback': async (p) => ({ enabled: (await gf.call('player.setFollow', { cursorFollowsPlayback: !!p.enabled })).cursorFollowsPlayback }),
    'config.showLibraryPreferences': () => gf.call('player.showPreferences', { page: 'library' }),
    'config.showPreferences': () => gf.call('player.showPreferences', { page: 'main' }),
    'playlist.getGroupRuns': async (p) => {
      const guid = await guidOf(p);
      if (!guid) return { success: false, code: 'NOT_FOUND' };
      const r = await gf.call('playlist.groupRuns', { playlist: guid, format: String((p.patterns || [p.pattern || '%album%'])[0]).slice(0, 1000) });
      return { runs: r.runs.map((x) => ({ start: x.start, count: x.count, key: x.key, value: x.key })), total: r.total };
    },

    'dnd.getPathsAsync': async () => {
      const fresh = () => lastDrop && Date.now() - lastDrop.at < 5000;
      for (let i = 0; i < 40 && !fresh(); i++) await new Promise((r) => setTimeout(r, 25));
      if (!fresh()) return { success: false, code: 'NOT_FOUND', error: 'no files were dropped', paths: [] };
      const paths = lastDrop.paths;
      lastDrop = null;
      return { paths, resolvedPaths: paths };
    },
    // the window's own frame: the host drops the system title bar; where to drag is said in CSS (app-region)
    'window.setFrameless': async (p) => { const r = await gf.call('window.setFrame', { custom: !!p.frameless }); dragCss(!!p.frameless); return { frameless: r.customFrame }; },
    'window.setDragRegions': async () => ({}),
    'window.setNoDragRegions': async () => ({}),
    'window.setMaximizeButtonRegion': async (p) => {
      const r = p && p.region ? p.region : { x: 0, y: 0, width: 0, height: 0 };
      return gf.call('window.setMaximizeButton', { x: +r.x || 0, y: +r.y || 0, width: Math.max(0, +r.width || 0), height: Math.max(0, +r.height || 0) });
    },
    'window.setMica': async (p) => ({ applied: (await gf.call('window.setBackdrop', { kind: p.enabled ? (p.variant === 'mica-alt' ? 'mica-alt' : p.variant === 'acrylic' ? 'acrylic' : 'mica') : 'none', dark: p.darkMode !== false })).applied }),
    'window.setBackgroundTransparency': async () => ({}),
    'window.setMinSize': (p) => gf.call('window.setMinSize', { width: Math.max(100, Math.round(+p.width || 100)), height: Math.max(100, Math.round(+p.height || 100)) }),
    'window.getBounds': () => gf.call('window.getBounds'),
    'window.setBounds': (p) => gf.call('window.setBounds', { x: Math.round(+p.x || 0), y: Math.round(+p.y || 0), width: Math.max(100, Math.round(+p.width || 100)), height: Math.max(100, Math.round(+p.height || 100)) }),
    'window.close': () => gf.call('window.close'),
    'shell.openExternal': (p) => gf.call('shell.openUrl', { url: String(p.url || '') }),
    'shell.showInExplorer': (p) => gf.call('shell.showFile', { path: String(p.path || '') }),
    'queue.clear': () => (writable() ? gf.call('queue.clear') : readonly('queue.clear')),

    // library
    'library.getAlbums': async (p) => {
      let list = (await allAlbums()).map(oldAlbum);
      if (p.query) { const q = String(p.query).toLowerCase(); list = list.filter((a) => a.name.toLowerCase().includes(q) || a.albumArtist.toLowerCase().includes(q)); }
      if (p.sort === 'name') list.sort((a, b) => a.name.localeCompare(b.name));
      const off = Math.max(0, +p.offset || 0), lim = Math.max(1, +p.limit || 1000);
      return { albums: list.slice(off, off + lim), total: list.length, hasMore: off + lim < list.length };
    },
    'library.getAlbumTracks': async (p) => {
      const lc = (s) => String(s || '').toLowerCase();
      const a = (await allAlbums()).find((x) => lc(x.name) === lc(p.album) && (p.albumArtist == null || lc(x.albumArtist) === lc(p.albumArtist)));
      if (!a) return { tracks: [] };
      const r = await gf.call('library.tracksOf', { keys: [a.key] });
      return { tracks: (r.albums[a.key] || []).map((t) => oldTrack(t)) };
    },
    'library.query': (p) => search(p),
    'library.search': (p) => search(p),
    'config.getLibraryStatus': async () => { const a = await allAlbums(); return { enabled: true, itemCount: a.reduce((n, x) => n + x.trackCount, 0), albumCount: a.length }; },
    'config.getVersionInfo': async () => ({ version: gf.info.foobar2000, is64bit: true, isPortable: false, plugin: { name: gf.info.host, version: gf.info.version }, host: gf.info.host }),

    // pictures: URLs on the page's own origin (no tainted canvases)
    'artwork.getFb2kUrl': async (p) => { if (!nowTrack) await M['playback.getCurrentTrack'](); return nowTrack ? { available: true, dataUrl: artPath(nowTrack, p.type, +p.maxSize || 0) } : { available: false }; },
    'artwork.getCurrent': async (p) => M['artwork.getFb2kUrl'](p || {}),
    'artwork.getFb2kUrlByPath': async (p) => ({ available: true, dataUrl: artPath(refOf(p.path), p.type, +p.maxSize || 0) }),
    'artwork.getFb2kUrlByPathBatch': async (p) => {
      const items = p.items || (p.paths || []).map((path) => ({ path }));
      const artworks = items.map((it) => ({ path: it.path, available: true, dataUrl: artPath(refOf(it.path), it.type || p.type, +(it.maxSize || p.maxSize) || 0) }));
      // a file without a picture: said so, rather than an address that ends in a broken image. Asked of the host the
      // way an <img> would (the answer is cached, so the picture itself then costs nothing more), six at a time
      if (typeof fetch === 'function') {
        let next = 0;
        const worker = async () => { for (let i = next++; i < artworks.length; i = next++) {
          try { const r = await fetch(artworks[i].dataUrl); artworks[i].available = r.ok; if (!r.ok) artworks[i].dataUrl = ''; } catch { /* left as it is */ }
        } };
        await Promise.all(Array.from({ length: Math.min(6, artworks.length) }, worker));
      }
      return { artworks, items: artworks };
    },

    // title formatting
    'titleformat.evalFieldsBatch': async (p) => {
      const fields = Array.isArray(p.fields) ? Object.fromEntries(p.fields.map((f, i) => ['c' + i, f])) : p.fields || {};
      const r = await gf.call('titleformat.evalBatch', { tracks: (p.paths || p.handles || []).map(refOf), fields });
      return { results: r.rows };
    },
    'titleformat.eval': async (p) => { const r = await gf.call('titleformat.evalNow', { format: String(p.pattern || p.format || '') }); return { result: r.value, value: r.value, text: r.value }; },

    // the seek bar's waveform: decoded by the host in the background, answered when ready
    'audio.generateFullWaveform': async (p) => {
      const r = await gf.call('audio.waveform', { track: refOf(p.path), points: Math.max(16, Math.min(10000, +p.resolution || 1000)) });
      return { status: 'ready', waveform: { peaks: r.peaks }, duration: r.duration, channels: r.channels };
    },

    // the live sound: the host's ring in shared memory has the layout the visualiser reads (sequence [7], written [8],
    // capacity [6], slot [15], frames from byte 64); its arrival is passed on as the event the visualiser listens for
    'audio.subscribeStream': async (p) => {
      await gf.call('audio.openStream', { seconds: Math.max(0.1, Math.min(4, +p.bufferSeconds || 1)), tag: String(p.subscriptionId || '').slice(0, 100) });
      return { subscribed: true };
    },
    'audio.unsubscribeStream': async () => { await gf.call('audio.closeStream'); return { unsubscribed: true }; },
    // a piece of a track as samples: answered at once with a task, the samples and audio:pcmReady follow
    'audio.decodePcm': async (p) => {
      const taskId = 'pcm' + ++pcmSeq;
      const params = { track: refOf(p.path), start: Math.max(0, +p.start || 0), end: Math.max(0, +p.end || 0), mono: !!p.mono, id: taskId };
      if (p.sampleRate) params.sampleRate = Math.max(1000, Math.min(384000, Math.round(+p.sampleRate)));
      const c = gf.cancellable('audio.decodePcm', params);
      pcmTasks.set(taskId, c);
      c.promise.then((r) => emit('audio:pcmReady', { taskId, end: r.end, truncated: r.ended, frames: r.frames, sampleRate: r.sampleRate, channels: r.channels }),
                     (e) => { if (e.code !== 'CANCELLED') emit('audio:pcmFailed', { taskId, code: e.code, error: e.message }); })
        .finally(() => pcmTasks.delete(taskId));
      return { taskId };
    },
    'audio.cancelDecodePcm': async (p) => { const c = pcmTasks.get(String(p.taskId)); if (c) c.cancel(); return { cancelled: !!c }; },

    // HTTP through the host (no CORS), answered inline: bridge.js takes a body in the answer as it is
    'http.get': (p) => http(p, 'GET'),
    'http.post': (p) => http(p, 'POST'),
    'http.abort': async () => ({}),

    // the theme's own files: only inside its data folder
    // pictures in an album's folder: listed by the host, shown and read through their address on the page's origin
    'artwork.getFolderImages': async (p) => {
      const dir = String(p.directory || '').replace(/[\\/]+$/, '');
      const r = await gf.call('art.folderImages', { folder: dir });
      return { images: r.images.map((im) => { const path = dir + '\\' + im.name; beside.set(norm(path), im); return { name: im.name, path, size: im.size, modified: im.modified, url: im.url }; }) };
    },
    'file.read': (p) => file(p, 'read'),
    'file.write': (p) => file(p, 'write'),
    'file.exists': (p) => file(p, 'exists'),
    'file.getInfo': (p) => file(p, 'info'),
    'file.list': (p) => file(p, 'list'),
    'file.delete': (p) => file(p, 'delete'),
    'file.mkdir': async () => ({}),
  };

  async function http(p, method) {
    const headers = {};
    if (p.headers && typeof p.headers === 'object') {
      for (const [k, v] of Object.entries(p.headers)) if (v != null) headers[k] = String(v);
    } else if (typeof p.headers === 'string') headers['User-Agent'] = p.headers;
    let body;
    if (p.body != null) body = typeof p.body === 'string' ? p.body : JSON.stringify(p.body);
    if (p.json != null) { body = JSON.stringify(p.json); headers['Content-Type'] ??= 'application/json'; }
    const r = await gf.call('net.fetch', {
      url: String(p.url || ''), method: p.method ? String(p.method).toUpperCase() : method, headers,
      ...(body != null ? { body } : {}),
      timeoutMs: Math.max(1000, Math.min(600000, +p.timeout || 30000)),
      encoding: p.responseType === 'base64' ? 'base64' : 'utf8',
    });
    return { status: r.status, headers: r.headers, body: r.body, url: r.url, finalUrl: r.url };
  }

  /** library.query / library.search: a foobar2000 query in the host, the asked fields in the old shape */
  async function search(p) {
    const q = String(p.query ?? '').trim();
    if (!q) return { tracks: [], totalCount: 0, total: 0 };
    const fields = p.fields || [];
    const refsOnly = fields.length > 0 && fields.every((f) => ['absolutePath', 'subsong', 'handle', 'path'].includes(f));
    const r = await gf.call('library.search', { query: q, ...(p.sort ? { sort: String(p.sort) } : {}), limit: Math.max(1, Math.min(1000000, +p.limit || 100000)), detail: refsOnly ? 'refs' : 'tracks' });
    const tracks = refsOnly ? r.refs.map((x) => oldTrack({ path: x.path, subsong: x.subsong || 0 })) : await withFields(r.tracks, fields);
    return { tracks, totalCount: r.total, total: r.total };
  }

  // «binary» in the old API: a data: address (what an <img> or a decoder takes)
  const MIME = { jpg: 'image/jpeg', jpeg: 'image/jpeg', png: 'image/png', webp: 'image/webp', gif: 'image/gif', bmp: 'image/bmp', json: 'application/json', txt: 'text/plain' };
  const dataUrl = (path, b64) => `data:${MIME[String(path).split('.').pop().toLowerCase()] || 'application/octet-stream'};base64,${b64}`;
  /** the old API's picture as a data: address: asked of the host the way an <img> would */
  const artBytes = async (path, type) => {
    try {
      const r = await fetch(artPath(refOf(path), type, 0));
      if (!r.ok) return { available: false };
      const buf = new Uint8Array(await r.arrayBuffer());
      let bin = '';
      for (let i = 0; i < buf.length; i += 0x8000) bin += String.fromCharCode.apply(null, buf.subarray(i, i + 0x8000));
      const mimeType = r.headers.get('content-type') || 'image/jpeg';
      return { available: true, mimeType, dataUrl: `data:${mimeType};base64,${btoa(bin)}`, size: buf.length };
    } catch { return { available: false }; }
  };
  let ctxToken = 0, mainMenu = null;
  const menuNorm = (x) => String(x || '').toLowerCase().replace(/\.{3}|…/g, '').replace(/&/g, '').replace(/\s+/g, ' ').trim();
  /** flat items with levels → the tree the old API gave (children under submenus) */
  const menuTree = (flat, extra) => {
    const root = [], stack = [{ level: -1, children: root }];
    for (const it of flat) {
      const node = { type: it.kind, label: it.label, displayLabel: it.label, enabled: it.enabled, checked: it.checked, ...(it.kind === 'command' ? extra(it) : {}), ...(it.kind === 'submenu' ? { children: [] } : {}) };
      while (stack.length > 1 && stack[stack.length - 1].level >= it.level) stack.pop();
      stack[stack.length - 1].children.push(node);
      if (it.kind === 'submenu') stack.push({ level: it.level, children: node.children });
    }
    return root;
  };
  const menuSource = async (p) => {
    if (p.mode === 'nowPlaying') return { nowPlaying: true };
    if (p.mode === 'selection') {
      const act = (await playlists()).find((x) => x.isActive);
      return act ? { playlist: act.guid } : { error: { success: false, code: 'NOT_FOUND', error: 'no active playlist' } };
    }
    const tracks = (p.handles || p.paths || []).map(refOf).filter((r) => r.path);
    return tracks.length ? { tracks } : { error: { success: false, code: 'INVALID_PARAMS', error: 'no tracks' } };
  };
  let pcmSeq = 0;
  const pcmTasks = new Map();                 // taskId → the cancellable call
  const oldRg = (r) => ({ sourceMode: r.source, processingMode: r.processing, preampWithRg: r.preampWithRg, preampWithoutRg: r.preampWithoutRg, withRg: r.preampWithRg, withoutRg: r.preampWithoutRg });
  const picked = new Set();                   // paths the person chose in this window's file dialogs
  const beside = new Map();                   // pictures the host listed beside the music: path → { url, size, modified }
  const norm = (path) => String(path || '').replace(/\//g, '\\').toLowerCase();
  const dialogOpts = (p) => ({
    title: String(p.title || '').slice(0, 200), defaultPath: String(p.defaultPath || '').slice(0, 1000),
    filters: (p.filters || []).slice(0, 20).map((f) => ({ name: String(f.name || '').slice(0, 100), extensions: (f.extensions || []).map(String).slice(0, 100) })),
  });
  M['dialog.openFile'] = async (p) => {
    const r = await gf.call('dialog.openFile', { ...dialogOpts(p), multiple: !!p.multiple });
    r.paths.forEach((x) => picked.add(norm(x)));
    return { canceled: r.canceled, filePaths: r.paths, filePath: r.paths[0] || '' };
  };
  M['dialog.saveFile'] = async (p) => {
    const r = await gf.call('dialog.saveFile', { ...dialogOpts(p), defaultName: String(p.defaultName || '').slice(0, 260) });
    if (r.path) picked.add(norm(r.path));
    return { canceled: r.canceled, filePath: r.path || '' };
  };
  M['dialog.openFolder'] = async (p) => { const r = await gf.call('dialog.openFolder', dialogOpts(p)); return { canceled: r.canceled, folderPath: r.path || '' }; };

  const relOf = (path) => {
    const root = String(gf.info.dataDir || '').replace(/[\\/]+$/, '').toLowerCase();
    let p = String(path || '').replace(/\//g, '\\');
    // «%profile%\…» (the old component's foobar2000 profile folder): the theme's own data folder here
    if (/^%profile%\\/i.test(p)) return p.slice(10).replace(/\\/g, '/');
    if (!root || !p.toLowerCase().startsWith(root + '\\')) return null;
    return p.slice(root.length + 1).replace(/\\/g, '/');
  };
  const nameAndParent = (path) => { const p = String(path || '').replace(/\//g, '\\').replace(/\\+$/, ''); const i = p.lastIndexOf('\\'); return { name: p.slice(i + 1), parent: i > 0 ? p.slice(0, i) : '' }; };
  const absOf = (rel) => String(gf.info.dataDir).replace(/[\\/]+$/, '') + '\\' + String(rel).replace(/\//g, '\\');
  async function file(p, op) {
    const rel = relOf(p.path);
    const enc = p.encoding === 'base64' || p.encoding === 'binary' ? 'base64' : 'utf8';
    if (rel == null) {
      // outside the theme's folder: only what the person chose in a file dialog of this window
      const im = beside.get(norm(p.path));
      if (im && op === 'read' && p.encoding === 'binary') {
        const res = await fetch(im.url);
        if (!res.ok) return { success: false, code: 'NOT_FOUND', error: 'the picture is gone' };
        const blob = await res.blob();
        const url = await new Promise((ok, bad) => { const fr = new FileReader(); fr.onload = () => ok(fr.result); fr.onerror = () => bad(fr.error); fr.readAsDataURL(blob); });
        return { content: url, size: blob.size, encoding: 'base64' };
      }
      if (im && (op === 'info' || op === 'exists')) return { exists: true, size: im.size, isDirectory: false, modified: im.modified, lastModified: im.modified };
      if (op === 'read' && picked.has(norm(p.path))) { const r = await gf.call('picked.read', { path: String(p.path), encoding: enc }); return { content: p.encoding === 'binary' ? dataUrl(p.path, r.content) : r.content, size: r.size, encoding: enc }; }
      if (op === 'write' && picked.has(norm(p.path))) { const r = await gf.call('picked.write', { path: String(p.path), content: String(p.content ?? ''), encoding: enc }); return { size: r.size }; }
      if (op === 'list') {
        // a folder of the library's music: the host lists its pictures (and nothing else there)
        const dir = String(p.path || '').replace(/[\\/]+$/, '');
        try {
          const r = await gf.call('art.folderImages', { folder: dir });
          const files = r.images.map((im) => { beside.set(norm(dir + '\\' + im.name), im); return im.name; });
          return { files, directories: [], entries: r.images.map((im) => ({ name: im.name, path: dir + '\\' + im.name, isDirectory: false, size: im.size, modified: im.modified })) };
        } catch (e) { if (e.code !== 'PERMISSION_DENIED') throw e; }
      }
      return unsupported('file.' + op + ' outside the theme folder');
    }
    if (op === 'read') { const r = await gf.call('storage.read', { path: rel, encoding: enc }); return { content: p.encoding === 'binary' ? dataUrl(p.path, r.content) : r.content, size: r.size, encoding: enc }; }
    if (op === 'write') { const r = await gf.call('storage.write', { path: rel, content: String(p.content ?? ''), encoding: p.encoding === 'base64' ? 'base64' : 'utf8' }); return { size: r.size }; }
    if (op === 'exists') { const r = await gf.call('storage.stat', { path: rel }); return { exists: r.exists, isDirectory: r.dir }; }
    if (op === 'info') { const r = await gf.call('storage.stat', { path: rel }); return r.exists ? { exists: true, size: r.size, isDirectory: r.dir, modified: r.modified, lastModified: r.modified, ...nameAndParent(absOf(rel)) } : { success: false, code: 'NOT_FOUND', exists: false }; }
    if (op === 'delete') { const r = await gf.call('storage.remove', { path: rel, recursive: false }); return { deleted: r.removed > 0 }; }
    if (op === 'list') {
      const r = await gf.call('storage.list', { path: rel });
      const re = p.pattern ? new RegExp('^' + String(p.pattern).replace(/[.+^${}()|[\]\\]/g, '\\$&').replace(/\*/g, '.*').replace(/\?/g, '.') + '$', 'i') : null;
      const list = r.entries.filter((e) => !re || re.test(e.path.split('/').pop()));
      return {
        entries: list.map((e) => ({ name: e.path.split('/').pop(), path: absOf(e.path), isDirectory: e.dir, size: e.size, modified: e.modified })),
        files: list.filter((e) => !e.dir).map((e) => e.path.split('/').pop()),         // the old component's shape
        directories: list.filter((e) => e.dir).map((e) => e.path.split('/').pop()),
      };
    }
    return unsupported('file.' + op);
  }

  // ---------------------------------------------------------------- events
  const subs = new Map();   // old name → Set of fns
  const emit = (name, data) => { const s = subs.get(name); if (s) for (const fn of s) { try { fn(data); } catch (e) { console.error('[Gatefold] handler', name, e); } } };
  const wv = typeof window !== 'undefined' && window.chrome && window.chrome.webview;
  if (wv && gf.onAudioStream) gf.onAudioStream((st) => {
    const ev = new Event('sharedbufferreceived');
    ev.additionalData = { purpose: 'audio.subscribeStream', subscriptionId: st.tag, channels: st.channels, sampleRate: st.sampleRate, epoch: st.epoch };
    ev.getBuffer = () => st.buffer;
    try { wv.dispatchEvent(ev); } catch (e) { gf.call('host.log', { level: 'warn', message: 'audio stream not passed on: ' + e.message }).catch(() => {}); }
  });
  // samples for loudness and tempo: passed on in the shape those modules read (planes at 64 + c × capacity × 4)
  if (wv && gf.onPcm) gf.onPcm((p) => {
    const ev = new Event('sharedbufferreceived');
    ev.additionalData = { purpose: 'audio.decodePcm', taskId: p.id, frames: p.frames, channels: p.channels, sampleRate: p.sampleRate };
    ev.getBuffer = () => p.buffer;
    try { wv.dispatchEvent(ev); } catch { p.release(); }
  });
  gf.on('window.filesDropped', (d) => { lastDrop = { paths: d.paths, at: Date.now() }; });
  gf.on('taskbar.buttonClicked', (d) => emit('taskbar:buttonClicked', { id: d.id }));
  gf.on('tray.menuItem', (d) => emit('tray:menuItemClicked', { id: d.id }));
  gf.on('tray.clicked', (d) => emit(d.button === 'double' ? 'tray:doubleClick' : 'tray:click', {}));
  gf.on('playlist.changed', () => { lists = null; });
  // the host says what changed; the old events Gatefold listens to are named after it
  const OLD_PL = { added: 'playlist:itemsAdded', removed: 'playlist:itemsRemoved', reordered: 'playlist:itemsReordered', modified: 'playlist:itemsModified',
    list: 'playlist:reordered', active: 'playlist:activated' };
  gf.on('playlist.changed', (d) => {
    const ev = OLD_PL[d.what];
    if (!ev) return;
    const data = d.playlist ? { playlistGuid: d.playlist, playlist: d.playlist, ...(d.count != null ? { itemCount: d.count } : {}) } : {};
    emit(ev, data);
    if (d.what === 'modified') emit('playlist:itemsReplaced', data);   // tags or items changed: what the views refresh on
    if (d.what === 'list') { emit('playlist:created', {}); emit('playlist:renamed', {}); }   // the sidebar and likes re-read the list
  });
  gf.on('library.changed', () => { albums = null; emit('library:itemsModified', {}); emit('library:itemsAdded', {}); emit('metadb:changed', {}); });
  gf.on('playback.trackChanged', (d) => {
    nowTrack = d.track || null;
    if (d.track) emit('playback:trackChanged', oldTrack(d.track));
  });
  gf.on('playback.state', (d) => {
    const was = state; state = d.state;
    emit('playback:stateChanged', { state: d.state });
    if (d.state === 'paused' || (d.state === 'playing' && was === 'paused')) emit('playback:paused', { paused: d.state === 'paused' });
    if (d.state === 'playing' && was === 'stopped') emit('playback:starting', { paused: false });
    if (d.state === 'stopped') emit('playback:stopped', { reason: 'user' });
  });
  gf.on('playback.position', (d) => emit('playback:time', { position: d.position, hostTime: performance.now() }));
  gf.on('playback.seeked', (d) => emit('playback:seeked', { position: d.position }));
  let orderNames = null;
  gf.on('playback.order', async (d) => {
    try { orderNames = orderNames || (await gf.call('playback.orders')).orders; } catch { orderNames = []; }
    const i = orderNames.indexOf(d.order);
    emit('playback:orderChanged', { order: i, orderIndex: i, name: d.order });
  });
  gf.on('playback.stopAfterCurrent', (d) => emit('playback:stopAfterCurrentChanged', { enabled: d.enabled }));
  let focused = null;
  gf.on('window.state', (d) => {
    emit('window:stateChanged', oldWin(d.state));
    if (d.state.focused !== focused) { focused = d.state.focused; emit('window:activated', { active: focused }); }
  });
  gf.on('player.dspChanged', () => emit('audio:dspPresetChanged', {}));
  gf.on('playback.dynamicInfo', (d) => emit('playback:dynamicInfoTrack', { title: d.title, artist: d.artist || '' }));
  gf.on('playback.edited', (d) => emit('playback:edited', oldTrack(d.track)));
  gf.on('player.colorsChanged', (d) => emit('system:themeChanged', { dark: d.dark, isDark: d.dark }));
  gf.on('player.replayGainChanged', (d) => emit('audio:replaygainModeChanged', { mode: { none: 0, track: 1, album: 2, auto: 3 }[d.source] ?? 0, ...oldRg(d) }));
  gf.on('queue.changed', (d) => emit('playback:queueChanged', { origin: d.origin }));
  gf.on('playback.volume', (d) => { volumeDb = d.volumeDb; emit('playback:volumeChanged', { volume: pct(d.volumeDb), volumeDb: d.volumeDb, isMuted: d.volumeDb <= -100 }); });

  // the window shows the page's background colour where the page is not drawn yet (it grew faster than the page)
  if (typeof document !== 'undefined' && typeof MutationObserver !== 'undefined') {
    let last = '', timer = 0;
    const hex = (c) => {
      const m = /rgba?\(\s*(\d+)[,\s]+(\d+)[,\s]+(\d+)/.exec(c) || [];
      if (m.length) return '#' + [m[1], m[2], m[3]].map((v) => (+v).toString(16).padStart(2, '0')).join('');
      return /^#[0-9a-f]{6}$/i.test(c) ? c.toLowerCase() : '';
    };
    const probe = document.createElement('div');
    const send = () => {
      timer = 0;
      if (!document.body) return;
      probe.style.cssText = 'position:absolute;width:0;height:0;visibility:hidden;background:var(--bg)';
      if (!probe.isConnected) document.body.appendChild(probe);
      const c = hex(getComputedStyle(probe).backgroundColor);
      if (c && c !== last) { last = c; gf.call('window.setBackground', { color: c }).catch(() => {}); }
    };
    const later = () => { if (!timer) timer = setTimeout(send, 400); };
    new MutationObserver(later).observe(document.documentElement, { attributes: true, attributeFilter: ['style', 'class', 'data-scheme'] });
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', later); else later();
  }

  // a window the theme opened (the mini player) has no system title bar: it is dragged by its own body
  if (gf.info && gf.info.window && gf.info.window !== 'main') dragCss(true);

  // keys Gatefold leaves alone (with Ctrl, Alt, the F keys, media keys) reach foobar2000's own shortcuts
  if (typeof gf.forwardKeys === 'function') gf.forwardKeys(true);

  return {
    isGf: true,
    async invoke(method, params) {
      const fn = M[method];
      if (!fn) return unsupported(method);
      try {
        const r = await fn(params || {});
        return r && typeof r === 'object' && !Array.isArray(r) ? { success: true, ...r } : { success: true };
      } catch (e) { return fail(e); }
    },
    on(event, fn) {
      if (!subs.has(event)) subs.set(event, new Set());
      subs.get(event).add(fn);
    },
    /** for tests and diagnostics */
    _methods: () => Object.keys(M),
    _cacheAge: () => (albums ? Date.now() - albumsAt : -1),
  };
}
