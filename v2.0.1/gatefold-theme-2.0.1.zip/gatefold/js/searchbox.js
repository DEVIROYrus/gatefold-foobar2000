/*
 * Gatefold · searchbox.js — the search field in the title bar: suggestions as you type.
 * Artists, albums (with covers) and tracks from smartsearch.js, a «did you mean» line when the words needed a
 * correction, and «All results» at the bottom. ↑ ↓ choose, Enter opens (with nothing chosen: all results),
 * Esc closes the list, a second Esc clears the field. Library only, so it answers as fast as you type.
 */
import { esc } from './bridge.js';
import { router, h, icon } from './ui.js';
import { $t } from './i18n.js';
import * as Smart from './smartsearch.js';
import * as Lib from './library.js';
import * as Art from './artistart.js';

let input = null, pop = null, items = [], sel = -1, token = 0, timer = 0;

export function attach(el) {
  input = el;
  input.setAttribute('autocomplete', 'off');
  input.setAttribute('role', 'combobox');
  input.setAttribute('aria-expanded', 'false');
  input.addEventListener('input', () => { clearTimeout(timer); timer = setTimeout(suggest, 60); });
  input.addEventListener('focus', () => { Smart.warm(); if (input.value.trim()) suggest(); });
  input.addEventListener('blur', () => setTimeout(close, 160));
  input.addEventListener('keydown', (e) => {
    e.stopPropagation();
    if (e.key === 'ArrowDown') { e.preventDefault(); if (!pop) suggest(); else move(1); }
    else if (e.key === 'ArrowUp') { e.preventDefault(); move(-1); }
    else if (e.key === 'Enter') { e.preventDefault(); if (sel >= 0 && items[sel]) run(items[sel]); else all(); }
    else if (e.key === 'Escape') {
      if (pop) { close(); return; }
      input.value = ''; input.blur();
      if (router.current === 'search') router.back();
    }
  });
}

function all() {
  const q = input.value.trim();
  close();
  if (q) Lib.openSearch(q);
}

async function suggest() {
  const q = input.value.trim();
  const tk = ++token;
  if (!q) { close(); return; }
  const r = await Smart.search(q, { artists: 3, albums: 4, tracks: 5 }).catch(() => null);
  if (tk !== token || document.activeElement !== input) return;
  items = [];
  if (r && r.suggestion) items.push({ kind: 'fix', label: r.suggestion });
  if (r) {
    for (const { item } of r.artists) items.push({ kind: 'artist', label: item.name, sub: $t('Исполнитель'), artist: item.name, cover: firstCover(item), run: () => router.go('artist', item) });
    for (const { item } of r.albums) items.push({ kind: 'album', label: item.name, sub: [item.albumArtist || item.artist, item.year].filter(Boolean).join(' · '), cover: item.firstTrackAbsolutePath, run: () => router.go('album', item) });
    for (const { item } of r.tracks) items.push({ kind: 'track', label: item.title, sub: [item.artist, item.album].filter(Boolean).join(' · '), cover: item.absolutePath || '', run: () => Lib.playPaths([item.handle || item.absolutePath], 0, item.title) });
  }
  items.push({ kind: 'all', label: $t('Все результаты по «{0}»', q) });
  sel = -1;
  paint();
}

function paint() {
  if (!pop) {
    pop = h('<div class="sb-pop" role="listbox"></div>');
    document.getElementById('layer').append(pop);
    pop.addEventListener('mousedown', (e) => e.preventDefault());   // the field keeps the focus
    pop.addEventListener('click', (e) => { const el = e.target.closest('.sb-it'); if (el) run(items[+el.dataset.i]); });
    requestAnimationFrame(() => pop && pop.classList.add('on'));
  }
  const r = document.getElementById('searchBox').getBoundingClientRect();
  pop.style.left = r.left + 'px'; pop.style.top = r.bottom + 6 + 'px'; pop.style.width = Math.max(r.width, 420) + 'px';
  const ICON = { artist: 'mic', album: 'grid', track: 'music', fix: 'sparkle', all: 'search' };
  const HEAD = { artist: $t('Исполнители'), album: $t('Альбомы'), track: $t('Треки') };
  let last = '', html = '';
  items.forEach((it, i) => {
    if (HEAD[it.kind] && it.kind !== last) html += `<div class="sb-g">${esc(HEAD[it.kind])}</div>`;
    last = it.kind;
    if (it.kind === 'fix') { html += `<div class="sb-it sb-fix${i === sel ? ' on' : ''}" data-i="${i}" role="option">${icon('sparkle', 15)}<span>${esc($t('Возможно, вы имели в виду'))} <b>${esc(it.label)}</b></span></div>`; return; }
    if (it.kind === 'all') { html += `<div class="sb-it sb-all${i === sel ? ' on' : ''}" data-i="${i}" role="option">${icon('search', 15)}<span>${esc(it.label)}</span><kbd>Enter</kbd></div>`; return; }
    html += `<div class="sb-it${i === sel ? ' on' : ''}" data-i="${i}" role="option"><span class="sb-cov${it.kind === 'artist' ? ' round' : ''}">${icon(ICON[it.kind], 15)}<img alt=""${it.cover ? ` data-p="${esc(it.cover)}"` : ''}${it.artist ? ` data-a="${esc(it.artist)}"` : ''}></span><span class="sb-l"><b>${esc(it.label)}</b>${it.sub ? `<small>${esc(it.sub)}</small>` : ''}</span></div>`;
  });
  pop.innerHTML = html;
  input.setAttribute('aria-expanded', 'true');
  fillPictures(pop, 40);
}

/** the first album cover of an artist (their picture while no photo is kept) */
export function firstCover(a) {
  const f = (a.albums && a.albums[0]) || (a.appears && a.appears[0]);
  return (f && f.firstTrackAbsolutePath) || '';
}
/**
 * Pictures for result rows: <img data-a="artist"> gets the artist's photo (or, without one, their first cover),
 * <img data-p="path"> the cover of that track's album. Shared with Ctrl+K and the results page.
 */
export async function fillPictures(root, px) {
  const imgs = [...root.querySelectorAll('img[data-p], img[data-a]')];
  if (!imgs.length) return;
  const size = Math.round(px * (window.devicePixelRatio || 1));
  const put = (img, u) => { if (u && img.isConnected && !img.getAttribute('src')) Lib.setImg(img, u); };
  // artists: their photo when one is kept
  await Promise.all(imgs.filter((i) => i.dataset.a).map(async (img) => put(img, await Art.avatarUrl(img.dataset.a).catch(() => ''))));
  const rest = imgs.filter((i) => !i.getAttribute('src') && i.dataset.p);
  if (!rest.length) return;
  const get = await Lib.coversFor([...new Set(rest.map((i) => i.dataset.p))], size);
  rest.forEach((img) => put(img, get(img.dataset.p)));
}

function move(d) {
  if (!items.length) return;
  sel = sel < 0 ? (d > 0 ? 0 : items.length - 1) : (sel + d + items.length) % items.length;
  pop.querySelectorAll('.sb-it').forEach((el) => { const on = +el.dataset.i === sel; el.classList.toggle('on', on); if (on) el.scrollIntoView({ block: 'nearest' }); });
}

function run(it) {
  if (!it) return;
  if (it.kind === 'fix') { input.value = it.label; suggest(); return; }
  if (it.kind === 'all') { all(); return; }
  close(); input.blur();
  it.run();
}

export function close() {
  token++;
  if (!pop) return;
  const p = pop; pop = null; items = []; sel = -1;
  if (input) input.setAttribute('aria-expanded', 'false');
  p.classList.remove('on');
  setTimeout(() => p.remove(), 140);
}
