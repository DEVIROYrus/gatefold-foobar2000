<#
  Gatefold - upgrade.ps1: the step from Gatefold 1.x (on foo_ui_webview2) to Gatefold 2.0 (its own component).
  Written next to the downloaded component and started by Gatefold 2.0's page on foo_ui_webview2 (js/upgrade.js),
  which then asks foobar2000 to exit. With foobar2000 closed this script:
    1. puts the component in <profile>\user-components-x64\foo_gatefold the way foobar2000 x64 installs one
       (the whole archive extracted, then the files of its x64\ folder copied over the top),
    2. makes Gatefold foobar2000's user interface in <profile>\config.sqlite (a copy is kept as
       config.sqlite.before-gatefold-2) and marks it as already offered, so no "new interface found" question,
    3. starts foobar2000 again.
  Anything that fails puts back what was there (the component folder, the configuration) and still starts
  foobar2000: the page then shows what went wrong (status.json beside this script).
  Pure ASCII on purpose: Windows PowerShell 5.1 reads a file without a byte order mark in the ANSI code page.
#>
param(
  [Parameter(Mandatory = $true)][string]$ProfileDir,
  [Parameter(Mandatory = $true)][string]$Exe,
  [Parameter(Mandatory = $true)][string]$Package,
  [Parameter(Mandatory = $true)][string]$Status
)
$ErrorActionPreference = 'Stop'
$log = [System.Collections.Generic.List[string]]::new()
function Note($m) { $log.Add(((Get-Date).ToString('HH:mm:ss.fff')) + ' ' + $m) }
function Save-Status($state, $err) {
  $o = [ordered]@{ state = $state; error = $err; at = (Get-Date).ToString('o'); log = $log.ToArray() }
  [System.IO.File]::WriteAllText($Status, ($o | ConvertTo-Json -Depth 4), (New-Object System.Text.UTF8Encoding($false)))
}

# 1. foobar2000 (this copy of it) has to be closed: up to 90 s
$deadline = (Get-Date).AddSeconds(90)
Save-Status 'waiting' ''
while (Get-Process foobar2000 -ErrorAction SilentlyContinue | Where-Object { $_.Path -eq $Exe }) {
  if ((Get-Date) -gt $deadline) { Note 'foobar2000 did not exit in 90 s'; Save-Status 'failed' 'foobar2000 did not close'; exit 3 }
  Start-Sleep -Milliseconds 300
}
Start-Sleep -Milliseconds 700   # its last files released
Note 'foobar2000 has exited'

$compRoot = Join-Path $ProfileDir 'user-components-x64'
$comp = Join-Path $compRoot 'foo_gatefold'
$keep = "$comp.before-2"
$cfg = Join-Path $ProfileDir 'config.sqlite'
$cfgKeep = "$cfg.before-gatefold-2"
$tmp = Join-Path ([System.IO.Path]::GetTempPath()) ('gatefold-2-' + [guid]::NewGuid().ToString('N'))
$movedOld = $false; $cfgCopied = $false
try {
  Add-Type -AssemblyName System.IO.Compression.FileSystem
  [System.IO.Compression.ZipFile]::ExtractToDirectory($Package, $tmp)
  if (-not (Test-Path -LiteralPath (Join-Path $tmp 'x64\foo_gatefold.dll'))) { throw 'the package has no x64\foo_gatefold.dll' }
  New-Item -ItemType Directory -Force -Path $compRoot | Out-Null
  if (Test-Path -LiteralPath $comp) {
    if (Test-Path -LiteralPath $keep) { Remove-Item -LiteralPath $keep -Recurse -Force }
    Rename-Item -LiteralPath $comp -NewName (Split-Path $keep -Leaf); $movedOld = $true
  }
  New-Item -ItemType Directory -Force -Path $comp | Out-Null
  Copy-Item -Path (Join-Path $tmp '*') -Destination $comp -Recurse -Force
  Copy-Item -Path (Join-Path $tmp 'x64\*') -Destination $comp -Recurse -Force
  Note "component in $comp"

  if (Test-Path -LiteralPath $cfg) {
    Copy-Item -LiteralPath $cfg -Destination $cfgKeep -Force; $cfgCopied = $true
    Add-Type -TypeDefinition @'
using System;
using System.Text;
using System.Runtime.InteropServices;
public static class GfUi {
  const string L = "winsqlite3.dll";
  [DllImport(L)] static extern int sqlite3_open_v2(byte[] name, out IntPtr db, int flags, IntPtr vfs);
  [DllImport(L)] static extern int sqlite3_close(IntPtr db);
  [DllImport(L)] static extern int sqlite3_prepare_v2(IntPtr db, byte[] sql, int n, out IntPtr st, IntPtr tail);
  [DllImport(L)] static extern int sqlite3_bind_blob(IntPtr st, int i, byte[] v, int n, IntPtr destructor);
  [DllImport(L)] static extern int sqlite3_bind_text(IntPtr st, int i, byte[] v, int n, IntPtr destructor);
  [DllImport(L)] static extern int sqlite3_step(IntPtr st);
  [DllImport(L)] static extern IntPtr sqlite3_column_blob(IntPtr st, int i);
  [DllImport(L)] static extern int sqlite3_column_bytes(IntPtr st, int i);
  [DllImport(L)] static extern int sqlite3_finalize(IntPtr st);
  [DllImport(L)] static extern IntPtr sqlite3_errmsg(IntPtr db);
  static readonly IntPtr TRANSIENT = new IntPtr(-1);
  static byte[] U(string s) { return Encoding.UTF8.GetBytes(s + "\0"); }
  static IntPtr db;
  static string Err() { return Marshal.PtrToStringAnsi(sqlite3_errmsg(db)); }
  static IntPtr Prep(string sql) { IntPtr st; if (sqlite3_prepare_v2(db, U(sql), -1, out st, IntPtr.Zero) != 0) throw new Exception(sql + ": " + Err()); return st; }
  static void Exec(string sql) { IntPtr st = Prep(sql); int rc = sqlite3_step(st); sqlite3_finalize(st); if (rc != 101) throw new Exception(sql + ": " + Err()); }
  static byte[] Get(string name) {
    IntPtr st = Prep("SELECT value FROM configBlobs WHERE name = ?");
    byte[] n = Encoding.UTF8.GetBytes(name); sqlite3_bind_text(st, 1, n, n.Length, TRANSIENT);
    byte[] r = null;
    if (sqlite3_step(st) == 100) { int len = sqlite3_column_bytes(st, 0); r = new byte[len]; if (len > 0) Marshal.Copy(sqlite3_column_blob(st, 0), r, 0, len); }
    sqlite3_finalize(st); return r;
  }
  static void Set(string name, byte[] v) {
    IntPtr st = Prep("INSERT OR REPLACE INTO configBlobs (name, value) VALUES (?, ?)");
    byte[] n = Encoding.UTF8.GetBytes(name); sqlite3_bind_text(st, 1, n, n.Length, TRANSIENT);
    sqlite3_bind_blob(st, 2, v, v.Length, TRANSIENT);
    int rc = sqlite3_step(st); sqlite3_finalize(st); if (rc != 101) throw new Exception("write " + name + ": " + Err());
  }
  // foobar2000 2.x: cfg_var.094A28DA-... is the user interface (a GUID), cfg_var.AD13B1D4-... the interfaces it
  // has already offered (uint32 count, then GUIDs). Gatefold's interface: D8D6A892-A500-4259-8A57-701685A3BC63.
  public static string Run(string path) {
    byte[] ui = new Guid("D8D6A892-A500-4259-8A57-701685A3BC63").ToByteArray();
    byte[] dui = new Guid("6EBCE8DE-A55C-4E09-9EFE-A8B6A66D69FD").ToByteArray();
    if (sqlite3_open_v2(U(path), out db, 2, IntPtr.Zero) != 0) throw new Exception("open: " + path);
    try {
      Exec("CREATE TABLE IF NOT EXISTS configBlobs ( name TEXT UNIQUE PRIMARY KEY NOT NULL, value BLOB)");
      Exec("BEGIN IMMEDIATE");
      int count = 0;
      try {
        const string KNOWN = "cfg_var.AD13B1D4-A6F7-425E-A93B-2A3C7DC37A93";
        byte[] k = Get(KNOWN);
        var list = new System.Collections.Generic.List<byte[]>();
        if (k != null && k.Length >= 4) {
          int cnt = BitConverter.ToInt32(k, 0);
          if (cnt < 0 || 4 + cnt * 16 != k.Length) throw new Exception("unexpected list of interfaces (" + k.Length + " bytes)");
          for (int i = 0; i < cnt; i++) { byte[] g = new byte[16]; Array.Copy(k, 4 + i * 16, g, 0, 16); list.Add(g); }
        } else list.Add(dui);
        // Gatefold first: foobar2000 asks "which interface?" again when the chosen one is anywhere else in this list
        // (seen on 2.26: Webview2 UI, Default UI, Gatefold asked; Gatefold, Webview2 UI, Default UI did not)
        list.RemoveAll(g => Convert.ToBase64String(g) == Convert.ToBase64String(ui));
        list.Insert(0, ui);
        byte[] outList = new byte[4 + list.Count * 16];
        BitConverter.GetBytes(list.Count).CopyTo(outList, 0);
        for (int i = 0; i < list.Count; i++) list[i].CopyTo(outList, 4 + i * 16);
        Set(KNOWN, outList);
        Set("cfg_var.094A28DA-C6E8-4392-BAF1-AD0F29E5B303", ui);
        Exec("COMMIT");
        count = list.Count;
      } catch { try { Exec("ROLLBACK"); } catch { } throw; }
      return "Gatefold is the user interface (" + count + " interfaces known)";
    } finally { sqlite3_close(db); }
  }
}
'@
    Note ([GfUi]::Run((Resolve-Path -LiteralPath $cfg).Path))
  } else {
    Note 'no configuration yet: foobar2000 will offer Gatefold itself'
  }
  if ($movedOld) { Remove-Item -LiteralPath $keep -Recurse -Force -ErrorAction SilentlyContinue }
  Save-Status 'done' ''
} catch {
  $err = $_.Exception.Message
  Note "failed: $err"
  # put back what was there
  try {
    if (Test-Path -LiteralPath $comp) { Remove-Item -LiteralPath $comp -Recurse -Force }
    if ($movedOld) { Rename-Item -LiteralPath $keep -NewName (Split-Path $comp -Leaf) }
    if ($cfgCopied) { Copy-Item -LiteralPath $cfgKeep -Destination $cfg -Force }
    Note 'restored'
  } catch { Note "restoring failed: $($_.Exception.Message)" }
  Save-Status 'failed' $err
} finally {
  if (Test-Path -LiteralPath $tmp) { Remove-Item -LiteralPath $tmp -Recurse -Force -ErrorAction SilentlyContinue }
  Start-Process -FilePath $Exe -WorkingDirectory (Split-Path -Parent $Exe)
}
