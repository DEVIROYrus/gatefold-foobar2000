# Third-party notices

Gatefold 2.0 is proprietary software (see `LICENSE`; Gatefold 1.x remains under the MIT License). It ships the following third-party files, each under its own license:

| Files | Project | License | License text |
|---|---|---|---|
| `fonts/inter-*.woff2` | Inter — © 2016 The Inter Project Authors | SIL Open Font License 1.1 | `fonts/OFL.txt` |
| `js/vendor/ort/*` | ONNX Runtime Web 1.22.0 — © Microsoft Corporation | MIT | `js/vendor/ort/LICENSE` |

Software the installer downloads (not bundled in the theme):

| Software | License | Source |
|---|---|---|
| foobar2000 | Freeware; only unmodified installers may be redistributed | https://www.foobar2000.org/license |
| foo_ui_webview2 | GPL-3.0-or-later (SDK: MIT) | https://github.com/NereaFantasia/foo_ui_webview2 |
| Microsoft Edge WebView2 Runtime | Microsoft software license | https://developer.microsoft.com/microsoft-edge/webview2/ |

Downloaded by the theme only when you turn on «Sound analysis (AI)» (not bundled, not in the installer):

| Files | License | Source |
|---|---|---|
| Discogs-EffNet and its classification heads (mood, danceability, voice/instrumental, …) — Music Technology Group, Universitat Pompeu Fabra; heads converted to ONNX, weights unchanged | **CC BY-NC-SA 4.0** — non-commercial use only | https://essentia.upf.edu/models.html |
| ONNX Runtime Web WebAssembly binary — Microsoft | MIT | https://github.com/microsoft/onnxruntime |

Online services are used only through their public APIs, or — when you turn them on yourself — through unofficial interfaces described in the README. Trademarks belong to their owners. Gatefold is not affiliated with foobar2000, foo_ui_webview2, YouTube/Google, Apple, Deezer, MusicBrainz, LRCLIB, Musixmatch, NetEase, Tencent or Kugou.
