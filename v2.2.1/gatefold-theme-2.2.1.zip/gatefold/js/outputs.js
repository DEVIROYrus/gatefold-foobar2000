/*
 * Gatefold · outputs.js — where the sound goes (#36): the output device, chosen from the player bar.
 *
 * foobar2000 lists every device once per way of output: WASAPI shared («Speakers (Realtek Audio)»), exclusive
 * («… [exclusive]»), ASIO («ASIO : …»), and «Null Output». Shown as foobar2000 lists them that is a long list of
 * near-twins, so here:
 *   · the devices of the way in use now come first, their names cleaned («Speakers» over «High Definition Audio
 *     Device»; «Primary Sound Driver» is «the Windows default»), and the other ways under «Other outputs»;
 *   · «Null Output» only when it is the one in use;
 *   · a device with its own equalizer (Equalizer → Headphones → «for this device») is marked — switching to it
 *     switches the equalizer too (headphones.js).
 * Where: the «Sound» popover's first section, a right click on the «Sound» button (a menu, no popover), the
 * button's tip, and Ctrl+K. The list is asked for each time (a device plugged in or out shows at once);
 * the component tells when the device changed elsewhere (player.outputChanged → audio:outputChanged).
 * Switching restarts playback on the new device; the position is kept.
 */
import { call, ok, on, esc } from './bridge.js';
import { toast, popupMenu } from './ui.js';
import { $t } from './i18n.js';
import { settings } from './settings.js';

export const events = new EventTarget();
const changed = () => events.dispatchEvent(new Event('change'));
on('audio:outputChanged', changed);

/** a device as foobar2000 names it → { main, sub, mode }: «Speakers (Realtek Audio) [exclusive]» →
 *  { main: 'Speakers', sub: 'Realtek Audio', mode: 'exclusive' } */
export function nameOf(raw) {
  let s = String(raw || '').trim(), mode = 'shared';
  if (/\s*\[exclusive\]$/i.test(s)) { mode = 'exclusive'; s = s.replace(/\s*\[exclusive\]$/i, ''); }
  const pre = /^([A-Za-z][\w ()-]{0,24}?)\s+:\s+(.+)$/.exec(s);   // «ASIO : Focusrite USB ASIO», «DS : …» (1.x)
  if (pre) { mode = /asio/i.test(pre[1]) ? 'asio' : /wasapi/i.test(pre[1]) && /excl/i.test(pre[1]) ? 'exclusive' : /^ds$/i.test(pre[1]) ? 'ds' : pre[1]; s = pre[2]; }
  if (/^null output$/i.test(s)) return { main: $t('Без звука (Null Output)'), sub: '', mode: 'null' };
  if (/^primary sound driver$/i.test(s)) return { main: $t('Как в Windows'), sub: $t('устройство по умолчанию'), mode };
  const m = /^(.*?)\s*\((.+)\)$/.exec(s);
  return m && m[1] ? { main: m[1], sub: m[2], mode } : { main: s, sub: '', mode };
}
const MODE = () => ({ shared: 'WASAPI', exclusive: $t('Монопольный режим'), asio: 'ASIO', ds: 'DirectSound', null: '' });
export const modeLabel = (m) => MODE()[m] ?? m;

/** the devices: { list: [{ name, outputId, deviceId, isCurrent, main, sub, mode, id, eq }], current, mine, others } —
 *  mine: those of the way in use now; others: [{ mode, label, list }] */
export async function list() {
  const r = await call('config.getOutputDevices');
  if (!ok(r)) return null;
  const eqs = settings.eqHpByDevice || {};
  const all = (r.devices || []).map((d) => ({ ...d, ...nameOf(d.name), id: `${d.outputId}|${d.deviceId}`, eq: !!eqs[`${d.outputId}|${d.deviceId}`] }));
  const current = all.find((d) => d.isCurrent) || null;
  const out = current ? current.outputId : (all.find((d) => d.mode === 'shared') || all[0] || {}).outputId;
  const show = (d) => d.mode !== 'null' || d.isCurrent;
  const mine = all.filter((d) => d.outputId === out && show(d));
  const groups = new Map();
  for (const d of all) {
    if (d.outputId === out || !show(d)) continue;
    if (!groups.has(d.outputId)) groups.set(d.outputId, { mode: d.mode, label: modeLabel(d.mode), list: [] });
    groups.get(d.outputId).list.push(d);
  }
  return { list: all, current, mine, others: [...groups.values()] };
}

/** what the button's tip says */
export const shortName = (d) => (d ? (d.sub && d.main.length < 14 ? `${d.main} (${d.sub})` : d.main) + (d.mode === 'exclusive' ? ` · ${$t('монопольно')}` : '') : '');

/** to this device; playback goes on there from where it was */
export async function choose(d, { quiet = false } = {}) {
  if (!d || d.isCurrent) return true;
  const st = await call('playback.getState').catch(() => null);
  const before = await call('playback.getPosition').catch(() => null);
  const playing = ok(st) && (st.state === 'playing' || st.isPlaying), at = ok(before) ? +before.position : NaN, t0 = performance.now();
  const r = await call('config.setOutputDevice', { outputId: d.outputId, deviceId: d.deviceId });
  if (!ok(r)) { toast(esc(r.error || $t('foobar2000 не переключил устройство'))); return false; }
  import('./headphones.js').then((m) => m.nudge()).catch(() => {});
  changed();
  if (!quiet) toast($t('Вывод: {0}', esc(shortName(d))));
  // foobar2000 restarts playback on the new device; where it does that from the start, the position comes back
  if (playing && at > 3) setTimeout(async () => {
    const p = await call('playback.getPosition').catch(() => null);
    const want = at + (performance.now() - t0) / 1000;
    if (ok(p) && +p.position < at - 2) call('playback.setPosition', { position: want });
  }, 900);
  return true;
}

/** the right click on the «Sound» button: the devices as a menu */
export async function menu(x, y) {
  const L = await list();
  if (!L) { toast($t('Список устройств недоступен в этой версии компонента')); return; }
  const item = (d) => ({ id: d.id, label: d.main + (d.sub ? ` · ${d.sub}` : '') + (d.eq ? ' · EQ' : ''), checked: d.isCurrent });
  const items = L.mine.map(item);
  if (L.others.length) {
    items.push({ type: 'sep' });
    for (const g of L.others) items.push({ id: 'g:' + g.label, label: g.label || $t('Другие'), children: g.list.map(item) });
  }
  items.push({ type: 'sep' }, { id: 'prefs', label: $t('Настройки вывода…') });
  const id = await popupMenu(items, x, y);
  if (!id) return;
  if (id === 'prefs') { const { router } = await import('./ui.js'); router.go('settings'); setTimeout(() => document.querySelector('.st-link[data-sec=foobar]')?.click(), 120); return; }
  await choose(L.list.find((d) => d.id === id));
}

/** the section of the «Sound» popover */
export function sectionHtml(L) {
  if (!L) return '';
  const row = (d) => `<button class="mi snd-out${d.isCurrent ? ' on' : ''}" data-dev="${esc(d.id)}" role="menuitemradio" aria-checked="${d.isCurrent}">
      <span class="chk">${d.isCurrent ? '✓' : ''}</span><span class="snd-out-n"><b>${esc(d.main)}</b>${d.sub ? `<small>${esc(d.sub)}</small>` : ''}</span>${d.eq ? `<span class="chip snd-eqchip" title="${esc($t('Своя настройка эквалайзера для этого устройства'))}">EQ</span>` : ''}</button>`;
  const mode = L.current && L.current.mode !== 'shared' && L.current.mode !== 'null' ? `<small>${esc(modeLabel(L.current.mode))}</small>` : '';
  return `<div class="snd-sec">${$t('Вывод')}${mode}</div>
    <div class="snd-outs">${L.mine.map(row).join('')}</div>
    ${L.others.length ? `<details class="snd-more"><summary class="mi"><span class="chk"></span><span>${$t('Другие способы вывода')}</span></summary>${L.others.map((g) => `<div class="snd-sub">${esc(g.label)}</div>${g.list.map(row).join('')}`).join('')}</details>` : ''}`;
}
export function wireSection(body, L, after) {
  const more = body.querySelector('.snd-more');
  if (more) more.addEventListener('toggle', () => body.dispatchEvent(new Event('grow', { bubbles: true })));
  body.querySelectorAll('.snd-out').forEach((b) => {
    b.onclick = async () => {
      const d = L.list.find((x) => x.id === b.dataset.dev);
      if (!d || d.isCurrent) return;
      b.classList.add('busy');
      if (await choose(d, { quiet: true })) after && after();
      b.classList.remove('busy');
    };
  });
}
