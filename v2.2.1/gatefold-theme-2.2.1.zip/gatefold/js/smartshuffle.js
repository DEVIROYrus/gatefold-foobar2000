/*
 * Gatefold · smartshuffle.js — shuffle played by Gatefold rather than by foobar2000.
 *
 * foobar2000's own «shuffle» picks the next track when the time comes and tells no one: «Up next» could only say
 * «something random». Here the order is worked out beforehand (shufflealgo.js: artists spread, what you heard
 * lately later, a smooth flow of sound) and foobar2000 is told one track ahead: its playback order is «Default»,
 * and the next track of the shuffle waits at the end of its queue — as an item of the playlist, so the playing row
 * is marked and gapless playback works as always. So «Up next» shows the real next tracks, «previous» goes back
 * through what was played, and whatever you queue yourself plays first, before the shuffle goes on.
 *
 *  · You pick a track in the playlist: the shuffle goes on from it (it is taken out of what is still to come).
 *  · Another playlist starts playing: a new order for it.
 *  · The playlist changes (tracks added or removed): the rest of the order is mended — new tracks spread into
 *    what is still to come, removed ones dropped.
 *  · All played: a new round, which does not begin with what ended the last one.
 * State survives a restart (the order, where it is, what was played): whether it is on, in localStorage (read at
 * start); the order itself, which for a big playlist is megabytes, in IndexedDB, written when the page is idle —
 * never on every track (a 50 000-track order written to localStorage froze the page and filled its quota).
 * Every step is linear: a playlist of the whole library mends in milliseconds.
 */
import { call, on, ok, log } from './bridge.js';
import { smartOrder, rng } from './shufflealgo.js';
import * as IDB from './idb.js';

const KEY = 'gatefold.smartShuffle.v1', BIG = 'smartShuffle.order.v2';
const FIELDS = ['title', 'artist', 'album', 'albumArtist', 'duration', 'absolutePath', 'path', 'subsong'];
export const keyOf = (t) => { const p = String((t && (t.absolutePath || t.path)) || '').toLowerCase(); return p ? p + (t.subsong ? '|' + t.subsong : '') : ''; };

const S = { on: false, guid: '', order: [], pos: -1, hist: [], meta: new Map(), total: 0, ours: '', busy: null, back: 0 };
export const events = new EventTarget();
const changed = () => events.dispatchEvent(new Event('change'));
export const isOn = () => S.on;

let bigT = 0;
function save() {
  if (S.hist.length > 600) S.hist = S.hist.slice(-300);
  try { localStorage.setItem(KEY, JSON.stringify({ on: S.on, guid: S.guid, ours: S.ours, v: 2 })); } catch { /* blocked */ }
  // the order with where it is, together (a restart finds them matching), when the page has a moment
  clearTimeout(bigT);
  bigT = setTimeout(() => {
    const go = () => IDB.kvSet(BIG, S.on ? { guid: S.guid, order: S.order, pos: S.pos, hist: S.hist.slice(-300), total: S.total } : null).catch(() => {});
    if (window.requestIdleCallback) requestIdleCallback(go, { timeout: 5000 }); else go();
  }, 1500);
}
async function load() {
  let o = null;
  try { o = JSON.parse(localStorage.getItem(KEY) || 'null'); } catch { /* none */ }
  if (!o || !o.on) return;
  let big = o.order ? o : await IDB.kvGet(BIG, null).catch(() => null);   // before 2.2.1 the order lay in localStorage
  if (big && big.guid !== o.guid) big = null;
  Object.assign(S, { on: true, guid: o.guid || '', ours: o.ours || '', order: (big && big.order) || [], pos: big ? big.pos ?? -1 : -1, hist: (big && big.hist) || [], total: (big && big.total) || 0 });
  if (o.order) save();   // moved out of localStorage: megabytes there slowed every other setting and filled it
}

/** every track of a playlist, with what the order needs */
async function tracksOf(guid) {
  const out = [];
  for (let start = 0; start < 200000; start += 2000) {
    const r = await call('playlist.getTracks', { playlist: guid, start, count: 2000, fields: FIELDS });
    if (!ok(r)) break;
    const got = r.tracks || [];
    out.push(...got);
    if (got.length < 2000 || out.length >= (r.total ?? r.totalCount ?? Infinity)) break;
  }
  return out;
}
/** what Gatefold knows to make the order better: when each track was last heard, the liked ones, their sound */
async function hints() {
  const heardAt = new Map(), liked = new Map();
  try { const H = await import('./history.js'); for (const e of await H.all()) { const k = keyOf({ path: e.p || e.h }); if (k) heardAt.set(k, e.ts); } } catch { /* no history */ }
  try { const L = await import('./likes.js'); for (const t of S.meta.values()) if (L.has(t)) liked.set(t.key, true); } catch { /* no likes */ }
  let sound = null, dist = null;
  try {
    const Sd = await import('./ml/sound.js');
    if (Sd.ready && Sd.ready()) {
      const memo = new Map();
      sound = (k) => { if (memo.has(k)) return memo.get(k); const t = S.meta.get(k); const r = t && Sd.get(t); const v = r ? { r, T: Sd.target(r) } : null; memo.set(k, v); return v; };
      dist = (a, b) => Sd.distance(a.T, b.r);
    }
  } catch { /* no sound analysis */ }
  return { heardAt, liked, sound, dist };
}

async function build(guid, firstKey, avoidFirst = []) {
  const tracks = await tracksOf(guid);
  S.meta = new Map();
  for (const t of tracks) { const k = keyOf(t); if (k && !S.meta.has(k)) S.meta.set(k, { ...t, key: k }); }
  const h = await hints();
  S.guid = guid; S.total = tracks.length;
  S.order = smartOrder([...S.meta.values()], { first: firstKey, avoidFirst, ...h, rnd: rng() });
  S.pos = firstKey && S.order[0] === firstKey ? 0 : -1;
}

async function playingPlace() {
  const ci = await call('playback.getCurrentTrackIndex');
  if (ok(ci) && ci.found !== false) return { guid: ci.playlistGuid || '', index: ci.index };
  return null;
}
async function activeGuid() {
  const p = await call('playlist.getPlaying');
  if (ok(p) && p.found !== false && p.guid) return p.guid;
  const a = await call('playlist.getActive');
  return ok(a) && a.found !== false ? a.guid || '' : '';
}

/** the playing order of the playlist, from the playing track; foobar2000 to «Default» (the shuffle is ours) */
export async function enable(current) {
  S.on = true;
  await call('playback.setPlaybackOrder', { order: 0 });
  const place = await playingPlace();
  const guid = (place && place.guid) || (await activeGuid());
  if (!guid) { save(); changed(); return; }
  await build(guid, current ? keyOf(current) : '');
  S.hist = current ? [keyOf(current)] : [];
  save(); changed();
  await keepNext();
}
export async function disable() {
  if (!S.on) return;
  S.on = false;
  await dropOurs();
  S.order = []; S.pos = -1; S.meta = new Map();
  save(); changed();
}

/* ---------------------------------------------------------------- one track ahead, at the end of the queue */
async function queueNow() { const q = await call('queue.get', {}); return ok(q) ? q.items || q.tracks || [] : []; }
const ourItem = (items) => items.findIndex((it) => S.ours && keyOf(it) === S.ours && (it.playlistGuid || '') === S.guid);
async function dropOurs() {
  if (!S.ours) return;
  const items = await queueNow(), i = ourItem(items);
  if (i >= 0) await call('queue.remove', { index: i });
  S.ours = '';
}
/** the queued item Gatefold put there (the queue view marks it; «Up next» does not list it twice) */
export const isOurs = (it) => S.on && !!S.ours && keyOf(it) === S.ours && (!it.playlistGuid || it.playlistGuid === S.guid);

async function keepNext() {
  if (!S.on || !S.guid) return;
  if (S.busy) return S.busy;
  S.busy = (async () => {
    // a whole round played: the next one (not opening with how this one ended)
    if (S.pos >= S.order.length - 1 && S.order.length) {
      const tail = S.order.slice(-Math.max(3, Math.ceil(S.order.length * 0.15)));
      const cur = S.order[S.pos];
      await build(S.guid, '', tail);
      S.order = S.order.filter((k) => k !== cur);
      S.pos = -1;
    }
    const want = S.order[S.pos + 1];
    const t = want && S.meta.get(want);
    const items = await queueNow();
    const i = ourItem(items);
    // already there, last in the queue: nothing to do. Yours queued after it: it goes back to the end
    if (i >= 0 && S.ours === want && i === items.length - 1) return;
    if (i >= 0) await call('queue.remove', { index: i });
    S.ours = '';
    if (t && t.index != null) {
      const r = await call('queue.add', { playlist: S.guid, tracks: [t.index] });
      if (ok(r)) S.ours = want;
    }
    save(); changed();
  })().catch((e) => log('smart shuffle', e && e.message)).finally(() => { S.busy = null; });
  return S.busy;
}

/* playlists the shuffle leaves alone (Radio: its order is the point of it) */
let skip = () => false;
export const setSkip = (fn) => { skip = fn || (() => false); };

/** shuffle a playlist from the start of a new order (the «shuffle» button of a playlist or album) */
export async function start(guid) {
  S.on = true;
  await call('playback.setPlaybackOrder', { order: 0 });
  await build(guid, '');
  S.hist = []; S.ours = '';
  const first = S.meta.get(S.order[0]);
  save(); changed();
  if (first && first.index != null) await call('playlist.playTrack', { playlist: guid, index: first.index });
}

/** a new track plays: where are we in the order */
export async function onTrack(track) {
  if (!S.on || !track) return;
  const k = keyOf(track);
  const place = await playingPlace();
  if (place && skip(place.guid)) { await dropOurs(); return; }
  // another playlist plays now: its own order, from this track
  if (place && place.guid && place.guid !== S.guid) { await build(place.guid, k); S.hist = [k]; S.ours = ''; save(); changed(); return keepNext(); }
  if (S.back) { S.back--; }
  else if (S.order[S.pos + 1] === k) { S.pos++; S.hist.push(k); }
  else if (S.order[S.pos] === k) { /* the same one again (restarted, tags edited) */ }
  else {
    // picked by hand (or foobar2000 went its own way): the shuffle goes on from it
    const i = S.order.indexOf(k);
    if (i > S.pos) { S.order.splice(i, 1); S.order.splice(S.pos + 1, 0, k); S.pos++; }
    else if (i >= 0) { S.order.splice(i, 1); S.order.splice(S.pos + 1, 0, k); S.pos++; }
    else if (place && place.guid === S.guid) { await mend(); const j = S.order.indexOf(k); if (j >= 0) { S.order.splice(j, 1); S.order.splice(S.pos + 1, 0, k); S.pos++; } }
    S.hist.push(k);
  }
  if (S.ours === k) S.ours = '';
  save(); changed();
  return keepNext();
}

/** the playlist changed: new tracks spread into what is to come, removed ones dropped, indexes refreshed */
async function mend() {
  if (!S.guid) return;
  const tracks = await tracksOf(S.guid);
  const meta = new Map();
  for (const t of tracks) { const k = keyOf(t); if (k && !meta.has(k)) meta.set(k, { ...t, key: k }); }
  const played = S.order.slice(0, S.pos + 1).filter((k) => meta.has(k));
  const rest = S.order.slice(S.pos + 1).filter((k) => meta.has(k));
  const known = new Set(S.order);                    // not order.includes per track: 50 000² comparisons froze the page
  const added = [...meta.keys()].filter((k) => !known.has(k));
  S.meta = meta; S.total = tracks.length;
  if (added.length > Math.max(20, rest.length / 4)) {
    // many new ones: a new order of all that is still to come
    const h = await hints();
    const fresh = smartOrder([...rest, ...added].map((k) => meta.get(k)), { ...h, rnd: rng() });
    S.order = [...played, ...fresh];
  } else if (added.length) {
    // a few: each at a random place of what is to come — «Up next» stays as it was, and nothing is reordered
    const r = rng(), out = rest.slice();
    for (const k of added) out.splice(Math.floor(r() * (out.length + 1)), 0, k);
    S.order = [...played, ...out];
  } else S.order = [...played, ...rest];
  S.pos = played.length - 1;
  save(); changed();
}
let mendT = 0;
export function playlistChanged(guid) {
  if (!S.on || (guid && guid !== S.guid)) return;
  clearTimeout(mendT);
  mendT = setTimeout(() => mend().then(() => keepNext()), 600);
}

/** «previous» in a shuffle: the track played before this one (true when handled) */
export async function previous() {
  if (!S.on || S.pos <= 0) return false;
  const k = S.order[S.pos - 1], t = S.meta.get(k);
  if (!t || t.index == null) return false;
  S.pos -= 1; S.back++;
  await call('playlist.playTrack', { playlist: S.guid, index: t.index });
  save(); changed();
  keepNext();
  return true;
}

/** what comes next: the order's next tracks (after whatever you queued yourself) */
export function upcoming(n = 15) {
  if (!S.on) return [];
  const out = [];
  for (let i = S.pos + 1; i < S.order.length && out.length < n; i++) { const t = S.meta.get(S.order[i]); if (t) out.push({ t, playlist: S.guid, index: t.index, shuffle: true }); }
  return out;
}
export const info = () => ({ on: S.on, total: S.order.length, played: S.pos + 1, guid: S.guid });

/** start: the state of the last session, if the shuffle was on and foobar2000 still plays «Default» */
export async function init({ order }) {
  await load();
  if (!S.on) return;
  if (order !== 0) { S.on = false; save(); return; }
  if (S.guid) {
    try { await mend(); } catch { /* the playlist is gone */ }
    if (!S.meta.size) { S.on = false; save(); return; }
  }
  changed();
  keepNext();
}
on('playback:queueChanged', () => { if (S.on && !S.busy) { clearTimeout(qT); qT = setTimeout(() => keepNext(), 250); } });
let qT = 0;
