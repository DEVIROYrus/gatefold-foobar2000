/*
 * Gatefold · autotag/engine.js — which MusicBrainz release an album of yours is, and the tags it would get.
 *
 *  1. what your files say now (every field autotagging may write, read from the files themselves);
 *  2. the candidates: the release id already in your tags; MusicBrainz searches (title + artist, the title
 *     without edition notes, the title + the number of tracks); AcoustID — the sound of your tracks
 *     (a few tracks to confirm a good text match, every track when the text does not find the album);
 *  3. each candidate read in full and weighed (score.js): the track list one to one, title, artist,
 *     counts, lengths, year, the fingerprints;
 *  4. the best one, how sure (against the best *other album*, not another edition of the same one),
 *     and for each track the fields it would get.
 */
import * as IDB from '../idb.js';
import { call, ok } from '../bridge.js';
import { settings } from '../settings.js';
import * as Net from './net.js';
import * as S from './score.js';
import { decode } from '../vibe.js';

/* ---------------------------------------------------------------- the fields */
export const GROUPS = [
  ['main', ['TITLE', 'ARTIST', 'ALBUM', 'ALBUMARTIST', 'DATE', 'TRACKNUMBER', 'TOTALTRACKS', 'DISCNUMBER', 'TOTALDISCS', 'DISCSUBTITLE']],
  ['release', ['ORIGINALDATE', 'LABEL', 'CATALOGNUMBER', 'BARCODE', 'RELEASECOUNTRY', 'RELEASETYPE', 'RELEASESTATUS', 'MEDIA']],
  ['sort', ['ARTISTS', 'ARTISTSORT', 'ALBUMARTISTSORT']],
  ['isrc', ['ISRC']],
  ['genre', ['GENRE']],
  ['ids', ['MUSICBRAINZ_ALBUMID', 'MUSICBRAINZ_RELEASEGROUPID', 'MUSICBRAINZ_ALBUMARTISTID', 'MUSICBRAINZ_ARTISTID', 'MUSICBRAINZ_TRACKID', 'MUSICBRAINZ_RELEASETRACKID', 'ACOUSTID_ID']],
  // what only spoils tags: who ripped or uploaded it, sites, players' leftovers — taken out (cleanup() below)
  ['clean', ['COMMENT', 'DESCRIPTION', 'URL', 'WWW', 'WEBSITE', 'ENCODED BY', 'ENCODEDBY', 'ENCODED_BY', 'RIPPER', 'RIPPED BY', 'UPLOADER', 'UPLOADED BY', 'TRACKER',
    'ITUNNORM', 'ITUNES_CDDB_1', 'ITUNES_CDDB_IDS', 'LOG']],
];
export const FIELDS = GROUPS.flatMap(([, f]) => f);
export const groupOf = (f) => (GROUPS.find(([, l]) => l.includes(f)) || ['main'])[0];
const SEP = '\u0001';

/* ---------------------------------------------------------------- your album, as the files have it */
const handleOf = (t) => t.handle || t.absolutePath || t.path;
const refOf = (hd) => { const m = /^(.*)\|subsong:(\d+)$/.exec(hd); return m ? { path: m[1], subsong: +m[2] } : { path: hd }; };
export { refOf, handleOf };
const mode = (arr) => { const c = new Map(); let best = '', n = 0; for (const v of arr) { if (!v) continue; const k = (c.get(v) || 0) + 1; c.set(v, k); if (k > n) { n = k; best = v; } } return best; };

/** tracks (Lib.albumTracks) → the album as matching and the diff need it */
export async function readAlbum(tracks, info = {}) {
  const handles = tracks.map(handleOf);
  const fields = Object.fromEntries(FIELDS.map((f, i) => ['f' + i, `[$meta_sep(${f},'${SEP}')]`]));
  fields.len = '%length_seconds_fp%';
  const rows = [];
  for (let i = 0; i < handles.length; i += 500) {
    const r = await call('titleformat.evalFieldsBatch', { paths: handles.slice(i, i + 500), fields });
    rows.push(...(ok(r) ? r.results || [] : []));
  }
  const list = tracks.map((t, i) => {
    const row = rows[i] || {};
    const old = {}; FIELDS.forEach((f, k) => { const v = String(row['f' + k] || ''); old[f] = v ? v.split(SEP) : []; });
    const g = (f) => old[f][0] || '';
    return { handle: handles[i], track: t, old, title: g('TITLE') || t.title || '', artist: g('ARTIST') || t.artist || '',
      length: +row.len || +t.duration || +t.length || 0, no: S.num(g('TRACKNUMBER') || t.trackNumber), disc: S.num(g('DISCNUMBER') || t.discNumber) || 1 };
  });
  const first = list[0]?.old || {};
  const pick = (f) => mode(list.map((t) => t.old[f][0] || ''));
  return {
    title: pick('ALBUM') || info.name || '', artist: pick('ALBUMARTIST') || info.albumArtist || '', trackArtist: pick('ARTIST'),
    year: pick('DATE') || '', barcode: pick('BARCODE'), catalog: pick('CATALOGNUMBER'), mbid: pick('MUSICBRAINZ_ALBUMID'),
    tracks: list, firstOld: first,
  };
}

/* ---------------------------------------------------------------- fingerprints */
const fpWorker = (() => {
  let w = null, seq = 0; const wait = new Map();
  return (pcm) => {
    if (!w) {
      w = new Worker(new URL('./fp-worker.js', import.meta.url), { type: 'module' });
      w.onmessage = (e) => { const p = wait.get(e.data.id); if (p) { wait.delete(e.data.id); p(e.data); } };
    }
    const id = ++seq;
    return new Promise((res) => { wait.set(id, res); w.postMessage({ id, pcm }, [pcm.buffer]); });
  };
})();
/** the AcoustID fingerprint of a track (its first two minutes) → { fp, duration } or null */
export async function fingerprintTrack(t) {
  // kept by track and length: decoding two minutes of every track again on each check of the library was most of
  // its time (the fingerprint of the same file does not change)
  const key = 'at.fp.' + String(t.handle || '').toLowerCase() + '|' + Math.round(t.length || 0);
  try { const c = await IDB.kvGet(key); if (c && c.fp) return c; } catch { /* none */ }
  const r = await fingerprintNow(t);
  if (r) IDB.kvSet(key, r).catch(() => {});
  return r;
}
async function fingerprintNow(t) {
  const len = t.length || 0;
  const pcm = await decode(t.handle, 0, Math.min(120, len || 120), 11025);
  if (!pcm || pcm.length < 11025 * 10) return null;
  const s16 = new Int16Array(pcm.length);
  for (let i = 0; i < pcm.length; i++) { const v = Math.round(pcm[i] * 32767); s16[i] = v > 32767 ? 32767 : v < -32768 ? -32768 : v; }
  const r = await fpWorker(s16);
  return r && r.fp ? { fp: r.fp, duration: len || pcm.length / 11025 } : null;
}

/* ---------------------------------------------------------------- matching */
const quick = (album, r) => {            // a search result, weighed before it is read in full
  const n = album.tracks.length, m = r['track-count'] || (r.media || []).reduce((s, x) => s + (x['track-count'] || 0), 0);
  return S.sim(S.bare(album.title), S.bare(r.title)) * 0.45 + S.sim(album.artist || album.trackArtist, S.creditName(r['artist-credit'])) * 0.3
    + (m ? (n === m ? 1 : Math.max(0, 1 - Math.abs(n - m) / Math.max(n, m))) : 0.5) * 0.2 + (r.score || 0) / 100 * 0.05;
};

/**
 * album (readAlbum) → { candidates: [{ release, score, map, parts, rt }], best, verdict, margin, notes }
 * opts.onStep(text) tells what it is doing; opts.sound: 'auto' | 'always' | 'never'
 */
export async function match(album, opts = {}) {
  const step = opts.onStep || (() => {});
  const signal = opts.signal;
  const ids = new Map();                     // release id → why it is a candidate
  const add = (id, why) => { if (id && !ids.has(id)) ids.set(id, why); };
  if (album.mbid) add(album.mbid, 'tags');
  const n = album.tracks.length;
  const artist = album.artist || album.trackArtist;
  // MusicBrainz searches
  step('search');
  const found = new Map();
  const searches = [];
  if (album.title && artist) searches.push(`release:${Net.q(S.bare(album.title) || album.title)} AND artist:${Net.q(artist)}`);
  if (album.title) searches.push(`release:${Net.q(S.bare(album.title) || album.title)} AND tracks:${n}`);
  if (album.title && artist && S.bare(album.title) !== album.title) searches.push(`release:${Net.q(album.title)} AND artist:${Net.q(artist)}`);
  for (const qy of searches) {
    let res = null;
    try { res = await Net.searchReleases(qy, 15, { signal }); } catch (e) { if (e.code === 'ABORT') throw e; }
    for (const r of res?.releases || []) if (!found.has(r.id)) found.set(r.id, r);
    if ([...found.values()].some((r) => quick(album, r) > 0.9)) break;    // a clear hit: no need to look further
  }
  [...found.values()].sort((a, b) => quick(album, b) - quick(album, a)).slice(0, 6).forEach((r) => add(r.id, 'search'));

  // read and weigh
  const scored = new Map();
  const weigh = async (fpRec) => {
    for (const [id, why] of ids) {
      if (scored.has(id) && !fpRec) continue;
      step('read');
      let rel = scored.get(id)?.release;
      if (!rel) { try { rel = await Net.release(id, { signal }); } catch (e) { if (e.code === 'ABORT') throw e; continue; } }
      if (!rel) continue;
      scored.set(id, { release: rel, why, ...S.scoreRelease(album, rel, { fpRecordings: fpRec }) });
    }
  };
  await weigh(null);
  const bestNow = () => Math.max(0, ...[...scored.values()].map((c) => c.score));

  // the sound: always when asked, when the text found nothing good, a little to confirm a good match
  const sound = opts.sound || settings.autotagSound || 'auto';
  let heard = false;
  if (sound !== 'never') {
    const weak = bestNow() < 0.88;
    const which = sound === 'always' || weak ? album.tracks.slice(0, 40) : [album.tracks[0], album.tracks[Math.floor(n / 2)]].filter((t, i, a) => t && a.indexOf(t) === i);
    const votes = new Map();
    let keyBad = false;
    for (const t of which) {
      if (signal?.aborted) throw new Net.NetError('stopped', 'ABORT');
      step('listen');
      const f = await fingerprintTrack(t).catch(() => null);
      if (!f) continue;
      let res;
      try { res = await Net.acoustid(f.fp, f.duration, { signal }); } catch (e) { if (e.code === 'ABORT') throw e; if (e.code === 'KEY') { keyBad = true; break; } continue; }
      const best = res.filter((x) => x.score >= 0.5).sort((a, b) => b.score - a.score)[0];
      if (!best) continue;
      t.acoustid = best.id;
      t.recordings = new Set(best.recordings.map((r) => r.id));
      for (const rec of best.recordings) for (const rl of rec.releases) votes.set(rl, (votes.get(rl) || 0) + 1);
      heard = true;
    }
    if (heard) {
      // the releases most of your tracks are on (only when the text found little: the votes find the album)
      if (weak) [...votes.entries()].sort((a, b) => b[1] - a[1]).slice(0, 6).forEach(([id]) => add(id, 'sound'));
      await weigh(true);
    }
    if (keyBad) step('nokey');
  }

  const candidates = [...scored.values()].sort((a, b) => b.score - a.score);
  const best = candidates[0] || null;
  // how sure: against the best candidate that is another album (another release group)
  const rg = (c) => c.release['release-group']?.id || c.release.id;
  const other = best ? candidates.find((c) => rg(c) !== rg(best)) : null;
  const margin = best ? best.score - (other ? other.score : 0) : 0;
  return { candidates, best, margin, verdict: best ? S.verdict(best.score, margin) : 'none', heard };
}

/* ---------------------------------------------------------------- the tags a release gives */
const titleCase = (s) => s.replace(/(^|[\s\-/(])(\p{L})/gu, (m, a, b) => a + b.toUpperCase());
const yearOf = (d) => (/^(\d{4})/.exec(d || '') || [])[1] || '';

/** genres of the release (and its group), MusicBrainz users' votes: the strongest few */
export async function genresOf(rel, opts = {}) {
  let list = (rel.genres || []).slice();
  if (rel['release-group']?.id) {
    try { const g = await Net.releaseGroup(rel['release-group'].id, opts); list = list.concat(g?.genres || []); } catch {}
  }
  const by = new Map(); for (const g of list) by.set(g.name, (by.get(g.name) || 0) + (g.count || 1));
  const top = [...by.entries()].sort((a, b) => b[1] - a[1]);
  const max = top[0]?.[1] || 0;
  return top.filter(([, c]) => c >= Math.max(1, max * 0.34)).slice(0, 4).map(([n]) => titleCase(n));
}

/**
 * the new values, field by field, for each of your tracks matched to the release
 * → [{ i (your track), set: { FIELD: [values] } }]  (tracks the release does not have get nothing)
 */
export function proposals(album, cand, { genres = [], dateMode = settings.autotagDate || 'original' } = {}) {
  const rel = cand.release, rt = cand.rt;
  const rg = rel['release-group'] || {};
  const labels = (rel['label-info'] || []).filter((l) => l.label);
  const ac = rel['artist-credit'] || [];
  const albumArtist = S.creditName(ac);
  const types = [rg['primary-type'], ...(rg['secondary-types'] || [])].filter(Boolean).map((x) => x.toLowerCase());
  const orig = rg['first-release-date'] || rel.date || '';
  const albumSet = {
    ALBUM: [rel.title], ALBUMARTIST: [albumArtist],
    DATE: [dateMode === 'release' ? (rel.date || orig) : dateMode === 'year' ? yearOf(rel.date || orig) : (yearOf(orig) || yearOf(rel.date))].filter(Boolean),
    ORIGINALDATE: orig ? [orig] : [],
    LABEL: [...new Set(labels.map((l) => l.label.name))], CATALOGNUMBER: [...new Set(labels.map((l) => l['catalog-number']).filter(Boolean))],
    BARCODE: rel.barcode ? [rel.barcode] : [], RELEASECOUNTRY: rel.country ? [rel.country] : [], RELEASETYPE: types, RELEASESTATUS: rel.status ? [rel.status.toLowerCase()] : [],
    TOTALDISCS: [String((rel.media || []).length || 1)],
    ALBUMARTISTSORT: [ac.map((c) => (c.artist?.['sort-name'] || c.name || '') + (c.joinphrase || '')).join('')].filter(Boolean),
    MUSICBRAINZ_ALBUMID: [rel.id], MUSICBRAINZ_RELEASEGROUPID: rg.id ? [rg.id] : [], MUSICBRAINZ_ALBUMARTISTID: ac.map((c) => c.artist?.id).filter(Boolean),
    GENRE: genres,
  };
  const out = [];
  cand.map.forEach((j, i) => {
    if (j < 0) return;
    const t = rt[j];
    const set = {
      ...albumSet,
      TITLE: [t.title], ARTIST: [t.artist || albumArtist],
      ARTISTS: (t.credit.length ? t.credit : ac).map((c) => c.artist?.name || c.name).filter(Boolean),
      ARTISTSORT: [(t.credit.length ? t.credit : ac).map((c) => (c.artist?.['sort-name'] || c.name || '') + (c.joinphrase || '')).join('')].filter(Boolean),
      TRACKNUMBER: [String(t.no)], TOTALTRACKS: [String(t.tracksOnDisc)], DISCNUMBER: [String(t.disc)], DISCSUBTITLE: t.discTitle ? [t.discTitle] : [],
      MEDIA: t.format ? [t.format] : [],
      ISRC: t.isrcs || [],
      MUSICBRAINZ_ARTISTID: (t.credit.length ? t.credit : ac).map((c) => c.artist?.id).filter(Boolean),
      MUSICBRAINZ_TRACKID: t.recording ? [t.recording] : [], MUSICBRAINZ_RELEASETRACKID: t.id ? [t.id] : [],
      ACOUSTID_ID: album.tracks[i].acoustid ? [album.tracks[i].acoustid] : [],
    };
    out.push({ i, j, set });
  });
  return out;
}

/* ---------------------------------------------------------------- the clean-up
   Leftovers of where the files came from, not facts about the music: a catalogue number or the format in the
   album's name («Appetite For Destruction (MVCG-12)», «… [FLAC 24-96]»), store notes on titles («Innocent Exile -
   2015 Remaster», «(Deluxe Edition)», «[Explicit]»), the disc in the album's name («… CD1»: DISCNUMBER says it),
   comments with sites and rippers' names, players' bookkeeping (iTunNORM …). A release found on MusicBrainz
   brings its own names anyway; this also works when none is found. Every removal is shown, as any change. */
const ALWAYS_JUNK = new Set(['URL', 'WWW', 'WEBSITE', 'ENCODED BY', 'ENCODEDBY', 'ENCODED_BY', 'RIPPER', 'RIPPED BY', 'UPLOADER', 'UPLOADED BY', 'TRACKER', 'ITUNNORM', 'ITUNES_CDDB_1', 'ITUNES_CDDB_IDS', 'LOG']);
/**
 * The clean-up for one of your tracks: [{ f, from, to, clean: true }] — fields to take out (to: []), names without
 * their leftovers. `skip`: fields a release's own proposal already changes (those win).
 */
export function cleanup(album, i, skip = new Set()) {
  const tr = album.tracks[i], old = tr.old, out = [];
  for (const f of GROUPS.find(([g]) => g === 'clean')[1]) {
    const ov = old[f] || []; if (!ov.length || skip.has(f)) continue;
    if (ALWAYS_JUNK.has(f) || ov.every((v) => S.junkText(v, album))) out.push({ f, from: ov, to: [], clean: true });
    else if (ov.some((v) => S.junkText(v, album))) out.push({ f, from: ov, to: ov.filter((v) => !S.junkText(v, album)), clean: true });
  }
  for (const f of ['ALBUM', 'TITLE', 'DISCSUBTITLE']) {
    const ov = old[f] || []; if (ov.length !== 1 || skip.has(f)) continue;
    const c = S.cleanName(ov[0]);
    if (c.text !== ov[0].trim()) {
      out.push({ f, from: ov, to: [c.text], clean: true });
      // «Album CD2» → DISCNUMBER 2, where the files have none and nothing else proposes one
      if (f === 'ALBUM' && c.disc && !(old.DISCNUMBER || []).length && !skip.has('DISCNUMBER')) out.push({ f: 'DISCNUMBER', from: [], to: [String(c.disc)], clean: true });
    }
  }
  return out;
}
/** clean-up only (no release found): one row per track that has something to clean */
export function cleanupOnly(album) {
  return album.tracks.map((_, i) => ({ i, j: -1, changes: cleanup(album, i), flag: '' })).filter((r) => r.changes.length);
}

const script = (s) => (/[\u3040-\u30ff\u3400-\u9fff\uac00-\ud7af]/.test(s) ? 'cjk' : /[\u0400-\u04ff]/.test(s) ? 'cyr' : /[\u0590-\u06ff]/.test(s) ? 'rtl' : /[a-z]/i.test(s) ? 'lat' : '');
const NAMES = new Set(['TITLE', 'ARTIST', 'ALBUM', 'ALBUMARTIST', 'DISCSUBTITLE', 'ARTISTS']);

/**
 * what would change: per track and field, old → new (equal values and empty proposals left out).
 * A change is proposed «off» (shown, not ticked) when it would write a name in another script than yours
 * («Good Morning Boy» → «早安男孩»): your choice, not a correction. A track is marked when its sound says it is
 * another song than its title says (AcoustID) or when nothing but its place pairs it (no title, no length).
 */
export function diff(album, props, { fields = FIELDS, keepFilled = [], cand = null } = {}) {
  const same = (a, b) => a.length === b.length && a.every((v, k) => String(v).trim() === String(b[k]).trim());
  return props.map((p) => {
    const tr = album.tracks[p.i], old = tr.old;
    const changes = [];
    for (const f of fields) {
      const nv = p.set[f]; if (!nv || !nv.length) continue;           // the release has nothing for it: left as it is
      const ov = old[f] || [];
      if (same(ov, nv)) continue;
      if (keepFilled.includes(f) && ov.length) continue;                // only filled in where empty
      const off = NAMES.has(f) && ov.length && script(ov.join(' ')) && script(nv.join(' ')) && script(ov.join(' ')) !== script(nv.join(' '));
      changes.push({ f, from: ov, to: nv, off: !!off });
    }
    let flag = '';
    const rt = cand && cand.rt ? cand.rt[p.j] : null;
    if (rt) {
      const ts = S.sim(tr.title, rt.title);
      if (tr.recordings && tr.recordings.has(rt.recording) && tr.title && ts < 0.5) flag = 'sound';           // the sound says: this song
      else if (!(tr.recordings && tr.recordings.has(rt.recording)) && tr.title && ts < 0.5 && S.lengthSim(tr.length, rt.length) < 0.6) flag = 'unsure';
    }
    return { i: p.i, j: p.j, changes, flag };
  });
}
