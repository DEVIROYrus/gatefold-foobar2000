/*
 * Gatefold · smartsearch.js — search that forgives, over the library only (in memory, instant, offline).
 *
 * What is typed is compared with every artist, album and track title in several ways at once, and the best
 * reading wins:
 *   as typed        exact, start of the name, start of each word («dark si» → The Dark Side of the Moon),
 *                   inside the name, words in any order;
 *   transliterated  Cyrillic and Latin meet in the middle («кино» ↔ Kino, «metallica» ↔ «металлика»);
 *   wrong layout    «ьуефддшсф» is «metallica» typed with the Russian layout on (and the other way round);
 *   initials        «rhcp» → Red Hot Chili Peppers, «бг» → Борис Гребенщиков;
 *   typos           each word within one to three edits, swapped letters count as one («metalica», «nirvanna»);
 *                   a word still being typed matches the start of a longer one with a typo in it.
 * Results are ranked by how good the match is, then by how much of the library the artist or album fills.
 * When the best results needed a correction, `suggestion` says what was probably meant.
 */
import * as TS from './trackstore.js';
import { norm } from './match.js';
// library.js and artists.js import this module themselves, so they are reached lazily (no import cycle at start)

// ---------------------------------------------------------------- the keyboard layouts
const RU = 'йцукенгшщзхъфывапролджэячсмитьбюё', EN = "qwertyuiop[]asdfghjkl;'zxcvbnm,.`";
const toEn = {}, toRu = {};
for (let i = 0; i < RU.length; i++) { toEn[RU[i]] = EN[i]; toRu[EN[i]] = RU[i]; }
/** the same keys pressed with the other layout on («ьуефддшсф» ↔ «metallica»); null when nothing changes */
export function swapLayout(s) {
  const t = String(s || '').toLowerCase();
  const cyr = (t.match(/[а-яё]/g) || []).length, lat = (t.match(/[a-z]/g) || []).length;
  if (!cyr && !lat) return null;
  const map = cyr >= lat ? toEn : toRu;
  const out = [...t].map((c) => map[c] ?? c).join('');
  return out === t ? null : out;
}

// ---------------------------------------------------------------- distance
/** optimal string alignment distance (a swap of neighbours is one edit), giving up beyond `max` */
export function editDistance(a, b, max = 3) {
  const la = a.length, lb = b.length;
  if (Math.abs(la - lb) > max) return max + 1;
  if (!la) return lb; if (!lb) return la;
  let p2 = new Array(lb + 1), p1 = new Array(lb + 1), cur = new Array(lb + 1);
  for (let j = 0; j <= lb; j++) p1[j] = j;
  for (let i = 1; i <= la; i++) {
    cur[0] = i; let best = i;
    for (let j = 1; j <= lb; j++) {
      const cost = a[i - 1] === b[j - 1] ? 0 : 1;
      let v = Math.min(p1[j] + 1, cur[j - 1] + 1, p1[j - 1] + cost);
      if (i > 1 && j > 1 && a[i - 1] === b[j - 2] && a[i - 2] === b[j - 1]) v = Math.min(v, p2[j - 2] + 1);
      cur[j] = v; if (v < best) best = v;
    }
    if (best > max) return max + 1;
    [p2, p1, cur] = [p1, cur, p2];
  }
  return p1[lb];
}
const allowed = (n) => (n <= 4 ? 0 : n <= 6 ? 1 : n <= 10 ? 2 : 3);   // a short word with a typo is another word («кино» is not «king»)
/* typed without some letters: what was left out may only be vowels or a doubled letter («dft pnk» → daft punk,
   «mtlc» → metallica), so «кино» does not turn into «kingdom» */
const VOW = new Set('aeiouyjhаеёиоуыэюяйьъ');   // and the letters transliteration adds or drops (j, h, й, ь)
const subseq = (t, w) => {
  let i = 0;
  for (let j = 0; j < w.length; j++) {
    if (i < t.length && w[j] === t[i]) { i++; continue; }
    if (!VOW.has(w[j]) && w[j] !== w[j - 1]) return false;
  }
  return i === t.length;
};

// ---------------------------------------------------------------- one name against one query
// the same names come back thousands of times (an artist on every track of theirs): prepared once
const prepMemo = new Map();
function prep(text) {
  const k = String(text || '');
  let r = prepMemo.get(k);
  if (!r) { r = prepNow(k); if (prepMemo.size > 60000) prepMemo.clear(); prepMemo.set(k, r); }
  return r;
}
function prepNow(text) {
  const full = norm(text);
  const words = full.split(' ').filter(Boolean);
  return { full, words, initials: words.map((w) => w[0]).join('') };
}
/** how well a prepared query matches a prepared name: 0 (not at all) … 100 (exactly); `fuzzy` when typos were forgiven */
export function score(q, c) {
  if (!q.full || !c.full) return { s: 0 };
  if (c.full === q.full) return { s: 100 };
  if (c.full.startsWith(q.full)) return { s: 92 - Math.min(10, (c.full.length - q.full.length) / 4) };
  let allPrefix = true;
  for (const t of q.words) if (!c.words.some((w) => w.startsWith(t))) { allPrefix = false; break; }
  if (allPrefix) return { s: 82 - Math.min(8, c.words.length - q.words.length) };
  if (c.full.includes(q.full)) return { s: 72 };
  const compact = q.full.replace(/ /g, '');
  if (compact.length >= 2 && c.initials.length >= 2 && c.initials.startsWith(compact)) return { s: 66 + (c.initials === compact ? 4 : 0) };
  // typos: every typed word close to some word of the name (a word being typed: close to that word's start)
  let cost = 0;
  for (let k = 0; k < q.words.length; k++) {
    const t = q.words[k], last = k === q.words.length - 1;
    let best = 9;   // the cheapest way this typed word fits some word of the name (9: none)
    const m = byWord && byWord(t, last);
    for (const w of c.words) {
      const v = m ? m.get(w) : undefined;
      best = Math.min(best, v !== undefined ? v : m && vocab.has(w) ? 9 : wordCost(t, w, last));
      if (best === 0) break;
    }
    if (best === 9) return { s: 0 };
    cost += best;
  }
  return { s: Math.max(1, 60 - cost * 9), fuzzy: cost > 0 };
}
/* What one typed word costs against one word of a name. A library has a few tens of thousands of different words
   but hundreds of thousands of titles: each pair is worked out once per search and remembered (a search over
   100 000 tracks did the same edit distances hundreds of thousands of times — Reddit: 42 s) */
let costs = new Map();
/* Faster still: during a search each typed word is priced once against every distinct word of the library (the
   vocabulary, a few tens of thousands), keeping the ones that fit; a title then costs a lookup per word — no key
   built per pair. 50 000 tracks: a five-word query 1 s → a few tens of ms */
let vocab = new Set(), byWord = null;
function pricer() {
  const memo = new Map();
  return (t, last) => {
    const k = (last ? '1' : '0') + t;
    let m = memo.get(k);
    if (!m) { m = new Map(); for (const w of vocab) { const v = wordCostNow(t, w, last); if (v < 9) m.set(w, v); } memo.set(k, m); }
    return m;
  };
}
function wordCost(t, w, last) {
  const k = (last ? '1' : '0') + t + '\u0001' + w;
  let v = costs.get(k);
  if (v === undefined) { v = wordCostNow(t, w, last); costs.set(k, v); }
  return v;
}
function wordCostNow(t, w, last) {
  const max = allowed(t.length);
  let best = 9;
  if (w.startsWith(t)) return 0;
  // typed without some letters («dft pnk», «mtlc»): the same first letter, the rest in order
  if (t.length >= 3 && w[0] === t[0] && w.length > t.length && subseq(t, w)) best = Math.min(best, Math.min(2, (w.length - t.length) * 0.5));
  // a short word forgives only two neighbours swapped («bsuh» → bush), never another letter («кино» ≠ king)
  if (!max) { if (t.length >= 3 && w.length === t.length && editDistance(t, w, 1) === 1 && [...t].sort().join('') === [...w].sort().join('')) best = Math.min(best, 1); return best; }
  const d = editDistance(t, w, max);
  if (d <= max) best = Math.min(best, d);
  if (last && w.length > t.length) { const dp = editDistance(t, w.slice(0, t.length), max); if (dp <= max) best = Math.min(best, dp + 0.5); }
  return best;
}

// ---------------------------------------------------------------- the index
let IX = null, building = null;
/* The index of the last library read answers at once. The library changes all the time — every played song gets
   its play count written (foo_playcount), and each change made the next search read the whole library again and
   rebuild the index first: half a minute on a big library. Now the search answers from the index it has and a
   fresh one is built in the background, a few seconds after the changes stop. */
let refreshT = 0;
function refreshLater() {
  clearTimeout(refreshT);
  refreshT = setTimeout(() => { const go = () => build().catch(() => {}); if (window.requestIdleCallback) requestIdleCallback(go, { timeout: 10000 }); else go(); }, 4000);
}
async function index(urgent = false) {
  if (IX) { if (!TS.fresh() || IX.gen !== TS.generation()) refreshLater(); return IX; }
  return build(urgent);
}
async function build(urgent = false) {
  const tracks = await TS.all({ urgent }).catch(() => []);
  const gen = TS.generation();
  if (IX && IX.gen === gen && IX.tracksN === tracks.length) return IX;
  if (building) return building;
  building = (async () => {
    const [Lib, Ar] = await Promise.all([import('./library.js'), import('./artists.js')]);
    const albums = await Lib.getAllAlbums().catch(() => []);
    const { artistsState } = Ar;
    if (!artistsState.loaded) await Ar.loadArtists(false).catch(() => {});
    const artists = (artistsState.list || []).map((a) => ({ a, p: prep(a.name), weight: (a.albums ? a.albums.length : 0) + (a.appears ? a.appears.length * 0.3 : 0) }));
    // in slices with a breath between: a big library's 50 000 tracks were one long freeze of the page
    const sliced = async (list, fn) => {
      const out = new Array(list.length);
      let at = performance.now();
      for (let i = 0; i < list.length; i++) {
        out[i] = fn(list[i]);
        if ((i & 255) === 255 && performance.now() - at > 12) { await new Promise((r) => setTimeout(r, 0)); at = performance.now(); }
      }
      return out;
    };
    const al = await sliced(albums, (a) => ({ a, p: prep(a.name), ap: prep(a.albumArtist || a.artist || ''), weight: a.trackCount || 1 }));
    const tr = await sliced(tracks, (t) => ({ t, p: prep(t.title || ''), ap: prep(t.artist || '') }));
    const words = new Set();
    for (const list of [artists, al, tr]) for (const e of list) { for (const w of e.p.words) words.add(w); if (e.ap) for (const w of e.ap.words) words.add(w); }
    IX = { gen, tracksN: tracks.length, artists, albums: al, tracks: tr, words };
    return IX;
  })().finally(() => { building = null; });
  return building;
}
/** build the index when the page is idle, so the first search is instant */
export function warm() {
  const go = () => index().catch(() => {});
  if (window.requestIdleCallback) requestIdleCallback(go, { timeout: 6000 }); else setTimeout(go, 1500);
}

/**
 * Search the library. Returns { artists, albums, tracks, suggestion } — each item { item, score }, best first.
 * Albums and tracks also match their artist («queen bohemian», «nirvana nevermind»).
 */
export async function search(text, { artists = 6, albums = 12, tracks = 300, stale = null } = {}) {
  const ix = await index(true);   // someone is waiting for the answer
  if (stale && stale()) return null;
  const mine = { costs: new Map(), vocab: ix.words || new Set(), byWord: pricer() };
  const own_ = () => { costs = mine.costs; vocab = mine.vocab; byWord = mine.byWord; };   // again after every breath: another search may have run meanwhile
  own_();
  const variants = [{ q: prep(text), swapped: false }];
  const sw = swapLayout(text);
  if (sw) variants.push({ q: prep(sw), swapped: true });
  // a query of two names (the thing and its artist, either way round): the ways to cut it, prepared once
  for (const v of variants) {
    v.cuts = [];
    for (let cut = 1; cut < Math.min(v.q.words.length, 5); cut++) v.cuts.push([prep(v.q.words.slice(0, cut).join(' ')), prep(v.q.words.slice(cut).join(' '))]);
  }
  const pair = (v, own, artist) => {
    const a = score(v.q, own);
    if (a.s >= 80 || !v.cuts.length) return a;
    let b = { s: 0 };
    for (const [head, tail] of v.cuts) {
      for (const [mine, theirs] of [[tail, head], [head, tail]]) {
        const o = score(mine, own); if (!o.s) continue;
        const r = score(theirs, artist); if (!r.s) continue;
        const sc = Math.min(o.s, r.s) * 0.95;
        if (sc > b.s) b = { s: sc, fuzzy: !!(o.fuzzy || r.fuzzy) };
      }
    }
    return b.s > a.s ? b : a;
  };
  // in slices: typing stays smooth on a big library, and a search overtaken by the next letter stops (`stale`)
  let at = performance.now(), gone = false;
  const breathe = async () => { await new Promise((r) => setTimeout(r, 0)); at = performance.now(); if (stale && stale()) gone = true; own_(); };
  const rank = async (list, fn, weightOf, n) => {
    const out = [];
    let i = 0;
    for (const e of list) {
      if ((++i & 127) === 0 && performance.now() - at > 12) { await breathe(); if (gone) return []; }
      let r = { s: 0 };
      for (const v of variants) { const x = fn(v, e); const sc = x.s - (v.swapped ? 3 : 0); if (sc > r.s) r = { s: sc, fuzzy: x.fuzzy || v.swapped }; }
      if (r.s > 0) out.push({ item: e.a || e.t, score: r.s + Math.log1p(weightOf(e)) * 2, fuzzy: !!r.fuzzy, e });
    }
    out.sort((x, y) => y.score - x.score);
    return out.slice(0, n);
  };
  const ar = await rank(ix.artists, (v, e) => score(v.q, e.p), (e) => e.weight, artists);
  // the artist that was found brings their albums and songs along, ahead of chance matches in other titles
  // («bodon» → Children of Bodom's albums, not an album with «boon» in its name)
  const who = ar[0] && ar[0].score >= 45 ? norm(ar[0].item.name) : '';
  const own = (v, e) => {
    const x = pair(v, e.p, e.ap);
    if (!who || e.ap.full !== who) return x;
    const y = score(v.q, e.ap);
    const by = y.s ? { s: y.s * 0.92, fuzzy: y.fuzzy } : { s: 0 };
    return { s: Math.max(x.s, by.s) + 8, fuzzy: x.s >= by.s ? x.fuzzy : by.fuzzy };
  };
  const al = await rank(ix.albums, own, (e) => e.weight, albums);
  const tr = gone ? [] : await rank(ix.tracks, own, () => 0, tracks);
  if (gone) { byWord = null; return null; }
  // what was probably meant: the top result, when it needed a correction and nothing exact came first
  // (an artist first: «бьорк» means Björk, not one of her albums)
  const exact = [ar[0], al[0], tr[0]].some((x) => x && !x.fuzzy && x.score >= 70);
  const top = [ar[0], al[0], tr[0]].find((x) => x && x.fuzzy && x.score >= 40);
  const suggestion = !exact && top ? (top.e.a ? top.e.a.name : top.e.t.title) : null;
  byWord = null;   // score() called on its own (outside a search) prices words one by one again
  return { artists: ar, albums: al, tracks: tr, suggestion, swapped: !!sw && variants.length > 1 };
}

export const ready = () => !!IX;
export const prepare = (s) => prep(s);
