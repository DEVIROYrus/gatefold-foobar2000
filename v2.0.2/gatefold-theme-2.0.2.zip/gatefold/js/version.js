/* Gatefold version — shown in Settings, used by the update check and the installer. */
export const VERSION = '2.0.2';
export const REPO = 'DEVIROYrus/gatefold-foobar2000';
