/*
 * Gatefold · history.js — Gatefold's own listening history, for Home.
 * A track counts as played after 30 s (or half of a shorter track). Kept in IndexedDB, newest
 * last, at most 20 000 plays (years of listening for most people). Works without foo_playcount.
 */
import * as IDB from './idb.js';
import { albumKeyOf } from './bridge.js';

const KEY = 'history.v1', MAX = 20000, AFTER = 30;
let list = null, loading = null, pending = null, timer = 0;
export const events = new EventTarget();

async function load() {
  if (list) return list;
  if (!loading) loading = IDB.kvGet(KEY, []).then((v) => (list = dedupe(Array.isArray(v) ? v : []))).catch(() => (list = []));
  return loading;
}
/* 2.0.0 recorded a play twice when the track's tags changed while it played (foo_playcount's count): the same
   track again sooner than it can have played through is that, not a second listen. Cleaned once on load. */
function dedupe(l) {
  const out = [];
  for (const e of l) {
    const p = out[out.length - 1];
    if (p && p.h === e.h && e.ts - p.ts < Math.max(1, (p.d || 0) * 0.9) * 1000) continue;
    out.push(e);
  }
  if (out.length !== l.length) IDB.kvSet(KEY, out).catch(() => {});
  return out;
}
const save = () => { clearTimeout(timer); timer = setTimeout(() => IDB.kvSet(KEY, list.slice(-MAX)).catch(() => {}), 1500); };

const idOf = (t) => (t && (t.handle || t.path)) || '';
/** the playing track: recorded once it has played long enough.
 *  fresh: foobar2000 started it (a new play, a repeat too). Otherwise the same track came back without a new start —
 *  its tags were edited (foo_playcount writes the play count a minute in), the page was reloaded or opened mid-track:
 *  that is the same play, so it is not counted again (2.0.0 counted every such play twice). */
export function nowPlaying(t, fresh = false) {
  const id = idOf(t);
  if (!id) { pending = null; return; }
  if (!fresh && pending && pending.id === id) { pending.t = t; return; }   // the same play, newer tags
  pending = { t, id, fresh, need: Math.min(AFTER, (t.duration || AFTER * 2) / 2), heard: 0 };
}
/** counts the time music actually plays (also while the window is hidden) */
export function init(isPlaying) {
  let prev = Date.now();
  setInterval(() => {
    const now = Date.now(), dt = (now - prev) / 1000; prev = now;
    const p = pending; if (!p || !isPlaying() || dt > 10) return;
    p.heard += dt;
    if (p.heard >= p.need) { pending = null; record(p.t, p.fresh); }
  }, 2000);
}
async function record(t, fresh = true) {
  await load();
  // not a new start and this track was recorded within its own length: the same play seen again
  const prev = list[list.length - 1];
  if (!fresh && prev && prev.h === idOf(t) && Date.now() - prev.ts < Math.max(60, t.duration || 0) * 1000) return;
  list.push({ h: t.handle || t.path, p: t.path, ti: t.title, ar: t.artist, aa: t.albumArtist, al: t.album, y: t.year, d: Math.round(t.duration || 0), ts: Date.now() });
  if (list.length > MAX * 1.1) list = list.slice(-MAX);
  save();
  events.dispatchEvent(new Event('change'));
}

export async function all() { return (await load()).slice(); }
/** today's listening: tracks and seconds since local midnight */
export async function today() {
  const l = await load(), from = new Date().setHours(0, 0, 0, 0);
  let n = 0, s = 0;
  for (let i = l.length - 1; i >= 0 && l[i].ts >= from; i--) { n++; s += l[i].d || 0; }
  return { n, s };
}
export const albumOf = (e) => albumKeyOf(e.aa || e.ar, e.al);

/** last played entry, or null */
export async function last() { const l = await load(); return l[l.length - 1] || null; }

/** albums played between two times, most plays first: [{ e, n }] */
export async function albumsBetween(from, to) {
  const m = new Map();
  for (const e of await load()) if (e.ts >= from && e.ts < to && e.al) { const k = albumOf(e); const x = m.get(k); if (x) x.n++; else m.set(k, { e, n: 1 }); }
  return [...m.values()].sort((a, b) => b.n - a.n);
}
/** artists played since a time, most plays first: [{ name, n }] */
export async function artistsSince(from) {
  const m = new Map();
  for (const e of await load()) if (e.ts >= from) { const a = e.aa || e.ar; if (a) m.set(a, (m.get(a) || 0) + 1); }
  return [...m].map(([name, n]) => ({ name, n })).sort((a, b) => b.n - a.n);
}
/** albums once played a lot but not for `quietDays` */
export async function forgotten(quietDays = 90, minPlays = 8) {
  const m = new Map(), cut = Date.now() - quietDays * 864e5;
  for (const e of await load()) { if (!e.al) continue; const k = albumOf(e); const x = m.get(k) || { e, n: 0, lastTs: 0 }; x.n++; x.lastTs = Math.max(x.lastTs, e.ts); x.e = e; m.set(k, x); }
  return [...m.values()].filter((x) => x.n >= minPlays && x.lastTs < cut).sort((a, b) => b.n - a.n);
}
