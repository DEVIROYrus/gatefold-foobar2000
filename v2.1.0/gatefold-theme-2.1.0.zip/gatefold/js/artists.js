/* Gatefold · artists.js — Artists grid → artist page → albums */
import * as SORT from './sorting.js';
import { call, ok, on, esc, plural, fmtDuration, fmtTime, debounce, settle } from './bridge.js';
import { settings, setSetting } from './settings.js';
import { router, onRoute, $, h, icon, toast, placeholder, popupMenu, backButton } from './ui.js';
import * as Lib from './library.js';
import * as AA from './artistart.js';
import { paletteForAlbum } from './theme.js';
import { isVarious } from './match.js';
import * as Names from './artistnames.js';

import { $t } from './i18n.js';
import { emptyActions } from './welcome.js';
import { img as imgOp } from './imgw.js';
import * as Loud from './loudness.js';
import * as History from './history.js';
import * as Info from './artistinfo.js';
const dpr = () => Math.min(2, window.devicePixelRatio || 1);
const AR = { list: [], view: [], byKey: new Map(), nodes: new Map(), cols: 1, tw: 160, rh: 210, loaded: false, loading: false };
const scroller = $('artScroller'), grid = $('artGrid');
const GAP = 8, PAD = 20;
/** what the photo search needs: the name, and albums to check the candidate's discography against */
export const jobOf = (x) => ({ name: x.name, albums: (x.albums.length ? x.albums : x.appears || []).map((a) => a.name) });
/* every track of an artist (#13.4, #12.5): their albums by year, their songs on others' albums, then songs with no
   album at all — each once */
const mineIn = (x, t) => Names.splitAll(t.artists && t.artists.length ? t.artists : [t.artist]).some((n) => n.toLowerCase() === x.key)
  || Names.splitAll(t.albumArtists && t.albumArtists.length ? t.albumArtists : [t.albumArtist]).some((n) => n.toLowerCase() === x.key);
const byYear = (l) => l.slice().sort((a, b) => (yearOf(a) || 9999) - (yearOf(b) || 9999) || String(a.name).localeCompare(String(b.name)));
const allMemo = new Map();   // artist key + library → the list (the page asks for it twice: play, the list)
export async function artistTracks(x) {
  const memo = allMemo.get(x.key);
  if (memo && memo.src === AR.src) return memo.list;
  const out = [], seen = new Set();
  const push = (t, a, kind) => { const k = String(t.handle || t.absolutePath || '').toLowerCase(); if (!k || seen.has(k)) return; seen.add(k); out.push({ t, a, kind }); };
  for (const a of byYear(x.albums)) for (const t of await Lib.albumTracks(a)) push(t, a, 'own');
  for (const a of byYear(x.appears || [])) for (const t of await Lib.albumTracks(a)) if (mineIn(x, t)) push(t, a, 'guest');
  const n = String(x.name).replace(/"/g, ' ');
  const r = await call('library.search', { query: `%album% MISSING AND (%artist% HAS "${n}" OR %album artist% HAS "${n}")`, limit: 5000,
    fields: ['title', 'artist', 'artists', 'album', 'albumArtist', 'albumArtists', 'duration', 'date', 'absolutePath', 'subsong', 'handle', 'trackNumber'] });
  for (const t of ((ok(r) && r.tracks) || []).slice().sort((p, q) => String(p.title || '').localeCompare(String(q.title || '')))) if (mineIn(x, t)) push(t, null, 'loose');
  allMemo.set(x.key, { src: AR.src, list: out });
  return out;
}
/** what the artist's discography search needs: your albums of theirs, and — with none — their songs on others' albums */
async function infoJob(x) {
  const job = jobOf(x);
  if (x.albums.length) return job;
  job.albums = [];
  job.tracks = [...new Set((await artistTracks(x)).map((e) => e.t.title).filter(Boolean))].slice(0, 60);
  return job;
}
const firstAlbum = (x) => x.albums[0] || (x.appears && x.appears[0]);
const albumsLine = (x) => (x.albums.length || !x.appears ? `${x.albums.length} ${plural(x.albums.length, 'альбом', 'альбома', 'альбомов')}` : $t('Участие: {0}', `${x.appears.length} ${plural(x.appears.length, 'альбом', 'альбома', 'альбомов')}`));
const yearOf = (a) => parseInt((String(a.year || '').match(/\d{4}/) || ['0'])[0], 10) || 0;

let loadP = null;
/** a rebuild already under way is waited for, not skipped: returning at once let a caller look an artist up
    in the old (or empty) index, and the page went on showing the artist opened before */
export function loadArtists(force) {
  if (loadP) return loadP;
  if (AR.loaded && !force) { layout(); return Promise.resolve(); }
  loadP = buildArtists().finally(() => { AR.loading = false; loadP = null; });
  return loadP;
}
async function buildArtists() {
  AR.loading = true;
  if (!AR.list.length) grid.innerHTML = `<div class="empty"><div class="spinner"></div><b>${$t('Собираю исполнителей…')}</b></div>`;
  const scan = AA.astate.scanned ? null : AA.scanFolder(); // in parallel with the album list
  const albums = await Lib.getAllAlbums();
  if (scan) await scan;
  if (albums === AR.src && AR.list.length && grid.querySelector('.atile')) { AR.loaded = true; return; } // library unchanged
  AR.src = albums;
  const map = new Map();
  for (const a of albums) {
    // «A; B», a multi-value tag or a list of artists the library knows: the album is listed under each of them
    const names = Lib.albumArtistNames(a);
    if (!names.length) names.push($t('Неизвестный исполнитель'));
    for (const name of names) {
      const k = name.toLowerCase();
      let x = map.get(k);
      if (!x) map.set(k, x = { name, key: k, albums: [], appears: [], tracks: 0, duration: 0, y0: 0, y1: 0 });
      x.albums.push(a); x.tracks += a.trackCount || 0; x.duration += a.duration || 0;
      const y = yearOf(a); if (y) { x.y0 = x.y0 ? Math.min(x.y0, y) : y; x.y1 = Math.max(x.y1, y); }
    }
  }
  // the albums an artist only sings on (a guest, a compilation): «Appears on» on their page; an artist
  // with none of their own gets a page too (a link to them works) and, if asked for, a tile in the grid
  const guests = new Map();
  for (const a of albums) for (const [name, n] of a.guests || []) {
    const k = name.toLowerCase();
    let x = map.get(k) || guests.get(k);
    if (!x) guests.set(k, x = { name, key: k, albums: [], appears: [], tracks: 0, duration: 0, y0: 0, y1: 0, guest: true });
    if (x.appears[x.appears.length - 1] === a) continue;
    x.appears.push(a);
    if (x.guest) { x.tracks += n; const y = yearOf(a); if (y) { x.y0 = x.y0 ? Math.min(x.y0, y) : y; x.y1 = Math.max(x.y1, y); } }
  }
  AR.list = [...map.values(), ...(settings.artistGuests ? [...guests.values()].filter((x) => !isVarious(x.name)) : [])];
  for (const x of [...map.values(), ...guests.values()]) { SORT.sortDiscography(x.albums); SORT.sortDiscography(x.appears); }
  AR.byKey = new Map([...guests, ...map]);
  await sortList();
  AR.loaded = true;
  const ac = $('artCount'); if (ac) ac.textContent = AR.list.length || '';
  grid.innerHTML = ''; AR.nodes.clear();
  if (!AR.list.length) { grid.innerHTML = `<div class="empty"><b>${$t('Медиатека пуста')}</b><span>${$t('Исполнители появятся, когда в медиатеке будет музыка')}</span>${emptyActions()}</div>`; return; }
  applyFilter();
  // background download of every missing photo (visible tiles jump the queue)
  if (settings.artistAuto) for (const x of AR.list) if (!x.guest) AA.want(jobOf(x)); // guests: when their tile is seen
}

async function sortList() {
  const by = settings.artistSort || 'name';
  if (by === 'added' || by === 'played') await SORT.ensure(by, AR.src || []);
  SORT.sortArtists(AR.list, by, isVarious);
}

function applyFilter() {
  const q = $('artFilter').value.trim().toLowerCase();
  AR.view = q ? AR.list.filter((x) => x.key.includes(q) || x.albums.some((a) => a.name.toLowerCase().includes(q)) || (x.guest && x.appears.some((a) => a.name.toLowerCase().includes(q)))) : AR.list;
  $('artSub').textContent = `${AR.view.length} ${plural(AR.view.length, 'исполнитель', 'исполнителя', 'исполнителей')}`;
  grid.querySelectorAll('.atile').forEach((t) => t.remove()); AR.nodes.clear();
  layout();
}

function layout() {
  // no width (the window minimized or in the tray while a library change reloads the list): nothing to measure —
  // tiles laid out now got a negative width and piled up in a column, and the ResizeObserver never fixed them
  // (no frames while hidden: back at its old size, it saw no change). laidW tells the next look it is stale.
  if (scroller.clientWidth < 80) { AR.laidW = 0; requestAnimationFrame(fresh); return; }
  AR.laidW = scroller.clientWidth;
  const W = scroller.clientWidth - PAD * 2;
  const min = 150 + (settings.baseSize - 14) * 6;
  AR.cols = Math.max(2, Math.floor((W + GAP) / (min + GAP)));
  AR.tw = (W - GAP * (AR.cols - 1)) / AR.cols;
  // name + «N альбомов» + years: three text lines that grow with the text size
  AR.rh = AR.tw + Math.max(64, Math.round(10 + (settings.baseSize || 14) * 3.8));
  grid.style.height = Math.ceil(AR.view.length / AR.cols) * AR.rh + 40 + 'px';
  schedule(true);
}

/** text size changed */
export function relayoutArtists() { if (AR.loaded) { grid.querySelectorAll('.atile').forEach((t) => t.remove()); AR.nodes.clear(); layout(); } }
let raf = 0, re = false;
function schedule(r) { re = re || r; if (!raf) raf = requestAnimationFrame(() => { raf = 0; render(re); re = false; }); }
scroller.addEventListener('scroll', () => schedule(false), { passive: true });
new ResizeObserver(() => { if (router.current === 'artists' && AR.loaded) layout(); }).observe(scroller);
/** laid out for another width (or for none): again — on the way back to the screen, to the window, to a frame */
function fresh() { if (router.current === 'artists' && AR.loaded && scroller.clientWidth >= 80 && scroller.clientWidth !== AR.laidW) layout(); }
addEventListener('resize', fresh); addEventListener('focus', fresh);
document.addEventListener('visibilitychange', () => { if (!document.hidden) requestAnimationFrame(fresh); });

function setAv(el, url, fallback) {
  const img = el.querySelector('img');
  img.classList.toggle('fallback', !!fallback);
  img.onload = () => { img.classList.add('on'); el.querySelector('.ph')?.remove(); if (fallback) Lib.coverLoaded(url); };
  img.src = url;
}

function render(relayout) {
  if (router.current !== 'artists' || !AR.view.length) return;
  if (scroller.clientWidth !== AR.laidW) { if (scroller.clientWidth >= 80) layout(); return; }
  const st = scroller.scrollTop, vh = scroller.clientHeight;
  const r0 = Math.max(0, Math.floor((st - 300) / AR.rh)), r1 = Math.ceil((st + vh + 300) / AR.rh);
  const keep = new Set(), noAvatar = [];
  for (let r = r0; r <= r1; r++) for (let c = 0; c < AR.cols; c++) {
    const i = r * AR.cols + c; if (i >= AR.view.length) break;
    const x = AR.view[i];
    keep.add(x.key);
    let el = AR.nodes.get(x.key);
    if (!el) {
      const ph = placeholder(x.name, '');
      el = h(`<div class="atile"><div class="av"><div class="ph" style="background:${ph.bg}">${esc(ph.ini)}</div><img alt=""></div><div class="an"></div><div class="as"></div></div>`);
      el.querySelector('.an').textContent = x.name;
      el.querySelector('.as').textContent = `${albumsLine(x)}${x.y0 ? `\n${x.y0}${x.y1 > x.y0 ? '–' + x.y1 : ''}` : ''}`;
      el.addEventListener('click', () => router.go('artist', x));
      el.addEventListener('contextmenu', (e) => { e.preventDefault(); artistMenu(x, e.clientX, e.clientY); });
      grid.appendChild(el); AR.nodes.set(x.key, el); relayout = true;
      AA.avatarUrl(x.name).then((u) => { if (u) setAv(el, u); else noAvatar.push([el, x]); flushFallback(); });
    }
    if (relayout) el.style.cssText = `width:${AR.tw}px;transform:translate(${PAD + c * (AR.tw + GAP)}px,${r * AR.rh + 4}px)`;
  }
  for (const [k, el] of AR.nodes) if (!keep.has(k)) { el.remove(); AR.nodes.delete(k); }
  function flushFallback() {
    if (!noAvatar.length) return;
    const batch = noAvatar.splice(0);
    // while the photo is being fetched, show the artist's first album cover in the circle
    Lib.coversFor(batch.map(([, x]) => firstAlbum(x)?.firstTrackAbsolutePath).filter(Boolean), Math.min(400, Math.round(AR.tw * dpr() / 50) * 50)).then((get) => {
      for (const [el, x] of batch) {
        const u = get(firstAlbum(x)?.firstTrackAbsolutePath);
        if (u && !el.querySelector('img.on')) setAv(el, u, true);
        if (!isVarious(x.name)) AA.want(jobOf(x), true);
      }
    });
  }
}

AA.events.addEventListener('saved', (e) => {
  const { name, url } = e.detail;
  const el = AR.nodes.get(name.toLowerCase());
  if (el) setAv(el, url);
  if (router.current === 'artist' && current && current.key === name.toLowerCase()) {
    const im = document.querySelector('#artistHero .artist-av img'); if (im) { im.src = url; im.classList.remove('fallback'); }
  }
});

$('artFilter').addEventListener('input', debounce(applyFilter, 150));
$('artSort').addEventListener('change', async (e) => { setSetting('artistSort', e.target.value); await sortList(); applyFilter(); $('artScroller').scrollTop = 0; });

async function artistMenu(x, px, py) {
  const id = await popupMenu([
    { id: 'open', label: $t('Открыть') },
    { id: 'play', label: $t('Слушать всё') },
    ...(Lib.shared.radioFor ? [{ id: 'radio', label: $t('Радио «Похожее на это»') }] : []),
    { type: 'sep' },
    { id: 'add', label: $t('Добавить фото…') },
    { id: 'refresh', label: $t('Обновить фото') },
    { id: 'photo', label: $t('Найти фото заново') },
    ...(AA.hasPhoto(x.name) ? [{ id: 'nophoto', label: $t('Убрать фото') }] : []),
    { id: 'folder', label: $t('Открыть папку с фото') },
  ], px, py);
  if (id === 'add') addPhoto(x);
  if (id === 'refresh') refreshPhoto(x);
  if (id === 'open') router.go('artist', x);
  if (id === 'play') playArtist(x, false);
  if (id === 'radio') Lib.shared.radioFor(x.name);
  if (id === 'photo') { AA.refetch(jobOf(x)); toast(`${$t('Ищу фото:')} <b>${esc(x.name)}</b>`); }
  if (id === 'nophoto') removePhoto(x);
  if (id === 'folder') openFolder();
}

const IMG_EXT = ['jpg', 'jpeg', 'png', 'webp', 'gif', 'bmp'];
/** a picture from the computer as the artist's photo */
async function addPhoto(x) {
  const r = await call('dialog.openFile', { title: $t('Фото для «{0}»', x.name), filters: [{ name: $t('Картинки'), extensions: IMG_EXT }] });
  if (!ok(r) || r.canceled || !(r.filePaths || []).length) return;
  try {
    const rd = await call('file.read', { path: r.filePaths[0], encoding: 'binary' });
    if (!ok(rd) || !rd.content) throw new Error(rd.error || $t('не удалось прочитать файл'));
    const blob = await imgOp('fromDataUrl', { dataUrl: rd.content });
    photoDone(x, await AA.setPhoto(x.name, blob));
  } catch (e) { toast(esc(e.message)); }
}
const photoDone = (x, done) => toast(done ? $t('Фото добавлено: <b>{0}</b>', esc(x.name)) : $t('Это не картинка — выберите файл изображения'));
/** the photo read again from the folder (a file put there by hand) */
async function refreshPhoto(x) {
  if (await AA.refreshPhoto(x.name)) toast($t('Фото обновлено: <b>{0}</b>', esc(x.name)));
  else toast($t('Фото не найдено: <b>{0}</b>. Добавьте его через «Добавить фото…»', esc(x.name)));
}
/** the photo menu of the artist page (its button and a right click on the circle) */
async function photoMenu(x, px, py) {
  const id = await popupMenu([
    { id: 'add', label: $t('Добавить фото…') },
    { id: 'refresh', label: $t('Обновить фото') },
    { id: 'refetch', label: $t('Найти фото заново') },
    ...(AA.hasPhoto(x.name) ? [{ id: 'nophoto', label: $t('Убрать фото') }] : []),
    { id: 'folder', label: $t('Открыть папку с фото') },
    { type: 'sep' },
    { id: 'help', label: $t('Как поставить своё фото') },
  ], px, py);
  if (id === 'add') addPhoto(x);
  if (id === 'refresh') refreshPhoto(x);
  if (id === 'refetch') { AA.refetch(jobOf(x)); toast(`${$t('Ищу фото:')} <b>${esc(x.name)}</b>`); }
  if (id === 'nophoto') removePhoto(x);
  if (id === 'folder') openFolder();
  if (id === 'help') toast($t('Своё фото: перетащите картинку на круг или «Добавить фото…»; или положите <b>{0}</b> в папку с фото и «Обновить фото»', esc(AA.fileNameFor(x.name))), { ms: 9000 });
}

/* a wrong photo: gone, the album cover stands in, and it is not looked for again until «Find photo again» */
async function removePhoto(x) {
  if (await AA.removePhoto(jobOf(x))) toast($t('Фото убрано: <b>{0}</b>. «Найти фото заново» вернёт его', esc(x.name)), { ms: 6000 });
  else toast($t('Не удалось убрать фото — попробуйте ещё раз'));
}
AA.events.addEventListener('removed', (e) => {
  const key = e.detail.name, el = AR.nodes.get(key);
  if (el) { el.remove(); AR.nodes.delete(key); schedule(true); }
  if (router.current === 'artist' && current && current.key === key) openArtist(current);
});

export async function openFolder() {
  if (!AA.astate.scanned) await AA.scanFolder();
  const p = AA.astate.folderAbs;
  const r = p ? await call('shell.showInExplorer', { path: p }) : { success: false };
  if (!ok(r)) toast(`${$t('Папка с фото:')} <b>${esc(p || AA.DIR)}</b>`, { ms: 8000 });
}

async function playArtist(x, shuffle) {
  // everything of theirs: their albums, their songs on others' albums, songs with no album (#12.5)
  const paths = (await artistTracks(x)).map((e) => e.t.handle || e.t.absolutePath);
  if (shuffle) for (let i = paths.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [paths[i], paths[j]] = [paths[j], paths[i]]; }
  if (paths.length) Lib.playPaths(paths, 0, x.name);
}

// ---------------------------------------------------------------- artist page
let current = null, token = 0;
export async function openArtist(arg) {
  if (!arg) return;
  if (typeof arg === 'string') {
    // the index there is first: waiting for a rebuild (play counts and tag writes mark it stale often) kept the
    // page on the artist opened before; only a name the index does not know yet waits for one
    const find = (name) => {
      const q = name.trim().toLowerCase(), first = q.split(/\s*(?:[,;&/]|\bfeat\.?|\bft\.?|\bx\b)\s*/)[0];
      return AR.byKey.get(q) || [...AR.byKey.values()].find((x) => x.key.split(/\s*[,;&]\s*/)[0] === q) || AR.byKey.get(first)
        || [...AR.byKey.values()].find((x) => x.key.split(/\s*[,;&]\s*/)[0] === first);
    };
    let hit = AR.loaded ? find(arg) : null;
    if (!hit) { await loadArtists(false); hit = find(arg); }
    if (!hit) { toast($t('Исполнитель не найден в медиатеке')); return; }
    arg = hit;
  }
  const x = arg; current = x;
  const tk = ++token;
  if (!AA.astate.scanned) await AA.scanFolder();
  const ph = placeholder(x.name, '');
  $('artistHero').innerHTML = `
    <div class="artist-av" style="background:${ph.bg}"><span>${esc(ph.ini)}</span><img alt=""></div>
    <div style="min-width:0">
      <div class="kicker">${$t('Исполнитель')}</div>
      <h1>${esc(x.name)}</h1>
      <div class="album-meta">${albumsLine(x)} · ${x.tracks} ${plural(x.tracks, 'трек', 'трека', 'треков')}${x.duration ? ' · ' + fmtDuration(x.duration) : ''}${x.y0 ? ` · ${x.y0}${x.y1 > x.y0 ? '–' + x.y1 : ''}` : ''}</div>
      <div class="album-actions">
        <button class="hm-btn primary" id="arPlay">${icon('play', 16)}<span>${$t('Слушать всё')}</span></button>
        <button class="hm-btn" id="arShuffle">${icon('shuffle', 16)}<span>${$t('Вперемешку')}</span></button>
        <span class="al-tools"><button class="round-btn" id="arPhoto" title="${$t('Фото ▾')}" aria-label="${$t('Фото ▾')}">${icon('image')}</button></span>
      </div>
    </div>
    <div class="hero-bio" id="artistBio" hidden></div>`;
  $('artistHero').prepend(backButton('artists'));
  $('arPlay').onclick = () => playArtist(x, false);
  $('arShuffle').onclick = () => playArtist(x, true);
  $('arPhoto').onclick = (e) => { const r = e.currentTarget.getBoundingClientRect(); photoMenu(x, r.left, r.bottom + 4); };
  // the circle: right click for the photo menu
  const avEl = document.querySelector('#artistHero .artist-av');
  avEl.oncontextmenu = (e) => { e.preventDefault(); photoMenu(x, e.clientX, e.clientY); };
  document.body.dataset.photoFor = x.name;   // a picture dragged in gets a «photo of this artist» zone (dropzone.js)
  const avImg = document.querySelector('#artistHero .artist-av img');
  avImg.onload = () => { avImg.classList.add('on'); document.querySelector('#artistHero .artist-av span')?.remove(); };
  AA.avatarUrl(x.name).then(async (u) => {
    if (tk !== token) return;
    if (u) { avImg.src = u; $('artistHero').style.setProperty('--ar-bg', `url("${u}")`); }
    else {
      const get = await Lib.coversFor([firstAlbum(x)?.firstTrackAbsolutePath], Math.round(180 * dpr()));
      const c = get(firstAlbum(x)?.firstTrackAbsolutePath);
      if (c && tk === token) { avImg.classList.add('fallback'); avImg.src = c; }
      if (settings.artistAuto) AA.want(jobOf(x), true);
    }
  });
  paletteForAlbum(firstAlbum(x)?.albumArtist, firstAlbum(x)?.name, firstAlbum(x)?.firstTrackAbsolutePath).then((p) => {
    if (tk !== token) return;
    const v = $('view-artist'); v.style.setProperty('--a-accent', p.accent.css); v.style.setProperty('--a-glow', p.glow.css);
  });
  /* the albums heading belongs to this artist from the first frame: a discography heading (and its filter
     buttons) left from the previous page would otherwise stay until MusicBrainz answers — and clicking it
     drew the previous artist's albums here */
  const online = settings.onlineInfo !== false;
  const pre = online ? Info.cached(x.name) : null;
  if (pre) infoJob(x).then((j) => Info.revalidate(j)).catch(() => {});   // a copy older than a month: shown now, refreshed in the background
  const H = $('artistAlbumsH');
  H.innerHTML = `<span>${esc($t('Альбомы'))}</span>${online && !pre ? `<small class="dz-count dz-wait"><span class="spinner"></span>${esc($t('ищу дискографию…'))}</small>` : ''}`;
  H.append(Lib.tileTools());
  const appears = x.appears || [];
  H.hidden = $('artistAlbums').hidden = !x.albums.length;
  $('artistAppearsH').hidden = $('artistAppears').hidden = !appears.length;
  $('artistScroller').scrollTop = 0;
  // a discography already known is drawn at once, without first showing the plain album grid
  const quick = pre && pre.disco && pre.disco.length >= 2;
  if (quick) renderDisco(x, pre, tk);
  Lib.heroBio($('artistBio'), pre, '');
  renderInfo(x, tk, pre);
  await Promise.all([quick ? null : albumTiles($('artistAlbums'), x.albums, tk, false), albumTiles($('artistAppears'), appears, tk, true)]);
  allTracks(x, tk);
}
/* «All tracks» (#13.4): every song of the artist in one list under the albums, folded by default (remembered) —
   their albums, then their songs on others' albums, then songs with no album */
const ALL_OPEN = 'gatefold.artistAllOpen';
async function allTracks(x, tk) {
  const box = $('artistAll');
  box.hidden = true; box.innerHTML = '';
  const list = await artistTracks(x).catch(() => []);
  if (tk !== token || !list.length) return;
  let open = false; try { open = localStorage.getItem(ALL_OPEN) === '1'; } catch {}
  const dur = list.reduce((s, e) => s + (+e.t.duration || 0), 0);
  box.innerHTML = `<button class="ar-all-h" aria-expanded="${open}"><span class="nav-label">${esc($t('Все треки'))}</span><small class="num">${list.length} · ${esc(fmtDuration(dur))}</small>${icon('chev', 14)}</button><div class="ar-all-list" role="list"></div>`;
  box.hidden = false;
  const head = box.querySelector('.ar-all-h'), rows = box.querySelector('.ar-all-list');
  const KIND = { guest: $t('участие'), loose: $t('без альбома') };
  let drawn = 0;
  const draw = (upTo) => {
    rows.querySelector('.ar-all-more')?.remove();
    const html = [];
    for (let i = drawn; i < Math.min(list.length, upTo); i++) {
      const { t, a, kind } = list[i];
      const sub = [kind === 'guest' ? t.artist : '', a ? a.name : '', a ? (yearOf(a) || '') : '', KIND[kind] || ''].filter(Boolean).map((v) => esc(String(v)));
      html.push(`<div class="ar-trow" role="listitem" data-i="${i}"><span class="n num">${i + 1}</span><span class="t"><b>${esc(t.title || '')}</b><small>${a ? `<span class="lnk" data-go="album">${sub.join(' · ')}</span>` : sub.join(' · ')}</small></span><span class="d num">${t.duration ? fmtTime(t.duration) : ''}</span></div>`);
    }
    rows.insertAdjacentHTML('beforeend', html.join(''));
    drawn = Math.min(list.length, upTo);
    if (drawn < list.length) {
      const more = h(`<button class="more-link ar-all-more">${esc($t('Показать ещё {0}', Math.min(500, list.length - drawn)))}</button>`);
      more.onclick = () => draw(drawn + 500);
      rows.append(more);
    }
  };
  const paint = () => { head.setAttribute('aria-expanded', String(open)); box.classList.toggle('open', open); if (open && !drawn) draw(500); };
  head.onclick = () => { open = !open; try { localStorage.setItem(ALL_OPEN, open ? '1' : '0'); } catch {} paint(); };
  paint();
  const paths = list.map((e) => e.t.handle || e.t.absolutePath);
  rows.ondblclick = (e) => { const r = e.target.closest('.ar-trow'); if (r) Lib.playPaths(paths, +r.dataset.i, x.name); };
  rows.onclick = (e) => {
    const r = e.target.closest('.ar-trow'); if (!r) return;
    if (e.target.closest('.lnk')) { const it = list[+r.dataset.i]; if (it.a) Lib.openAlbumFrom(null, it.a); return; }
    rows.querySelectorAll('.ar-trow.sel').forEach((n) => n.classList.remove('sel')); r.classList.add('sel');
  };
  // foobar2000's own menu for the song: add to a playlist, queue, properties…
  rows.oncontextmenu = (e) => { const r = e.target.closest('.ar-trow'); if (!r) return; e.preventDefault(); rows.querySelectorAll('.ar-trow.sel').forEach((n) => n.classList.remove('sel')); r.classList.add('sel'); call('menu.showNativePopup', { mode: 'handles', handles: [paths[+r.dataset.i]] }); };
}
/* ------------------------------------------------------------------ the discography
   One grid of everything the artist released (MusicBrainz: albums, EPs, singles) together with your own
   albums: the ones you have open the album page; the others open their full track list (release.js),
   where what you have plays from the disk and the rest through YouTube. Your albums MusicBrainz does
   not list (compilations, live…) stay in the grid. Without online data it is just your albums. */
const TYPE = { Album: () => $t('Альбом'), EP: () => 'EP', Single: () => $t('Сингл') };
/* by default only what you have (the missing ones are a click away); the choice is remembered */
// own: mine | missing | '' (all); types: the kinds shown, none = all (2.0.0 kept one kind in `type`)
let discoFilter = (() => {
  let f = {};
  try { f = JSON.parse(localStorage.getItem('gatefold.discoFilter') || '{}') || {}; } catch {}
  const types = Array.isArray(f.types) ? f.types : f.type ? [f.type] : [];
  return { own: f.own ?? 'mine', types: types.filter((t) => ['Album', 'EP', 'Single'].includes(t)) };
})();
/* what your own files say an album is: %releasetype% (MusicBrainz Picard writes it) — it wins over the online
   sources, whose kinds disagree (Deezer calls many short albums an EP). Asked once per album. */
const localKind = new Map();
const kindOf = (v) => { const s = String(v || '').toLowerCase(); return /\bsingle\b/.test(s) ? 'Single' : /\bep\b/.test(s) ? 'EP' : /\balbum\b/.test(s) ? 'Album' : ''; };
async function loadLocalKinds(albums) {
  const want = albums.filter((a) => a.firstTrackAbsolutePath && !localKind.has(a.firstTrackAbsolutePath));
  if (!want.length) return false;
  const r = await call('titleformat.evalFieldsBatch', { paths: want.map((a) => a.firstTrackAbsolutePath), fields: { k: '[$if2(%releasetype%,$if2(%musicbrainz_albumtype%,%release type%))]' } });
  want.forEach((a, i) => localKind.set(a.firstTrackAbsolutePath, ok(r) ? kindOf(r.results && r.results[i] && r.results[i].k) : ''));
  return want.some((a) => localKind.get(a.firstTrackAbsolutePath));
}
function renderDisco(x, info, tk) {
  if (tk !== token || x !== current) return;   // another artist is open by now
  $('artistDisco').hidden = true;
  const mine = [...(x.albums || [])];
  const disco = (info && info.disco) || [];
  if (disco.length < 2) {
    // say why there is no discography instead of leaving it to guesswork
    const H = $('artistAlbumsH');
    H.innerHTML = `<span>${esc($t('Альбомы'))}</span>${info ? `<small class="dz-count">${esc(info.failed ? $t('сервисы музыки не ответили') : $t('дискография не найдена'))} · <button class="more-link dz-retry">${esc($t('Повторить'))}</button></small>` : ''}`;
    H.append(Lib.tileTools());
    const rb = H.querySelector('.dz-retry');
    if (rb) rb.onclick = async () => {
      rb.disabled = true; rb.textContent = $t('ищу дискографию…');
      Info.forget(x.name);
      const again = await infoJob(x).then((j) => Info.get(j)).catch(() => null);
      renderDisco(x, again, tk);
    };
    // nobody answered (offline, all three busy): tried again by itself while the page stays open
    if (info && info.failed && rb) setTimeout(() => { if (tk === token && x === current && rb.isConnected && !rb.disabled) rb.click(); }, 45000);
    return;
  }
  $('artistAlbumsH').hidden = $('artistAlbums').hidden = false;
  const used = new Set();
  const items = disco.map((d) => {
    const a = mine.find((m) => !used.has(m) && Info.sameTitle(m.name, d.title));
    if (a) used.add(a);
    return { d, a };
  });
  for (const a of mine) if (!used.has(a)) items.push({ d: null, a });
  // in the order of the years shown on the tiles: yours (your tags) for what you have, the source's for the rest —
  // the source's year for an album of yours put a 2016 reissue among 2014's (#12.8)
  const yr = (i) => (i.a ? yearOf(i.a) || (i.d && i.d.year) : i.d.year) || 9999;
  items.sort((p, q) => yr(p) - yr(q) || String(p.a ? p.a.name : p.d.title).localeCompare(String(q.a ? q.a.name : q.d.title)));
  // the kind of each item: your tags first, then the source's, else an album
  // Deezer's own kinds are loose: what you have with 7+ tracks or over 30 minutes is an album (the usual rule)
  const byLength = (it) => (it.a && info.src === 'deezer' && it.d && it.d.type !== 'Album' && ((it.a.trackCount || 0) >= 7 || (it.a.duration || 0) > 1800) ? 'Album' : '');
  for (const it of items) it.kind = (it.a && localKind.get(it.a.firstTrackAbsolutePath)) || byLength(it) || (it.d && it.d.type) || 'Album';
  const own = items.filter((i) => i.a).length, total = items.length;
  const types = ['Album', 'EP', 'Single'].filter((t) => items.some((i) => i.kind === t));
  const H = $('artistAlbumsH');
  const SRC = { musicbrainz: 'MusicBrainz', deezer: 'Deezer', itunes: 'Apple Music' };
  H.innerHTML = `<span title="${esc(SRC[info.src] ? $t('Источник: {0}', SRC[info.src]) : '')}">${esc($t('Дискография'))}</span><span class="dz-filters"></span>`;
  H.append(Lib.tileTools());
  const bar = H.querySelector('.dz-filters');
  const save = () => { try { localStorage.setItem('gatefold.discoFilter', JSON.stringify(discoFilter)); } catch {} renderDisco(x, info, tk); };
  const ownChip = (val, label) => {
    const on = (!mine.length && discoFilter.own === 'mine' ? '' : discoFilter.own) === val;
    const b = h(`<button class="chip dz-f${on ? ' on' : ''}" aria-pressed="${on}"></button>`);
    b.textContent = label;
    b.onclick = () => { if (tk !== token) return; discoFilter.own = on && val ? '' : val; save(); };
    return b;
  };
  // kinds combine: albums and EPs, only singles… (none chosen = all of them)
  const typeChip = (t, label) => {
    const on = discoFilter.types.includes(t);
    const b = h(`<button class="chip dz-f${on ? ' on' : ''}" aria-pressed="${on}"></button>`);
    b.textContent = label;
    b.onclick = () => { if (tk !== token) return; discoFilter.types = on ? discoFilter.types.filter((v) => v !== t) : [...discoFilter.types, t]; if (discoFilter.types.length === types.length) discoFilter.types = []; save(); };
    return b;
  };
  bar.append(ownChip('mine', `${$t('У вас')} · ${own}`), ownChip('missing', `${$t('Нет у вас')} · ${total - own}`), ownChip('', $t('Все')));
  if (types.length > 1) { bar.append(h('<i class="dz-sep"></i>')); for (const t of types) bar.append(typeChip(t, t === 'Album' ? $t('Альбомы') : t === 'EP' ? 'EP' : $t('Синглы'))); }
  const kinds = discoFilter.types.filter((t) => types.includes(t));
  // none of it yours (an artist you have only on others' albums): «yours» would show nothing — all of it is shown
  const own0 = !mine.length && discoFilter.own === 'mine' ? '' : discoFilter.own;
  const shown = items.filter((i) => (own0 === 'mine' ? i.a : own0 === 'missing' ? !i.a : true) && (!kinds.length || kinds.includes(i.kind)));
  discoTiles($('artistAlbums'), shown, x, tk);
  // your tags may name the kinds better: asked once, drawn again when they change something
  loadLocalKinds(mine).then((changed) => { if (changed && tk === token && x === current) renderDisco(x, info, tk); }).catch(() => {});
}
async function discoTiles(box, items, x, tk) {
  box.innerHTML = '';
  const gen = box.dataset.gen = String(+(box.dataset.gen || 0) + 1);
  if (!items.length) { box.innerHTML = `<div class="dz-empty">${esc($t('Ничего под этот фильтр'))}</div>`; return; }
  for (const it of items) {
    const name = it.a ? it.a.name : it.d.title;
    const ph2 = placeholder(name, x.name);
    const el = h(`<div class="tile static${it.a ? '' : ' online'}"><div class="cov"><div class="ph" style="background:${ph2.bg}">${esc(ph2.ini)}</div><img alt=""><button class="play" title="${esc(it.a ? $t('Слушать') : $t('Слушать на YouTube'))}" aria-label="${esc(it.a ? $t('Слушать') : $t('Слушать на YouTube'))}">${icon('play', 18)}</button>${it.a ? '' : `<span class="dz-yt" title="${esc($t('Нет у вас — играет с YouTube'))}">${icon('yt', 13)}</span>`}</div><div class="tt"></div><div class="ta"></div></div>`);
    el.querySelector('.tt').textContent = name;
    const kind = it.kind && it.kind !== 'Album' ? TYPE[it.kind]() : '';
    el.querySelector('.ta').textContent = it.a
      ? [Lib.yearEdition(it.a), kind, `${it.a.trackCount || 0} ${plural(it.a.trackCount || 0, 'трек', 'трека', 'треков')}`].filter(Boolean).join(' · ')
      : [it.d.year || '', kind].filter(Boolean).join(' · ');
    el.onclick = () => (it.a ? Lib.openAlbumFrom(el, it.a) : router.go('release', { artist: x.name, d: it.d, x }));
    el.querySelector('.play').onclick = (e) => { e.stopPropagation(); if (it.a) Lib.playAlbumRow(it.a); else import('./release.js').then((R) => R.playRelease(x, it.d)); };
    el.oncontextmenu = it.a ? (e) => { e.preventDefault(); Lib.albumMenu(it.a, e.clientX, e.clientY); } : null;
    box.appendChild(el);
  }
  const local = items.filter((i) => i.a);
  const get = local.length ? await Lib.coversFor(local.map((i) => i.a.firstTrackAbsolutePath), 400) : () => '';
  if (tk !== token || box.dataset.gen !== gen) return;
  [...box.children].forEach((el, i) => {
    const it = items[i]; if (!it) return;
    const u = it.a ? get(it.a.firstTrackAbsolutePath) : Info.releaseCover(it.d, 250);
    const img = el.querySelector('img');
    if (u) { img.onload = () => { if (img.naturalWidth > 1) { img.classList.add('on'); el.querySelector('.ph')?.remove(); if (it.a) Lib.coverLoaded(u); } }; img.onerror = () => img.remove(); img.src = u; }
  });
}
/** under the header: your most played tracks of this artist (history.js) and what the web says (artistinfo.js) */
/** the artist's most played tracks by %play_count% (foo_playcount), as history-like entries */
async function topByPlaycount(x) {
  const tracks = [];
  for (const a of x.albums.slice(0, 20)) for (const t of await Lib.albumTracks(a)) tracks.push({ t, a });
  if (!tracks.length) return [];
  const r = await call('titleformat.evalFieldsBatch', { paths: tracks.map(({ t }) => t.handle || t.absolutePath), fields: { plays: '[%play_count%]' } });
  if (!ok(r)) return [];
  return (r.results || []).map((v, i) => ({ n: parseInt(v && v.plays, 10) || 0, ...tracks[i] })).filter((v) => v.n > 0).sort((p, q) => q.n - p.n).slice(0, 5)
    .map(({ n, t, a }) => ({ n, e: { ti: t.title, al: a.name, y: a.year, h: t.handle || t.absolutePath } }));
}

async function renderInfo(x, tk, pre = null) {
  const box = $('artistInfo');
  box.innerHTML = ''; box.hidden = true;
  const dz = $('artistDisco'); dz.innerHTML = ''; dz.hidden = true;
  const names = new Set([x.name, ...(x.aliases || [])].map((n) => String(n).toLowerCase()));
  const per = new Map();
  for (const e of await History.all()) {
    if (!names.has(String(e.aa || '').toLowerCase()) && !names.has(String(e.ar || '').toLowerCase())) continue;
    const k = (e.ti || '') + '\u0001' + (e.al || '');
    const v = per.get(k) || { e, n: 0 }; v.n++; v.e = e; per.set(k, v);
  }
  if (tk !== token) return;
  let top = [...per.values()].sort((a, b) => b.n - a.n).slice(0, 5);
  // no own history of this artist yet (a fresh 2.0): foobar2000's play counts say the same
  if (!top.length) {
    const pc = await topByPlaycount(x).catch(() => []);
    if (tk !== token) return;
    if (pc.length > top.length) top = pc;
  }
  const cols = [];
  if (top.length) {
    const col = h(`<div class="ar-col"><h2>${esc($t('Чаще всего у вас'))}</h2><div class="ar-top"></div></div>`);
    const list = col.querySelector('.ar-top');
    top.forEach((v, i) => {
      const r = h(`<button class="ar-row"><span class="n num">${i + 1}</span><span class="t"><b></b><small></small></span><span class="c num"></span></button>`);
      r.querySelector('b').textContent = v.e.ti || '';
      r.querySelector('small').textContent = [v.e.al, v.e.y].filter(Boolean).join(' · ');
      r.querySelector('.c').textContent = `${v.n}×`;
      r.title = $t('Слушать');
      r.onclick = () => Lib.playPaths(top.map((t) => t.e.h), i, x.name);
      list.append(r);
    });
    cols.push(col);
  }
  /* nothing is drawn before there is something to say: no empty headings, no placeholders that collapse */
  if (cols.length) { box.append(...cols); box.hidden = false; }
  if (settings.onlineInfo === false) return;
  const info = pre || await infoJob(x).then((j) => Info.get(j)).catch(() => null);
  if (tk !== token) return;
  if (info !== pre || !(pre.disco && pre.disco.length >= 2)) renderDisco(x, info, tk);
  if (!info) return;
  if (info !== pre) Lib.heroBio($('artistBio'), info, '');
  const sim = (info.similar || []).slice(0, 10);
  if (!info.about && !sim.length) return;
  // without a description the column is just «similar artists», titled that way
  /* the description also stands in the header on a wide window (CSS hides this copy there; the heading then
     reads «similar artists») */
  const about = h(`<div class="ar-col ar-about${info.about ? ' has-bio' : ''}${sim.length ? '' : ' only-bio'}"><h2><span class="h-bio"></span><span class="h-sim"></span></h2><div class="ar-text"></div></div>`);
  about.querySelector('.h-bio').textContent = info.about ? $t('Об исполнителе') : $t('Похожие исполнители');
  about.querySelector('.h-sim').textContent = $t('Похожие исполнители');
  const text = about.querySelector('.ar-text');
  if (info.about) {
    const p = h('<p class="ar-bio"></p>'); p.textContent = info.about.text + ' ';
    const a = h(`<a href="#" class="ar-link"></a>`); a.textContent = $t('Читать в Википедии');
    a.onclick = (e) => { e.preventDefault(); call('shell.openExternal', { url: info.about.url }); };
    p.append(a); text.append(p);
  }
  if (sim.length) {
    if (info.about) text.append(h(`<div class="ar-sim-h ar-bio">${esc($t('Похожие исполнители'))}</div>`));
    const row = h('<div class="ar-sim"></div>');
    // the ones you have first: they lead somewhere
    const ranked = sim.map((n) => ({ n, mine: AR.byKey.get(String(n).trim().toLowerCase()) })).sort((p, q) => (q.mine ? 1 : 0) - (p.mine ? 1 : 0));
    for (const { n, mine } of ranked) {
      const c = h(`<${mine ? 'button' : 'span'} class="chip${mine ? ' accent' : ''}"></${mine ? 'button' : 'span'}>`);
      c.textContent = n;
      if (mine) { c.title = $t('Есть в вашей медиатеке'); c.onclick = () => router.go('artist', mine); }
      row.append(c);
    }
    text.append(row);
  }
  box.append(about); box.hidden = false;
  box.classList.toggle('one', box.children.length === 1);
}
/** an artist page's album tiles; «Appears on» tiles say whose album it is */
async function albumTiles(box, albums, tk, others) {
  box.innerHTML = '';
  const gen = box.dataset.gen = String(+(box.dataset.gen || 0) + 1);   // the discography may redraw this grid meanwhile
  for (const a of albums) {
    const ph2 = placeholder(a.name, a.albumArtist);
    const el = h(`<div class="tile static"><div class="cov"><div class="ph" style="background:${ph2.bg}">${esc(ph2.ini)}</div><img alt=""><button class="play" title="${$t('Слушать')}">${icon('play', 18)}</button></div><div class="tt"></div><div class="ta"></div></div>`);
    el.querySelector('.tt').textContent = a.name || $t('Без альбома');
    el.querySelector('.ta').textContent = others ? [a.artist || a.albumArtist || '', yearOf(a) || ''].filter(Boolean).join(' · ') : [Lib.yearEdition(a), `${a.trackCount || 0} ${plural(a.trackCount || 0, 'трек', 'трека', 'треков')}`].filter(Boolean).join(' · ');
    el.onclick = () => Lib.openAlbumFrom(el, a);
    el.querySelector('.play').onclick = (e) => { e.stopPropagation(); Lib.playAlbumRow(a); };
    el.oncontextmenu = (e) => { e.preventDefault(); Lib.albumMenu(a, e.clientX, e.clientY); };
    box.appendChild(el);
  }
  if (!albums.length) return;
  const get = await Lib.coversFor(albums.map((a) => (a.noAlbum ? '' : a.firstTrackAbsolutePath)), 400);
  if (tk !== token || box.dataset.gen !== gen) return;
  [...box.children].forEach((el, i) => {
    if (!albums[i]) return;
    const u = albums[i].noAlbum ? '' : get(albums[i].firstTrackAbsolutePath);
    const img = el.querySelector('img');
    if (u) { img.onload = () => { if (img.naturalWidth > 1) { img.classList.add('on'); el.querySelector('.ph')?.remove(); Lib.coverLoaded(u); } }; img.src = u; }
  });
}

router.on('artists', () => { loadArtists(false); requestAnimationFrame(fresh); });
import('./coverfetch.js').then((CF) => CF.events.addEventListener('repaired', () => {
  AR.nodes.forEach((el) => el.remove()); AR.nodes.clear();
  if (router.current === 'artists') layout();
}));
router.on('artist', (x) => openArtist(x));
['library:itemsAdded', 'library:itemsRemoved', 'library:itemsModified'].forEach((ev) => on(ev, settle(() => { if (ev === 'library:itemsModified' && performance.now() < Loud.writingUntil) return; AR.loaded = false; if (router.current === 'artists') loadArtists(true); }, 3000, 30000)));
/* the library list came back different from the on-disk snapshot → rebuild */
Lib.libEvents.addEventListener('changed', () => { AR.loaded = false; if (router.current === 'artists') loadArtists(true); });
export const artistsState = AR;

/* a picture dropped on the «artist's photo» zone (dropzone.js) */
addEventListener('gatefold:artist-photo', async (e) => {
  if (router.current !== 'artist' || !current) return;
  const f = e.detail && e.detail.file;
  photoDone(current, f ? await AA.setPhoto(current.name, f) : false);
});
onRoute((v) => { if (v !== 'artist') delete document.body.dataset.photoFor; });
