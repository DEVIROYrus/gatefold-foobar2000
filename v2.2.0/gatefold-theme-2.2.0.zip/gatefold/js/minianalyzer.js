/*
 * Gatefold · minianalyzer.js — the small analyzer under the track (spectrum style «Analyzer»), measured as the big
 * one measures (analyzer-worker.js), not drawn from the bars of the other styles.
 *
 * The bars are made for looks: one 4096-point FFT (11 Hz between bins, so the bass is guessed between them), the
 * loudest bin of each of 56 bands, a level squeezed into 0…1 over 60 dB. An analyzer needs the opposite: the power
 * in each band, the bass resolved, a real dB scale. So this one keeps its own worker on the same live samples:
 *   · a multi-resolution FFT (8192 points under 300 Hz — 5 Hz between bins —, 4096 above 2 kHz, crossfaded between),
 *     Blackman-Harris window, the level of a sine read in dBFS
 *   · 1/6-octave smoothing by power: the shape of the mix, readable in a strip a few dozen pixels tall
 *   · the tilt of the big analyzer (4.5 dB per octave around 1 kHz unless changed there): pink noise — music on
 *     average — draws flat, as in Pro-Q and SPAN
 *   · its ballistics: up at once, down at the big one's speed (28 dB/s), the peaks held for a moment and let fall
 *   · 20 Hz – 20 kHz on a log axis; 54 dB tall, the top on a 6 dB step that follows the music slowly (up at once
 *     when the curve reaches it, down only after a few quieter seconds): the scale stays put long enough to read
 *     and the curve uses the height it has.
 * Without the host's live samples (an older component) the style falls back to the bars' shape.
 */
import * as Viz from './viz.js';
import { reader } from './ringpull.js';
import { settings } from './settings.js';

export const F_LO = 20, F_HI = 20000, SPAN = 54;
const DECAY = { slow: 12, medium: 28, fast: 70 };
let worker = null, read = null, pending = false, lastAsk = 0, lastT = 0, lastSeen = 0;
const st = { spec: null, disp: null, hold: null, holdAt: null, top: -12, shownTop: -12, quietSince: 0, live: false };

function ensure() {
  if (worker) return;
  worker = new Worker(new URL('./analyzer-worker.js', import.meta.url));
  worker.onmessage = (e) => { pending = false; if (e.data.spec) st.spec = e.data.spec; };
  read = reader(() => Viz.ring && Viz.ring(), { first: 8192 });
}
/** let the worker go when the style has not been drawn for a while */
function idle() { if (worker && performance.now() - lastSeen > 4000) { worker.terminate(); worker = null; read = null; st.spec = st.disp = null; } }
setInterval(idle, 5000);

/**
 * One frame of the strip, `points` wide: the newest samples to the worker, the next picture asked for, the
 * ballistics stepped. → the state to draw ({ disp, hold, top }) or null (no live samples: the fallback).
 */
export function step(now, points) {
  lastSeen = now;
  ensure();
  const got = read();
  if (got === false) { st.live = false; return null; }
  st.live = true;
  if (got) worker.postMessage({ type: 'push', frames: got.frames, ch: got.ch, sr: got.sr, lite: true }, [got.frames.buffer]);
  const o = { ...(settings.analyzer || {}) };
  if (!pending && now - lastAsk > 15) {
    pending = true; lastAsk = now;
    worker.postMessage({ type: 'frame', lite: true, res: 'medium', smooth: 6, tilt: Number.isFinite(+o.tilt) ? +o.tilt : 4.5, mode: 'sum', points });
  }
  const dt = Math.min(0.1, (now - (lastT || now)) / 1000); lastT = now;
  const s = st.spec;
  if (!s) return st.disp ? st : null;
  const n = s.length, fall = (DECAY[o.speed] || DECAY.medium) * dt;
  if (!st.disp || st.disp.length !== n) { st.disp = Float32Array.from(s); st.hold = Float32Array.from(s); st.holdAt = new Float64Array(n).fill(now); }
  let max = -Infinity;
  for (let i = 0; i < n; i++) {
    const v = s[i];
    st.disp[i] = v > st.disp[i] ? v : Math.max(v, st.disp[i] - fall);
    if (st.disp[i] > st.hold[i]) { st.hold[i] = st.disp[i]; st.holdAt[i] = now; }
    else if (now - st.holdAt[i] > 1200) st.hold[i] -= 6 * dt;
    if (st.disp[i] > max) max = st.disp[i];
  }
  // the top of the scale: a 6 dB step above the loudest band, at most 0 dB, at least −30
  if (Number.isFinite(max)) {
    const want = Math.max(-30, Math.min(6, Math.ceil((max + 3) / 6) * 6));
    if (want > st.top) { st.top = want; st.quietSince = 0; }
    else if (want < st.top) {
      if (!st.quietSince) st.quietSince = now;
      else if (now - st.quietSince > 4000) { st.top -= 6; st.quietSince = now; }
    } else st.quietSince = 0;
  }
  st.shownTop += (st.top - st.shownTop) * (1 - Math.exp(-dt / 0.25));   // a new step glides in a quarter of a second
  return st;
}
