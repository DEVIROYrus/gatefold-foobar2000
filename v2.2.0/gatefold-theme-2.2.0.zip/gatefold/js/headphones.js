/*
 * Gatefold · headphones.js — equalizer settings made for your headphones (Equalizer → «Наушники»).
 *
 * The database is AutoEq's (github.com/jaakkopasanen/AutoEq, MIT): thousands of headphone measurements, each
 * equalized to the target AutoEq recommends for its measurement rig. tools/eqdb/build.py turns them into three
 * settings per measurement — neutral, more bass, warmer — of a low shelf, a high shelf and eight bells (the same
 * filters as our equalizer), and publishes them on this repository's branch «eq-db»:
 *   v1/index.json     every model: id, name, form, the sources that measured it (~0.5 MB, read once a week)
 *   v1/m/<id>.json    one model: each measurement's curve, its target and the three settings (~3 kB, when picked)
 * Both come through jsDelivr (GitHub's raw files as a fallback) and are kept on this computer (IndexedDB): after
 * the first look everything works offline.
 *
 * The sheet: search (forgives spaces, dashes and the Russian keyboard layout), form chips, the model with its
 * curves (as measured · the target · with the setting), four settings («Мягкий» is the neutral one at half
 * strength), a strength slider, the source when several labs measured it, and «for this output device». Every
 * choice is heard at once; «Отмена» (or Esc) puts the equalizer back as it was, «Применить» keeps it.
 */
import { esc, log, call, ok } from './bridge.js';
import { h, icon, toast } from './ui.js';
import { $t, plural, num, locale } from './i18n.js';
import { settings, setSetting } from './settings.js';
import { fetchJSON } from './coverfetch.js';
import * as IDB from './idb.js';
import * as EQ from './eq.js';
import { onPalette } from './theme.js';

const BASES = ['https://cdn.jsdelivr.net/gh/DEVIROYrus/gatefold-foobar2000@eq-db/v1/', 'https://raw.githubusercontent.com/DEVIROYrus/gatefold-foobar2000/eq-db/v1/'];
const WEEK = 7 * 864e5;
const FORMS = () => ({ 'over-ear': $t('Накладные'), 'in-ear': $t('Внутриканальные'), earbud: $t('Вкладыши') });
export const RECIPES = () => [
  ['neutral', $t('Нейтральный'), $t('точно к цели'), 1],
  ['soft', $t('Мягкий'), $t('половина коррекции'), 0.5],
  ['bass', $t('Больше баса'), $t('+4 дБ снизу'), 1],
  ['warm', $t('Теплее'), $t('мягче верха'), 1],
];

/* ---------------------------------------------------------------- the database */
let index = null, indexP = null;
async function fetchAny(path) {
  for (const b of BASES) {
    const r = await fetchJSON(b + path);
    if (r.data) return r.data;
  }
  return null;
}
/** the list of models (from this computer when it is fresh, else from the network; the old copy if offline) */
export function loadIndex(force = false) {
  if (index && !force) return Promise.resolve(index);
  if (indexP) return indexP;
  indexP = (async () => {
    const kept = await IDB.kvGet('eqdb:index').catch(() => null);
    if (kept && kept.data && !force && Date.now() - kept.at < WEEK) return (index = prep(kept.data));
    const fresh = await fetchAny('index.json');
    if (fresh && Array.isArray(fresh.M)) { IDB.kvSet('eqdb:index', { at: Date.now(), data: fresh }).catch(() => {}); return (index = prep(fresh)); }
    return (index = kept && kept.data ? prep(kept.data) : null);
  })().finally(() => { indexP = null; });
  return indexP;
}
const compact = (s) => String(s || '').toLowerCase().normalize('NFKD').replace(/[̀-ͯ]/g, '').replace(/[^a-z0-9а-яё]+/g, '');
function prep(d) {
  d.list = d.M.map(([id, name, form, src]) => ({ id, name, form, src, key: compact(name), words: String(name).toLowerCase().split(/[^a-z0-9а-яё]+/i).filter(Boolean) }));
  return d;
}
/** one model, kept for good once read (a newer database reads it again) */
export async function loadModel(id) {
  const kept = await IDB.kvGet('eqdb:m:' + id).catch(() => null);
  if (kept && kept.data && (!index || kept.built === index.built)) return kept.data;
  const m = await fetchAny(`m/${encodeURIComponent(id)}.json`);
  if (m) { IDB.kvSet('eqdb:m:' + id, { built: index ? index.built : '', data: m }).catch(() => {}); return m; }
  return kept ? kept.data : null;
}

/* ---------------------------------------------------------------- search */
const RU = 'йцукенгшщзхъфывапролджэячсмитьбю', EN = "qwertyuiop[]asdfghjkl;'zxcvbnm,.";
const layout = (s) => s.replace(/[а-яё]/gi, (c) => { const i = RU.indexOf(c.toLowerCase()); return i >= 0 ? EN[i] : c; });
// brands as people write them in Russian, then letter by letter for the rest («аирподс» → airpods)
const BRANDS = [[/^(эпп?л|апп?л)/, 'apple'], [/^(аирподс|эйрподс|эирподс|айрподс)/, 'airpods'], [/^сон[иы]/, 'sony'], [/^(се?нн?хайзер|зе?нн?хайзер)/, 'sennheiser'],
  [/^(бе[йи]ердинамик|беердинамик)/, 'beyerdynamic'], [/^самсунг/, 'samsung'], [/^(сяоми|ксиаоми|шаоми)/, 'xiaomi'], [/^хуав[еэ]й/, 'huawei'], [/^(бо[уо]?зе?|боус)$/, 'bose'],
  [/^(джибиэль|жбл)$/, 'jbl'], [/^(аудио-?техника|аудиотехника)/, 'audio-technica'], [/^мундроп/, 'moondrop'], [/^(акг|акаге)$/, 'akg'], [/^(шур|шуре)$/, 'shure'],
  [/^(хайфайман|хифиман)/, 'hifiman'], [/^(фокал)/, 'focal'], [/^(маршалл?)/, 'marshall'], [/^(битс|битз)/, 'beats'], [/^(логитек|логитех)/, 'logitech'], [/^(стилсерис|стилсириес)/, 'steelseries'],
  [/^(хайпер[иь]кс|хайпер х)/, 'hyperx'], [/^(рейзер|разер)/, 'razer'], [/^(корсар)/, 'corsair'], [/^(кз)$/, 'kz'], [/^(трутир|тру ир)/, 'truthear'], [/^(фиио|фио)$/, 'fiio'], [/^(нотинг|нафинг)/, 'nothing']];
const TR = { а: 'a', б: 'b', в: 'v', г: 'g', д: 'd', е: 'e', ё: 'e', ж: 'zh', з: 'z', и: 'i', й: 'y', к: 'k', л: 'l', м: 'm', н: 'n', о: 'o', п: 'p', р: 'r', с: 's', т: 't', у: 'u', ф: 'f', х: 'h', ц: 'ts', ч: 'ch', ш: 'sh', щ: 'sch', ы: 'y', э: 'e', ю: 'yu', я: 'ya', ь: '', ъ: '' };
const translit = (s) => s.split(/\s+/).map((w) => { for (const [re, en] of BRANDS) if (re.test(w)) return en; return w.replace(/[а-яё]/g, (c) => TR[c] ?? c); }).join(' ');
/** models whose names hold every word of the query (spaces and dashes do not matter: «hd650» finds «HD 650») */
export function search(q, form = '') {
  if (!index) return [];
  const raw = String(q || '').trim().toLowerCase();
  const tries = [raw, layout(raw), translit(raw)].filter((v, i, a) => v && a.indexOf(v) === i);
  const pool = form ? index.list.filter((m) => m.form === form) : index.list;
  if (!raw) return [];
  let best = [];
  for (const t of tries) {
    const words = t.split(/\s+/).map(compact).filter(Boolean);
    const all = compact(t);
    const hit = pool.filter((m) => m.key.includes(all) || words.every((w) => m.key.includes(w)));
    if (hit.length > best.length) best = hit;
  }
  const first = compact(tries[0].split(/\s+/)[0]);
  return best.sort((a, b) => (b.key.startsWith(first) - a.key.startsWith(first)) || (a.name.length - b.name.length) || a.name.localeCompare(b.name)).slice(0, 150);
}

/* ---------------------------------------------------------------- a setting → our equalizer */
/** bands for the equalizer: the measurement's setting, at a strength (0…1) */
export function bandsFor(item, recipe, k = 1) {
  const s = item[recipe === 'soft' ? 'neutral' : recipe] || item.neutral;
  const kk = recipe === 'soft' ? 0.5 * k : k;
  return s.f.map(([type, freq, q, gain]) => ({ type, freq, q, gain: Math.round(gain * kk * 10) / 10, on: true }));
}
export function stateFor(model, item, recipe, k = 1) {
  const bands = bandsFor(item, recipe, k);
  const peak = EQ.peakDb(bands);
  const label = `${model.name} · ${(RECIPES().find((r) => r[0] === recipe) || [])[1] || ''}`;
  // headroom: «Без перегрузки» (autoGain) already lowers the level by the curve's highest lift — a preamp of our
  // own on top would take it twice (−6.5 dB became −12.7 dB); without it the preamp is the headroom
  const auto = !!(EQ.state() && EQ.state().autoGain);
  return { mode: 'parametric', bands, preamp: auto ? 0 : Math.max(-12, Math.round(-(peak + 0.1) * 2) / 2) + 0, enabled: true, preset: 'hp:' + label };
}

/* ---------------------------------------------------------------- following the output device */
const snap = (s) => ({ mode: s.mode, graphic: (s.graphic || []).slice(), bands: (s.bands || []).map((b) => ({ ...b })), preamp: s.preamp, preset: s.preset || '', enabled: !!s.enabled });
// the device the sound went to when last looked at — kept, so a device changed while foobar2000 was closed counts too
let lastDevice = settings.eqHpLast || null, watchT = 0;
const setLast = (id) => { lastDevice = id; if (settings.eqHpLast !== id) setSetting('eqHpLast', id); };
async function currentDevice() {
  try { const r = await call('config.getOutputConfig'); if (!ok(r) || !r.outputId) return null; return { id: `${r.outputId}|${r.deviceId}`, name: r.deviceName || r.outputName || '' }; } catch { return null; }
}
/** settings.eqHpByDevice: device → equalizer; switching to such a device applies it, leaving it puts back the rest */
async function checkDevice() {
  const map = settings.eqHpByDevice || {};
  if (!Object.keys(map).length || !EQ.state()) return;
  const d = await currentDevice(); if (!d) return;
  if (d.id === lastDevice) return;
  const was = lastDevice; setLast(d.id);
  if (was === null) return;   // the first look ever: the equalizer as it is belongs to this device
  // leaving a device: what you set on it (a tweak in the equalizer after «Применить» too) is kept for it
  if (map[was]) setSetting('eqHpByDevice', { ...map, [was]: snap(EQ.state()) });
  else setSetting('eqHpOther', snap(EQ.state()));
  const next = (settings.eqHpByDevice || {})[d.id];
  if (next) { EQ.set(next, true); toast($t('Эквалайзер для «{0}»', esc(d.name || '—'))); }
  else if (map[was] && settings.eqHpOther) EQ.set(settings.eqHpOther, true);
}
/** the output device was just changed here (Settings → foobar2000): look now, not in up to 8 s */
export function nudge() { if (Object.keys(settings.eqHpByDevice || {}).length) setTimeout(checkDevice, 300); }
export function watch() {
  clearInterval(watchT);
  watchT = setInterval(checkDevice, 8000);
  setTimeout(checkDevice, 3000);
}

/* ---------------------------------------------------------------- the sheet */
let sheet = null;
export async function open() {
  if (sheet) return;
  if (!EQ.state()) await EQ.load();
  if (!EQ.state()) { toast($t('Эквалайзер недоступен в этой версии компонента')); return; }
  const before = snap(EQ.state());
  const S = { form: settings.eqHpForm || '', model: null, item: 0, recipe: 'neutral', k: 1, results: [], token: 0, kept: false, device: null };
  sheet = h(`<div class="eq-veil hp-veil" role="dialog" aria-modal="true" aria-label="${esc($t('Наушники'))}">
    <div class="eq-sheet hp-sheet">
      <div class="eq-head">
        <div class="eq-title"><b>${$t('Наушники')}</b><small class="hp-db"></small></div>
        <button class="btn icon eq-close" aria-label="${$t('Закрыть')}">${icon('x', 18)}</button>
      </div>
      <div class="hp-body">
        <div class="hp-left">
          <label class="search hp-search">${icon('search', 16)}<input type="search" spellcheck="false" autocomplete="off"></label>
          <div class="hp-forms"></div>
          <div class="hp-list" role="listbox"></div>
        </div>
        <div class="hp-right"><div class="hp-empty"></div></div>
      </div>
      <div class="hp-foot"><small class="hp-credit"></small></div>
    </div></div>`);
  document.getElementById('layer').append(sheet);
  requestAnimationFrame(() => sheet && sheet.classList.add('in'));   // at once: the database may take a while to come
  const $s = (q) => sheet.querySelector(q);
  const input = $s('.hp-search input');
  input.placeholder = $t('Модель, например HD 650 или AirPods');
  $s('.hp-credit').innerHTML = `${$t('Данные')}: <a href="#" data-u="https://github.com/jaakkopasanen/AutoEq">AutoEq</a> (MIT) · ${$t('измерения')}: oratory1990, Rtings, Innerfidelity, HypetheSonics ${$t('и другие')}`;
  $s('.hp-credit a').onclick = (e) => { e.preventDefault(); call('shell.openExternal', { url: e.currentTarget.dataset.u }); };

  const close = (keep) => {
    if (!sheet) return;
    if (!keep) EQ.set(before, true);
    const s = sheet; sheet = null;
    document.removeEventListener('keydown', onKey, true);
    ro.disconnect(); offPal();
    s.classList.remove('in'); s.classList.add('out');
    setTimeout(() => s.remove(), 220);
  };
  const onKey = (e) => {
    if (!sheet) return;
    // Esc closes an open list (the source of the measurements) first, the sheet only after
    if (e.key === 'Escape' && !document.querySelector('#layer .menu')) { e.preventDefault(); e.stopPropagation(); close(false); }
    // Tab stays in the sheet (the equalizer under it is not reachable while this is open)
    if (e.key === 'Tab') {
      const f = [...sheet.querySelectorAll('button, input, select, a[href], [tabindex]:not([tabindex="-1"])')].filter((x) => !x.disabled && x.offsetParent && !x.closest('[hidden]') && !x.classList.contains('sel-native'));
      if (!f.length) return;
      const i = f.indexOf(document.activeElement);
      if (e.shiftKey && i <= 0) { e.preventDefault(); f[f.length - 1].focus(); }
      else if (!e.shiftKey && (i === f.length - 1 || i < 0)) { e.preventDefault(); f[0].focus(); }
    }
  };
  document.addEventListener('keydown', onKey, true);
  $s('.eq-close').onclick = () => close(false);
  sheet.addEventListener('mousedown', (e) => { if (e.target === sheet) close(false); });

  // form chips
  const forms = $s('.hp-forms');
  const paintForms = () => {
    forms.innerHTML = [['', $t('Все')], ...Object.entries(FORMS())].map(([k, l]) => `<button class="chip${S.form === k ? ' on' : ''}" data-f="${k}">${esc(l)}</button>`).join('');
    forms.querySelectorAll('[data-f]').forEach((b) => { b.onclick = () => { S.form = b.dataset.f; setSetting('eqHpForm', S.form); paintForms(); list(); }; });
  };
  paintForms();

  // the list: results, or the models you chose before
  const listBox = $s('.hp-list');
  const row = (m) => `<button class="hp-row${S.model && S.model.id === m.id ? ' on' : ''}" data-id="${esc(m.id)}" role="option"><b></b><small>${esc(FORMS()[m.form] || m.form)} · ${esc($t('измерений: {0}', m.src.length))}</small></button>`;
  const list = () => {
    const q = input.value;
    const recent = (settings.eqHpRecent || []).map((id) => index && index.list.find((m) => m.id === id)).filter(Boolean).filter((m) => !S.form || m.form === S.form);
    const items = q.trim() ? search(q, S.form) : recent;
    S.results = items;
    if (!index) { listBox.innerHTML = `<div class="hp-note">${esc($t('Нет связи с базой — проверьте интернет'))}</div>`; return; }
    listBox.innerHTML = (q.trim() ? '' : (items.length ? `<div class="hp-cap">${esc($t('Недавние'))}</div>` : `<div class="hp-note">${esc($t('Начните вводить название модели'))}</div>`))
      + (q.trim() && !items.length ? `<div class="hp-note">${esc($t('Ничего не нашлось'))}</div>` : '') + items.map(row).join('');
    listBox.querySelectorAll('.hp-row').forEach((b, i) => { b.querySelector('b').textContent = items[i].name; b.onclick = () => pick(items[i]); });
  };
  let tt = 0;
  input.addEventListener('input', () => { clearTimeout(tt); tt = setTimeout(list, 90); });
  input.addEventListener('keydown', (e) => {
    e.stopPropagation();
    if (e.key === 'Enter' && S.results[0]) pick(S.results[0]);
    if (e.key === 'ArrowDown') { e.preventDefault(); listBox.querySelector('.hp-row')?.focus(); }
  });
  listBox.addEventListener('keydown', (e) => {
    const b = e.target.closest('.hp-row'); if (!b) return;
    if (e.key === 'ArrowDown') { e.preventDefault(); b.nextElementSibling?.focus(); }
    if (e.key === 'ArrowUp') { e.preventDefault(); (b.previousElementSibling?.classList.contains('hp-row') ? b.previousElementSibling : input).focus(); }
  });

  // the right side
  const right = $s('.hp-right');
  const hear = () => { if (S.model) EQ.set(stateFor(S.model, S.model.items[S.item], S.recipe, S.k), true); };
  const detail = () => {
    const m = S.model; if (!m) return;
    const it = m.items[S.item];
    right.innerHTML = `
      <div class="hp-title"><div><b></b><small></small></div>
        ${m.items.length > 1 ? `<label class="hp-src"><span>${esc($t('Измерения'))}</span><select class="st-input"></select></label>` : `<small class="hp-src1"></small>`}</div>
      <div class="hp-graph"><canvas></canvas></div>
      <div class="hp-legend"><span class="l-fr">${esc($t('как звучат'))}</span><span class="l-tg">${esc($t('цель'))}</span><span class="l-eq">${esc($t('с настройкой'))}</span></div>
      <div class="hp-recipes">${RECIPES().map(([id, t, sub]) => `<button class="hp-rc${S.recipe === id ? ' on' : ''}" data-r="${id}"><b>${esc(t)}</b><small>${esc(sub)}</small></button>`).join('')}</div>
      <div class="hp-k"><span>${esc($t('Сила'))}</span><input type="range" class="range" min="0" max="100" step="5"><b></b></div>
      <div class="hp-acts">
        <label class="hp-dev"><input type="checkbox"><span></span></label><span class="grow"></span>
        <button class="btn icon eq-ab hp-ab" title="${esc($t('Удерживайте, чтобы послушать без эквалайзера'))}">A/B</button>
        <button class="btn hp-cancel">${esc($t('Отмена'))}</button>
        <button class="btn primary hp-apply">${esc($t('Применить'))}</button>
      </div>`;
    right.querySelector('.hp-title b').textContent = m.name;
    right.querySelector('.hp-title small').textContent = `${FORMS()[m.form] || m.form} · ${$t('цель')}: ${it.target}`;
    const sel = right.querySelector('.hp-src select');
    if (sel) {
      sel.innerHTML = m.items.map((x, i) => `<option value="${i}"${i === S.item ? ' selected' : ''}>${esc(x.s + (x.rig ? ' · ' + x.rig : ''))}</option>`).join('');
      sel.onchange = () => { S.item = +sel.value; detail(); hear(); };
    } else right.querySelector('.hp-src1').textContent = it.s + (it.rig ? ' · ' + it.rig : '');
    right.querySelectorAll('.hp-rc').forEach((b) => { b.onclick = () => { S.recipe = b.dataset.r; right.querySelectorAll('.hp-rc').forEach((x) => x.classList.toggle('on', x === b)); draw(); hear(); }; });
    const kr = right.querySelector('.hp-k input'), kb = right.querySelector('.hp-k b');
    const paintK = () => { kr.value = Math.round(S.k * 100); kr.style.setProperty('--p', kr.value + '%'); kb.textContent = kr.value + '%'; };
    paintK();
    let kt = 0;
    kr.oninput = () => { S.k = +kr.value / 100; paintK(); draw(); clearTimeout(kt); kt = setTimeout(hear, 60); };
    // this output device
    const dev = right.querySelector('.hp-dev');
    if (S.device) { dev.querySelector('span').textContent = $t('Для «{0}»', S.device.name || $t('этого устройства')); dev.querySelector('input').checked = !!(settings.eqHpByDevice || {})[S.device.id] || !Object.keys(settings.eqHpByDevice || {}).length; }
    else dev.hidden = true;
    // A/B: held — the music without the equalizer
    const ab = right.querySelector('.hp-ab');
    const abUp = () => { if (!ab.classList.contains('on')) return; ab.classList.remove('on'); EQ.set({ enabled: true }, true); };
    ab.addEventListener('pointerdown', (e) => { e.preventDefault(); ab.classList.add('on'); EQ.set({ enabled: false }, true); });
    ab.addEventListener('pointerup', abUp); ab.addEventListener('pointerleave', abUp);
    ab.addEventListener('keydown', (e) => { if ((e.key === ' ' || e.key === 'Enter') && !e.repeat) { e.preventDefault(); ab.classList.add('on'); EQ.set({ enabled: false }, true); } });
    ab.addEventListener('keyup', (e) => { if (e.key === ' ' || e.key === 'Enter') { e.preventDefault(); abUp(); } });
    ab.addEventListener('blur', abUp);
    right.querySelector('.hp-cancel').onclick = () => close(false);
    right.querySelector('.hp-apply').onclick = () => {
      const s = stateFor(m, m.items[S.item], S.recipe, S.k);
      EQ.set(s, true);
      setSetting('eqHpRecent', [m.id, ...(settings.eqHpRecent || []).filter((x) => x !== m.id)].slice(0, 8));
      setSetting('eqHp', { id: m.id, name: m.name, item: S.item, recipe: S.recipe, k: S.k });
      if (S.device) {
        const map = { ...(settings.eqHpByDevice || {}) };
        if (dev.querySelector('input').checked) {
          map[S.device.id] = snap(s); setLast(S.device.id);
          // what plays on the other devices: the equalizer as it was before (a plain one if that was a headphone tuning too)
          const mine = String(before.preset || '').startsWith('hp:');
          if (!mine) setSetting('eqHpOther', before);
          else if (!settings.eqHpOther) setSetting('eqHpOther', { ...before, enabled: false });
        } else delete map[S.device.id];
        setSetting('eqHpByDevice', map);
        if (Object.keys(map).length) watch();
      }
      close(true);
      toast($t('Эквалайзер настроен для «{0}»', esc(m.name)));
    };
    draw();
  };

  // the curves: as measured (grey), the target (dashed), with the setting (accent); all at the database's 48 points
  const draw = () => {
    const cv = right.querySelector('.hp-graph canvas'); if (!cv || !S.model) return;
    const it = S.model.items[S.item], F = index.F;
    const dpr = window.devicePixelRatio || 1, w = cv.clientWidth, hh = cv.clientHeight;
    cv.width = Math.round(w * dpr); cv.height = Math.round(hh * dpr);
    const x = cv.getContext('2d'); x.setTransform(dpr, 0, 0, dpr, 0, 0); x.clearRect(0, 0, w, hh);
    const eq = EQ.curve(bandsFor(it, S.recipe, S.k), F);
    const withEq = it.fr.map((v, i) => v + eq[i]);
    const all = [...it.fr, ...it.tg, ...withEq].filter((v) => v > -30);
    const mid = (Math.max(...all) + Math.min(...all)) / 2, R = Math.max(12, (Math.max(...all) - Math.min(...all)) / 2 + 2);
    const X = (i) => 34 + (Math.log(F[i] / F[0]) / Math.log(F[F.length - 1] / F[0])) * (w - 42);
    const Y = (v) => hh / 2 - ((v - mid) / R) * (hh / 2 - 10);
    const cs = getComputedStyle(sheet);
    const col = (n, f) => cs.getPropertyValue(n).trim() || f;
    x.font = `11px ${col('--font-ui', 'sans-serif')}`; x.fillStyle = col('--text-3', '#888'); x.strokeStyle = col('--line', 'rgba(127,127,127,.25)'); x.lineWidth = 1;
    for (const f of [100, 1000, 10000]) { const i = Math.log(f / F[0]) / Math.log(F[F.length - 1] / F[0]) * (w - 42) + 34; x.beginPath(); x.moveTo(i, 6); x.lineTo(i, hh - 16); x.stroke(); x.fillText(f >= 1000 ? f / 1000 + 'k' : String(f), i + 3, hh - 4); }
    for (const v of [-10, 0, 10]) { const y = Y(mid + v); if (y < 6 || y > hh - 16) continue; x.globalAlpha = 0.55; x.beginPath(); x.moveTo(34, y); x.lineTo(w - 8, y); x.stroke(); x.globalAlpha = 1; x.fillText((v > 0 ? '+' : '') + v, 4, y + 4); }
    const line = (arr, color, width, dash) => { x.beginPath(); x.setLineDash(dash || []); x.strokeStyle = color; x.lineWidth = width; arr.forEach((v, i) => (i ? x.lineTo(X(i), Y(v)) : x.moveTo(X(i), Y(v)))); x.stroke(); x.setLineDash([]); };
    line(it.fr, col('--text-3', '#888'), 1.5);
    line(it.tg, col('--text-2', '#aaa'), 1.2, [5, 4]);
    line(withEq, col('--accent', '#e07a5f'), 2.2);
  };

  // the window changes size: the curves are drawn again for the new size (not stretched)
  const ro = new ResizeObserver(() => draw());
  ro.observe(right);
  // new colours (a new track, a theme): the curves take them (the canvas does not follow CSS by itself)
  const offPal = onPalette(() => requestAnimationFrame(draw));

  const pick = async (m, quiet = false) => {
    const tk = ++S.token;
    S.model = null; S.item = 0;
    listBox.querySelectorAll('.hp-row').forEach((b) => b.classList.toggle('on', b.dataset.id === m.id));
    right.innerHTML = `<div class="hp-empty"><span class="spinner"></span></div>`;
    const data = await loadModel(m.id);
    if (tk !== S.token || !sheet) return;
    if (!data) { right.innerHTML = `<div class="hp-empty">${esc($t('Не удалось загрузить — проверьте интернет'))}</div>`; return; }
    S.model = { ...data, id: m.id };
    const was = settings.eqHp && settings.eqHp.id === m.id ? settings.eqHp : null;
    if (was) { S.item = Math.min(was.item || 0, data.items.length - 1); S.recipe = was.recipe || 'neutral'; S.k = was.k ?? 1; }
    detail(); if (!quiet) hear();
  };

  // start: the database, the device, and the model you chose last time
  $s('.hp-empty').innerHTML = `<span class="spinner"></span>`;
  input.focus();
  const [idx, dev] = await Promise.all([loadIndex(), currentDevice()]);
  if (!sheet) return;
  S.device = dev;
  const built = idx && /^\d{4}-\d\d-\d\d$/.test(idx.built) ? new Date(idx.built + 'T12:00:00').toLocaleDateString(locale, { day: 'numeric', month: 'long', year: 'numeric' }) : (idx && idx.built) || '';
  $s('.hp-db').textContent = idx ? `${num(idx.list.length)} ${plural(idx.list.length, 'модель', 'модели', 'моделей')} · ${$t('база от {0}', built)}` : $t('База недоступна');
  right.innerHTML = `<div class="hp-empty">${esc(idx ? $t('Выберите свою модель слева') : $t('Нет связи с базой — проверьте интернет'))}</div>`;
  list();
  if (settings.eqHp && idx) { const m = idx.list.find((x) => x.id === settings.eqHp.id); if (m) pick(m, true); }
}
export const isOpen = () => !!sheet;
