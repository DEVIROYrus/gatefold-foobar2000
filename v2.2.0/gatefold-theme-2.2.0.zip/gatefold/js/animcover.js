/*
 * Gatefold · animcover.js — covers that move (Reddit 15.11): a GIF beside the music.
 *
 * foobar2000 hands out covers as still pictures (it scales them, and a scaled GIF is its first frame). A cover.gif
 * (folder.gif, front.gif… or the only GIF there) in the album's folder — or in the folder above its disc folders —
 * is shown as it is, moving, on «Сейчас играет» and on the album page. The grid and the colours keep the still one.
 * Settings → Appearance turns it off.
 */
import { call, ok, dirOfTrack } from './bridge.js';
import { settings } from './settings.js';

const memo = new Map();   // folder → address of its GIF ('' = none)
const NAMED = /^(cover|folder|front|album|animated|artwork)\b[^\\/]*\.gif$/i;
const dirOf = (p) => String(p || '').replace(/[\\/][^\\/]*$/, '');

async function gifIn(dir) {
  if (!dir) return '';
  if (memo.has(dir)) return memo.get(dir);
  const r = await call('gf:art.folderImages', { folder: dir });
  const gifs = ok(r) ? (r.images || []).filter((i) => /\.gif$/i.test(i.name)) : [];
  const pick = gifs.find((i) => NAMED.test(i.name)) || (gifs.length === 1 ? gifs[0] : null);
  const url = pick ? pick.url : '';
  memo.set(dir, url);
  return url;
}

/** the moving cover of a track's album, or '' */
export async function gifFor(path) {
  if (settings.animatedCovers === false) return '';
  const dir = dirOfTrack(path);
  const own = await gifIn(dir).catch(() => '');
  if (own) return own;
  // an album in disc folders keeps its cover in the folder above them
  const up = dirOf(dir);
  return up && up !== dir ? gifIn(up).catch(() => '') : '';
}
/** after a library change the folders may hold other pictures */
export const forget = () => memo.clear();
