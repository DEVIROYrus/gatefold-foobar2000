/*
 * Gatefold · genretools.js — two things done to a genre from its menu (right click on a genre in the sidebar list
 * or in the genre list of the Library):
 *
 * · «Change genre on all its albums…»: the genre is renamed in the files of every album that has it. Only that
 *   value of a track's GENRE changes — «Hip Hop; Electronic» becomes «Rap; Electronic» — and a name that is already
 *   a genre merges the two. What will change is shown first; nothing is written before «Apply». foobar2000 writes
 *   the files (its progress window, its own report of a file it could not change).
 * · «Make a sub-genre…»: the genre is put under another one (a new name makes a new parent): the parent's albums
 *   then include its children's. A setting only, no file is touched.
 *
 * The caller (library.js) gives the albums and their tracks: this module does not import library.js.
 */
import { call, ok, esc } from './bridge.js';
import { h, icon, toast } from './ui.js';
import { $t } from './i18n.js';

const SEP = '\u001e';
const split = (s) => String(s || '').split(/\s*[;/,]\s*/).map((g) => g.trim()).filter(Boolean);
const lc = (s) => String(s || '').trim().toLowerCase();
const handleOf = (t) => t.handle || (t.subsong ? `${t.absolutePath || t.path}|subsong:${t.subsong}` : (t.absolutePath || t.path));
const refOf = (hd) => { const m = /^(.*)\|subsong:(\d+)$/.exec(hd); return m ? { path: m[1], subsong: +m[2] } : { path: hd }; };

/** a track's genre values with `from` replaced by `to` (once, keeping the others and their order); null: no change */
export function renamed(values, from, to) {
  const f = lc(from), out = [];
  let hit = false;
  for (const v of values) {
    const x = lc(v) === f ? (hit = true, to) : v;
    if (!out.some((o) => lc(o) === lc(x))) out.push(x);
  }
  return hit ? out : null;
}

function sheet(title) {
  const veil = h(`<div class="upd-veil gt-veil"><div class="upd-sheet gt-sheet" role="dialog" aria-modal="true">
    <button class="icon-btn upd-x" title="${esc($t('Закрыть'))}">${icon('x', 16)}</button>
    <div class="upd-head"><div><h3></h3></div></div><div class="gt-body"></div></div></div>`);
  veil.querySelector('h3').textContent = title;
  let done = null;
  const closed = new Promise((r) => { done = r; });
  const close = (v) => { if (!done) return; veil.classList.remove('on'); setTimeout(() => veil.remove(), 220); const d = done; done = null; d(v); };
  veil.addEventListener('click', (e) => { if (e.target === veil || e.target.closest('.upd-x')) close(false); });
  veil.addEventListener('keydown', (e) => { e.stopPropagation(); if (e.key === 'Escape') { e.preventDefault(); close(false); } });
  document.body.append(veil);
  requestAnimationFrame(() => veil.classList.add('on'));
  return { veil, body: veil.querySelector('.gt-body'), close, closed };
}
const datalist = (id, names) => `<datalist id="${id}">${names.map((g) => `<option value="${esc(g)}">`).join('')}</datalist>`;

/** rename a genre in the files of its albums. deps: albums() → the library's albums having it (their own genre),
    tracks(album) → its tracks, genres → all genre names (suggestions). Resolves true when files were written. */
export async function rename(genre, { albums, tracks, genres = [] }) {
  const list = await albums();
  const nTracks = list.reduce((n, a) => n + (a.trackCount || 0), 0);
  const S = sheet($t('Сменить жанр: {0}', genre));
  S.body.innerHTML = `<p class="gt-p"></p><p class="gt-count"></p>
    <label class="gt-label">${esc($t('Новый жанр'))}<input class="st-input gt-input" list="gt-names" spellcheck="false" autocomplete="off"></label>${datalist('gt-names', genres.filter((g) => lc(g) !== lc(genre)))}
    <p class="gt-merge" hidden></p>
    <div class="upd-acts"><button class="btn primary gt-apply">${esc($t('Применить'))}</button><button class="btn gt-cancel">${esc($t('Отмена'))}</button></div>`;
  S.body.querySelector('.gt-p').textContent = $t('«{0}» заменится новым жанром во всех файлах этих альбомов; остальные жанры треков останутся. Ничего не записывается, пока вы не нажмёте «Применить».', genre);
  S.body.querySelector('.gt-count').textContent = $t('Альбомов: {0} · треков: {1}', list.length, nTracks);
  const inp = S.body.querySelector('.gt-input'), apply = S.body.querySelector('.gt-apply'), merge = S.body.querySelector('.gt-merge');
  inp.value = genre;
  const sync = () => {
    const v = inp.value.trim();
    apply.disabled = !v || v === genre || !list.length;
    const into = genres.find((g) => lc(g) === lc(v) && lc(g) !== lc(genre));
    merge.hidden = !into;
    if (into) merge.textContent = $t('Такой жанр уже есть: альбомы «{0}» добавятся к «{1}».', genre, into);
  };
  inp.oninput = sync; sync();
  inp.onkeydown = (e) => { e.stopPropagation(); if (e.key === 'Enter' && !apply.disabled) apply.click(); if (e.key === 'Escape') S.close(false); };
  S.body.querySelector('.gt-cancel').onclick = () => S.close(false);
  apply.onclick = async () => {
    const to = inp.value.trim(); if (!to || to === genre) return;
    apply.disabled = true; inp.disabled = true;
    const stage = h(`<p class="gt-stage"></p>`); S.body.querySelector('.upd-acts').before(stage);
    // the tracks, and each one's genre values as the file has them (not the album's summary)
    const all = [];
    for (let i = 0; i < list.length; i++) {
      stage.textContent = $t('Читаю альбомы… {0} из {1}', i + 1, list.length);
      for (const t of await tracks(list[i]).catch(() => [])) all.push(handleOf(t));
    }
    const items = [];
    for (let i = 0; i < all.length; i += 2000) {
      const part = all.slice(i, i + 2000);
      const r = await call('titleformat.evalFieldsBatch', { paths: part, fields: { g: `[$meta_sep(genre,'${SEP}')]` } });
      const rows = ok(r) ? r.results || [] : [];
      // «Rock; Pop» kept as one value is two genres too
      part.forEach((hd, k) => { const vals = String((rows[k] && rows[k].g) || '').split(SEP).flatMap(split); const nv = renamed(vals, genre, to); if (nv) items.push({ track: refOf(hd), set: { GENRE: nv } }); });
    }
    if (!items.length) { stage.textContent = $t('Менять нечего: у треков нет жанра «{0}».', genre); apply.disabled = false; inp.disabled = false; return; }
    stage.textContent = $t('Записываю… {0} треков', items.length);
    let status = 'done';
    for (let i = 0; i < items.length && status === 'done'; i += 5000) {
      const w = await call('gf:tags.write', { items: items.slice(i, i + 5000) });
      status = ok(w) ? w.status : 'failed';
    }
    if (status !== 'done') { toast(status === 'aborted' ? $t('Запись тегов остановлена') : $t('foobar2000 не записал теги: {0}', esc(status))); S.close(status !== 'failed'); return; }
    toast($t('Жанр «{0}» → «{1}»: {2} треков', esc(genre), esc(to), items.length));
    S.close(true);
  };
  requestAnimationFrame(() => { inp.focus(); inp.select(); });
  return S.closed;
}

/** choose the parent of a genre (free text: a new name makes a new parent). Resolves the parent, '' for none,
    null when closed */
export async function parent(genre, { current = '', genres = [] }) {
  const S = sheet($t('Сделать поджанром: {0}', genre));
  S.body.innerHTML = `<p class="gt-p"></p>${current ? `<p class="gt-count"></p>` : ''}
    <label class="gt-label">${esc($t('Родительский жанр'))}<input class="st-input gt-input" list="gt-parents" spellcheck="false" autocomplete="off"></label>${datalist('gt-parents', genres)}
    <div class="upd-acts"><button class="btn primary gt-set">${esc($t('Задать родителя'))}</button>${current ? `<button class="btn gt-clear">${esc($t('Без родителя'))}</button>` : ''}<button class="btn gt-cancel">${esc($t('Отмена'))}</button></div>`;
  S.body.querySelector('.gt-p').textContent = $t('Альбомы «{0}» будут показаны и в родительском жанре. Файлы не меняются. Новое имя создаст новый родительский жанр.', genre);
  if (current) S.body.querySelector('.gt-count').textContent = $t('Сейчас — в «{0}».', current);
  const inp = S.body.querySelector('.gt-input'), set = S.body.querySelector('.gt-set');
  inp.value = current;
  const sync = () => { const v = inp.value.trim(); set.disabled = !v || lc(v) === lc(current) || lc(v) === lc(genre); };
  inp.oninput = sync; sync();
  inp.onkeydown = (e) => { e.stopPropagation(); if (e.key === 'Enter' && !set.disabled) set.click(); if (e.key === 'Escape') S.close(null); };
  set.onclick = () => S.close(inp.value.trim());
  S.body.querySelector('.gt-clear')?.addEventListener('click', () => S.close(''));
  S.body.querySelector('.gt-cancel').onclick = () => S.close(null);
  requestAnimationFrame(() => inp.focus());
  return S.closed.then((v) => (v === false ? null : v));
}
