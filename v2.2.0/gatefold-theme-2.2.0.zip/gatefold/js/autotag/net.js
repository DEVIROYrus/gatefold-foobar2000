/*
 * Gatefold · autotag/net.js — MusicBrainz and AcoustID, asked the way they ask to be asked.
 *
 * MusicBrainz: one request a second for the whole of Gatefold's autotagging (their limit), a User-Agent
 * that says who asks, a pause and another try on 503 (busy). Answers kept for two weeks (IndexedDB), so a
 * second look at an album, or the whole library again, costs nothing.
 * AcoustID: three lookups a second (their limit), Gatefold's own application key.
 * Both through foobar2000's HTTP client (no CORS, the header that names us).
 */
import { httpGet, httpPost, ok } from '../bridge.js';
import { VERSION } from '../version.js';
import * as IDB from '../idb.js';

const UA = `Gatefold/${VERSION} (https://github.com/DEVIROYrus/gatefold-foobar2000)`;
export const ACOUSTID_KEY = '8eim0CUjDF';
const MB = 'https://musicbrainz.org/ws/2/';
const TTL = 14 * 86400e3;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

/* a queue that keeps requests apart */
function pacer(gap) {
  let last = 0, chain = Promise.resolve();
  return (fn) => {
    const run = chain.then(async () => { const w = last + gap - Date.now(); if (w > 0) await sleep(w); last = Date.now(); return fn(); });
    chain = run.catch(() => {});
    return run;
  };
}
const mbPace = pacer(1100), aidPace = pacer(350);

export class NetError extends Error { constructor(msg, code) { super(msg); this.code = code; } }

/** a MusicBrainz web service answer (JSON); path like 'release/<id>?inc=…' (fmt=json is added) */
export async function mb(path, { cache = true, signal } = {}) {
  const url = MB + path + (path.includes('?') ? '&' : '?') + 'fmt=json';
  const key = 'at.mb.' + url;
  if (cache) { try { const c = await IDB.kvGet(key); if (c && Date.now() - c.t < TTL) return c.v; } catch {} }
  for (let attempt = 0; ; attempt++) {
    if (signal?.aborted) throw new NetError('stopped', 'ABORT');
    const r = await mbPace(() => httpGet({ url, timeout: 30000, headers: { 'User-Agent': UA, Accept: 'application/json' } }));
    const status = r.status || 0;
    if (ok(r) && status >= 200 && status < 300) {
      let v; try { v = typeof r.body === 'string' ? JSON.parse(r.body) : r.body; } catch { throw new NetError('MusicBrainz: not JSON', 'BAD'); }
      if (cache) IDB.kvSet(key, { t: Date.now(), v }).catch(() => {});
      return v;
    }
    if (status === 404) return null;
    if ((status === 503 || status === 429 || status === 0 || status >= 500) && attempt < 4) { await sleep(1500 * 2 ** attempt); continue; }
    throw new NetError(`MusicBrainz: ${status || r.error || 'network'}`, status ? 'HTTP' : 'NET');
  }
}

/** the whole release, everything a tag can take from it */
export const RELEASE_INC = 'recordings+artist-credits+labels+release-groups+media+isrcs+genres+artists';
export const release = (id, o) => mb(`release/${id}?inc=${RELEASE_INC}`, o);
/** releases found by a Lucene query (MusicBrainz search) */
export const searchReleases = (q, limit = 15, o) => mb(`release/?query=${encodeURIComponent(q)}&limit=${limit}`, o);
/** a release group's genres (the album's, voted by MusicBrainz users) */
export const releaseGroup = (id, o) => mb(`release-group/${id}?inc=genres`, o);

/** Lucene's special characters, escaped; the value in quotes */
export const q = (s) => '"' + String(s || '').replace(/([+\-!(){}[\]^"~*?:\\/]|&&|\|\|)/g, '\\$1') + '"';

/**
 * AcoustID: the recordings a fingerprint is, with the releases they are on.
 * → [{ score, recordings: [{ id, releases: [ids] }] }]
 */
export async function acoustid(fp, duration, { signal } = {}) {
  const body = `client=${ACOUSTID_KEY}&format=json&meta=recordingids+releaseids&duration=${Math.round(duration)}&fingerprint=${encodeURIComponent(fp)}`;
  for (let attempt = 0; ; attempt++) {
    if (signal?.aborted) throw new NetError('stopped', 'ABORT');
    const r = await aidPace(() => httpPost({ url: 'https://api.acoustid.org/v2/lookup', body, timeout: 30000,
      headers: { 'User-Agent': UA, 'Content-Type': 'application/x-www-form-urlencoded', Accept: 'application/json' } }));
    const status = r.status || 0;
    let j = null; try { j = typeof r.body === 'string' ? JSON.parse(r.body) : r.body; } catch {}
    if (j && j.status === 'ok') {
      return (j.results || []).map((x) => ({ score: x.score || 0, id: x.id,
        recordings: (x.recordings || []).map((rec) => ({ id: rec.id, releases: (rec.releases || []).map((rl) => (typeof rl === 'string' ? rl : rl.id)).filter(Boolean) })) }));
    }
    if (j && j.error) {
      if (j.error.code === 14 /* rate */ && attempt < 3) { await sleep(1000 * (attempt + 1)); continue; }
      throw new NetError(`AcoustID: ${j.error.message || j.error.code}`, j.error.code === 4 ? 'KEY' : 'API');
    }
    if ((status === 0 || status >= 500) && attempt < 3) { await sleep(1500 * 2 ** attempt); continue; }
    throw new NetError(`AcoustID: ${status || r.error || 'network'}`, 'NET');
  }
}
