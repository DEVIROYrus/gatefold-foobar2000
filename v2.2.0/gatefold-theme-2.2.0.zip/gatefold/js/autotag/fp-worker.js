/*
 * Gatefold · autotag/fp-worker.js — the fingerprint computed off the interface thread.
 * In: { id, pcm: Int16Array (mono, 11025 Hz) } → out: { id, fp, n }
 */
import { fingerprint } from './chromaprint.js';

self.onmessage = (e) => {
  const { id, pcm } = e.data;
  try { const r = fingerprint(pcm); self.postMessage({ id, fp: r.fp, n: r.raw.length }); }
  catch (err) { self.postMessage({ id, error: String(err && err.message || err) }); }
};
