/*
 * Gatefold · autotag/ui.js — tags from MusicBrainz for an album, or for the whole library, nothing written unseen.
 *
 *  · one album (its menu → «Найти теги в MusicBrainz…»): the release found, how sure, the other editions,
 *    every change «было → станет» with a tick per field and per track, then «Записать»;
 *  · many albums (Settings → «Автотеги», or several albums chosen): each one looked up in the background,
 *    sorted into «уверенно / проверить / не найдено»; the sure ones written in one go, any of them opened;
 *  · whatever was written can be put back (the files' old values are kept: «Вернуть как было»).
 */
import { call, ok, esc } from '../bridge.js';
import { h, icon, toast } from '../ui.js';
import { $t, plural } from '../i18n.js';
import { settings, setSetting } from '../settings.js';
import * as IDB from '../idb.js';
import * as E from './engine.js';
import * as S from './score.js';

const LABEL = () => ({
  TITLE: $t('Название'), ARTIST: $t('Исполнитель'), ALBUM: $t('Альбом'), ALBUMARTIST: $t('Исполнитель альбома'), DATE: $t('Год'),
  TRACKNUMBER: $t('Номер'), TOTALTRACKS: $t('Всего треков'), DISCNUMBER: $t('Диск'), TOTALDISCS: $t('Всего дисков'), DISCSUBTITLE: $t('Название диска'),
  ORIGINALDATE: $t('Дата первого выпуска'), LABEL: $t('Лейбл'), CATALOGNUMBER: $t('Каталожный номер'), BARCODE: $t('Штрихкод'),
  RELEASECOUNTRY: $t('Страна издания'), RELEASETYPE: $t('Тип релиза'), RELEASESTATUS: $t('Статус релиза'), MEDIA: $t('Носитель'),
  ARTISTS: $t('Исполнители (списком)'), ARTISTSORT: $t('Исполнитель для сортировки'), ALBUMARTISTSORT: $t('Исполнитель альбома для сортировки'),
  ISRC: 'ISRC', GENRE: $t('Жанр'), COMMENT: $t('Комментарий'), DESCRIPTION: $t('Описание'),
  MUSICBRAINZ_ALBUMID: 'MusicBrainz Album Id', MUSICBRAINZ_RELEASEGROUPID: 'MusicBrainz Release Group Id', MUSICBRAINZ_ALBUMARTISTID: 'MusicBrainz Album Artist Id',
  MUSICBRAINZ_ARTISTID: 'MusicBrainz Artist Id', MUSICBRAINZ_TRACKID: 'MusicBrainz Recording Id', MUSICBRAINZ_RELEASETRACKID: 'MusicBrainz Track Id', ACOUSTID_ID: 'AcoustID',
});
const GROUP_LABEL = () => ({ main: $t('Основное'), release: $t('Издание'), sort: $t('Сортировка'), isrc: 'ISRC', genre: $t('Жанры'), ids: $t('Идентификаторы'), clean: $t('Убрать лишнее') });
const DEFAULT_GROUPS = ['main', 'release', 'sort', 'isrc', 'ids'];
// «Убрать лишнее» is its own setting (on unless turned off): a group list saved before it existed does not turn it off
const groupsOn = () => [...(Array.isArray(settings.autotagGroups) ? settings.autotagGroups : DEFAULT_GROUPS).filter((g) => g !== 'clean'), ...(settings.autotagClean === false ? [] : ['clean'])];
const STEP = () => ({ search: $t('Ищу альбом в MusicBrainz…'), read: $t('Сравниваю издания…'), listen: $t('Слушаю треки (AcoustID)…'), nokey: $t('AcoustID не принял ключ — ищу по тегам') });
const VERDICT = () => ({ sure: $t('Уверенно'), check: $t('Проверьте'), weak: $t('Похоже, не то'), none: $t('Не найдено') });
const fmtLen = (s) => (s > 0 ? `${Math.floor(s / 60)}:${String(Math.round(s % 60)).padStart(2, '0')}` : '—');
const pct = (x) => Math.round(Math.max(0, Math.min(1, x)) * 100) + '%';
const yearOf = (d) => (/^(\d{4})/.exec(d || '') || [])[1] || '';
const mbUrl = (id) => `https://musicbrainz.org/release/${id}`;

/* ---------------------------------------------------------------- what an album is looked up as */
async function load(a, tracks) {
  if (!tracks) { const L = await import('../library.js'); tracks = await L.albumTracks(a); }
  tracks = (tracks || []).filter((t) => /^[a-z]:[\\/]|^\\\\/i.test(String(t.absolutePath || t.path || t.handle || '')));
  if (!tracks.length) return null;
  return E.readAlbum(tracks, a);
}
/** one album looked up (cached for the batch) */
async function lookup(album, opts) {
  const r = await E.match(album, opts);
  let genres = [];
  if (r.best && groupsOn().includes('genre')) genres = await E.genresOf(r.best.release).catch(() => []);
  return { ...r, genres, chosen: r.best };
}
function build(album, res, cand) {
  const clean = groupsOn().includes('clean');
  if (!cand) return clean ? E.cleanupOnly(album) : [];            // not found: the clean-up alone
  const props = E.proposals(album, cand, { genres: res.genres });
  const fields = E.FIELDS.filter((f) => groupsOn().includes(E.groupOf(f)) && E.groupOf(f) !== 'clean');
  const keepFilled = settings.autotagKeep === 'all' ? E.FIELDS : settings.autotagKeep === 'none' ? [] : ['GENRE'];
  const rows = E.diff(album, props, { fields, keepFilled, cand });
  // the release's own names win; what it leaves (or «only empty fields» keeps) is cleaned of leftovers
  if (clean) for (const r of rows) r.changes.push(...E.cleanup(album, r.i, new Set(r.changes.map((c) => c.f))));
  return rows;
}

/* ---------------------------------------------------------------- writing, and putting back */
const JOURNAL = 'at.journal';
/** writes the ticked changes; keeps what the files had (for «Вернуть как было») → number of tracks written or -1 */
export async function write(album, rows, title = '') {
  const items = [], undo = [];
  for (const r of rows) {
    const t = album.tracks[r.i];
    const set = {}, back = {};
    for (const c of r.changes) { if (c.skip) continue; set[c.f] = !c.to.length ? null : c.to.length === 1 ? c.to[0] : c.to; back[c.f] = c.from.length ? (c.from.length === 1 ? c.from[0] : c.from) : null; }
    if (!Object.keys(set).length) continue;
    items.push({ track: E.refOf(t.handle), set }); undo.push({ h: t.handle, set: back });
  }
  if (!items.length) return 0;
  const w = await call('gf:tags.write', { items });
  if (!ok(w) || w.status !== 'done') {
    toast(w && w.status === 'aborted' ? $t('Запись тегов остановлена') : $t('foobar2000 не записал теги: {0}', esc((w && (w.error || w.status)) || '?')));
    return -1;
  }
  const j = (await IDB.kvGet(JOURNAL, [])) || [];
  j.unshift({ id: Date.now().toString(36), t: Date.now(), title: title || album.title, items: undo });
  await IDB.kvSet(JOURNAL, j.slice(0, 200));
  return items.length;
}
export const journal = async () => (await IDB.kvGet(JOURNAL, [])) || [];
/** the files of one journal entry back as they were */
export async function undo(id) {
  const j = await journal(); const e = j.find((x) => x.id === id); if (!e) return false;
  const w = await call('gf:tags.write', { items: e.items.map((x) => ({ track: E.refOf(x.h), set: x.set })) });
  if (!ok(w) || w.status !== 'done') { toast($t('foobar2000 не записал теги: {0}', esc((w && (w.error || w.status)) || '?'))); return false; }
  await IDB.kvSet(JOURNAL, j.filter((x) => x.id !== id));
  toast($t('Теги «{0}» возвращены как были', esc(e.title)));
  return true;
}
const undoToast = (title, n, id) => toast($t('Теги записаны: «{0}», {1} {2}', esc(title), n, plural(n, 'трек', 'трека', 'треков')),
  { ms: 9000, action: { label: $t('Вернуть'), fn: () => undo(id) } });

/* ---------------------------------------------------------------- one album: the review */
let sheetOpen = null;
/** the review of one album; res: an earlier lookup (from the batch), else looked up now. Resolves true when written. */
export async function open(a, tracks = null, res = null, album = null) {
  if (sheetOpen) sheetOpen.close();
  return new Promise((resolve) => {
    let wrote = false, rows = [], cand = null, closed = false;
    const veil = h(`<div class="upd-veil at-veil"><div class="upd-sheet at-sheet" role="dialog" aria-modal="true" aria-label="${esc($t('Теги из MusicBrainz'))}">
      <button class="icon-btn upd-x" title="${esc($t('Закрыть'))}">${icon('x', 16)}</button>
      <div class="at-head"><h3>${esc($t('Теги из MusicBrainz'))}</h3><div class="sub"></div></div>
      <div class="at-body"><div class="at-wait"><span class="spinner"></span><span class="at-step"></span></div></div>
      <div class="at-foot"><span class="at-note"></span><button type="button" class="btn at-cancel">${esc($t('Закрыть'))}</button><button type="button" class="btn primary at-write" disabled>${esc($t('Записать'))}</button></div>
    </div></div>`);
    const $ = (q) => veil.querySelector(q);
    const ctrl = new AbortController();
    const close = () => {
      if (closed) return; closed = true; sheetOpen = null; ctrl.abort();
      document.removeEventListener('keydown', onKey, true);
      veil.classList.remove('on'); setTimeout(() => veil.remove(), 220); resolve(wrote);
    };
    const onKey = (e) => { if (e.key === 'Escape' && !document.querySelector('#layer .menu')) { e.preventDefault(); e.stopPropagation(); close(); } };
    document.addEventListener('keydown', onKey, true);
    veil.addEventListener('click', (e) => { if (e.target === veil || e.target.closest('.upd-x, .at-cancel')) close(); });
    document.body.append(veil); sheetOpen = { close };
    requestAnimationFrame(() => veil.classList.add('on'));

    const count = () => rows.reduce((s, r) => s + (r.off ? 0 : r.changes.filter((c) => !c.skip).length), 0);
    const paintCount = () => { const n = count(); const b = $('.at-write'); b.disabled = !n; b.textContent = n ? $t('Записать {0} {1}', n, plural(n, 'изменение', 'изменения', 'изменений')) : $t('Нечего записывать'); };

    /* album-wide changes: one row per field (ticked for every track at once) */
    const albumRows = (abox) => {
      const byField = new Map();
      for (const r of rows) for (const c of r.changes) { if (!byField.has(c.f)) byField.set(c.f, []); byField.get(c.f).push({ r, c }); }
      const perTrack = new Set(['TITLE', 'ARTIST', 'TRACKNUMBER', 'ISRC', 'MUSICBRAINZ_TRACKID', 'MUSICBRAINZ_RELEASETRACKID', 'ACOUSTID_ID', 'ARTISTS', 'ARTISTSORT', 'MUSICBRAINZ_ARTISTID', 'DISCNUMBER', 'TOTALTRACKS', 'DISCSUBTITLE', 'MEDIA']);
      const albumFields = [...byField.keys()].filter((f) => !perTrack.has(f) || new Set(byField.get(f).map((x) => x.c.to.join('; '))).size === 1 && !['TITLE', 'TRACKNUMBER', 'ISRC', 'MUSICBRAINZ_TRACKID', 'MUSICBRAINZ_RELEASETRACKID', 'ACOUSTID_ID'].includes(f));
      if (albumFields.length) {
        abox.innerHTML = `<div class="at-cap">${esc($t('Для всего альбома'))}</div>`;
        for (const f of albumFields) {
          const list = byField.get(f);
          const from = [...new Set(list.map((x) => x.c.from.join('; ')))];
          const row = h(`<label class="at-f"><input type="checkbox"><span class="k"></span><span class="v"><s></s><b></b></span></label>`);
          const cb = row.querySelector('input'); cb.checked = list.every((x) => !x.c.skip);
          row.querySelector('.k').textContent = LABEL()[f] || f;
          row.querySelector('s').textContent = from.length > 1 ? $t('‹разные›') : from[0] || $t('пусто');
          row.querySelector('b').textContent = list[0].c.to.length ? list[0].c.to.join('; ') : $t('убрать');
          if (!list[0].c.to.length) row.classList.add('rm');
          if (list[0].c.clean) row.classList.add('cl');
          if (list.some((x) => x.c.off)) row.title = $t('Другое письмо: включите, если хотите название как на MusicBrainz');
          cb.onchange = () => { for (const x of list) x.c.skip = !cb.checked; paintCount(); };
          abox.append(row);
        }
      }
    };
    const render = () => {
      const body = $('.at-body');
      if (!res.best) {
        body.innerHTML = `<div class="at-none"><b>${esc($t('Альбом не нашёлся в MusicBrainz'))}</b><p>${esc($t('Проверьте название и исполнителя в тегах или укажите релиз сами: ссылку на него или его MBID.'))}</p></div><div class="at-album"></div><div class="at-tracks"></div>`;
        if (rows.length) {
          body.querySelector('.at-none p').textContent += ' ' + $t('Лишнее из тегов можно убрать и без него:');
          albumRows(body.querySelector('.at-album'));
          const tbox = body.querySelector('.at-tracks');
          tbox.innerHTML = `<div class="at-cap">${esc($t('Треки'))}</div>`;
          for (const r of rows) {
            const t = album.tracks[r.i], tc = r.changes.find((c) => c.f === 'TITLE');
            const row = h(`<label class="at-t"><input type="checkbox" checked><span class="n"></span><span class="tt"><s></s><b></b><i></i></span><span class="len"></span></label>`);
            row.querySelector('.n').textContent = t.no || '—';
            if (tc) { row.querySelector('s').textContent = tc.from.join('; '); row.querySelector('b').textContent = tc.to.join('; '); }
            else row.querySelector('b').textContent = t.title || t.handle.split(/[\\/]/).pop();
            row.querySelector('.len').textContent = fmtLen(t.length);
            const cb = row.querySelector('input'); cb.onchange = () => { r.off = !cb.checked; paintCount(); };
            tbox.append(row);
          }
        }
        body.append(manualBox()); paintCount(); return;
      }
      const rel = cand.release, rgDate = rel['release-group']?.['first-release-date'];
      const v = cand === res.best ? res.verdict : S.verdict(cand.score, 1);
      const labels = (rel['label-info'] || []).map((l) => [l.label?.name, l['catalog-number']].filter(Boolean).join(' · ')).filter(Boolean);
      const fmts = [...new Set((rel.media || []).map((m) => m.format).filter(Boolean))];
      const p = cand.parts || {};
      const why = [[$t('треки'), p.tracks], [$t('название'), p.album], [$t('исполнитель'), p.artist], [$t('число треков'), p.count], [$t('длительность'), p.length], ...(p.fp != null ? [[$t('по звуку'), p.fp]] : [])];
      body.innerHTML = `
        <div class="at-rel">
          <div class="at-rel-main"><b class="at-rel-t"></b><span class="at-rel-a"></span>
            <span class="at-rel-meta"></span></div>
          <div class="at-score ${v}"><b>${esc(VERDICT()[v])}</b><span>${pct(cand.score)}</span></div>
        </div>
        <div class="at-why">${why.map(([k, x]) => `<span class="${x >= 0.9 ? 'g' : x >= 0.6 ? 'm' : 'b'}">${esc(k)} ${pct(x)}</span>`).join('')}</div>
        <label class="at-ed"><span>${esc($t('Издание'))}</span><select class="st-input"></select></label>
        <div class="at-groups"></div>
        <div class="at-album"></div>
        <div class="at-tracks"></div>`;
      $('.at-rel-t').textContent = rel.title + (rel.disambiguation ? ` (${rel.disambiguation})` : '');
      $('.at-rel-a').textContent = S.creditName(rel['artist-credit']);
      $('.at-rel-meta').innerHTML = [yearOf(rel.date) && (rel.date + (rgDate && yearOf(rgDate) !== yearOf(rel.date) ? ' · ' + $t('впервые {0}', yearOf(rgDate)) : '')), rel.country, fmts.join(' + '), labels[0], `${cand.rt.length} ${plural(cand.rt.length, 'трек', 'трека', 'треков')}`]
        .filter(Boolean).map((x) => `<span>${esc(x)}</span>`).join('') + `<a href="#" class="at-mb">${esc($t('Открыть в MusicBrainz'))}</a>`;
      $('.at-mb').onclick = (e) => { e.preventDefault(); call('shell.openExternal', { url: mbUrl(rel.id) }); };
      // the editions (and other albums) found
      const sel = $('.at-ed select');
      res.candidates.slice(0, 20).forEach((c, k) => {
        const r = c.release, f = [...new Set((r.media || []).map((m) => m.format).filter(Boolean))].join('+');
        const o = new Option(`${r.title} — ${[r.country, r.date, f, (r['label-info'] || [])[0]?.label?.name].filter(Boolean).join(' · ')} · ${c.rt.length} · ${pct(c.score)}`, String(k));
        if (c === cand) o.selected = true; sel.append(o);
      });
      sel.onchange = () => { cand = res.candidates[+sel.value]; rows = build(album, res, cand); render(); };
      // the kinds of fields
      const gbox = $('.at-groups');
      for (const [g] of E.GROUPS) {
        const b = h(`<button type="button" class="chip${groupsOn().includes(g) ? ' on' : ''}" aria-pressed="${groupsOn().includes(g)}"></button>`);
        b.textContent = GROUP_LABEL()[g];
        b.onclick = async () => {
          const on = new Set(groupsOn()); on.has(g) ? on.delete(g) : on.add(g);
          if (g === 'clean') setSetting('autotagClean', on.has('clean'));
          else setSetting('autotagGroups', E.GROUPS.map(([x]) => x).filter((x) => on.has(x) && x !== 'clean'));
          if (g === 'genre' && on.has('genre') && !res.genres.length) res.genres = await E.genresOf(cand.release).catch(() => []);
          rows = build(album, res, cand); render();
        };
        gbox.append(b);
      }
      albumRows($('.at-album'));
      // the tracks: title and number changes, one row each
      const tbox = $('.at-tracks');
      tbox.innerHTML = `<div class="at-cap">${esc($t('Треки'))}</div>`;
      const mineIdx = new Map(rows.map((r) => [r.i, r]));
      album.tracks.forEach((t, i) => {
        const r = mineIdx.get(i);
        const rt = r ? cand.rt[r.j] : null;
        const tc = r?.changes.find((c) => c.f === 'TITLE');
        const nc = r?.changes.find((c) => c.f === 'TRACKNUMBER');
        const row = h(`<label class="at-t${r ? '' : ' none'}${r?.flag ? ' ' + r.flag : ''}"><input type="checkbox"${r ? '' : ' disabled'}><span class="n"></span><span class="tt"><s></s><b></b><i></i></span><span class="len"></span></label>`);
        const cb = row.querySelector('input');
        row.querySelector('.n').textContent = rt ? `${cand.rt.some((x) => x.disc > 1) ? rt.disc + '-' : ''}${rt.no}` : '—';
        if (nc) row.querySelector('.n').title = $t('Было: {0}', nc.from.join() || '—');
        if (tc) { row.querySelector('s').textContent = tc.from.join('; ') || $t('без названия'); row.querySelector('b').textContent = tc.to.join('; '); }
        else row.querySelector('b').textContent = rt ? rt.title : t.title || t.handle.split(/[\\/]/).pop();
        const why = !r ? $t('Нет в этом издании — не меняется') : r.flag === 'sound' ? $t('По звуку это «{0}» — название в тегах другое', rt.title)
          : r.flag === 'unsure' ? $t('Ни название, ни длительность не совпадают — проверьте') : r.changes.length ? '' : $t('Без изменений');
        row.querySelector('i').textContent = why;
        // the length is the file's and is never written (it is not a tag): MusicBrainz's own, when it differs, only
        // beside it, for comparing — not «was → becomes» as the tags are
        const len = row.querySelector('.len');
        len.textContent = fmtLen(t.length);
        if (rt && rt.length && Math.abs(rt.length - t.length) > 2) {
          const mb = document.createElement('span');
          mb.className = 'mb'; mb.textContent = `MB ${fmtLen(rt.length)}`;
          mb.title = $t('Длительность в MusicBrainz — для сверки, в файл не пишется');
          len.append(mb);
        }
        if (r) {
          if (r.flag === 'unsure' && r.off === undefined) r.off = true;
          cb.checked = !r.off && r.changes.length > 0; cb.disabled = !r.changes.length;
          cb.onchange = () => { r.off = !cb.checked; paintCount(); };
        }
        tbox.append(row);
      });
      body.append(manualBox());
      paintCount();
    };

    /* another release by hand: a link, an MBID, or words to search */
    const manualBox = () => {
      const box = h(`<form class="at-manual"><input class="st-input" spellcheck="false"><button class="btn sm" type="submit"></button></form>`);
      box.querySelector('input').placeholder = $t('Другой релиз: ссылка MusicBrainz, MBID или поиск');
      box.querySelector('button').textContent = $t('Найти');
      box.onsubmit = async (e) => {
        e.preventDefault();
        const v = box.querySelector('input').value.trim(); if (!v) return;
        const id = (/([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})/i.exec(v) || [])[1];
        waiting($t('Ищу…'));
        try {
          const Net = await import('./net.js');
          const rels = [];
          if (id) { const r = await Net.release(id, { signal: ctrl.signal }); if (r) rels.push(r); }
          else {
            const s = await Net.searchReleases(v, 10, { signal: ctrl.signal });
            for (const x of (s?.releases || []).slice(0, 5)) { const r = await Net.release(x.id, { signal: ctrl.signal }); if (r) rels.push(r); }
          }
          const extra = rels.map((rel) => ({ release: rel, why: 'manual', ...S.scoreRelease(album, rel, { fpRecordings: album.tracks.some((t) => t.recordings) ? true : null }) }));
          if (!extra.length) { toast($t('Ничего не нашлось')); render(); return; }
          res.candidates = [...extra, ...res.candidates.filter((c) => !extra.some((x) => x.release.id === c.release.id))];
          if (!res.best) { res.best = extra[0]; res.verdict = S.verdict(extra[0].score, 1); }
          cand = extra[0]; rows = build(album, res, cand); render();
        } catch (err) { if (!closed) { toast($t('MusicBrainz не ответил: {0}', esc(err.message || ''))); render(); } }
      };
      return box;
    };
    const waiting = (text) => { $('.at-body').innerHTML = `<div class="at-wait"><span class="spinner"></span><span class="at-step"></span></div>`; $('.at-step').textContent = text; };

    $('.at-write').onclick = async () => {
      const btn = $('.at-write'); btn.disabled = true;
      const use = rows.filter((r) => !r.off).map((r) => ({ ...r, changes: r.changes.filter((c) => !c.skip) }));
      const n = await write(album, use, album.title);
      btn.disabled = false;
      if (n > 0) { wrote = true; const j = await journal(); undoToast(album.title, n, j[0].id); close(); }
      else if (n === 0) close();
    };

    (async () => {
      try {
        if (!album) { waiting($t('Читаю теги…')); album = await load(a, tracks); }
        if (!album) { toast($t('Теги можно менять только у файлов')); close(); return; }
        $('.sub').textContent = `${album.title || $t('Без названия')} · ${album.artist || album.trackArtist || $t('Неизвестный исполнитель')} · ${album.tracks.length} ${plural(album.tracks.length, 'трек', 'трека', 'треков')}`;
        if (!res) { waiting(STEP().search); res = await lookup(album, { signal: ctrl.signal, onStep: (s) => !closed && $('.at-step') && ($('.at-step').textContent = STEP()[s] || '') }); }
        if (closed) return;
        cand = res.chosen || res.best;
        rows = build(album, res, cand || null);
        // a change to another script, proposed but not ticked
        for (const r of rows) for (const c of r.changes) if (c.off) c.skip = true;
        render();
      } catch (e) {
        if (closed || e.code === 'ABORT') return;
        $('.at-body').innerHTML = `<div class="upd-err"></div>`; $('.upd-err').textContent = $t('Не получилось: {0}', e.message || String(e));
      }
    })();
  });
}

/* ---------------------------------------------------------------- many albums */
let batch = null;
/** where the library check is: null when none is running; the toolbar button shows it (event «gf:autotag») */
let status = null;
export const batchStatus = () => status;
const tell = (st) => { status = st; try { window.dispatchEvent(new CustomEvent('gf:autotag', { detail: st })); } catch { /* old */ } };
/** the whole library (or the albums given), looked up one after another; the review of each on a click */
export async function openBatch(albums = null) {
  if (batch) { batch.show(); return; }
  if (!albums) { const L = await import('../library.js'); albums = await L.getAllAlbums(); }
  const items = albums.map((a) => ({ a, state: 'wait', res: null, album: null, n: 0 }));
  const ctrl = { stop: false, paused: false };
  const veil = h(`<div class="upd-veil at-veil"><div class="upd-sheet at-sheet at-batch" role="dialog" aria-modal="true" aria-label="${esc($t('Автотеги'))}">
    <button class="icon-btn upd-x" title="${esc($t('Свернуть'))}">${icon('x', 16)}</button>
    <div class="at-head"><h3>${esc($t('Автотеги'))}</h3><div class="sub"></div></div>
    <div class="at-filter"></div>
    <div class="at-list" role="list"></div>
    <div class="at-foot"><span class="at-note"></span><button type="button" class="btn at-pause"></button><button type="button" class="btn primary at-sure" disabled></button></div>
  </div></div>`);
  const $ = (q) => veil.querySelector(q);
  let filter = 'all';
  const KINDS = () => [['all', $t('Все')], ['sure', $t('Уверенно')], ['check', $t('Проверить')], ['none', $t('Не найдено')], ['same', $t('Без изменений')], ['done', $t('Записано')]];
  const kind = (it) => (it.state === 'done' ? 'done' : it.state !== 'ready' ? 'wait' : !it.res?.best ? 'none' : it.n === 0 ? 'same' : it.res.verdict === 'sure' ? 'sure' : it.res.verdict === 'check' ? 'check' : 'none');
  const paint = () => {
    const counts = {}; for (const it of items) { const k = kind(it); counts[k] = (counts[k] || 0) + 1; }
    const done = items.filter((it) => it.state !== 'wait' && it.state !== 'busy').length;
    $('.sub').textContent = done < items.length ? $t('Проверено {0} из {1}', done, items.length) + (ctrl.paused ? ' · ' + $t('пауза') : '') : $t('Проверено: {0} {1}', items.length, plural(items.length, 'альбом', 'альбома', 'альбомов'));
    $('.at-filter').replaceChildren(...KINDS().map(([k, l]) => {
      const b = h(`<button type="button" class="chip${filter === k ? ' on' : ''}"></button>`);
      b.textContent = `${l} ${k === 'all' ? items.length : counts[k] || 0}`; b.onclick = () => { filter = k; paint(); }; return b;
    }));
    const list = $('.at-list'); list.replaceChildren();
    for (const it of items) {
      const k = kind(it); if (filter !== 'all' && k !== filter) continue;
      const row = h(`<button type="button" class="at-row ${k}" role="listitem"><span class="dot"></span><span class="t"><b></b><small></small></span><span class="s"></span></button>`);
      row.querySelector('b').textContent = it.a.name || $t('Без названия');
      const rel = it.res?.best?.release;
      row.querySelector('small').textContent = it.a.albumArtist || '';
      row.querySelector('.s').textContent = it.state === 'busy' ? $t('ищу…') : it.state === 'wait' ? '' : it.state === 'error' ? $t('ошибка') : k === 'done' ? $t('записано') : !rel ? (it.n ? $t('не найдено · лишнее: {0}', it.n) : $t('не найдено'))
        : `${it.n} ${plural(it.n, 'изменение', 'изменения', 'изменений')} · ${pct(it.res.best.score)}`;
      if (it.state === 'ready' || it.state === 'done') row.onclick = async () => {
        const w = await open(it.a, null, it.res, it.album);
        if (w) { it.state = 'done'; paint(); report(); }
      };
      list.append(row);
    }
    const sure = items.filter((it) => kind(it) === 'sure');
    $('.at-sure').disabled = !sure.length;
    $('.at-sure').textContent = $t('Записать уверенные ({0})', sure.length);
    $('.at-pause').textContent = done >= items.length ? $t('Готово') : ctrl.paused ? $t('Продолжить') : $t('Пауза');
  };
  const report = () => {
    const done = items.filter((it) => it.state !== 'wait' && it.state !== 'busy').length;
    const sure = items.filter((it) => kind(it) === 'sure').length;
    tell(batch ? { done, total: items.length, sure, paused: ctrl.paused, finished: done >= items.length } : null);
  };
  const run = async () => {
    for (const it of items) {
      report();
      while (ctrl.paused && !ctrl.stop) await new Promise((r) => setTimeout(r, 400));
      if (ctrl.stop) return;
      if (it.state !== 'wait') continue;
      it.state = 'busy'; if (visible) paint();
      try {
        it.album = await load(it.a);
        if (!it.album) { it.state = 'ready'; it.res = { best: null, candidates: [] }; continue; }
        it.res = await lookup(it.album, {});
        {
          const rows = build(it.album, it.res, it.res.best || null);   // not found: the clean-up alone
          for (const r of rows) for (const c of r.changes) if (c.off) c.skip = true;
          it.rows = rows;
          it.n = rows.reduce((s, r) => s + (r.flag === 'unsure' ? 0 : r.changes.filter((c) => !c.skip).length), 0);
        }
        it.state = 'ready';
      } catch { it.state = 'error'; }
      if (visible) paint();
    }
    if (visible) paint();
    report();
    if (!visible) toast($t('Автотеги: проверено {0} {1}', items.length, plural(items.length, 'альбом', 'альбома', 'альбомов')), { ms: 8000, action: { label: $t('Открыть'), fn: () => batch && batch.show() } });
  };
  let visible = true;
  const hide = () => { visible = false; veil.classList.remove('on'); setTimeout(() => veil.remove(), 220); document.removeEventListener('keydown', onKey, true); };
  const onKey = (e) => { if (e.key === 'Escape' && !document.querySelector('.at-sheet:not(.at-batch)')) { e.preventDefault(); e.stopPropagation(); hide(); } };
  const show = () => { if (visible) return; visible = true; document.body.append(veil); document.addEventListener('keydown', onKey, true); paint(); requestAnimationFrame(() => veil.classList.add('on')); };
  veil.addEventListener('click', (e) => { if (e.target === veil || e.target.closest('.upd-x')) hide(); });
  $('.at-pause').onclick = () => {
    const done = items.every((it) => it.state !== 'wait' && it.state !== 'busy');
    if (done) { ctrl.stop = true; batch = null; report(); hide(); return; }
    ctrl.paused = !ctrl.paused; paint(); report();
  };
  $('.at-sure').onclick = async () => {
    const sure = items.filter((it) => kind(it) === 'sure');
    $('.at-sure').disabled = true;
    let tracks = 0, albumsN = 0;
    for (const it of sure) {
      const use = it.rows.filter((r) => r.flag !== 'unsure').map((r) => ({ ...r, changes: r.changes.filter((c) => !c.skip) }));
      const n = await write(it.album, use, it.album.title);
      if (n > 0) { it.state = 'done'; tracks += n; albumsN++; }
      if (n < 0) break;
    }
    paint(); report();
    if (albumsN) toast($t('Теги записаны: {0} {1}, {2} {3}', albumsN, plural(albumsN, 'альбом', 'альбома', 'альбомов'), tracks, plural(tracks, 'трек', 'трека', 'треков')));
  };
  batch = { show };
  document.body.append(veil); document.addEventListener('keydown', onKey, true);
  paint(); requestAnimationFrame(() => veil.classList.add('on'));
  run();
}
