/*
 * Gatefold · autotag/chromaprint.js — the AcoustID fingerprint of a piece of audio.
 *
 * A port of Chromaprint's own code (© Lukas Lalinsky, MIT licence — the part of Chromaprint that is MIT:
 * the FFT front end, chroma, the chroma filter, the classifiers and the fingerprint compressor; the
 * LGPL resampler is not used: foobar2000 hands the audio over already at 11025 Hz, mono).
 * Algorithm 2 («TEST2», Chromaprint's default — the one AcoustID's database is made of).
 *
 * In:  Int16Array (or any array of 16-bit sample values) — mono, 11025 Hz, ideally the first 120 s.
 * Out: { raw: Uint32Array (sub-fingerprints), fp: the compressed, URL-safe Base64 string AcoustID takes }.
 *
 * Checked against libchromaprint itself (tools/check.mjs → tests/fixtures/chromaprint).
 */
const SAMPLE_RATE = 11025, FRAME = 4096, STEP = FRAME - (FRAME - ((FRAME / 3) | 0));   // 1365
const MIN_FREQ = 28, MAX_FREQ = 3520, BANDS = 12;
const FILTER_COEF = [0.25, 0.75, 1.0, 0.75, 0.25];
// TEST2 classifiers: [filter type, y, height, width, t0, t1, t2]
const CLASSIFIERS = [
  [0, 4, 3, 15, 1.98215, 2.35817, 2.63523], [4, 4, 6, 15, -1.03809, -0.651211, -0.282167],
  [1, 0, 4, 16, -0.298702, 0.119262, 0.558497], [3, 8, 2, 12, -0.105439, 0.0153946, 0.135898],
  [3, 4, 4, 8, -0.142891, 0.0258736, 0.200632], [4, 0, 3, 5, -0.826319, -0.590612, -0.368214],
  [1, 2, 2, 9, -0.557409, -0.233035, 0.0534525], [2, 7, 3, 4, -0.0646826, 0.00620476, 0.0784847],
  [2, 6, 2, 16, -0.192387, -0.029699, 0.215855], [2, 1, 3, 2, -0.0397818, -0.00568076, 0.0292026],
  [5, 10, 1, 15, -0.53823, -0.369934, -0.190235], [3, 6, 2, 10, -0.124877, 0.0296483, 0.139239],
  [2, 1, 1, 14, -0.101475, 0.0225617, 0.231971], [3, 5, 6, 4, -0.0799915, -0.00729616, 0.063262],
  [1, 9, 2, 12, -0.272556, 0.019424, 0.302559], [3, 4, 2, 14, -0.164292, -0.0321188, 0.0846339],
];
const MAX_W = Math.max(...CLASSIFIERS.map((c) => c[3]));   // 16
const GRAY = [0, 1, 3, 2];

/* ---- a real FFT of 4096 points (radix-2, double precision), the power spectrum out */
const N = FRAME, LOG = 12;
const rev = new Uint16Array(N);
for (let i = 0; i < N; i++) { let r = 0; for (let b = 0; b < LOG; b++) r |= ((i >> b) & 1) << (LOG - 1 - b); rev[i] = r; }
const cosT = new Float64Array(N / 2), sinT = new Float64Array(N / 2);
for (let i = 0; i < N / 2; i++) { cosT[i] = Math.cos(2 * Math.PI * i / N); sinT[i] = -Math.sin(2 * Math.PI * i / N); }
const window = new Float64Array(N);
for (let i = 0; i < N; i++) window[i] = (0.54 - 0.46 * Math.cos(i * 2 * Math.PI / (N - 1))) / 32767;
const re = new Float64Array(N), im = new Float64Array(N);
function power(samples, off, out) {
  for (let i = 0; i < N; i++) { const j = rev[i]; re[j] = samples[off + i] * window[i]; im[j] = 0; }
  for (let size = 2; size <= N; size <<= 1) {
    const half = size >> 1, step = N / size;
    for (let s = 0; s < N; s += size) {
      for (let k = 0, t = 0; k < half; k++, t += step) {
        const a = s + k, b = a + half, wr = cosT[t], wi = sinT[t];
        const xr = re[b] * wr - im[b] * wi, xi = re[b] * wi + im[b] * wr;
        re[b] = re[a] - xr; im[b] = im[a] - xi; re[a] += xr; im[a] += xi;
      }
    }
  }
  for (let i = 0; i <= N / 2; i++) out[i] = re[i] * re[i] + im[i] * im[i];
}

/* ---- which of the 12 notes each FFT bin belongs to */
const minIdx = Math.max(1, Math.round(FRAME * MIN_FREQ / SAMPLE_RATE));
const maxIdx = Math.min(FRAME / 2, Math.round(FRAME * MAX_FREQ / SAMPLE_RATE));
const notes = new Int8Array(FRAME);
for (let i = minIdx; i < maxIdx; i++) {
  const freq = i * SAMPLE_RATE / FRAME, oct = Math.log(freq / (440 / 16)) / Math.log(2);
  notes[i] = Math.trunc(BANDS * (oct - Math.floor(oct)));
}

const subtractLog = (a, b) => Math.log((1 + a) / (1 + b));

/** the raw fingerprint: one 32-bit number per ~124 ms */
function raw(samples) {
  const n = samples.length;
  const spec = new Float64Array(FRAME / 2 + 1);
  const ring = []; let rows = 0;
  const integral = [];          // rows of 12 cumulative sums (the integral image)
  const out = [];
  const area = (r1, c1, r2, c2) => {
    if (r1 === r2 || c1 === c2) return 0;
    const b = integral[r2 - 1];
    if (r1 === 0) return c1 === 0 ? b[c2 - 1] : b[c2 - 1] - b[c1 - 1];
    const a = integral[r1 - 1];
    return c1 === 0 ? b[c2 - 1] - a[c2 - 1] : b[c2 - 1] - a[c2 - 1] - b[c1 - 1] + a[c1 - 1];
  };
  const apply = (type, x, y, w, h) => {
    switch (type) {
      case 0: return subtractLog(area(x, y, x + w, y + h), 0);
      case 1: { const h2 = h >> 1; return subtractLog(area(x, y + h2, x + w, y + h), area(x, y, x + w, y + h2)); }
      case 2: { const w2 = w >> 1; return subtractLog(area(x + w2, y, x + w, y + h), area(x, y, x + w2, y + h)); }
      case 3: { const w2 = w >> 1, h2 = h >> 1;
        return subtractLog(area(x, y + h2, x + w2, y + h) + area(x + w2, y, x + w, y + h2), area(x, y, x + w2, y + h2) + area(x + w2, y + h2, x + w, y + h)); }
      case 4: { const h3 = (h / 3) | 0; return subtractLog(area(x, y + h3, x + w, y + 2 * h3), area(x, y, x + w, y + h3) + area(x, y + 2 * h3, x + w, y + h)); }
      case 5: { const w3 = (w / 3) | 0; return subtractLog(area(x + w3, y, x + 2 * w3, y + h), area(x, y, x + w3, y + h) + area(x + 2 * w3, y, x + w, y + h)); }
    }
    return 0;
  };
  for (let off = 0; off + FRAME <= n; off += STEP) {
    power(samples, off, spec);
    const f = new Float64Array(BANDS);
    for (let i = minIdx; i < maxIdx; i++) f[notes[i]] += spec[i];
    ring.push(f); if (ring.length > FILTER_COEF.length) ring.shift();
    if (ring.length < FILTER_COEF.length) continue;
    // the chroma filter (5 frames), then the vector normalised
    const g = new Float64Array(BANDS);
    for (let b = 0; b < BANDS; b++) { let s = 0; for (let j = 0; j < FILTER_COEF.length; j++) s += ring[j][b] * FILTER_COEF[j]; g[b] = s; }
    let norm = 0; for (let b = 0; b < BANDS; b++) norm += g[b] * g[b]; norm = norm > 0 ? Math.sqrt(norm) : 0;
    if (norm < 0.01) g.fill(0); else for (let b = 0; b < BANDS; b++) g[b] /= norm;
    // a row of the integral image
    const row = new Float64Array(BANDS); let acc = 0;
    const prev = rows ? integral[rows - 1] : null;
    for (let b = 0; b < BANDS; b++) { acc += g[b]; row[b] = acc + (prev ? prev[b] : 0); }
    integral.push(row); rows++;
    if (rows >= MAX_W) {
      const x = rows - MAX_W; let bits = 0;
      for (const [type, y, h, w, t0, t1, t2] of CLASSIFIERS) {
        const v = apply(type, x, y, w, h);
        const q = v < t1 ? (v < t0 ? 0 : 1) : (v < t2 ? 2 : 3);
        bits = ((bits << 2) | GRAY[q]) >>> 0;
      }
      out.push(bits);
    }
  }
  return Uint32Array.from(out);
}

/* ---- the compressed form AcoustID takes: XOR of neighbours, bit gaps in 3-bit (and 5-bit) groups, Base64 */
const B64 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_';
function pack(values, bits) {
  const out = new Uint8Array(Math.ceil(values.length * bits / 8));
  let pos = 0;
  for (const v of values) { for (let b = 0; b < bits; b++, pos++) if ((v >> b) & 1) out[pos >> 3] |= 1 << (pos & 7); }
  return out;
}
function compress(fp, algorithm = 1) {
  const normal = [], exc = [];
  const sub = (x) => {
    let bit = 1, last = 0;
    while (x !== 0) {
      if (x & 1) { const v = bit - last; if (v >= 7) { normal.push(7); exc.push(v - 7); } else normal.push(v); last = bit; }
      x >>>= 1; bit++;
    }
    normal.push(0);
  };
  if (fp.length) { sub(fp[0] >>> 0); for (let i = 1; i < fp.length; i++) sub((fp[i] ^ fp[i - 1]) >>> 0); }
  const a = pack(normal, 3), b = pack(exc, 5), size = fp.length;
  const bytes = new Uint8Array(4 + a.length + b.length);
  bytes[0] = algorithm & 255; bytes[1] = (size >> 16) & 255; bytes[2] = (size >> 8) & 255; bytes[3] = size & 255;
  bytes.set(a, 4); bytes.set(b, 4 + a.length);
  let s = '', i = 0;
  for (; i + 3 <= bytes.length; i += 3) {
    const s0 = bytes[i], s1 = bytes[i + 1], s2 = bytes[i + 2];
    s += B64[s0 >> 2] + B64[((s0 << 4) | (s1 >> 4)) & 63] + B64[((s1 << 2) | (s2 >> 6)) & 63] + B64[s2 & 63];
  }
  if (bytes.length - i === 2) { const s0 = bytes[i], s1 = bytes[i + 1]; s += B64[s0 >> 2] + B64[((s0 << 4) | (s1 >> 4)) & 63] + B64[(s1 << 2) & 63]; }
  else if (bytes.length - i === 1) { const s0 = bytes[i]; s += B64[s0 >> 2] + B64[(s0 << 4) & 63]; }
  return s;
}

/** the fingerprint of mono 11025 Hz 16-bit audio */
export function fingerprint(samples) { const r = raw(samples); return { raw: r, fp: compress(r) }; }
export { SAMPLE_RATE, raw, compress };
