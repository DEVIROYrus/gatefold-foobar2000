/*
 * Gatefold · autotag/score.js — how well a MusicBrainz release fits an album of yours. Pure functions
 * (no network, no DOM): tested in tools/check.mjs.
 *
 * The weighing follows what the best taggers learned (MusicBrainz Picard's release weights, beets'
 * distance): the track list decides — every track's title, length and place, matched one to one by the
 * Hungarian method — then the album's title and artist, the number of tracks and discs, the year; an
 * AcoustID fingerprint that points at the release counts a lot; and between editions with the same
 * tracks the barcode, the catalogue number and plain preferences (official, an album, a CD or digital
 * release, the original year) settle it.
 */

/* ---------------------------------------------------------------- text */
const QUOTES = /[‘’‚‛′`´]/g, DQUOTES = /[“”„‟″«»]/g;
const DASHES = /[‐-―−﹘﹣－]/g;
/** what a title or a name is made of, for comparing: case, accents, punctuation, «&» and «and» do not count */
export function norm(s) {
  return String(s || '').normalize('NFKD').replace(/[̀-ͯ]/g, '')
    .replace(QUOTES, "'").replace(DQUOTES, '"').replace(DASHES, '-').toLowerCase()
    .replace(/\s*&\s*|\s+\+\s+/g, ' and ').replace(/\bthe\s+/g, '')
    .replace(/[^\p{L}\p{N}]+/gu, ' ').trim();
}
/* what editions and versions add to a name: «(Remastered 2011)», «[Bonus Track]», « - Live», «(Deluxe Edition)» */
const VERSION = /\s*[([]\s*(?:\d{4}\s+)?(?:re-?master(?:ed)?|deluxe|expanded|special|anniversary|bonus|live|demo|edit(?:ion)?|version|mono|stereo|mix|remix|single|radio|explicit|clean|instrumental|acoustic|feat\.?|ft\.?|with|from|original|limited|collector'?s?|digital|japan(?:ese)?|reissue|disc|cd)\b[^)\]]*[)\]]/gi;
const DASH_VERSION = /\s+-\s+(?:\d{4}\s+)?(?:re-?master(?:ed)?|live|demo|single|radio|mono|stereo|remix|mix|edit|version|acoustic|instrumental|bonus)\b.*$/i;
export const bare = (s) => String(s || '').replace(VERSION, '').replace(DASH_VERSION, '').trim();

function lev(a, b) {
  if (a === b) return 0;
  const m = a.length, n = b.length;
  if (!m) return n; if (!n) return m;
  let prev = new Array(n + 1), cur = new Array(n + 1);
  for (let j = 0; j <= n; j++) prev[j] = j;
  for (let i = 1; i <= m; i++) {
    cur[0] = i; const ca = a.charCodeAt(i - 1);
    for (let j = 1; j <= n; j++) cur[j] = Math.min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (ca === b.charCodeAt(j - 1) ? 0 : 1));
    [prev, cur] = [cur, prev];
  }
  return prev[n];
}
const ratio = (a, b) => (!a && !b ? 1 : 1 - lev(a, b) / Math.max(a.length, b.length));
const tokens = (s) => s.split(' ').filter(Boolean);
/* Cyrillic written in Latin letters (tags often are, MusicBrainz keeps the original script) */
const CYR = { а: 'a', б: 'b', в: 'v', г: 'g', д: 'd', е: 'e', ё: 'e', ж: 'zh', з: 'z', и: 'i', й: 'y', к: 'k', л: 'l', м: 'm', н: 'n', о: 'o', п: 'p', р: 'r', с: 's', т: 't', у: 'u', ф: 'f', х: 'h', ц: 'ts', ч: 'ch', ш: 'sh', щ: 'sch', ъ: '', ы: 'y', ь: '', э: 'e', ю: 'yu', я: 'ya', і: 'i', ї: 'i', є: 'e', ґ: 'g' };
const latin = (s) => s.replace(/[а-яёіїєґ]/g, (c) => CYR[c] ?? c).replace(/kh/g, 'h').replace(/iy\b|yy\b/g, 'y');
/** 0…1: how alike two titles or names are (1 = the same once case, accents, punctuation and edition notes go) */
export function sim(x, y) {
  const s1 = sim1(x, y);
  if (s1 >= 0.95 || !(/[а-яё]/i.test(x + y))) return s1;
  return Math.max(s1, sim1(latin(norm(x)), latin(norm(y))) * 0.97);
}
function sim1(x, y) {
  const a = norm(x), b = norm(y);
  if (a === b) return 1;
  if (!a || !b) return 0;
  let best = ratio(a, b);
  const ta = tokens(a).sort().join(' '), tb = tokens(b).sort().join(' ');
  best = Math.max(best, ratio(ta, tb) * 0.98);
  const ba = norm(bare(x)), bb = norm(bare(y));
  if (ba && bb) { if (ba === bb) best = Math.max(best, 0.95); else best = Math.max(best, ratio(ba, bb) * 0.97); }
  // one is the other with more words (a subtitle, «Part 1»): close, not the same
  if (a.length > 3 && b.length > 3 && (a.startsWith(b + ' ') || b.startsWith(a + ' '))) best = Math.max(best, 0.86);
  return best;
}

/* ---------------------------------------------------------------- numbers */
/** «3», «3/12», «03» → 3; letters (vinyl «A1») → their order */
export function num(v) {
  const s = String(v ?? '').trim(); if (!s) return 0;
  const m = /^(\d+)/.exec(s); if (m) return +m[1];
  const v2 = /^([A-Z])(\d+)$/i.exec(s); if (v2) return (v2[1].toUpperCase().charCodeAt(0) - 64) * 100 + +v2[2];
  return 0;
}
/** 0…1: how alike two lengths (seconds) are — 1 within 2 s, ½ at 8 s, 0 from 30 s */
export function lengthSim(a, b) {
  if (!(a > 0) || !(b > 0)) return 0.5;          // one is unknown: neither for nor against
  const d = Math.abs(a - b);
  if (d <= 2) return 1;
  if (d <= 8) return 1 - (d - 2) / 12;
  if (d <= 30) return 0.5 * (1 - (d - 8) / 22);
  return 0;
}
const year = (s) => { const m = /(\d{4})/.exec(String(s || '')); return m ? +m[1] : 0; };

/* ---------------------------------------------------------------- the Hungarian method (minimum cost, rectangular) */
/** for an n × m cost matrix (n ≤ m): the column each row gets */
export function hungarian(cost) {
  const n = cost.length, m = n ? cost[0].length : 0;
  if (!n) return [];
  const INF = 1e18, u = new Float64Array(n + 1), v = new Float64Array(m + 1), p = new Int32Array(m + 1), way = new Int32Array(m + 1);
  for (let i = 1; i <= n; i++) {
    p[0] = i; let j0 = 0;
    const minv = new Float64Array(m + 1).fill(INF), used = new Uint8Array(m + 1);
    do {
      used[j0] = 1; const i0 = p[j0]; let delta = INF, j1 = 0;
      for (let j = 1; j <= m; j++) if (!used[j]) {
        const c = cost[i0 - 1][j - 1] - u[i0] - v[j];
        if (c < minv[j]) { minv[j] = c; way[j] = j0; }
        if (minv[j] < delta) { delta = minv[j]; j1 = j; }
      }
      for (let j = 0; j <= m; j++) if (used[j]) { u[p[j]] += delta; v[j] -= delta; } else minv[j] -= delta;
      j0 = j1;
    } while (p[j0] !== 0);
    do { const j1 = way[j0]; p[j0] = p[j1]; j0 = j1; } while (j0);
  }
  const row = new Array(n).fill(-1);
  for (let j = 1; j <= m; j++) if (p[j]) row[p[j] - 1] = j - 1;
  return row;
}

/* ---------------------------------------------------------------- a release, flattened */
export const creditName = (ac) => (Array.isArray(ac) ? ac.map((c) => (c.name ?? c.artist?.name ?? '') + (c.joinphrase || '')).join('') : '');
/** the release's tracks in order, each with its disc, number, title, artist, length (s) and ids */
export function releaseTracks(rel) {
  const out = [];
  for (const m of rel.media || []) {
    for (const t of m.tracks || []) {
      out.push({ disc: m.position || 1, discs: (rel.media || []).length, discTitle: m.title || '', format: m.format || '', no: t.position || num(t.number), number: t.number,
        tracksOnDisc: m['track-count'] ?? (m.tracks || []).length, title: t.title || t.recording?.title || '', artist: creditName(t['artist-credit'] || t.recording?.['artist-credit']),
        credit: t['artist-credit'] || t.recording?.['artist-credit'] || [], length: (t.length || t.recording?.length || 0) / 1000, id: t.id, recording: t.recording?.id || '', isrcs: t.recording?.isrcs || [] });
    }
  }
  return out;
}

/* ---------------------------------------------------------------- one track of yours against one of the release */
/** 0…1 — and why: title, length, place, the fingerprint */
export function trackSim(mine, theirs, { sameDiscs = true, fp = null } = {}) {
  if (fp && theirs.recording && fp.has(theirs.recording)) return 1;               // AcoustID heard this very recording
  const t = sim(mine.title, theirs.title);
  const l = lengthSim(mine.length, theirs.length);
  const place = mine.no && theirs.no && mine.no === theirs.no && (!sameDiscs || (mine.disc || 1) === theirs.disc) ? 1 : 0;
  let s = t * 0.58 + l * 0.27 + place * 0.15;
  if (t < 0.5 && l < 0.5) s *= 0.6;                                               // neither the name nor the length: another song
  return Math.min(1, s);
}

/* ---------------------------------------------------------------- an album of yours against a release */
const W = { tracks: 0.4, album: 0.16, artist: 0.13, count: 0.11, length: 0.06, year: 0.04, fp: 0.1 };
/**
 * album: { title, artist, year, barcode, catalog, mbid, tracks: [{ title, artist, length, no, disc, recordings? }] }
 * rel:   a MusicBrainz release (inc=recordings+artist-credits+labels+release-groups+media)
 * → { score 0…1, map: [the release track index for each of your tracks, or -1], parts: { … } , why: [...] }
 */
export function scoreRelease(album, rel, { fpRecordings = null } = {}) {
  const rt = releaseTracks(rel);
  const mine = album.tracks;
  const n = mine.length, m = rt.length;
  const parts = {};
  if (!n || !m) return { score: 0, map: mine.map(() => -1), parts, rt };
  const discsMine = new Set(mine.map((t) => t.disc || 1)).size;
  const sameDiscs = discsMine === (rel.media || []).length;
  // the one-to-one matching of the tracks
  const S = mine.map((a) => rt.map((b) => trackSim(a, b, { sameDiscs, fp: a.recordings || null })));
  let map;
  if (n <= m) map = hungarian(S.map((r) => r.map((s) => 1 - s)));
  else { const cols = hungarian(rt.map((_, j) => mine.map((_, i) => 1 - S[i][j]))); map = new Array(n).fill(-1); cols.forEach((i, j) => { if (i >= 0) map[i] = j; }); }
  // a pairing that is surely wrong does not count as one
  map = map.map((j, i) => (j >= 0 && S[i][j] >= 0.45 ? j : -1));
  const got = map.reduce((s, j, i) => s + (j >= 0 ? S[i][j] : 0), 0);
  parts.tracks = got / Math.max(n, 1) * (n > m ? m / n : 1);
  parts.album = Math.max(sim(album.title, rel.title), sim(bare(album.title), bare(rel.title)));
  const relArtist = creditName(rel['artist-credit']);
  const artists = [album.artist, album.trackArtist].filter(Boolean);
  parts.artist = artists.length ? Math.max(...artists.map((a) => sim(a, relArtist))) : 0.5;
  if (/^various artists$/i.test(relArtist) && /^(various|va|сборник|разные)/i.test(album.artist || '')) parts.artist = 1;
  // the number of tracks: the same; fewer of yours (a few missing) is better than more
  parts.count = n === m ? 1 : n < m ? Math.max(0, 1 - (m - n) / Math.max(m, 4) * 1.4) : Math.max(0, 1 - (n - m) / n * 2.5);
  const lenMine = mine.reduce((s, t, i) => s + (map[i] >= 0 && rt[map[i]].length > 0 ? t.length || 0 : 0), 0);   // the matched pairs only: a missing track is the count's business
  const lenRel = map.reduce((s, j, i) => s + (j >= 0 && mine[i].length > 0 ? rt[j].length : 0), 0);
  parts.length = lenMine > 0 && lenRel > 0 ? Math.max(0, 1 - Math.abs(lenMine - lenRel) / Math.max(30, lenMine * 0.04) * 0.5) : 0.5;
  const yMine = year(album.year), yRel = year(rel.date), yOrig = year(rel['release-group']?.['first-release-date']);
  parts.year = !yMine ? 0.5 : yMine === yRel || yMine === yOrig ? 1 : Math.abs(yMine - yRel) === 1 || Math.abs(yMine - yOrig) === 1 ? 0.6 : 0.15;
  // AcoustID: how many of your tracks were heard on this release
  if (fpRecordings) {
    const heard = mine.filter((t) => t.recordings && t.recordings.size).length;
    const onIt = map.filter((j, i) => j >= 0 && mine[i].recordings && mine[i].recordings.has(rt[j].recording)).length;
    parts.fp = heard ? onIt / heard : 0.5;
  }
  // no fingerprint asked: the other parts share its weight
  let score = 0, wsum = 0; for (const k in W) { if (k === 'fp' && !fpRecordings) continue; score += W[k] * parts[k]; wsum += W[k]; }
  score /= wsum;
  // an id already in your tags, a barcode, a catalogue number: the same edition
  if (album.mbid && album.mbid === rel.id) score = Math.max(score, 0.97) + 0.02;
  if (album.barcode && rel.barcode && String(album.barcode).replace(/\D/g, '') === String(rel.barcode).replace(/\D/g, '')) score += 0.03;
  const cats = (rel['label-info'] || []).map((l) => norm(l['catalog-number'] || '')).filter(Boolean);
  if (album.catalog && cats.includes(norm(album.catalog))) score += 0.02;
  // the edition your files name: «Killers (2015 Remaster)», «… - 2011 Remaster» → the release of that year
  const hint = [album.title, ...mine.slice(0, 3).map((x) => x.title)].join(' ');
  const hy = [...hint.matchAll(/\b(19[5-9]\d|20[0-4]\d)\b/g)].map((x) => +x[1]).filter((y) => y !== yOrig);
  if (hy.length && (hy.includes(yRel) || hy.some((y) => String(rel.disambiguation || '').includes(String(y))))) score += 0.012;
  if (/\b(deluxe|expanded|anniversary)\b/i.test(hint) && /deluxe|expanded|anniversary/i.test(`${rel.title} ${rel.disambiguation || ''}`)) score += 0.008;
  // the first edition before later reissues, when nothing else tells them apart
  if (yRel && yOrig && yRel >= yOrig) score -= Math.min(40, yRel - yOrig) * 0.00004;
  // plain preferences between editions that fit alike (never enough to beat a better fit)
  if (rel.status === 'Official') score += 0.006;
  const rgType = rel['release-group']?.['primary-type'];
  if (rgType === 'Album' || rgType === 'EP') score += 0.004;
  const fmt = (rel.media || []).map((x) => x.format || '');
  if (fmt.every((f) => /^(CD|Digital Media|Enhanced CD|HDCD|SHM-CD|Blu-spec CD)$/i.test(f))) score += 0.004;
  if ((rel.media || []).every((x) => (x.tracks || []).length)) score += 0.001;
  return { score: Math.min(1, score), map, parts, rt };
}

/** how sure: 'sure' (write it), 'check' (look first), 'weak' (probably not this album) */
export const verdict = (score, margin = 1) => (score >= 0.9 && margin >= 0.015 ? 'sure' : score >= 0.9 || score >= 0.76 ? 'check' : 'weak');

/* ---------------------------------------------------------------- leftovers in names and comments (engine.js → cleanup) */
const FMT = String.raw`(?:flac|mp3|aac|alac|m4a|ogg|opus|wav|ape|wv|dsd\d*|sacd|shm-?cd|blu-?spec(?:\s?cd2?)?|web(?:-?dl)?|cdda|vinyl(?:\s?rip)?|lp|hi-?res|hd|lossless|24[\s-]?bit|16[\s-]?bit|\d{2,3}(?:[.,]\d)?\s?khz|\d{2,3}[\s-]\d{2,3}|\d{3}\s?kbps|v0|v2|cbr|vbr|log|cue|eac|scans?)`;
const JUNK_IN_BRACKETS = [
  /^(?!(?:BWV|KV|HWV|RV|TWV|WOO|HOB|FWV|SWV|ZWV|BUXWV|OP|NO|NR|VOL|PT|CH|MK|UK|US|EU|JP|DJ|MC|TV|OST|EP|LP)[-\s]?\d)[A-Z]{2,6}[-\s]?\d{2,7}(?:[-~/]\d{1,4})?$/,   // a catalogue number: MVCG-12, TOCP 65432 (not a work's: BWV 1007)                                                  // a catalogue number: MVCG-12, TOCP 65432
  new RegExp(`^${FMT}(?:[\\s,/+&_-]+${FMT})*$`, 'i'),                                                 // the format: FLAC, 24bit-96kHz, WEB
  /^(?:\d{4}\s+)?(?:digital(?:ly)?\s+)?re-?master(?:ed)?(?:\s+(?:in\s+)?\d{4})?(?:\s+(?:version|edition|mix))?$/i,     // (2015 Remaster)
  /^(?:\d+(?:st|nd|rd|th)\s+anniversary\s+|super\s+)?(?:deluxe|expanded|special|limited|collector'?s|japan(?:ese)?|international|anniversary|bonus\s+tracks?|tour|platinum|gold|digipak|digipack|ltd\.?)(?:\s+(?:edition|version|ed\.?|release|reissue))?$/i,
  /^(?:explicit|clean|album\s+version|lp\s+version|single\s+version|original\s+album\s+version)$/i,
  /^(?:cd|disc|disk)\s*\d{1,2}$/i,
];
const JUNK_SUFFIX = /\s+-\s+(?:(?:\d{4}\s+)?(?:digital(?:ly)?\s+)?re-?master(?:ed)?(?:\s+\d{4})?(?:\s+version)?|album\s+version|single\s+version|explicit)$/i;
const DISC_SUFFIX = /\s*(?:[-–—,:]\s*)?(?:cd|disc|disk)\s*(\d{1,2})$/i;
/** a name without the leftovers: { text, disc } (disc: the number taken out of «… CD2») */
export function cleanName(s) {
  let t = String(s || ''), disc = 0, prev;
  do {
    prev = t;
    t = t.replace(/\s*[\[(]\s*([^\[\]()]{1,60}?)\s*[\])]\s*$/, (m, inner) => {
      if (!JUNK_IN_BRACKETS.some((re) => re.test(inner))) return m;
      const d = /^(?:cd|disc|disk)\s*(\d{1,2})$/i.exec(inner); if (d) disc = +d[1];
      return '';
    });
    t = t.replace(JUNK_SUFFIX, '');
  } while (t !== prev && t.trim());
  const d = DISC_SUFFIX.exec(t);
  if (d && t.slice(0, d.index).trim().length >= 2) { disc = disc || +d[1]; t = t.slice(0, d.index); }
  t = t.trim();
  return { text: t || String(s || '').trim(), disc };
}
const JUNK_TEXT = /(https?:\/\/|www\.|\b[\w-]+\.(?:com|ru|net|org|info|to|cc|me|io|su|ua|xyz|club|fm|tv)\b|\bripped\b|\brip(?:ped)?\s+by\b|\bupload(?:ed|er)?\b|\bdownload(?:ed)?\b|torrent|\beac\b|exact audio copy|\bvisit\b|telegram|\bt\.me\b|\bvk\b|free\s+(?:music|mp3|download)|\bencoded\b|\bkbps\b|\bscene\b|\bpurchased\b|amazon\.|itunes|\bmusic\s+for\s+free\b|\bpromo\s+only\b|^\s*[0-9a-f]{8}(?:\s+[0-9a-f]{8}){3,}\s*$|^\s*track\s*\d+\s*$)/i;
/** a comment worth nothing: a site, a ripper, an uploader — or only the album's own name again */
export const junkText = (v, album = null) => JUNK_TEXT.test(String(v || '')) || (!!album && [album.title, album.artist].some((x) => x && norm(x) === norm(v)));
