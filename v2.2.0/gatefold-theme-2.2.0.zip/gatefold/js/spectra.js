/*
 * Gatefold · spectra.js — the looks of the spectrum under the track (Settings → Now playing → Spectrum style).
 * Each style draws the same data: bars (0…1, log-spaced 30 Hz – 16 kHz, already smoothed with a fast attack and a
 * slow release by viz.js), their falling peaks, the device pixel ratio and the cover's colours. Drawing only — no
 * state of their own beyond what a frame needs, so a style can be switched while music plays.
 *
 *   bars     rounded columns with peak caps (the classic)
 *   wave     a smooth mirrored wave, filled with the cover's colours, softly glowing
 *   line     an analyser line over a gradient, as in a studio EQ
 *   dots     an LED dot matrix, the top dot of each column in the accent
 *   mirror   thin columns rising and falling from the middle, with a faint reflection
 *   aurora   three translucent layers (bass, voice, air) that flow with the music
 *   analyzer a studio analyzer in small: the frequency grid, a filled curve, the held peaks (a click opens the
 *            full one, analyzer.js)
 */
export const STYLES = ['bars', 'wave', 'line', 'dots', 'mirror', 'aurora', 'analyzer'];

const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
let glow = null;     // the wave's glow, drawn small (see wave)
/** a smooth path through points (Catmull–Rom as Béziers) */
function smooth(c, pts, move = true) {
  if (!pts.length) return;
  if (move) c.moveTo(pts[0][0], pts[0][1]); else c.lineTo(pts[0][0], pts[0][1]);
  for (let i = 0; i < pts.length - 1; i++) {
    const p0 = pts[Math.max(0, i - 1)], p1 = pts[i], p2 = pts[i + 1], p3 = pts[Math.min(pts.length - 1, i + 2)];
    c.bezierCurveTo(p1[0] + (p2[0] - p0[0]) / 6, p1[1] + (p2[1] - p0[1]) / 6, p2[0] - (p3[0] - p1[0]) / 6, p2[1] - (p3[1] - p1[1]) / 6, p2[0], p2[1]);
  }
}
/** fewer, wider points for the curved styles: neighbours averaged (the 56 bars are too nervous for a wave) */
function resample(bars, n) {
  const out = new Float32Array(n), m = bars.length;
  for (let i = 0; i < n; i++) {
    const a = (i / n) * m, b = ((i + 1) / n) * m;
    let s = 0, k = 0;
    for (let j = Math.floor(a); j < Math.max(Math.floor(a) + 1, Math.ceil(b)); j++) { s += bars[Math.min(m - 1, j)] || 0; k++; }
    out[i] = k ? s / k : 0;
  }
  return out;
}

const draw = {
  /* the small analyzer: measured by minianalyzer.js (multi-resolution FFT, 1/6 octave, tilt, dBFS), drawn on a
     20 Hz – 20 kHz log axis with its dB scale; without live samples (an older component) the bars' shape */
  analyzer(c, w, h, bars, peaks, d, col, t, an) {
    if (an && an.disp) return analyzerMeasured(c, w, h, d, col, an);
    const n = bars.length; if (!n) return;
    const lo = 30, hi = 16000, X = (f) => (Math.log(f / lo) / Math.log(hi / lo)) * w;
    c.lineWidth = 1;
    // the grid: every octave faint, 100 Hz · 1 kHz · 10 kHz a little brighter, with their names
    for (const f of [31.5, 63, 125, 250, 500, 1000, 2000, 4000, 8000, 16000]) {
      const x = Math.round(X(f)) + 0.5;
      c.strokeStyle = col.dim; c.globalAlpha = f === 125 || f === 1000 || f === 8000 ? 0.9 : 0.45;
      c.beginPath(); c.moveTo(x, 0); c.lineTo(x, h); c.stroke();
    }
    c.globalAlpha = 1;
    for (let k = 1; k < 4; k++) { const y = Math.round((h * k) / 4) + 0.5; c.strokeStyle = col.dim; c.globalAlpha = 0.4; c.beginPath(); c.moveTo(0, y); c.lineTo(w, y); c.stroke(); }
    c.globalAlpha = 1;
    c.font = `${9 * d}px system-ui, sans-serif`; c.fillStyle = col.text3 || col.dim; c.textBaseline = 'top';
    for (const [f, l] of [[125, '125'], [1000, '1k'], [8000, '8k']]) c.fillText(l, X(f) + 3 * d, 2 * d);
    // (Array.from hands its map only the value and the index: the length is taken from the array itself)
    const curve = (arr) => { const r = resample(arr, Math.min(n, 48)), m = r.length; return Array.from(r, (v, i) => [(i / (m - 1)) * w, h - clamp(v, 0, 1) * (h - 4 * d)]); };
    const pts = curve(bars);
    c.beginPath(); smooth(c, pts); c.lineTo(w, h); c.lineTo(0, h); c.closePath();
    const g = c.createLinearGradient(0, 0, 0, h); g.addColorStop(0, hexA(col.a, 0.42)); g.addColorStop(1, hexA(col.a, 0.03));
    c.fillStyle = g; c.fill();
    c.beginPath(); smooth(c, pts); c.strokeStyle = col.a; c.lineWidth = 1.5 * d; c.lineJoin = 'round'; c.stroke();
    const pk = curve(peaks);
    c.beginPath(); smooth(c, pk); c.strokeStyle = hexA(col.b, 0.75); c.lineWidth = 1 * d; c.stroke();
  },
  bars(c, w, h, bars, peaks, d, col) {
    const n = bars.length; if (!n) return;
    const gap = Math.max(2, Math.round(w / n * 0.28)), bw = (w - gap * (n - 1)) / n;
    if (bw <= 0) return;
    const g = c.createLinearGradient(0, h, 0, 0); g.addColorStop(0, col.b); g.addColorStop(1, col.a);
    c.fillStyle = g;
    const r = Math.min(bw / 2, 4 * d);
    // one path and one fill for all the columns, one for all the caps: the same picture in two draw calls, not 112
    c.beginPath();
    for (let i = 0; i < n; i++) { const bh = Math.max(2 * d, bars[i] * h * 0.94); c.roundRect(i * (bw + gap), h - bh, bw, bh, [r, r, 1, 1]); }
    c.fill();
    c.globalAlpha = 0.55; c.fillStyle = col.a; c.beginPath();
    for (let i = 0; i < n; i++) c.rect(i * (bw + gap), Math.max(0, h - peaks[i] * h * 0.94 - 3 * d), bw, Math.max(1, d * 1.5));
    c.fill();
    c.globalAlpha = 1;
  },

  wave(c, w, h, bars, peaks, d, col) {
    const v = resample(bars, 28), mid = h / 2, n = v.length;
    const top = [], bot = [];
    for (let i = 0; i < n; i++) { const x = (i / (n - 1)) * w, a = Math.max(0.012, v[i]) * (h / 2 - 2 * d) * (0.55 + 0.45 * Math.sin(Math.PI * (0.08 + 0.84 * i / (n - 1)))); top.push([x, mid - a]); bot.push([x, mid + a]); }
    const g = c.createLinearGradient(0, 0, w, 0); g.addColorStop(0, col.b); g.addColorStop(0.5, col.a); g.addColorStop(1, col.b);
    bot.reverse();
    // the glow: the wave drawn with its blur into a canvas a quarter of the size and stretched under it. A shadowBlur
    // on the full-size canvas was a Gaussian over the whole spectrum on every frame (the costliest style by far, #29)
    const gw = Math.max(8, Math.round(w / 4)), gh = Math.max(4, Math.round(h / 4));
    if (!glow) glow = document.createElement('canvas');
    if (glow.width !== gw || glow.height !== gh) { glow.width = gw; glow.height = gh; }
    const gx = glow.getContext('2d');
    gx.clearRect(0, 0, gw, gh);
    gx.save(); gx.scale(gw / w, gh / h);
    gx.shadowColor = col.a; gx.shadowBlur = 14 * d * (gw / w);
    gx.beginPath(); smooth(gx, top); smooth(gx, bot, false); gx.closePath();
    gx.fillStyle = col.a; gx.fill();
    gx.restore();
    c.save();
    c.globalAlpha = 0.85; c.imageSmoothingQuality = 'medium'; c.drawImage(glow, 0, 0, w, h);
    c.beginPath(); smooth(c, top); smooth(c, bot, false); c.closePath();
    c.fillStyle = g; c.fill();
    c.restore();
    c.globalAlpha = 0.9; c.lineWidth = 1 * d; c.strokeStyle = col.dim; c.beginPath(); c.moveTo(0, mid + 0.5); c.lineTo(w, mid + 0.5); c.stroke(); c.globalAlpha = 1;
  },

  line(c, w, h, bars, peaks, d, col) {
    const v = resample(bars, 40), n = v.length, pts = [];
    for (let i = 0; i < n; i++) pts.push([(i / (n - 1)) * w, h - 3 * d - v[i] * (h - 8 * d)]);
    c.beginPath(); smooth(c, pts); c.lineTo(w, h); c.lineTo(0, h); c.closePath();
    const fill = c.createLinearGradient(0, 0, 0, h); fill.addColorStop(0, hexA(col.a, 0.38)); fill.addColorStop(1, hexA(col.b, 0));
    c.fillStyle = fill; c.fill();
    // the peaks as a faint second line
    const pk = resample(peaks, 40), pp = [];
    for (let i = 0; i < n; i++) pp.push([(i / (n - 1)) * w, h - 3 * d - pk[i] * (h - 8 * d)]);
    c.beginPath(); smooth(c, pp); c.lineWidth = 1 * d; c.strokeStyle = hexA(col.a, 0.35); c.stroke();
    c.beginPath(); smooth(c, pts); c.lineWidth = 2 * d; c.lineJoin = 'round'; c.strokeStyle = col.a; c.stroke();
  },

  dots(c, w, h, bars, peaks, d, col) {
    const cols = clamp(Math.round(w / (9 * d)), 24, 96), v = resample(bars, cols), pk = resample(peaks, cols);
    const step = w / cols, rows = Math.max(4, Math.floor(h / step)), r = Math.max(1.2 * d, step * 0.3);
    // the dots grouped by how they are filled (unlit, peak, lit at each brightness): one fill per group, not one per dot
    const dim = new Path2D(), top = new Path2D(), lit = new Map();
    const dot = (p, x, y) => { p.moveTo(x + r, y); p.arc(x, y, r, 0, Math.PI * 2); };
    for (let i = 0; i < cols; i++) {
      const on = Math.round(v[i] * rows), pkr = Math.min(rows - 1, Math.round(pk[i] * rows)), x = i * step + step / 2;
      for (let j = 0; j < rows; j++) {
        const y = h - (j * step + step / 2);
        if (j < on) { const a = j >= on - 1 ? 1 : 0.35 + 0.5 * (j / Math.max(1, on - 1)); let p = lit.get(a); if (!p) lit.set(a, (p = new Path2D())); dot(p, x, y); }
        else if (j === pkr && pkr > 0) dot(top, x, y);
        else dot(dim, x, y);
      }
    }
    c.globalAlpha = 1; c.fillStyle = col.dim; c.fill(dim);
    c.fillStyle = col.a; c.globalAlpha = 0.9; c.fill(top);
    for (const [a, p] of lit) { c.globalAlpha = a; c.fill(p); }
    c.globalAlpha = 1;
  },

  mirror(c, w, h, bars, peaks, d, col) {
    const n = bars.length; if (!n) return;
    const mid = h * 0.62, gap = Math.max(2, Math.round(w / n * 0.45)), bw = Math.max(1.5 * d, (w - gap * (n - 1)) / n);
    const up = c.createLinearGradient(0, 0, 0, mid); up.addColorStop(0, col.a); up.addColorStop(1, col.b);
    const rise = new Path2D(), refl = new Path2D();
    for (let i = 0; i < n; i++) {
      const x = i * (bw + gap), a = Math.max(1.5 * d, bars[i] * (mid - 2 * d));
      rise.roundRect(x, mid - a, bw, a, bw / 2); refl.roundRect(x, mid + 2 * d, bw, a * 0.55, bw / 2);
    }
    c.fillStyle = up; c.globalAlpha = 1; c.fill(rise);
    c.fillStyle = col.b; c.globalAlpha = 0.22; c.fill(refl);
    c.globalAlpha = 1;
    // the reflection fades towards the bottom
    const fade = c.createLinearGradient(0, mid, 0, h); fade.addColorStop(0, 'rgba(0,0,0,0)'); fade.addColorStop(1, 'rgba(0,0,0,1)');
    c.globalCompositeOperation = 'destination-out'; c.fillStyle = fade; c.fillRect(0, mid, w, h - mid); c.globalCompositeOperation = 'source-over';
  },

  aurora(c, w, h, bars, peaks, d, col, t) {
    const n = bars.length || 1;
    const band = (a, z) => { let s = 0, k = 0; for (let i = Math.floor(a * n); i < Math.floor(z * n); i++) { s += bars[i] || 0; k++; } return k ? s / k : 0; };
    const layers = [[band(0, 0.15), col.b, 0.55, 1.1], [band(0.15, 0.6), col.a, 0.45, 1.7], [band(0.6, 1), hexMix(col.a, '#ffffff', 0.35), 0.35, 2.6]];
    c.globalCompositeOperation = 'lighter';
    layers.forEach(([e, color, alpha, freq], k) => {
      const amp = (0.12 + Math.min(0.85, e * 1.15)) * h * 0.5, base = h * (0.62 + k * 0.08), pts = [];
      for (let i = 0; i <= 24; i++) { const x = (i / 24) * w, ph = t * (0.0004 + k * 0.00025) + i * 0.28 * freq; pts.push([x, base - amp * (0.55 + 0.45 * Math.sin(ph)) * Math.sin(Math.PI * i / 24)]); }
      const g = c.createLinearGradient(0, base - amp, 0, h); g.addColorStop(0, hexA(color, alpha)); g.addColorStop(1, hexA(color, 0));
      c.beginPath(); smooth(c, pts); c.lineTo(w, h); c.lineTo(0, h); c.closePath(); c.fillStyle = g; c.fill();
    });
    c.globalCompositeOperation = 'source-over';
  },
};

function hex(cs) {
  if (/^#[0-9a-f]{6}$/i.test(cs)) return [parseInt(cs.slice(1, 3), 16), parseInt(cs.slice(3, 5), 16), parseInt(cs.slice(5, 7), 16)];
  const m = /rgba?\(([^)]+)\)/.exec(cs); if (m) return m[1].split(',').slice(0, 3).map((x) => +x);
  return [143, 180, 255];
}
function hexA(cs, a) { const [r, g, b] = hex(cs); return `rgba(${r},${g},${b},${a})`; }
function hexMix(a, b, t) { const x = hex(a), y = hex(b); return '#' + x.map((v, i) => Math.round(v + (y[i] - v) * t).toString(16).padStart(2, '0')).join(''); }

/** one frame of a style; `t` = performance.now() (aurora moves with it) */
export function paint(style, c, w, h, bars, peaks, d, colors, t = performance.now(), extra = null) {
  (draw[style] || draw.bars)(c, w, h, bars, peaks, d, colors, t, extra);
}

function analyzerMeasured(c, w, h, d, col, an) {
  const LO = 20, HI = 20000, SPAN = 54, L = Math.log(HI / LO);
  const X = (f) => (Math.log(f / LO) / L) * w;
  const top = an.shownTop, pad = 2 * d;
  const Y = (db) => pad + ((top - db) / SPAN) * (h - pad);
  c.lineWidth = 1;
  // the grid: 50 · 100 · 200 · 500 · 1k · 2k · 5k · 10k, the decades a little brighter; every 12 dB across
  for (const f of [50, 100, 200, 500, 1000, 2000, 5000, 10000]) {
    const x = Math.round(X(f)) + 0.5;
    c.strokeStyle = col.dim; c.globalAlpha = f === 100 || f === 1000 || f === 10000 ? 0.9 : 0.4;
    c.beginPath(); c.moveTo(x, 0); c.lineTo(x, h); c.stroke();
  }
  c.font = `${9 * d}px system-ui, sans-serif`; c.fillStyle = col.text3 || col.dim; c.globalAlpha = 0.9;
  c.textBaseline = 'top'; c.textAlign = 'left';
  for (const [f, l] of [[100, '100'], [1000, '1k'], [10000, '10k']]) c.fillText(l, X(f) + 3 * d, 2 * d);
  // dB lines on whole 12 dB below the (gliding) top, named at the right edge
  c.textAlign = 'right'; c.textBaseline = 'bottom';
  for (let db = Math.floor((top - 6) / 12) * 12; db > top - SPAN + 4; db -= 12) {
    const y = Math.round(Y(db)) + 0.5;
    c.strokeStyle = col.dim; c.globalAlpha = 0.35; c.beginPath(); c.moveTo(0, y); c.lineTo(w, y); c.stroke();
    if (y > 12 * d && y < h - 2 * d) { c.globalAlpha = 0.75; c.fillText(String(db), w - 3 * d, y - 1 * d); }
  }
  c.globalAlpha = 1; c.textAlign = 'left';
  const n = an.disp.length;
  const path = (arr) => { c.beginPath(); for (let i = 0; i < n; i++) { const x = (i / (n - 1)) * w, y = Math.min(h, Y(arr[i])); i ? c.lineTo(x, y) : c.moveTo(x, y); } };
  path(an.disp); c.lineTo(w, h); c.lineTo(0, h); c.closePath();
  const g = c.createLinearGradient(0, 0, 0, h); g.addColorStop(0, hexA(col.a, 0.42)); g.addColorStop(1, hexA(col.a, 0.03));
  c.fillStyle = g; c.fill();
  path(an.disp); c.strokeStyle = col.a; c.lineWidth = 1.5 * d; c.lineJoin = 'round'; c.stroke();
  if (an.hold) { path(an.hold); c.strokeStyle = hexA(col.b, 0.7); c.lineWidth = 1 * d; c.stroke(); }
}

/** a made-up spectrum for previews: a slow music-like shape that breathes */
export function sample(n, t) {
  const out = new Float32Array(n), pk = new Float32Array(n);
  for (let i = 0; i < n; i++) {
    const x = i / n;
    const v = 0.75 * Math.exp(-x * 2.2) + 0.25 * Math.exp(-((x - 0.42) ** 2) / 0.02) + 0.12 * Math.sin(i * 1.7 + t * 0.004) * Math.exp(-x) + 0.06 * Math.sin(i * 0.9 - t * 0.003);
    out[i] = clamp(v * (0.75 + 0.25 * Math.sin(t * 0.003 + x * 3)), 0.02, 0.98);
    pk[i] = Math.min(1, out[i] + 0.06);
  }
  return [out, pk];
}
