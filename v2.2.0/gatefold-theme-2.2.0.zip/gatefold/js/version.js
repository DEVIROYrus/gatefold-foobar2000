/* Gatefold version — shown in Settings, used by the update check and the installer. */
export const VERSION = '2.2.0';
/** the component (foo_gatefold) this interface was built with: an older one gets a note (hostcheck.js) */
export const HOST_MIN = '2.2.0';
export const REPO = 'DEVIROYrus/gatefold-foobar2000';
