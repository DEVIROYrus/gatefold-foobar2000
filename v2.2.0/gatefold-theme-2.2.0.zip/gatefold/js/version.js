/* Gatefold version — shown in Settings, used by the update check and the installer. */
export const VERSION = '2.2.0';
/** the component (foo_gatefold) this interface was built with: an older one gets a note (hostcheck.js) */
export const HOST_MIN = '2.2.0';
export const REPO = 'DEVIROYrus/gatefold-foobar2000';
/** the release build (time-hash), stamped by release.py; '' in development. A newer build of the same version on
 *  GitHub is a fix that installs by itself (updater.js hotfix) */
export const BUILD = '20261123171748-7b981d4260be';
