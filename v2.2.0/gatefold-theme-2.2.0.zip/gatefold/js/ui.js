/* Gatefold · ui.js — router, toasts, popup menus, small DOM helpers */
import { esc } from './bridge.js';

import { $t } from './i18n.js';
export const $ = (id) => document.getElementById(id);
export const h = (html) => { const t = document.createElement('template'); t.innerHTML = html.trim(); return t.content.firstElementChild; };
export const icon = (name, size) => `<svg${size ? ` width="${size}" height="${size}"` : ''}><use href="#i-${name}"/></svg>`;

// ---------------------------------------------------------------- router
const handlers = new Map();
const stack = [], fwd = [];
const TITLES = { home: $t('Главная'), stats: $t('Итоги'), now: $t('Сейчас играет'), playlist: $t('Плейлист'), artists: $t('Исполнители'), library: $t('Альбомы'), queue: $t('Очередь'), search: $t('Поиск'), covers: $t('Обложки'), settings: $t('Настройки'), youtube: 'YouTube', liked: $t('Понравившиеся') };
const titleOf = ([v, a]) => (v === 'library' && a && a.folder !== undefined) ? (String(a.folder).split(/[\\/]/).filter(Boolean).pop() || $t('Папки')) : (v === 'album' && a && a.name) ? a.name : (v === 'release' && a && a.d) ? a.d.title : (v === 'artist' && a) ? (typeof a === 'string' ? a : a.name || $t('Исполнитель')) : TITLES[v] || '';
export const router = {
  current: '',
  arg: null,
  on(view, fn) { handlers.set(view, fn); },
  go(view, arg, { push = true, keepFwd = false } = {}) {
    // Settings is a panel over a screen, not a place to come back to: it never enters the history (back closes it,
    // a link out of it leads on from the screen it was opened over)
    if (push && this.current && this.current !== 'settings' && (this.current !== view || arg)) stack.push([this.current, this.arg]);
    if (push && !keepFwd) fwd.length = 0;
    if (stack.length > 40) stack.shift();
    this.current = view; this.arg = arg;
    document.querySelectorAll('.view').forEach((v) => v.classList.toggle('active', v.id === 'view-' + view));
    document.querySelectorAll('.nav-item[data-view]').forEach((n) => n.classList.toggle('active', n.dataset.view === view));
    const fn = handlers.get(view);
    if (fn) fn(arg);
    for (const l of listeners) l(view, arg);
  },
  /** previous screen, or `fallback` when there is no history (e.g. an album opened straight from Now Playing) */
  back(fallback) {
    const p = stack.pop();
    if (p) { if (this.current !== 'settings') fwd.push([this.current, this.arg]); this.go(p[0], p[1], { push: false }); }
    else if (fallback && fallback !== this.current) this.go(fallback, null, { push: false });
  },
  forward() { const n = fwd.pop(); if (n) { if (this.current !== 'settings') stack.push([this.current, this.arg]); this.go(n[0], n[1], { push: false }); } },
  /** there is a screen to go back to */
  canBack() { return stack.length > 0; },
  /** label for a «← …» button: where back() will lead */
  backLabel(fallback) { const p = stack[stack.length - 1]; return p ? titleOf(p) : (fallback ? TITLES[fallback] : ''); },
};
/** «← Альбомы» button for a page header; returns the element. */
export function backButton(fallback) {
  const label = router.backLabel(fallback) || $t('Назад');
  const b = h(`<button class="btn sm back-btn" title="${$t('Назад (Alt+←, Esc, боковая кнопка мыши)')}"><svg><use href="#i-back"/></svg><span></span></button>`);
  b.querySelector('span').textContent = label;
  b.onclick = () => router.back(fallback);
  return b;
}
const listeners = new Set();
export const onRoute = (fn) => listeners.add(fn);

// ---------------------------------------------------------------- titles that fit (#12.2)
/* A long title in the big display type took three, four lines: words cut off, the album's track list pushed down
   (in full screen one row fewer than in the window). The title now gets at most `lines` lines: smaller, step by
   step, down to `min` px — only then is it cut. Again whenever its box changes size. */
const fitted = new Map();   // element → options
const fitW = new WeakMap();  // element → the width it was fitted at
/* Lines are counted from the box's own height (its line boxes), not from scrollHeight: with the display type's
   tight line height the letters stick out of their lines by a few pixels, which scrollHeight counts — two lines
   that fit were taken for three and the title shrank to one small line. */
function fitNow(el, { lines = 2, min = 20 } = {}) {
  if (!el.isConnected) { fitted.delete(el); return; }
  el.style.fontSize = '';
  const cs = getComputedStyle(el);
  let fs = parseFloat(cs.fontSize);
  if (!fs) return;
  const pad = (parseFloat(cs.paddingTop) || 0) + (parseFloat(cs.paddingBottom) || 0);
  const lineOf = (size) => parseFloat(getComputedStyle(el).lineHeight) || size * 1.08;
  const count = (size) => Math.round((el.getBoundingClientRect().height - pad) / lineOf(size));
  for (let i = 0; i < 14 && fs > min; i++) {
    if (count(fs) <= lines) break;
    fs = Math.max(min, Math.floor(fs * 0.92));
    el.style.fontSize = fs + 'px';
  }
  fitW.set(el, el.parentElement ? el.parentElement.clientWidth : 0);
}
/* Fitted again when its box gets wider or narrower — not when only its height changes: the fitting itself changes
   the height, and refitting on that went round in a loop (a title switching between two sizes every frame). */
const fitRO = new ResizeObserver((list) => {
  for (const e of list) for (const [el, o] of fitted) {
    if (el.parentElement !== e.target) continue;
    if (e.target.clientWidth === fitW.get(el)) continue;
    fitNow(el, o);
  }
});
/** keep `el`'s text within `lines` lines (smaller type before cutting); call again after its text changes */
export function fitText(el, opts = {}) {
  if (!el) return;
  if (!fitted.has(el)) { fitted.set(el, opts); if (el.parentElement) fitRO.observe(el.parentElement); }
  else fitted.set(el, opts);
  fitNow(el, opts);
  requestAnimationFrame(() => fitNow(el, opts));   // fonts and layout settle in the next frame
}

// ---------------------------------------------------------------- toasts
export function toast(msg, { img = '', ms = 3600, action = null } = {}) {
  const el = h(`<div class="toast">${img ? `<img src="${esc(img)}" alt="">` : ''}<div style="flex:1">${msg}</div></div>`);
  const close = () => { el.classList.add('out'); setTimeout(() => el.remove(), 260); };
  if (action) {
    const b = h(`<button class="btn sm primary">${esc(action.label)}</button>`);
    b.onclick = () => { close(); action.fn(); };
    const x = h(`<button class="icon-btn" aria-label="${$t('Закрыть')}" style="width:28px;height:28px"><svg width="14" height="14"><use href="#i-x"/></svg></button>`);
    x.onclick = close;
    el.append(b, x);
  }
  $('toasts').appendChild(el);
  if (Number.isFinite(ms)) setTimeout(close, ms);
}

// ---------------------------------------------------------------- popup menu
// items: [{ id, label, checked, disabled, children:[…] } | { type: 'sep' }]
let openMenus = [];
let pending = null;   // the finish() of the menu on screen: a new menu settles the old one (null) first
const removeMenus = () => { openMenus.forEach((m) => m.remove()); openMenus = []; };
/** closes the menu on screen; its popupMenu() promise settles with null */
export function closeMenus() { if (pending) pending(null); removeMenus(); }

/* A second click on the button that opened a menu closes it (#12.6). The press on it already closes the menu
   (a press outside does); the click that follows would open it again — that one click is let go. The button is
   whatever the last left press landed on just before the menu opened (a menu opened by a right click or the
   keyboard has none). */
let lastPress = null;
const OPENER = 'button, [role=button], a, .nav-item, .sel-btn, .lf-chip, [data-menu]';
document.addEventListener('pointerdown', (e) => { lastPress = e.button === 0 ? { el: e.target, t: performance.now() } : null; }, true);
document.addEventListener('contextmenu', () => { lastPress = null; }, true);
/** the button the menu about to open comes from, if any */
export function menuOpener() {
  if (!lastPress || performance.now() - lastPress.t > 1500 || !lastPress.el.closest) return null;
  return lastPress.el.closest(OPENER);
}
/** the press `e` closes a menu opened from `opener`: on the opener itself, its click must not open it again */
export function pressClosesMenu(e, opener) {
  if (!opener || !opener.contains(e.target)) return;
  const until = performance.now() + 800;
  const eat = (c) => {
    document.removeEventListener('click', eat, true);
    if (performance.now() < until && opener.contains(c.target)) { c.stopImmediatePropagation(); c.preventDefault(); }
  };
  document.addEventListener('click', eat, true);
  setTimeout(() => document.removeEventListener('click', eat, true), 800);
}

export function popupMenu(items, x, y) {
  closeMenus();
  const opener = menuOpener();
  return new Promise((resolve) => {
    let done = false;
    const finish = (v) => { if (done) return; done = true; if (pending === finish) pending = null; removeMenus(); document.removeEventListener('pointerdown', outside, true); document.removeEventListener('keydown', key, true); resolve(v); };
    const outside = (e) => { if (!openMenus.some((m) => m.contains(e.target))) { pressClosesMenu(e, opener); finish(null); } };
    // Esc is the menu's: it closes the menu and nothing under it (the equalizer it was opened from stays)
    const key = (e) => { if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); finish(null); } };
    const build = (list, px, py, depth, flipX = 0) => {
      openMenus.filter((m) => +m.dataset.depth >= depth).forEach((m) => m.remove());
      openMenus = openMenus.filter((m) => +m.dataset.depth < depth);
      const m = h('<div class="menu"></div>');
      m.dataset.depth = depth;
      list.forEach((it) => {
        if (it.type === 'sep') { m.appendChild(h('<div class="ms"></div>')); return; }
        // swatches: [colour …] — a palette's colours beside its name ([] = an empty one, drawn as an outline)
        const sw = Array.isArray(it.swatches) ? `<span class="mi-sw${it.swatches.length ? '' : ' blank'}">${it.swatches.map((c) => `<i style="background:${esc(c)}"></i>`).join('')}</span>` : '';
        const row = h(`<div class="mi${it.disabled ? ' dis' : ''}"><span class="chk">${it.checked ? '✓' : ''}</span>${sw}<span>${esc(it.label)}</span>${it.children ? '<span class="arr">›</span>' : ''}</div>`);
        row.addEventListener('pointerenter', () => {
          m.querySelectorAll('.mi.hl').forEach((r) => r.classList.remove('hl'));
          if (it.children) { row.classList.add('hl'); const r = row.getBoundingClientRect(); build(it.children, r.right + 2, r.top - 5, depth + 1, m.getBoundingClientRect().left); }
          else openMenus.filter((mm) => +mm.dataset.depth > depth).forEach((mm) => { mm.remove(); openMenus = openMenus.filter((o) => o !== mm); });
        });
        if (!it.children) row.addEventListener('click', () => finish(it.id));
        m.appendChild(row);
      });
      $('layer').appendChild(m);
      openMenus.push(m);
      const r = m.getBoundingClientRect();
      const W = innerWidth, H = innerHeight;
      let lx = px, ly = py;
      if (lx + r.width > W - 6) lx = depth ? flipX - r.width - 2 : W - r.width - 6;
      if (ly + r.height > H - 6) ly = Math.max(6, H - r.height - 6);
      m.style.left = Math.max(6, lx) + 'px'; m.style.top = ly + 'px';
    };
    build(items, x, y, 0);
    pending = finish;
    setTimeout(() => { if (done) return; document.addEventListener('pointerdown', outside, true); document.addEventListener('keydown', key, true); }, 0);
  });
}

// ---------------------------------------------------------------- misc
const hash = (s) => { let x = 2166136261; for (let i = 0; i < s.length; i++) { x ^= s.charCodeAt(i); x = Math.imul(x, 16777619); } return x >>> 0; };
/** Placeholder cover: deterministic two-hue gradient + initials. */
export function placeholder(name, artist) {
  const hh = hash((artist || '') + '|' + (name || '')) % 360;
  const ini = String(name || '?').replace(/[^\p{L}\p{N} ]/gu, '').split(/\s+/).filter(Boolean).slice(0, 2).map((w) => w[0]).join('').toUpperCase() || '♪';
  return { bg: `linear-gradient(135deg, oklch(55% 0.13 ${hh}), oklch(32% 0.09 ${(hh + 50) % 360}))`, ini };
}

export function confirmInline(text) { return window.confirm ? window.confirm(text) : true; }
