/*
 * Gatefold · romaji-worker.js — Japanese lyrics in Latin letters (romaji), off the page's thread.
 *
 * kuromoji (vendor/kuromoji.js) cuts each line into words and reads each word in kana — the kanji too, from its
 * dictionary (IPADIC, ~18 MB, downloaded by romaji.js once and handed over here). The kana become Hepburn
 * romaji: «僕の名前は» → «boku no namae wa». Words are spaced; a particle は/へ/を reads wa/e/o.
 * Messages: { init: { name: ArrayBuffer… } } → { ready } | { error }; { id, lines: [text] } → { id, lines: [romaji] }.
 */
/* global importScripts, kuromoji */
importScripts('vendor/kuromoji.js');

let files = null, tokenizer = null;
self.gfKuromojiFile = (url) => (files ? files[String(url).split(/[\\/]/).pop()] : null);

const K = {
  ア: 'a', イ: 'i', ウ: 'u', エ: 'e', オ: 'o', カ: 'ka', キ: 'ki', ク: 'ku', ケ: 'ke', コ: 'ko', サ: 'sa', シ: 'shi', ス: 'su', セ: 'se', ソ: 'so',
  タ: 'ta', チ: 'chi', ツ: 'tsu', テ: 'te', ト: 'to', ナ: 'na', ニ: 'ni', ヌ: 'nu', ネ: 'ne', ノ: 'no', ハ: 'ha', ヒ: 'hi', フ: 'fu', ヘ: 'he', ホ: 'ho',
  マ: 'ma', ミ: 'mi', ム: 'mu', メ: 'me', モ: 'mo', ヤ: 'ya', ユ: 'yu', ヨ: 'yo', ラ: 'ra', リ: 'ri', ル: 'ru', レ: 're', ロ: 'ro', ワ: 'wa', ヰ: 'i', ヱ: 'e', ヲ: 'o', ン: 'n',
  ガ: 'ga', ギ: 'gi', グ: 'gu', ゲ: 'ge', ゴ: 'go', ザ: 'za', ジ: 'ji', ズ: 'zu', ゼ: 'ze', ゾ: 'zo', ダ: 'da', ヂ: 'ji', ヅ: 'zu', デ: 'de', ド: 'do',
  バ: 'ba', ビ: 'bi', ブ: 'bu', ベ: 'be', ボ: 'bo', パ: 'pa', ピ: 'pi', プ: 'pu', ペ: 'pe', ポ: 'po', ヴ: 'vu',
  ァ: 'a', ィ: 'i', ゥ: 'u', ェ: 'e', ォ: 'o', ャ: 'ya', ュ: 'yu', ョ: 'yo', ヮ: 'wa', ヵ: 'ka', ヶ: 'ke',
};
// two kana that read as one: キャ kya, シュ shu, チェ che, ティ ti, ファ fa…
const Y = { ャ: 'a', ュ: 'u', ョ: 'o' };
const SMALL = { ァ: 'a', ィ: 'i', ゥ: 'u', ェ: 'e', ォ: 'o' };
const DOUBLE = '\u0001';   // «the next word's first consonant twice» (待っ|て → matte)
const toKata = (s) => s.replace(/[ぁ-ゖ]/g, (c) => String.fromCharCode(c.charCodeAt(0) + 0x60));

function kanaToRomaji(kata) {
  const s = toKata(kata);
  let out = '', i = 0;
  while (i < s.length) {
    const c = s[i], n = s[i + 1];
    if (c === 'ッ') {   // a doubled consonant: the next one's first letter (ッチ → tchi); at the end of a word, the next word's
      const next = read(s, i + 1);
      out += next.r ? (next.r.startsWith('ch') ? 't' : next.r[0]) : (i === s.length - 1 ? DOUBLE : '');
      i++; continue;
    }
    if (c === 'ー') { const v = out.match(/[aeiou](?!.*[aeiou])/); out += v ? v[0] : ''; i++; continue; }
    if (c === 'ン') { out += /^[aeiouy]/.test(read(s, i + 1).r || '') ? "n'" : 'n'; i++; continue; }
    const r = read(s, i);
    if (!r.r) { out += c; i++; continue; }
    out += r.r; i += r.len;
    void n;
  }
  return out;
}
function read(s, i) {
  const c = s[i], n = s[i + 1];
  if (!c || !K[c]) return { r: '', len: 1 };
  const base = K[c];
  if (n && Y[n] && /i$/.test(base) && base.length > 1) {   // キャ kya, シャ sha, チャ cha, ジャ ja
    const stem = base.slice(0, -1);
    return { r: (/(sh|ch|j)$/.test(stem) ? stem : stem + 'y') + Y[n], len: 2 };
  }
  if (n && SMALL[n]) {   // ファ fa, ティ ti, ドゥ du, ウィ wi, ヴァ va
    if (c === 'フ') return { r: 'f' + SMALL[n], len: 2 };
    if (c === 'ヴ') return { r: 'v' + SMALL[n], len: 2 };
    if (c === 'テ' || c === 'デ') return { r: base[0] + SMALL[n], len: 2 };
    if (c === 'ト' || c === 'ド') return { r: base[0] + SMALL[n], len: 2 };
    if (c === 'ウ') return { r: 'w' + SMALL[n], len: 2 };
    if (/(shi|chi|ji)$/.test(base)) return { r: base.slice(0, -1) + SMALL[n], len: 2 };
    if (c === 'ツ') return { r: 'ts' + SMALL[n], len: 2 };
  }
  return { r: base, len: 1 };
}

const JA = /[぀-ヿ一-鿿㐀-䶿]/;
function line(text) {
  if (!JA.test(text)) return text;
  const words = [];
  for (const t of tokenizer.tokenize(text)) {
    const surf = t.surface_form;
    if (!JA.test(surf)) {   // Latin words, numbers, punctuation stay as they are
      if (/^[\s　]+$/.test(surf)) continue;
      if (/^[、。！？!?,.・…「」『』（）()〜~]+$/.test(surf)) { words.push({ r: surf.replace(/、/g, ',').replace(/。/g, '.').replace(/！/g, '!').replace(/？/g, '?').replace(/[「」『』]/g, '"').replace(/[（]/g, '(').replace(/[）]/g, ')').replace(/[〜]/g, '~').replace(/・/g, ' '), glue: true }); continue; }
      words.push({ r: surf }); continue;
    }
    let r;
    if (t.pos === '助詞' && surf === 'は') r = 'wa';
    else if (t.pos === '助詞' && surf === 'へ') r = 'e';
    else if (t.pos === '助詞' && surf === 'を') r = 'o';
    else r = kanaToRomaji(t.reading && t.reading !== '*' ? t.reading : surf);
    // a verb's or an adjective's endings stay on it (tabe-ta → tabeta, ikanai, matte); after a noun «desu», «da» stand
    // apart (tanaka desu); a katakana word the dictionary cut into a short piece and the rest is one word again (faitoo)
    const prev = words[words.length - 1];
    const kata = /^[\u30a0-\u30ff]+$/.test(surf);
    const afterVerb = prev && /^(動詞|形容詞|助動詞)$/.test(prev.pos);
    const glue = (t.pos === '助動詞' && afterVerb) || (t.pos === '動詞' && t.pos_detail_1 === '接尾') || (t.pos_detail_1 === '接続助詞' && /^(て|で)$/.test(surf))
      || (kata && prev && prev.kata && (surf.length <= 2 || prev.surf.length <= 2));
    words.push({ r, glue: glue && words.length > 0, pos: t.pos, kata, surf });
  }
  let out = '';
  for (const w of words) {
    let r = w.r;
    if (out.endsWith(DOUBLE)) { out = out.slice(0, -1); r = (/^ch/.test(r) ? 't' : /^[bcdfghjklmprstvwz]/.test(r) ? r[0] : '') + r; }
    out += (out && !w.glue ? ' ' : '') + r;
  }
  out = out.split(DOUBLE).join('');
  return out.replace(/\s+([,.!?)])/g, '$1').replace(/\(\s+/g, '(').trim();
}

self.onmessage = (e) => {
  const d = e.data || {};
  if (d.init) {
    files = d.init;
    kuromoji.builder({ dicPath: 'gfdict/' }).build((err, tk) => {
      files = null;   // the dictionary is built: the compressed copies can go
      if (err) { self.postMessage({ error: String(err && err.message || err) }); return; }
      tokenizer = tk;
      self.postMessage({ ready: true });
    });
    return;
  }
  if (d.id != null) {
    try { self.postMessage({ id: d.id, lines: (d.lines || []).map((l) => (tokenizer ? line(String(l || '')) : '')) }); }
    catch (err) { self.postMessage({ id: d.id, error: String(err && err.message || err) }); }
  }
};
