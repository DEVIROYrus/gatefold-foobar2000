/*
 * Gatefold · relink.js — songs of your playlists whose files moved (#12.4).
 *
 * A playlist keeps a file's path. Move or rename the folder and «Понравившиеся» (or any playlist) points at
 * nothing: the song is shown as lost, though it is still in the library under its new path (the play counts
 * stay — foobar2000 keeps them by the tags). Here each entry that is not in the library is looked up in the library
 * by its tags (artist, album, title; the length within two seconds). When exactly one track fits — or one with the
 * same file name — the entry is put on it, in the same place of the list. (Whether the old file is still somewhere
 * cannot be asked — a theme sees no folders but its own — and a copy outside the library is the same song anyway.)
 * An entry with no single answer is left as it is: nothing is guessed.
 */
import { call, ok, log } from './bridge.js';
import * as TS from './trackstore.js';

const norm = (s) => String(s || '').normalize('NFKC').toLowerCase().replace(/\s+/g, ' ').trim();
const keyOf = (t) => `${norm(t.artist)}\u0001${norm(t.album)}\u0001${norm(t.title)}`;
const lc = (s) => String(s || '').toLowerCase();
const fileOf = (p) => lc(String(p || '').split(/[\\/]/).pop());
const isFile = (p) => /^[a-z]:[\\/]|^\\\\/i.test(String(p || ''));
const handleOf = (t) => t.handle || (t.subsong ? `${t.absolutePath || t.path}|subsong:${t.subsong}` : (t.absolutePath || t.path));

/** the library by tags, and the set of its paths (built once per call of scanAll) */
async function libraryIndex() {
  const lib = await TS.all().catch(() => []);
  const inLib = new Set(), byKey = new Map();
  for (const t of lib) {
    inLib.add(lc(handleOf(t)));
    const k = keyOf(t);
    if (!norm(t.title)) continue;
    const l = byKey.get(k); if (l) l.push(t); else byKey.set(k, [t]);
  }
  return { inLib, byKey, size: lib.length };
}

/** what can be put right in one playlist: [{ index, from, to }] */
export async function scan(guid, ix) {
  const out = [];
  for (let start = 0; start < 200000; start += 2000) {
    const r = await call('playlist.getTracks', { playlistGuid: guid, start, count: 2000, fields: ['handle', 'title', 'artist', 'album', 'duration', 'absolutePath', 'subsong'] });
    if (!ok(r)) break;
    const tracks = r.tracks || [];
    for (let i = 0; i < tracks.length; i++) {
      const t = tracks[i], from = handleOf(t);
      if (!from || ix.inLib.has(lc(from)) || !isFile(t.absolutePath || t.path)) continue;   // in the library, or a stream
      let cands = ix.byKey.get(keyOf(t)) || [];
      if (t.duration) cands = cands.filter((c) => !c.duration || Math.abs(c.duration - t.duration) <= 2);
      if (cands.length > 1) { const same = cands.filter((c) => fileOf(c.absolutePath) === fileOf(t.absolutePath || t.path)); if (same.length === 1) cands = same; }
      if (cands.length !== 1) continue;
      out.push({ index: t.index ?? start + i, from, to: handleOf(cands[0]), title: t.title });
    }
    if (tracks.length < 2000) break;
  }
  return out;
}

/** put the entries back on their tracks, each in its place (from the end, so the places do not shift) */
export async function apply(guid, fixes) {
  let n = 0;
  for (const f of fixes.slice().sort((a, b) => b.index - a.index)) {
    const rm = await call('playlist.removeTracks', { playlistGuid: guid, items: [f.index] });
    if (!ok(rm)) { log('relink: remove failed', rm.error); continue; }
    const add = await call('playlist.addHandles', { playlistGuid: guid, handles: [f.to], position: f.index });
    if (!ok(add)) { log('relink: add failed', add.error); continue; }
    n++;
  }
  return n;
}

/** every playlist (or only `guids`): how many entries were put back, per playlist name */
export async function relinkAll({ guids = null, dry = false } = {}) {
  const ix = await libraryIndex();
  if (!ix.size) return { total: 0, lists: [] };
  const all = await call('playlist.getAll');
  const lists = ((ok(all) && all.playlists) || []).filter((p) => !p.isAutoplaylist && !p.isLocked && (!guids || guids.includes(p.guid)));
  const done = [];
  let total = 0;
  for (const p of lists) {
    const fixes = await scan(p.guid, ix);
    if (!fixes.length) continue;
    const n = dry ? fixes.length : await apply(p.guid, fixes);
    if (n) { done.push({ name: p.name, n }); total += n; }
  }
  return { total, lists: done };
}
