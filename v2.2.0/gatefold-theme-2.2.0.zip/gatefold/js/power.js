/*
 * Gatefold · power.js — how much may move on screen right now (#29).
 *
 *   Frame rate   Settings → «Smoothness»: what moves with the music (the spectrum, the cover's breathing, the VU
 *                meters, the analyzer) is drawn at most 60 (or 30) times a second, or at the monitor's own rate.
 *                Every frame the window draws costs the GPU the whole picture again, so on a 144 Hz laptop «the
 *                monitor's rate» is more than twice the work of 60 for a difference hardly seen.
 *   Battery      On battery, or with Windows' battery/energy saver on: the «Economy» set (or only the motion
 *                stopped) is in force until the laptop is plugged in — the user's own settings stay as they are and
 *                come back by themselves (settings.js → setOverrides).
 *   Background   While another program is in front, 30 frames a second and a slower drift.
 *   Hidden       Minimized or in the tray the page is hidden and draws nothing (the host tells the web view).
 *
 * The host says how the computer is powered (system.power, and system.powerChanged when it changes); an older
 * component does not, and then the web's Battery Status API is asked.
 */
import { on } from './bridge.js';
import { settings, userSettings, onSettings, setOverrides, PRESETS } from './settings.js';
import * as Ambient from './ambient.js';
import * as SlowMo from './slowmo.js';

const S = { battery: false, saver: false, percent: null, focused: true, source: '' };
export const events = new EventTarget();

/** on battery (or with the energy saver) and a battery mode chosen */
export const lowPower = () => (S.battery || S.saver) && userSettings.powerBattery !== 'off';
const FPS = { max: Infinity, 60: 60, 30: 30, eco: 30 };
/** frames a second at most for what moves with the music */
export function fps() {
  let f = FPS[String(settings.motionFps)] ?? 60;
  if (lowPower()) f = Math.min(f, 30);
  if (!S.focused && userSettings.powerBackground !== false) f = Math.min(f, 30);
  return f;
}
/** milliseconds between two frames (0: every frame of the monitor) */
export const frameMs = () => { const f = fps(); return Number.isFinite(f) ? 1000 / f : 0; };
/**
 * A limiter for a requestAnimationFrame loop: due(now) is true at most fps() times a second and evenly — on a
 * 144 Hz monitor at 60, every second or third frame of the monitor, 60 a second on average.
 */
export function limiter() {
  let next = 0;
  return (now) => {
    const ms = frameMs();
    if (!ms) return true;
    if (now < next - 1) return false;
    next = now - next > ms ? now + ms : next + ms;
    return true;
  };
}
export const state = () => ({ ...S, low: lowPower(), fps: fps(), mode: lowPower() ? userSettings.powerBattery || 'eco' : 'off' });

/* the battery modes: what is in force over the user's own settings */
const MODES = {
  eco: () => ({ ...PRESETS.eco, motionFps: '30' }),
  calm: () => ({ ambientMotion: false, beatReact: false, canvasMotion: false, coverSweep: false, artistAuto: false, motionFps: '30' }),
};
let lastKey = '';
function apply() {
  const m = lowPower() ? MODES[userSettings.powerBattery] || MODES.eco : null;
  setOverrides(m ? m() : null);
  Ambient.setSlow(fps() <= 30); SlowMo.setSlow(fps() <= 30);
  const key = [S.battery, S.saver, S.focused, lowPower(), fps(), userSettings.powerBattery].join('|');
  if (key === lastKey) return;
  lastKey = key;
  events.dispatchEvent(new CustomEvent('change', { detail: state() }));
}
function setPower(p, source) {
  if (!p) return;
  S.source = source;
  S.battery = !!p.onBattery; S.saver = !!p.saver; S.percent = p.percent ?? null;
  apply();
}

/* focus: a native menu or a file dialog takes it for a moment — only a blur that lasts counts */
let blurT = 0;
function setFocused(f) {
  clearTimeout(blurT);
  if (f) { if (!S.focused) { S.focused = true; apply(); } return; }
  blurT = setTimeout(() => { if (!document.hasFocus()) { S.focused = false; apply(); } }, 600);
}

let started = false;
export async function init() {
  if (started) return;
  started = true;
  addEventListener('focus', () => setFocused(true));
  addEventListener('blur', () => setFocused(false));
  on('window:activated', (d) => setFocused(!!(d && d.active)));
  onSettings((k) => { if (k === '*' || k === 'motionFps' || k === 'powerBattery' || k === 'powerBackground') apply(); });
  S.focused = document.hasFocus();
  const gf = window.gf;
  let host = false;
  if (gf && gf.call) {
    try { setPower(await gf.call('system.power'), 'host'); host = true; } catch { /* an older component */ }
    if (host) try { gf.on('system.powerChanged', (d) => setPower(d, 'host')); } catch {}
  }
  if (!host) {
    try {
      const b = navigator.getBattery && await navigator.getBattery();
      if (b) {
        const read = () => setPower({ onBattery: b.charging === false, saver: false, percent: Math.round(b.level * 100) }, 'web');
        b.addEventListener('chargingchange', read);
        read();
      }
    } catch { /* no battery API */ }
  }
  apply();
}
