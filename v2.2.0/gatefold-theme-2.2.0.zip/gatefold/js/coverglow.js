/*
 * Gatefold · coverglow.js — the light of a cover around it: album grids (Library, an artist's page, Home), the
 * album page's cover and Now Playing.
 *
 * The glow is the cover's own colours where they are — the top of a yellow sky lights up above the cover, an orange
 * floor below it: a small picture made once per cover (the cover shrunk to 20×20, drawn twice with a blur into a
 * larger transparent square — a wide spill and a bright rim — its edge faded out, a touch of noise against banding),
 * stretched behind the cover so that its middle lies exactly under it. No CSS blur on dozens of tiles while
 * scrolling, nothing redrawn when the pointer moves.
 *
 * It comes with the cover, not after it: a picture already made is put in place in the same moment the cover has
 * loaded; a new one is made within the next frame (a few per frame, a millisecond or two each). Pictures are kept
 * as data: URLs — nothing to revoke, so a tile drawn again later never points at a picture that is gone. Each glow
 * is an element of its own inside the tile (not a style on the tile, which the grid rewrites when it lays tiles
 * out), so it stays put.
 *
 * In the grids every glow sits in the grid's bottom layer (see islands.css), so a glow never covers another album.
 * Strength: Settings → Оформление → «Свечение обложек» (0 — off), separately for the grids and for Now Playing.
 */
import { settings, onSettings } from './settings.js';

const GRID = '#libGrid .tile .cov img, .agrid .tile .cov img, .hm-tile .cov img';
const HERO = '#albumHero .album-cover img';
const NP = '#npImgA, #npImgB';

/* The geometry, shared with islands.css: the cover fills the middle FIT of the glow picture, and the page
   stretches the picture to 1 / FIT of the cover. */
export const FIT = { S: 0.64, L: 0.56 };
const SIZE = { S: 80, L: 128 };

const cache = new Map();     // 'S|' / 'L|' + cover URL → data: URL of its glow, or a promise of it
const MAX = 3000;

let cv = null;
/** a glow picture (data: URL) for a loaded image */
async function make(img, size, fit) {
  // the colours, averaged down: no detail survives, no shimmer when the picture is stretched
  const bmp = await createImageBitmap(img, { resizeWidth: 20, resizeHeight: 20, resizeQuality: 'high' });
  try {
    if (!cv) cv = document.createElement('canvas');
    cv.width = cv.height = size;
    const x = cv.getContext('2d', { willReadFrequently: true });
    x.clearRect(0, 0, size, size);
    x.imageSmoothingQuality = 'high';
    const d = size * fit, o = (size - d) / 2;
    // a wide, soft spill: the cover a little larger, blurred far, colours lifted (a dark, dull cover still gives light)
    x.filter = `blur(${(size * 0.085).toFixed(1)}px) saturate(1.5) brightness(1.08)`;
    x.globalAlpha = 1;
    x.drawImage(bmp, o - d * 0.04, o - d * 0.04, d * 1.08, d * 1.08);
    // the bright rim right at the cover's edge
    x.filter = `blur(${(size * 0.035).toFixed(1)}px) saturate(1.35)`;
    x.globalAlpha = 0.8;
    x.drawImage(bmp, o, o, d, d);
    x.filter = 'none'; x.globalAlpha = 1;
    // the picture's own edge faded to nothing (no faint square around a bright cover), and ±1 level of noise: a smooth
    // gradient stretched five times over shows its 8-bit steps in the dark
    const im = x.getImageData(0, 0, size, size), p = im.data, ramp = size * 0.14;
    const edge = new Float32Array(size);
    for (let i = 0; i < size; i++) { const k = Math.min(1, Math.min(i + 0.5, size - i - 0.5) / ramp); edge[i] = k * k * (3 - 2 * k); }
    for (let y = 0, i = 0; y < size; y++) for (let xx = 0; xx < size; xx++, i += 4) {
      if (!p[i + 3]) continue;
      const n = (Math.random() - 0.5) * 2.2;
      p[i] += n; p[i + 1] += n; p[i + 2] += n;
      p[i + 3] = p[i + 3] * edge[xx] * edge[y] + (Math.random() - 0.5) * 2.2;
    }
    x.putImageData(im, 0, 0);
    return cv.toDataURL('image/png');
  } finally { bmp.close && bmp.close(); }
}

/* made a few per frame (≤6 ms of each): a screen of tiles gets its glows in a frame or two */
const queue = [];
let pumping = false;
function pump() {
  if (pumping) return;
  pumping = true;
  requestAnimationFrame(async () => {
    const t0 = performance.now();
    while (queue.length && performance.now() - t0 < 6) {
      const job = queue.shift();
      if (!job.img.isConnected) { job.done(''); continue; }   // a tile scrolled away before its turn
      try { job.done(await make(job.img, job.size, job.fit)); } catch { job.done(''); }   // a cover from another site: no pixels to read
    }
    pumping = false;
    if (queue.length) pump();
  });
}
/** the glow at once when it is made already (a string), else a promise of it */
function glowFor(img, big) {
  const key = (big ? 'L|' : 'S|') + img.currentSrc;
  const have = cache.get(key);
  if (have) return have;
  const k = big ? 'L' : 'S';
  const p = new Promise((done) => { queue.push({ img, size: SIZE[k], fit: FIT[k], done }); pump(); }).then((u) => {
    cache.delete(key);
    if (!u) return '';
    cache.set(key, u);
    if (cache.size > MAX) for (const k2 of cache.keys()) { cache.delete(k2); if (cache.size <= MAX * 0.9) break; }   // oldest first; tiles keep their own copy
    return u;
  });
  cache.set(key, p);
  return p;
}
const usable = (img) => img.complete && img.naturalWidth > 1 && img.currentSrc;
/** put `u` (or what it resolves to) in place unless the cover has changed meanwhile */
function put(el, img, u, fn) {
  const src = img.currentSrc;
  if (typeof u === 'string') { if (u) fn(u); return; }
  u.then((v) => { if (v && img.currentSrc === src && el.isConnected) fn(v); });
}

function attachGrid(img) {
  if (!(+settings.coverGlow > 0) || !usable(img)) return;
  const host = img.closest('.tile, .hm-tile'); if (!host) return;
  let g = host.querySelector(':scope > .cglow');
  if (!g) { g = document.createElement('i'); g.className = 'cglow'; g.setAttribute('aria-hidden', 'true'); host.prepend(g); }
  put(g, img, glowFor(img, false), (u) => { g.style.backgroundImage = `url("${u}")`; g.classList.add('on'); });
}
function attachHero(img) {
  const g = document.querySelector('#albumHero .cover-glow'); if (!g) return;
  if (!(+settings.coverGlowNp > 0) || !usable(img)) return;
  put(g, img, glowFor(img, true), (u) => {
    g.style.aspectRatio = String(img.naturalWidth / img.naturalHeight);   // a 3:4 cover glows as a 3:4 box
    g.style.backgroundImage = `url("${u}")`; g.classList.add('on');
  });
}
let npSrc = '';
function attachNp(img) {
  if (!(+settings.coverGlowNp > 0) || !usable(img)) return;
  const g = document.getElementById('npGlow'); if (!g) return;
  const src = npSrc = img.currentSrc;
  put(g, img, glowFor(img, true), (u) => {
    if (npSrc !== src) return;
    // two layers: the new glow fades in over the old one, as the cover itself does
    const [a, b] = g.children;
    const cur = a.classList.contains('on') ? a : b.classList.contains('on') ? b : null;
    if (cur && cur.dataset.src === src) return;                // the same cover again: nothing to change
    const next = cur === a ? b : a;
    next.style.backgroundImage = `url("${u}")`; next.dataset.src = src;
    next.classList.add('on'); if (cur) cur.classList.remove('on');
  });
}
/** no cover on Now Playing: no glow from the last one */
export function npClear() { npSrc = ''; document.querySelectorAll('#npGlow > i').forEach((x) => { x.classList.remove('on'); delete x.dataset.src; }); }

function route(img) {
  if (img.matches(NP)) attachNp(img);
  else if (img.matches(HERO)) attachHero(img);
  else if (img.matches(GRID)) attachGrid(img);
}
document.addEventListener('load', (e) => { const img = e.target; if (img instanceof HTMLImageElement) route(img); }, true);

/** strength from the settings: CSS variables, and the covers already on screen when it is switched on */
function apply(key) {
  const t = Math.max(0, Math.min(2, +settings.coverGlow || 0)), n = Math.max(0, Math.min(2, +settings.coverGlowNp || 0));
  const r = document.documentElement;
  r.style.setProperty('--glow-t', String(t)); r.style.setProperty('--glow-n', String(n));
  document.body.classList.toggle('glow-tiles', t > 0);
  document.body.classList.toggle('glow-np', n > 0);
  if ((key === 'coverGlow' && t > 0) || (key === 'coverGlowNp' && n > 0)) document.querySelectorAll(`${GRID}, ${HERO}, ${NP}`).forEach((img) => { if (!img.matches('#npImgA:not(.on), #npImgB:not(.on)')) route(img); });
}
apply('*');
onSettings((k) => { if (k === 'coverGlow' || k === 'coverGlowNp' || k === '*') apply(k); });
