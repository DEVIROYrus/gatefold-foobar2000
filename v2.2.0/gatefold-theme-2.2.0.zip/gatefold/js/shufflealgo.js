/*
 * Gatefold · shufflealgo.js — the order of a smart shuffle (smartshuffle.js plays it). Pure: no host, no page.
 *
 * Random is not what people mean by shuffle: true randomness clusters — three songs of one artist in a row, the
 * same album twice in ten tracks, the song you heard an hour ago first again. The order is built the way the
 * music services build theirs, in four steps:
 *
 *  1. Spread (Spotify's «balanced shuffle», after Martin Fiedler): each artist's tracks are laid evenly across the
 *     whole list — every artist at its own random offset, its tracks 1/n apart with a little jitter — and within
 *     an artist the albums the same way. A third of the list by one artist comes every third track, not in a lump.
 *  2. Freshness: what you heard recently moves towards the end, what you have not heard for a long time (or never)
 *     towards the start, a liked track a little forward. A nudge, not a sort: the spread stays.
 *  3. Flow: walking the list, each next track is chosen among the few that come next in it — the one whose sound
 *     follows best from the playing one (Gatefold's sound analysis: timbre, energy, mood) and is not the same
 *     artist or album — with a weighted draw, so the order stays surprising. Like a DJ who still shuffles.
 *  4. The seams: the track you start from plays first; a new round does not begin with what ended the last one.
 */

/** a seeded generator (mulberry32): the same seed gives the same order (tests; a restored session) */
export function rng(seed = (Math.random() * 2 ** 32) >>> 0) {
  let a = seed >>> 0;
  return () => { a = (a + 0x6d2b79f5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
}
const lc = (s) => String(s || '').trim().toLowerCase();
/** the artist a track is grouped by: its album artist (a compilation's «Various Artists» → the track's own) */
export const artistOf = (t) => {
  const aa = lc(t.albumArtist);
  return (aa && !/^(various|various artists|va|разные исполнители|сборник)$/.test(aa) ? aa : lc(t.artist).split(/\s*(?:;|,|&| feat\.? | ft\.? | x )\s*/)[0]) || '?';
};
export const albumOf = (t) => artistOf(t) + '\u0001' + lc(t.album);

function shuffled(list, rnd) {
  const a = list.slice();
  for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(rnd() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; }
  return a;
}
/** items spread evenly: groups by `keyOf`, each group's items `inner`-ordered, laid 1/n apart from a random start */
function spread(items, keyOf, inner, rnd) {
  const groups = new Map();
  for (const it of items) { const k = keyOf(it); if (!groups.has(k)) groups.set(k, []); groups.get(k).push(it); }
  const placed = [];
  for (const g of groups.values()) {
    const list = inner(g), n = list.length, step = 1 / n, off = rnd() * step;
    list.forEach((it, i) => placed.push([off + i * step + (rnd() - 0.5) * step * 0.2, it]));
  }
  placed.sort((a, b) => a[0] - b[0]);
  return placed.map((p) => p[1]);
}

/**
 * The order to play `tracks` in.
 *  tracks: [{ key, artist, albumArtist, album, … }]
 *  opts.first      key of the track that plays first (the one you started from)
 *  opts.heardAt    key → when it last played (ms), from Gatefold's history
 *  opts.liked      key → true
 *  opts.sound      key → a sound record, or nothing; opts.dist(a, b) → 0 (the same) … ~1.5 (far apart)
 *  opts.avoidFirst keys that should not open the round (how the last one ended)
 *  opts.now, opts.rnd
 * → keys, in order
 */
export function smartOrder(tracks, opts = {}) {
  const rnd = opts.rnd || rng(), now = opts.now || Date.now();
  const seen = new Set(), list = [];
  for (const t of tracks) if (t && t.key && !seen.has(t.key)) { seen.add(t.key); list.push(t); }
  if (list.length <= 1) return list.map((t) => t.key);
  // 1. the spread: artists over the whole list, each artist's albums over its share, tracks within an album shuffled
  let order = spread(list, artistOf, (g) => spread(g, albumOf, (al) => shuffled(al, rnd), rnd), rnd);
  // 2. freshness: heard in the last day → towards the end; not for a month or never → towards the start
  const heard = opts.heardAt || new Map(), liked = opts.liked || new Map();
  const N = order.length;
  const keyed = order.map((t, i) => {
    const at = heard.get(t.key), ageD = at ? (now - at) / 86400000 : Infinity;
    const fresh = ageD < 1 ? 0.3 : ageD < 3 ? 0.18 : ageD < 10 ? 0.07 : ageD > 45 ? -0.08 : 0;
    const like = liked.get(t.key) ? -0.05 : 0;
    return [i / N + fresh + like + (rnd() - 0.5) * 0.02, t];
  });
  keyed.sort((a, b) => a[0] - b[0]);
  order = keyed.map((x) => x[1]);
  // 4a. the start: the chosen track first; the end of the last round does not open this one
  const avoid = new Set(opts.avoidFirst || []);
  if (opts.first && seen.has(opts.first)) {
    const i = order.findIndex((t) => t.key === opts.first);
    order.unshift(...order.splice(i, 1));
  } else if (avoid.size) {
    const head = Math.min(order.length, Math.max(3, Math.ceil(order.length * 0.15)));
    const bad = order.slice(0, head).filter((t) => avoid.has(t.key));
    if (bad.length < order.length) { order = order.filter((t) => !bad.includes(t)); order.splice(Math.min(order.length, head + Math.floor(rnd() * head)), 0, ...bad); }
  }
  // 3. the flow: each next track among the next few of the spread, by how well it follows, drawn with weights
  const W = Math.min(6, order.length - 1), sound = opts.sound, dist = opts.dist;
  // (a window of the next W, refilled from the spread as it is used: linear, a library of 50 000 in a blink)
  const out = [order[0]], cand = order.slice(1, 1 + W);
  let next = 1 + W;
  while (cand.length) {
    const prev = out[out.length - 1], ps = sound && sound(prev.key);
    const cost = cand.map((t, i) => {
      let c = i * 0.22;                                              // keep close to the spread
      if (artistOf(t) === artistOf(prev)) c += 2.2;
      else if (out.length > 1 && artistOf(t) === artistOf(out[out.length - 2])) c += 0.7;
      if (albumOf(t) === albumOf(prev)) c += 1;
      const ts = ps && sound(t.key);
      if (ts && dist) c += Math.min(1.6, dist(ps, ts)) * 1.1;          // the sound: a smooth step, not a jump
      return c;
    });
    const T = 0.28, m = Math.min(...cost);
    const w = cost.map((c) => Math.exp(-(c - m) / T)), sum = w.reduce((s, x) => s + x, 0);
    let r = rnd() * sum, k = 0;
    while (k < w.length - 1 && (r -= w[k]) > 0) k++;
    out.push(cand.splice(k, 1)[0]);
    if (next < order.length) cand.push(order[next++]);
  }
  return out.map((t) => t.key);
}

/** how well an order is spread: the share of neighbours by the same artist (0 = none) */
export function sameArtistNeighbours(keys, byKey) {
  let n = 0; for (let i = 1; i < keys.length; i++) if (artistOf(byKey.get(keys[i])) === artistOf(byKey.get(keys[i - 1]))) n++;
  return keys.length > 1 ? n / (keys.length - 1) : 0;
}
