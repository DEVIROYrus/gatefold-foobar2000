/*
 * Gatefold · analyzer-worker.js — the measuring behind the spectrum analyzer (analyzer.js), off every UI thread.
 *
 *  In:  { type: 'push', frames: Float32Array (interleaved), ch, sr }   — every sample that was played, in order
 *       { type: 'frame', res, smooth, tilt, mode, points }             — a picture of the spectrum now
 *       { type: 'reset' }                                               — a new track: the integrated values start again
 *  Out: { spec: Float32Array(points) dB, spec2: (L/R or M/S: the second curve) | null, peak: { hz, db }, meters }
 *
 *  Spectrum: multi-resolution, as the studio analyzers do — a long FFT for the bass (where the notes are a few hertz
 *  apart), a short one for the treble (quick to follow), crossfaded between 300 Hz and 2 kHz. Blackman-Harris
 *  window (sidelobes at −92 dB: a loud bass note does not smear over the quiet rest), the level of a sine read
 *  in dBFS, fractional-octave smoothing by the power in each band (prefix sums: any width costs the same), the
 *  tilt (dB per octave around 1 kHz) that makes pink noise — music's average — draw flat.
 *
 *  Meters: sample peak and true peak (4× oversampled, as ITU-R BS.1770-4 describes), RMS (300 ms), loudness per
 *  EBU R128 — momentary (400 ms), short-term (3 s), integrated (gated: −70 LUFS absolute, −10 LU relative) and the
 *  loudness range (LRA: short-term values gated at −20 LU, 10th to 95th percentile) — the stereo correlation
 *  (−1 … +1), the width (side against mid) and the crest factor (peak over RMS).
 */
const HIST = 65536;                               // frames kept per channel (≥ the longest FFT)
let sr = 44100, ch = 2;
const hist = [new Float32Array(HIST), new Float32Array(HIST)];
let pos = 0, filled = 0;

/* ---------------------------------------------------------------- K-weighting (BS.1770), any sample rate */
let kw = null;
function kCoeffs(fs) {
  let f0 = 1681.974450955533, G = 3.999843853973347, Q = 0.7071752369554196;
  let K = Math.tan(Math.PI * f0 / fs);
  const Vh = Math.pow(10, G / 20), Vb = Math.pow(Vh, 0.4996667741545416);
  let a0 = 1 + K / Q + K * K;
  const pre = { b: [(Vh + Vb * K / Q + K * K) / a0, 2 * (K * K - Vh) / a0, (Vh - Vb * K / Q + K * K) / a0], a: [2 * (K * K - 1) / a0, (1 - K / Q + K * K) / a0] };
  f0 = 38.13547087602444; Q = 0.5003270373238773; K = Math.tan(Math.PI * f0 / fs);
  a0 = 1 + K / Q + K * K;
  const rlb = { b: [1, -2, 1], a: [2 * (K * K - 1) / a0, (1 - K / Q + K * K) / a0] };
  return { pre, rlb, z: [new Float64Array(4), new Float64Array(4)] };
}
function kSample(c, x) {
  const z = kw.z[c], p = kw.pre, r = kw.rlb;
  const y1 = p.b[0] * x + p.b[1] * z[0] + p.b[2] * z[1] - p.a[0] * z[2] - p.a[1] * z[3];
  z[1] = z[0]; z[0] = x; z[3] = z[2]; z[2] = y1;
  const s = kw.z2[c];                             // the second stage: its own state
  const y2 = r.b[0] * y1 + r.b[1] * s[0] + r.b[2] * s[1] - r.a[0] * s[2] - r.a[1] * s[3];
  s[1] = s[0]; s[0] = y1; s[3] = s[2]; s[2] = y2;
  return y2;
}

/* ---------------------------------------------------------------- true peak: 4× oversampling (48-tap windowed sinc) */
const TP_TAPS = 12, TP_PH = 4;
const tpFir = (() => {
  const n = TP_TAPS * TP_PH, h = new Float32Array(n), mid = (n - 1) / 2;
  for (let i = 0; i < n; i++) {
    const x = (i - mid) / TP_PH;
    const sinc = x === 0 ? 1 : Math.sin(Math.PI * x) / (Math.PI * x);
    const w = 0.42 - 0.5 * Math.cos(2 * Math.PI * i / (n - 1)) + 0.08 * Math.cos(4 * Math.PI * i / (n - 1));
    h[i] = sinc * w;
  }
  return h;
})();
const tpHist = [new Float32Array(TP_TAPS), new Float32Array(TP_TAPS)];
let tpAt = 0;

/* ---------------------------------------------------------------- the running meters */
const M = {
  peak: [0, 0], tp: [0, 0], tpMax: 0, samplePeakMax: 0,
  // 100 ms sub-blocks of K-weighted energy (per channel summed) and of plain squares, for windows of any length
  sub: [], subPlain: [], subLR: [], acc: 0, accPlain: [0, 0], accLR: 0, accMS: [0, 0], subMS: [], accN: 0, subLen: 4410,
  blocks: [],       // 400 ms block energies (every 100 ms), for the integrated value
  shorts: [],       // 3 s short-term loudness values (every 100 ms), for the range
};
function resetMeters() {
  M.tpMax = 0; M.samplePeakMax = 0; M.blocks = []; M.shorts = []; M.sub = []; M.subPlain = []; M.subLR = []; M.subMS = [];
  M.acc = 0; M.accPlain = [0, 0]; M.accLR = 0; M.accMS = [0, 0]; M.accN = 0;
  if (kw) { kw.z = [new Float64Array(4), new Float64Array(4)]; kw.z2 = [new Float64Array(4), new Float64Array(4)]; }
}
const lufs = (e) => (e > 0 ? -0.691 + 10 * Math.log10(e) : -Infinity);
function closeSub() {
  M.sub.push(M.acc / M.accN); M.subPlain.push([M.accPlain[0] / M.accN, M.accPlain[1] / M.accN]); M.subLR.push(M.accLR / M.accN); M.subMS.push([M.accMS[0] / M.accN, M.accMS[1] / M.accN]);
  if (M.sub.length > 30) { M.sub.shift(); M.subPlain.shift(); M.subLR.shift(); M.subMS.shift(); }
  M.acc = 0; M.accPlain = [0, 0]; M.accLR = 0; M.accMS = [0, 0]; M.accN = 0;
  const n = M.sub.length;
  if (n >= 4) { const e = (M.sub[n - 1] + M.sub[n - 2] + M.sub[n - 3] + M.sub[n - 4]) / 4; M.blocks.push(e); if (M.blocks.length > 200000) M.blocks.shift(); }
  if (n >= 30) { let e = 0; for (const v of M.sub) e += v; M.shorts.push(lufs(e / 30)); if (M.shorts.length > 100000) M.shorts.shift(); }
}

/* lite: only the spectrum is wanted (the small analyzer under the track) — no meters, no true peak */
function push(frames, c, rate, lite = false) {
  if (rate !== sr || c !== ch || !kw) {
    sr = rate; ch = c; kw = kCoeffs(sr); kw.z2 = [new Float64Array(4), new Float64Array(4)];
    M.subLen = Math.round(sr / 10); resetMeters(); filled = 0;
  }
  const n = frames.length / ch | 0;
  if (lite) {
    for (let i = 0; i < n; i++) { hist[0][pos] = frames[i * ch]; hist[1][pos] = ch > 1 ? frames[i * ch + 1] : frames[i * ch]; pos = (pos + 1) % HIST; if (filled < HIST) filled++; }
    return;
  }
  let pk0 = 0, pk1 = 0, tp0 = 0, tp1 = 0;
  for (let i = 0; i < n; i++) {
    const l = frames[i * ch], r = ch > 1 ? frames[i * ch + 1] : l;
    hist[0][pos] = l; hist[1][pos] = r; pos = (pos + 1) % HIST; if (filled < HIST) filled++;
    const al = Math.abs(l), ar = Math.abs(r);
    if (al > pk0) pk0 = al; if (ar > pk1) pk1 = ar;
    // true peak: the four points between this sample and the last
    tpHist[0][tpAt] = l; tpHist[1][tpAt] = r; tpAt = (tpAt + 1) % TP_TAPS;
    for (let ph = 0; ph < TP_PH; ph++) {
      let s0 = 0, s1 = 0;
      for (let k = 0; k < TP_TAPS; k++) { const hk = tpFir[k * TP_PH + ph], j = (tpAt + k) % TP_TAPS; s0 += tpHist[0][j] * hk; s1 += tpHist[1][j] * hk; }
      const a0 = Math.abs(s0), a1 = Math.abs(s1); if (a0 > tp0) tp0 = a0; if (a1 > tp1) tp1 = a1;
    }
    const kl = kSample(0, l), kr = ch > 1 ? kSample(1, r) : kl;
    M.acc += kl * kl + (ch > 1 ? kr * kr : 0);
    M.accPlain[0] += l * l; M.accPlain[1] += r * r; M.accLR += l * r;
    const m = (l + r) / 2, s = (l - r) / 2; M.accMS[0] += m * m; M.accMS[1] += s * s;
    if (++M.accN >= M.subLen) closeSub();
  }
  M.peak = [pk0, pk1]; M.tp = [tp0, tp1];
  M.tpMax = Math.max(M.tpMax, tp0, tp1); M.samplePeakMax = Math.max(M.samplePeakMax, pk0, pk1);
}

function meters() {
  const n = M.sub.length;
  const win = (k) => { let e = 0, p0 = 0, p1 = 0, lr = 0, mm = 0, ss = 0; const z = Math.min(k, n); for (let i = n - z; i < n; i++) { e += M.sub[i]; p0 += M.subPlain[i][0]; p1 += M.subPlain[i][1]; lr += M.subLR[i]; mm += M.subMS[i][0]; ss += M.subMS[i][1]; } return z ? { e: e / z, p0: p0 / z, p1: p1 / z, lr: lr / z, mm: mm / z, ss: ss / z } : null; };
  const m400 = win(4), s3 = win(30), r300 = win(3);
  // integrated: blocks above −70 LUFS, then above (their mean − 10 LU)
  let I = -Infinity;
  if (M.blocks.length) {
    let s = 0, k = 0; const absE = Math.pow(10, (-70 + 0.691) / 10);
    for (const e of M.blocks) if (e > absE) { s += e; k++; }
    if (k) { const relE = (s / k) * 0.1; let s2 = 0, k2 = 0; for (const e of M.blocks) if (e > absE && e > relE) { s2 += e; k2++; } if (k2) I = lufs(s2 / k2); }
  }
  // the range, worked out at most twice a second
  const now = performance.now();
  if (!meters.lraAt || now - meters.lraAt > 500) {
    meters.lraAt = now;
    const v = M.shorts.filter((x) => x > -70);
    let lra = 0;
    if (v.length > 10) {
      const meanE = v.reduce((s, x) => s + Math.pow(10, x / 10), 0) / v.length;
      const rel = 10 * Math.log10(meanE) - 20;
      const g = v.filter((x) => x > rel).sort((a, b) => a - b);
      if (g.length > 10) lra = g[Math.floor(g.length * 0.95) - 1] - g[Math.floor(g.length * 0.1)];
    }
    meters.lra = lra;
  }
  const db = (x) => (x > 0 ? 20 * Math.log10(x) : -Infinity);
  const rms = r300 ? [Math.sqrt(r300.p0), Math.sqrt(r300.p1)] : [0, 0];
  const corr = r300 && r300.p0 > 1e-10 && r300.p1 > 1e-10 ? Math.max(-1, Math.min(1, r300.lr / Math.sqrt(r300.p0 * r300.p1))) : null;
  const width = r300 && r300.mm > 1e-12 ? Math.min(2, Math.sqrt(r300.ss / r300.mm)) : null;
  const rmsAll = Math.sqrt((rms[0] * rms[0] + rms[1] * rms[1]) / 2);
  return {
    peak: M.peak.map(db), truePeak: M.tp.map(db), truePeakMax: db(M.tpMax), samplePeakMax: db(M.samplePeakMax), rms: rms.map(db),
    momentary: m400 ? lufs(m400.e) : -Infinity, shortTerm: n >= 30 && s3 ? lufs(s3.e) : -Infinity, integrated: I, lra: meters.lra || 0,
    correlation: corr, width, crest: rmsAll > 1e-6 ? db(Math.max(M.peak[0], M.peak[1])) - db(rmsAll) : null, sr, ch,
  };
}

/* ---------------------------------------------------------------- FFT (radix-2, in place), Blackman-Harris */
const plans = new Map();
function plan(N) {
  let p = plans.get(N); if (p) return p;
  const bits = Math.log2(N) | 0, rev = new Uint32Array(N);
  for (let i = 0; i < N; i++) { let r = 0; for (let b = 0; b < bits; b++) r |= ((i >> b) & 1) << (bits - 1 - b); rev[i] = r; }
  const cos = new Float64Array(N / 2), sin = new Float64Array(N / 2);
  for (let i = 0; i < N / 2; i++) { cos[i] = Math.cos(2 * Math.PI * i / N); sin[i] = -Math.sin(2 * Math.PI * i / N); }
  const win = new Float64Array(N); let sum = 0;
  for (let i = 0; i < N; i++) { const x = 2 * Math.PI * i / (N - 1); win[i] = 0.35875 - 0.48829 * Math.cos(x) + 0.14128 * Math.cos(2 * x) - 0.01168 * Math.cos(3 * x); sum += win[i]; }
  p = { N, rev, cos, sin, win, gain: 2 / sum, re: new Float64Array(N), im: new Float64Array(N), pw: new Float64Array(N / 2), pre: new Float64Array(N / 2 + 1) };
  plans.set(N, p);
  return p;
}
/** power per bin (amplitude² of a sine, in full scale) of the newest N frames of `src(i)` */
function spectrum(N, src) {
  const p = plan(N), { re, im, rev, win, cos, sin } = p;
  const start = (pos - N + HIST * 2) % HIST;
  for (let i = 0; i < N; i++) { const j = rev[i]; re[j] = src((start + i) % HIST) * win[i]; im[j] = 0; }
  for (let size = 2; size <= N; size <<= 1) {
    const half = size >> 1, step = N / size;
    for (let i = 0; i < N; i += size) for (let j = 0, k = 0; j < half; j++, k += step) {
      const a = i + j, b = a + half;
      const tr = re[b] * cos[k] - im[b] * sin[k], ti = re[b] * sin[k] + im[b] * cos[k];
      re[b] = re[a] - tr; im[b] = im[a] - ti; re[a] += tr; im[a] += ti;
    }
  }
  const g = p.gain * p.gain;
  p.pre[0] = 0;
  for (let k = 0; k < N / 2; k++) { const v = (re[k] * re[k] + im[k] * im[k]) * g; p.pw[k] = v; p.pre[k + 1] = p.pre[k] + v; }
  return p;
}
/** the power around f (Hz): the mean over ±half the smoothing width, or between bins where that is narrower */
function bandPower(p, f, half) {
  const binHz = sr / p.N, N2 = p.N / 2;
  const lo = f * half.lo / binHz, hi = f * half.hi / binHz;
  if (hi - lo >= 1) {
    const a = Math.max(0, Math.min(N2, lo)), b = Math.max(0, Math.min(N2, hi));
    // the prefix sum read between bins (linear), so a band's edge moves smoothly with f
    const at = (x) => { const i = Math.floor(x); return p.pre[Math.min(N2, i)] + (p.pre[Math.min(N2, i + 1)] - p.pre[Math.min(N2, i)]) * (x - i); };
    return b > a ? (at(b) - at(a)) / (b - a) : 0;
  }
  const x = f / binHz, i = Math.floor(x), t = x - i;
  const v0 = p.pw[Math.max(0, Math.min(N2 - 1, i))], v1 = p.pw[Math.max(0, Math.min(N2 - 1, i + 1))];
  return v0 + (v1 - v0) * t;
}
const RES = { low: [4096, 2048], medium: [8192, 4096], high: [16384, 4096], max: [32768, 8192] };
const freqs = new Map();
function pointsFor(n) {
  let f = freqs.get(n); if (f) return f;
  f = new Float64Array(n); for (let i = 0; i < n; i++) f[i] = 20 * Math.pow(1000, i / (n - 1));
  freqs.set(n, f); return f;
}
function curve(src, o) {
  const [big, small] = RES[o.res] || RES.medium;
  let nb = big; while (nb > filled && nb > 1024) nb >>= 1;       // just started: as long as there is sound for
  const pb = spectrum(nb, src);
  const ps = small < pb.N ? spectrum(small, src) : pb;
  const F = pointsFor(o.points), out = new Float32Array(o.points), P = new Float64Array(o.points);
  // smoothing: 1/N octave (0: none — then a sliver, so a band is never empty). A band of power N/2 wide, then a
  // Gaussian over the points (together about 1/N octave at half height): a box alone draws a lone tone as a flat
  // plateau with steep sides, the Gaussian rounds it into the peak it is
  const smooth = o.smooth > 0, oct = smooth ? 1 / o.smooth : 1 / 96;
  const bw = smooth ? oct / 2 : oct;
  const half = { lo: Math.pow(2, -bw / 2), hi: Math.pow(2, bw / 2) };
  for (let i = 0; i < o.points; i++) {
    const f = F[i];
    let pw;
    if (f <= 300 || ps === pb) pw = bandPower(pb, f, half);
    else if (f >= 2000) pw = bandPower(ps, f, half);
    else { const t = Math.log(f / 300) / Math.log(2000 / 300); pw = bandPower(pb, f, half) * (1 - t) + bandPower(ps, f, half) * t; }
    P[i] = pw;
  }
  const Q = smooth ? gauss(P, 0.368 * oct * (o.points - 1) / Math.log2(1000)) : P;
  for (let i = 0; i < o.points; i++) out[i] = 10 * Math.log10(Q[i] + 1e-14) + o.tilt * Math.log2(F[i] / 1000);
  return { out, pb };
}
/** a Gaussian of σ points over the powers (the edges weighted by what lies inside) */
function gauss(P, sigma) {
  if (!(sigma > 0.3)) return P;
  const r = Math.ceil(sigma * 3), k = new Float64Array(r * 2 + 1);
  for (let j = -r; j <= r; j++) k[j + r] = Math.exp(-(j * j) / (2 * sigma * sigma));
  const n = P.length, out = new Float64Array(n);
  for (let i = 0; i < n; i++) {
    let s = 0, w = 0;
    for (let j = -r; j <= r; j++) { const x = i + j; if (x < 0 || x >= n) continue; s += P[x] * k[j + r]; w += k[j + r]; }
    out[i] = s / w;
  }
  return out;
}
/** the loudest tone: the strongest bin of the long FFT, its frequency refined between bins (parabola on dB) */
function peakOf(p) {
  const binHz = sr / p.N; let best = -1, bv = 0;
  const k0 = Math.max(2, Math.ceil(25 / binHz)), k1 = Math.min(p.N / 2 - 2, Math.floor(18000 / binHz));
  for (let k = k0; k <= k1; k++) if (p.pw[k] > bv) { bv = p.pw[k]; best = k; }
  if (best < 0 || bv < 1e-9) return null;
  const a = 10 * Math.log10(p.pw[best - 1] + 1e-14), b = 10 * Math.log10(bv), c = 10 * Math.log10(p.pw[best + 1] + 1e-14);
  const d = (a - c) / (2 * (a - 2 * b + c) || 1);
  return { hz: (best + Math.max(-0.5, Math.min(0.5, d))) * binHz, db: b - 0.25 * (a - c) * d };
}

self.onmessage = (e) => {
  const m = e.data;
  if (m.type === 'push') { push(m.frames, m.ch, m.sr, !!m.lite); return; }
  if (m.type === 'reset') { resetMeters(); return; }
  if (m.type !== 'frame') return;
  if (filled < 1024) { self.postMessage({ spec: null, spec2: null, peak: null, meters: meters() }); return; }
  const L = (i) => hist[0][i], R = (i) => hist[1][i];
  let a, b = null;
  if (m.mode === 'lr' && ch > 1) { a = curve(L, m); b = curve(R, m).out; }
  else if (m.mode === 'ms' && ch > 1) { a = curve((i) => (hist[0][i] + hist[1][i]) / 2, m); b = curve((i) => (hist[0][i] - hist[1][i]) / 2, m).out; }
  else a = curve(ch > 1 ? (i) => (hist[0][i] + hist[1][i]) / 2 : L, m);
  const peak = peakOf(a.pb);
  const spec = a.out;
  self.postMessage({ spec, spec2: b, peak, meters: m.lite ? null : meters() }, [spec.buffer, ...(b ? [b.buffer] : [])]);
};
