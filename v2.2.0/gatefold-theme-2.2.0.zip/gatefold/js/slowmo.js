/*
 * Gatefold · slowmo.js — slow drifts moved from here, a step when they have really moved.
 *
 * Canvas (fullscreen) lets its backdrop, its two glows and the cover drift over tens of seconds. As CSS animations
 * they ran on the compositor at the monitor's rate: 60–240 new frames a second of the whole screen for motions of a
 * few pixels a second — for as long as the Canvas stayed open, which it does by itself after a few idle minutes (#29).
 * Here every drift is a function of its progress; it is given a new transform when its fastest point has moved half a
 * pixel since the last one, and the ticker wakes only as often as the fastest drift needs (at most 20 times a second,
 * 12 on battery or in the background). The same motion, a small fraction of the frames.
 */
function bezier(x1, y1, x2, y2) {
  const bx = (u) => 3 * (1 - u) * (1 - u) * u * x1 + 3 * (1 - u) * u * u * x2 + u * u * u;
  const by = (u) => 3 * (1 - u) * (1 - u) * u * y1 + 3 * (1 - u) * u * u * y2 + u * u * u;
  return (t) => { let lo = 0, hi = 1; for (let i = 0; i < 18; i++) { const m = (lo + hi) / 2; if (bx(m) < t) lo = m; else hi = m; } return by((lo + hi) / 2); };
}
export const EASE = bezier(0.22, 0.7, 0.18, 1);       // var(--ease)
export const IN_OUT = bezier(0.42, 0, 0.58, 1);       // ease-in-out

const items = new Set();
let timer = 0, slow = false;
/** fewer steps a second (battery, a window in the background): the drift as it is, coarser */
export function setSlow(on) { slow = !!on; }

/**
 * A drift there and back: `at(k)` gives the transform at progress k (0…1), `amp()` how far its fastest point goes
 * from 0 to 1, in pixels (asked again when the window changes size). Returns { stop, pause, resume }: a stopped or
 * paused drift leaves the element where it is; resumed, it goes on from there.
 */
export function drift(el, { period, ease = IN_OUT, at, amp, paused = false }) {
  const now = performance.now();
  const it = { el, period: period * 1000, ease, at, amp, px: amp(), acc: 0, since: now, paused, k: -1 };
  items.add(it);
  step(it, now, true);
  wake();
  return {
    stop: () => { items.delete(it); },
    pause: () => { if (it.paused) return; const t = performance.now(); it.acc += t - it.since; it.paused = true; },
    resume: () => { if (!it.paused) return; it.since = performance.now(); it.paused = false; wake(); },
  };
}
function progress(it, now) {
  const t = it.acc + (it.paused ? 0 : now - it.since);
  const ph = (t / it.period) % 2;
  return it.ease(ph < 1 ? ph : 2 - ph);
}
function step(it, now, force = false) {
  const k = progress(it, now);
  if (!force && Math.abs(k - it.k) * it.px < 0.5) return;
  it.k = k;
  it.el.style.transform = it.at(k);
}
function tick() {
  timer = 0;
  if (!items.size) return;
  if (document.hidden) { timer = setTimeout(tick, 500); return; }
  const now = performance.now();
  let wait = 250, moving = false;
  for (const it of items) {
    if (it.paused) continue;
    moving = true;
    step(it, now);
    // how soon this one moves another half pixel, from how fast it goes just now
    const v = Math.abs(progress(it, now + 200) - progress(it, now)) * it.px / 200;     // pixels per millisecond
    if (v > 0) wait = Math.min(wait, (0.5 - Math.abs(progress(it, now) - it.k) * it.px) / v);
  }
  if (moving) timer = setTimeout(tick, Math.max(slow ? 83 : 50, Math.min(250, wait)));
}
function wake() { if (!timer) timer = setTimeout(tick, 0); }
document.addEventListener('visibilitychange', () => { if (!document.hidden && items.size) { clearTimeout(timer); timer = 0; wake(); } });
addEventListener('resize', () => { for (const it of items) it.px = it.amp(); });
