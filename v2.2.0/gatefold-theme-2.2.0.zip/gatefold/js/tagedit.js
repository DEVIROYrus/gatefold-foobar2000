/*
 * Gatefold · tagedit.js — the tags of tracks, changed from Gatefold (Reddit 13.11: «I cannot adjust which songs
 * belong to which album»).
 *
 * One track or many: title (one track only), artist, album artist, album, year, genre, disc and number (one track
 * only). With several tracks a field they do not share shows «‹разные›» and stays as it is unless something is
 * typed in it. An emptied field removes the tag. Several values of a field are written apart: «A; B» is two artists,
 * as foobar2000 keeps them. foobar2000 writes the files (its progress window for many, its own report of a file
 * it could not change); the library and Gatefold catch up from its notice.
 */
import { call, ok, esc } from './bridge.js';
import { h, icon, toast } from './ui.js';
import { $t } from './i18n.js';

const FIELDS = () => [
  { key: 'TITLE', tf: '[%title%]', label: $t('Название'), one: true },
  { key: 'ARTIST', tf: "[$meta_sep(artist,'; ')]", label: $t('Исполнитель'), multi: true },
  { key: 'ALBUM ARTIST', tf: "[$meta_sep(album artist,'; ')]", label: $t('Исполнитель альбома'), multi: true },
  { key: 'ALBUM', tf: '[%album%]', label: $t('Альбом') },
  { key: 'GENRE', tf: "[$meta_sep(genre,'; ')]", label: $t('Жанр'), multi: true },
  { key: 'COMPOSER', tf: "[$meta_sep(composer,'; ')]", label: $t('Композитор'), multi: true },
  { key: 'PERFORMER', tf: "[$meta_sep(performer,'; ')]", label: $t('Исполнитель трека'), multi: true },
  { key: 'DATE', tf: '[%date%]', label: $t('Год'), narrow: true },
  { key: 'DISCNUMBER', tf: '[%discnumber%]', label: $t('Диск'), narrow: true },
  { key: 'TOTALDISCS', tf: '[%totaldiscs%]', label: $t('Всего дисков'), narrow: true },
  { key: 'TRACKNUMBER', tf: '[%tracknumber%]', label: $t('Номер'), narrow: true, one: true },
  { key: 'TOTALTRACKS', tf: '[%totaltracks%]', label: $t('Всего треков'), narrow: true },
];
const handleOf = (t) => t.handle || (t.subsong ? `${t.absolutePath || t.path}|subsong:${t.subsong}` : (t.absolutePath || t.path));
const refOf = (hd) => { const m = /^(.*)\|subsong:(\d+)$/.exec(hd); return m ? { path: m[1], subsong: +m[2] } : { path: hd }; };
const isFile = (p) => /^[a-z]:[\\/]|^\\\\/i.test(String(p || ''));

let open = null;
/** the editor for these tracks (objects with handle/absolutePath/path); resolves true when tags were written.
    opts.list: one track of an album opened with its album's tracks — «‹ Track 3 of 12 ›» steps through them,
    Enter saves this one and goes on to the next (the field you were in keeps the cursor, its text selected). */
export async function edit(tracks, opts = {}) {
  tracks = (tracks || []).filter((t) => t && isFile(t.absolutePath || t.path || t.handle));
  if (!tracks.length) { toast($t('Теги можно менять только у файлов')); return false; }
  if (open) open.close(false);
  const list = tracks.length === 1 && Array.isArray(opts.list) && opts.list.length > 1 ? opts.list.filter((t) => t && isFile(t.absolutePath || t.path || t.handle)) : null;
  let at = list ? Math.max(0, list.findIndex((t) => handleOf(t) === handleOf(tracks[0]))) : 0;
  let wrote = false, lastField = '';
  return new Promise((resolve) => {
    const veil = h(`<div class="upd-veil te-veil"><div class="upd-sheet te-sheet" role="dialog" aria-modal="true" aria-label="${esc($t('Теги'))}">
      <button class="icon-btn upd-x" title="${esc($t('Закрыть'))}">${icon('x', 16)}</button>
      <div class="upd-head"><div><h3>${esc($t('Теги'))}</h3><div class="sub"></div></div></div>
      <div class="te-step" hidden><button type="button" class="btn sm te-prev">${icon('prev', 14)} <span>${esc($t('Предыдущий'))}</span></button><b class="te-pos"></b><button type="button" class="btn sm te-next"><span>${esc($t('Следующий'))}</span> ${icon('next', 14)}</button></div>
      <form class="te-form" autocomplete="off"></form>
      <div class="te-foot"><span class="te-note"></span><button type="button" class="btn te-cancel">${esc($t('Закрыть'))}</button><button type="button" class="btn primary te-save">${esc($t('Сохранить'))}</button></div>
    </div></div>`);
    const form = veil.querySelector('.te-form');
    let cur = null;   // { tracks, handles, fields, values, inputs }
    const load = async (set) => {
      const handles = set.map(handleOf);
      const fields = FIELDS().filter((f) => !f.one || set.length === 1);
      // what the files hold now (not what the lists last read)
      const r = await call('titleformat.evalFieldsBatch', { paths: handles, fields: Object.fromEntries(fields.map((f, i) => ['f' + i, f.tf])) });
      const rows = ok(r) ? r.results || [] : [];
      const values = fields.map((f, i) => {
        const vs = new Set(handles.map((_, k) => String((rows[k] && rows[k]['f' + i]) || '')));
        return vs.size === 1 ? { same: true, v: [...vs][0] } : { same: false, v: '' };
      });
      const many = set.length > 1;
      veil.querySelector('.sub').textContent = many ? $t('{0} треков: меняется то, что вы исправите', set.length) : (set[0].title || String(handles[0]).split(/[\\/]/).pop());
      veil.querySelector('.te-note').textContent = list ? $t('Enter — сохранить и к следующему треку · Esc — закрыть') : $t('Пустое поле удаляет тег. Несколько значений — через «; »');
      form.replaceChildren();
      const inputs = fields.map((f, i) => {
        const row = h(`<label class="te-row${f.narrow ? ' narrow' : ''}"><span></span><input class="st-input" spellcheck="false"></label>`);
        row.querySelector('span').textContent = f.label;
        const inp = row.querySelector('input');
        inp.dataset.key = f.key;
        inp.value = values[i].same ? values[i].v : '';
        if (!values[i].same) inp.placeholder = $t('‹разные›');
        inp.addEventListener('input', () => { inp.dataset.touched = '1'; });
        inp.addEventListener('focus', () => { lastField = f.key; });
        inp.addEventListener('keydown', (e) => {
          e.stopPropagation();
          if (e.key === 'Enter') { e.preventDefault(); if (list && at < list.length - 1) step(1); else save(true); }
          if (e.key === 'Escape') { e.preventDefault(); close(); }
        });
        form.append(row);
        return inp;
      });
      cur = { tracks: set, handles, fields, values, inputs };
      if (list) {
        veil.querySelector('.te-step').hidden = false;
        veil.querySelector('.te-pos').textContent = $t('Трек {0} из {1}', at + 1, list.length);
        veil.querySelector('.te-prev').disabled = at === 0;
        veil.querySelector('.te-next').disabled = at === list.length - 1;
      }
      const focus = inputs.find((x) => x.dataset.key === (lastField || (many ? 'ALBUM' : 'TITLE'))) || inputs[0];
      focus.focus(); if (lastField) focus.select();
    };
    /** the changed fields written; true when there was nothing to write or it was written */
    const write = async () => {
      if (!cur) return true;
      const { fields, values, inputs, handles } = cur;
      const set = {};
      fields.forEach((f, i) => {
        const inp = inputs[i];
        // a field of several tracks that was not touched stays as each track has it
        if (!values[i].same && !inp.dataset.touched) return;
        const v = inp.value.trim();
        if (values[i].same && v === values[i].v) return;
        set[f.key] = !v ? null : f.multi ? v.split(/\s*;\s*/).filter(Boolean) : v;
      });
      if (!Object.keys(set).length) return true;
      const btn = veil.querySelector('.te-save'); btn.disabled = true;
      const w = await call('gf:tags.write', { items: handles.map((hd) => ({ track: refOf(hd), set })) });
      btn.disabled = false;
      if (!ok(w) || w.status !== 'done') {
        toast(w && w.status === 'aborted' ? $t('Запись тегов остановлена') : $t('foobar2000 не записал теги: {0}', esc((w && (w.error || w.status)) || '?')));
        return false;
      }
      wrote = true;
      return true;
    };
    const close = () => {
      if (!open) return;
      open = null;
      veil.classList.remove('on');
      setTimeout(() => veil.remove(), 220);
      resolve(wrote);
    };
    const save = async (andClose) => {
      const n = cur ? cur.tracks.length : 0;
      if (!(await write())) return;
      if (wrote) toast(n > 1 ? $t('Теги изменены: {0} треков', n) : $t('Теги изменены'));
      if (andClose) close();
    };
    /* the track on screen is saved first; a failed write keeps you on it */
    const step = async (d) => {
      if (!list || at + d < 0 || at + d >= list.length) return;
      if (!(await write())) return;
      at += d;
      await load([list[at]]);
    };
    veil.addEventListener('click', (e) => { if (e.target === veil || e.target.closest('.upd-x, .te-cancel')) close(); });
    veil.querySelector('.te-save').onclick = () => save(true);
    veil.querySelector('.te-prev').onclick = () => step(-1);
    veil.querySelector('.te-next').onclick = () => step(1);
    document.body.append(veil);
    open = { close };
    load(list ? [list[at]] : tracks).then(() => requestAnimationFrame(() => veil.classList.add('on')));
  });
}
