/*
 * Gatefold · eqglyph.js — the little three-bar equaliser beside what plays (the playlist in the menu, the playing
 * row, a tile), moved from here a few times a second.
 *
 * It used to be a CSS animation of `transform`. The compositor runs those by itself, but it runs them on every frame
 * of the monitor, however few steps the keyframes have: while music played the window made a new frame 60–240 times a
 * second for three bars of 12 pixels, and on «Now playing» each of those frames blended the whole live background
 * again. Measured in a headless window of 1920 × 1080: the GPU process went from 0.06 to 0.83 of a core, the glyph
 * alone (#29). Now the bars change 10 times a second, nothing in between asks for a frame, and nothing moves while
 * the window is hidden or the music is paused.
 */
const MS = 100;
/* the old keyframes: an ease-in-out from a quarter to the full height, there and back in 900 ms each way */
const PERIOD = 1800, DELAYS = [200, 500, 800];
const ease = (x) => 0.25 + 0.75 * (x < 0.5 ? 2 * x * x : 1 - (-2 * x + 2) ** 2 / 2);
let timer = 0;
const bars = () => document.querySelectorAll('.eq i');

function frame() {
  timer = 0;
  if (!running()) return;
  const now = performance.now();
  const fb = document.body.classList.contains('is-playing'), yt = ytPlaying();
  const list = bars();
  for (let i = 0; i < list.length; i++) {
    // YouTube's rows and badge move with YouTube's player, the rest with foobar2000's
    if (!(list[i].closest('.yt-row, .yt-badge') ? yt : fb)) continue;
    const ph = ((now + DELAYS[i % 3]) % PERIOD) / (PERIOD / 2);
    const v = ease(ph <= 1 ? ph : 2 - ph).toFixed(2);
    const t = `scaleY(${v})`;
    if (list[i].style.transform !== t) list[i].style.transform = t;
  }
  timer = setTimeout(frame, MS);
}
const ytPlaying = () => !!document.querySelector('#view-youtube.is-playing');
const running = () => !document.hidden && (document.body.classList.contains('is-playing') || ytPlaying());
/** start or stop with the music and the window */
export function sync() {
  if (running()) { if (!timer) frame(); }
  else if (timer) { clearTimeout(timer); timer = 0; }
}
export function init() {
  document.addEventListener('visibilitychange', sync);
  const mo = new MutationObserver(sync);
  mo.observe(document.body, { attributes: true, attributeFilter: ['class'] });
  const yt = document.getElementById('view-youtube'); if (yt) mo.observe(yt, { attributes: true, attributeFilter: ['class'] });
  sync();
}
