/*
 * Gatefold · hexinput.js — a colour typed or pasted as text (#50): «#7c5cff», «7c5cff», «#fa0», «rgb(124 92 255)».
 * Enter or leaving the field applies it; a value that is not a colour is marked and nothing changes.
 */
import { $t } from './i18n.js';

/** '#rrggbb' from what was typed, or '' when it is not a colour */
export function parseColor(s) {
  s = String(s || '').trim().toLowerCase();
  let m = s.match(/^#?([0-9a-f]{3}|[0-9a-f]{6})$/);
  if (m) { const x = m[1]; return '#' + (x.length === 3 ? x.replace(/./g, (c) => c + c) : x); }
  m = s.match(/^rgba?\(\s*(\d{1,3})[\s,]+(\d{1,3})[\s,]+(\d{1,3})(?:[\s,/]+[\d.]+%?)?\s*\)$/);
  if (m && m.slice(1, 4).every((v) => +v <= 255)) return '#' + m.slice(1, 4).map((v) => (+v).toString(16).padStart(2, '0')).join('');
  return '';
}

/** a small text field for a colour; `commit('#rrggbb')` when a new valid one is entered */
export function hexInput(value, commit, cls = '') {
  const el = document.createElement('input');
  el.type = 'text'; el.className = ('hex-in ' + cls).trim(); el.spellcheck = false; el.maxLength = 32;
  el.value = value || ''; el.placeholder = '#rrggbb';
  el.title = el.ariaLabel = $t('Цвет: #rrggbb или rgb(…), Enter — применить');
  let last = parseColor(value);
  const apply = () => {
    const c = parseColor(el.value);
    el.classList.toggle('bad', !!el.value.trim() && !c);
    if (!c) return;
    el.value = c;
    if (c !== last) { last = c; commit(c); }
  };
  el.addEventListener('keydown', (e) => {
    e.stopPropagation();   // typing here is not a player shortcut
    if (e.key === 'Enter') { e.preventDefault(); apply(); }
    else if (e.key === 'Escape') { el.value = last; el.classList.remove('bad'); el.blur(); }
  });
  el.addEventListener('blur', apply);
  el.addEventListener('paste', () => setTimeout(apply, 0));
  el.addEventListener('input', () => el.classList.remove('bad'));
  /** keep the field in step with the picker */
  el.setColor = (c) => { last = parseColor(c) || last; if (document.activeElement !== el) el.value = c; el.classList.remove('bad'); };
  return el;
}
