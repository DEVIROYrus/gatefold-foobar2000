/*
 * Gatefold · ambient.js — the background behind the interface: the cover's blurred art, the drifting colour blobs,
 * the veil and the grain, drawn as cheaply as they can be.
 *
 * The blobs: four soft gradients painted into one small canvas — a quarter of the window's size, scaled up (a soft
 * gradient loses nothing) — only when they have really moved (see tick). Still while «Background motion» is off,
 * stopped while the window is hidden.
 *
 * Three ways to show it all:
 *   live    the layers as they are (#bg: art, blobs, veil, grain). Used while a new cover or new colours fade in,
 *           and with Mica (the window itself is transparent there).
 *   still   painted once into one opaque picture that becomes the page's own background; the layers go away.
 *           Chromium draws text with ClearType only into an opaque layer: a live background is a layer of its own,
 *           so everything above it got grey antialiasing — soft on a 96–120 dpi monitor. With the picture the text
 *           is crisp. Every screen but «Now playing» (Settings → Look → «Sharpest text»), and «Now playing» too
 *           while the background does not drift.
 *   painted «Now playing» with the drift on: the same picture, but in a canvas of the window's size that is painted
 *           again when a blob has moved a pixel (a few times a second). Four large translucent layers were blended
 *           by the GPU on every frame the spectrum or the cover's breathing asked for (60–144 a second): now it is
 *           one opaque layer, and a new picture only when the drift has made one (#29).
 */
import { settings } from './settings.js';

const FPS = 12, SCALE = 0.25;
/* the CSS this replaces: size 78vmax; start offsets; drift (translate, scale) over a period, alternating */
const BLOBS = [
  { x: (w, h, m) => -24 * m, y: (w, h, m) => -30 * m, dx: 14, dy: 10, s: 1.15, T: 46, a: 0.62 },
  { x: (w, h, m) => w + 30 * m - 78 * m, y: (w, h, m) => -18 * m, dx: -12, dy: 14, s: 0.9, T: 58, a: 0.62 },
  { x: (w, h, m) => 8 * m, y: (w, h, m) => h + 44 * m - 78 * m, dx: 16, dy: -12, s: 1.1, T: 64, a: 0.62 },
  { x: (w, h, m) => w + 18 * m - 78 * m, y: (w, h, m) => h + 36 * m - 78 * m, dx: -14, dy: -8, s: 1.2, T: 52, a: 0.5 },
];
/* var(--ease) = cubic-bezier(.22, .7, .18, 1) */
function ease(t) {
  const x1 = 0.22, y1 = 0.7, x2 = 0.18, y2 = 1;
  const bx = (u) => 3 * (1 - u) * (1 - u) * u * x1 + 3 * (1 - u) * u * u * x2 + u * u * u;
  const by = (u) => 3 * (1 - u) * (1 - u) * u * y1 + 3 * (1 - u) * u * u * y2 + u * u * u;
  let lo = 0, hi = 1;
  for (let i = 0; i < 18; i++) { const m = (lo + hi) / 2; if (bx(m) < t) lo = m; else hi = m; }
  return by((lo + hi) / 2);
}

const root = document.documentElement;
let canvas = null, ctx = null, timer = 0, clock = 0, last = performance.now();
const probe = document.createElement('canvas').getContext('2d', { willReadFrequently: true });
const rgbCache = new Map();
function rgb(css) {
  let v = rgbCache.get(css);
  if (!v) {
    probe.clearRect(0, 0, 1, 1); probe.fillStyle = '#000'; probe.fillStyle = css; probe.fillRect(0, 0, 1, 1);
    const d = probe.getImageData(0, 0, 1, 1).data; v = [d[0], d[1], d[2]];
    if (rgbCache.size > 200) rgbCache.clear();
    rgbCache.set(css, v);
  }
  return v;
}

let blobCols = null, blobColsT = 0, colKey = '';
/* where every blob is at a moment of the drift, in window pixels: [cx, cy, r] × 4 */
function layout(t, W, H) {
  const m = Math.max(W, H) / 100;
  return BLOBS.map((b) => {
    const ph = (t / b.T) % 2, k = ease(ph < 1 ? ph : 2 - ph);            // alternate: there and back
    return [b.x(W, H, m) + 39 * m + b.dx * m * k, b.y(W, H, m) + 39 * m + b.dy * m * k, 39 * m * (1 + (b.s - 1) * k)];
  });
}
let drawn = null;   // the layout last painted
function draw(L) {
  stats.draws++;
  const W = innerWidth, H = innerHeight;
  const cw = Math.max(32, Math.round(W * SCALE)), ch = Math.max(32, Math.round(H * SCALE));
  if (canvas.width !== cw || canvas.height !== ch) { canvas.width = cw; canvas.height = ch; }
  ctx.clearRect(0, 0, cw, ch);
  L.forEach(([cx, cy, r], i) => {
    const [R, G, B] = blobCols[i], a = BLOBS[i].a;
    const g = ctx.createRadialGradient(cx * SCALE, cy * SCALE, 0, cx * SCALE, cy * SCALE, r * SCALE);
    g.addColorStop(0, `rgba(${R},${G},${B},${a})`);
    g.addColorStop(1, `rgba(${R},${G},${B},0)`);
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, cw, ch);
  });
  drawn = L;
}
/* the blob colours come from CSS variables: reading them forces a style pass, so at most 5 times a second
   (the palette crossfade is slower than that) instead of on every frame; true when they changed */
function readColours(now, force = false) {
  if (!force && blobCols && now - blobColsT < 200) return false;
  const cs = getComputedStyle(root);
  blobCols = BLOBS.map((b, i) => rgb(cs.getPropertyValue(`--blob-${i + 1}`).trim() || '#333'));
  blobColsT = now;
  const k = blobCols.join('|');
  if (k === colKey) return false;
  colKey = k;
  return true;
}
const moved = (A) => (A && drawn ? Math.max(...A.map((p, i) => Math.max(Math.abs(p[0] - drawn[i][0]), Math.abs(p[1] - drawn[i][1]), Math.abs(p[2] - drawn[i][2])))) : Infinity);
/* The blobs drift a few window pixels a second at most (a tenth of a pixel per frame of a 144 Hz monitor):
   painting every frame of the monitor makes the GPU blend the whole window again for a change nobody can see.
   So the background is painted when some blob has moved half a pixel since the last picture (two for the window-sized
   painted picture, which costs more to make: on blobs 1500 pixels across a step of two is not seen) or a colour changed, and the next look is planned from
   how fast they move just now: the same motion, a fraction of the frames. */
const STEP = 0.5, PSTEP = 2;
let slow = false;     // «Smoothness» 30, a laptop on battery, a window in the background: the drift at most 12 times a second
export function setSlow(on) { slow = !!on; }
function tick() {
  timer = 0;
  if (!canvas) return;
  const body = document.body;
  if (document.hidden || body.classList.contains('paused-bg') || body.classList.contains('no-ambient')) { timer = setTimeout(tick, 1000); return; }
  const now = performance.now();
  if (mode !== 'still') clock += Math.min(now - last, 250);       // the drift pauses while the background stands still
  last = now;
  if (mode === 'still') { timer = setTimeout(tick, 1000); return; }
  const coloured = readColours(now);
  const W = innerWidth, H = innerHeight;
  const moving = !body.classList.contains('no-motion');
  const L = layout(moving ? clock / 1000 : 0, W, H);
  const step = mode === 'paint' ? PSTEP : STEP;
  if (coloured || moved(L) >= step || canvas.width !== Math.max(32, Math.round(W * SCALE))) { draw(L); if (mode === 'paint') paintNow(); }
  if (!moving) { timer = setTimeout(tick, 250); return; }   // still: only colour changes need repainting
  // how long until the fastest blob has gone another step (looked at 0.4 s ahead)
  const v = moved(layout((clock + 400) / 1000, W, H)) / 400;   // pixels per millisecond (vs. the picture shown)
  const need = Math.max(0, step - (drawn ? moved(L) : 0));
  let wait = v > 0 ? (need || step) / v : 250;
  wait = Math.min(250, Math.max(slow ? 1000 / FPS : mode === 'paint' ? 80 : 16, wait));
  timer = setTimeout(tick, wait);
}

export function init() {
  const host = document.querySelector('#bg .aurora');
  if (!host || canvas) return;
  canvas = document.createElement('canvas');
  canvas.className = 'aurora-c';
  ctx = canvas.getContext('2d', { alpha: true });
  host.replaceChildren(canvas);
  paintC = document.createElement('canvas');
  paintC.className = 'bg-paint';
  paintX = paintC.getContext('2d', { alpha: false });
  document.getElementById('bg').append(paintC);
  document.addEventListener('visibilitychange', () => {
    if (document.hidden) return;
    if (!timer) tick();
    // shown again: what was put off while hidden (the window's «paused» class follows a moment later)
    setTimeout(() => { if (mode !== wanted()) refresh(); }, 300);
  });
  addEventListener('resize', () => {
    if (canvas && blobCols) { draw(layout(clock / 1000, innerWidth, innerHeight)); if (mode === 'paint') paintNow(); }
    if (mode !== 'live' || wanted() !== 'live') { clearTimeout(resizeT); resizeT = setTimeout(() => schedule(0), 300); }
  });
  // a new cover fades in on the backdrop: live while it fades, still again after
  for (const el of document.querySelectorAll('#bg .bg-art')) new MutationObserver(() => changed()).observe(el, { attributes: true, attributeFilter: ['class', 'style'] });
  tick();
  schedule(0);
}

/* ---------------------------------------------------------------- the grain
   Fine noise over the background keeps its large dark gradients from banding. It was a grey noise blended with
   mix-blend-mode: overlay — and a blend mode makes the GPU read back everything under it and blend the whole window
   again on every frame anything moves (with the live background of «Now playing»: four fifths of the GPU's work, #29).
   The same picture is now made without a blend mode: overlay at opacity o moves a colour b by o·min(b, 1 − b)·(2s − 1)
   for a noise value s, and that move is drawn as white (lighter) or black (darker) dots of just the alpha that gives it
   on the page's own background. Made again when the background's lightness has really changed. */
let grainL = -1, grainScheme = '', grainT = 0, grainUrl = '';
export function grain(force = false) {
  const el = document.querySelector('#bg .grain'); if (!el) return;
  const [R, G, B] = rgb(getComputedStyle(root).getPropertyValue('--bg').trim() || '#111');
  const L = Math.min(0.97, Math.max(0.03, (0.2126 * R + 0.7152 * G + 0.0722 * B) / 255));
  const scheme = root.dataset.scheme || 'dark';
  if (!force && scheme === grainScheme && Math.abs(L - grainL) < 0.04) return;
  grainL = L; grainScheme = scheme;
  const o = scheme === 'light' ? 0.05 : 0.07, m = Math.min(L, 1 - L);
  const N = 180, c = document.createElement('canvas'); c.width = c.height = N;
  const x = c.getContext('2d'), d = x.createImageData(N, N), px = d.data;
  for (let i = 0; i < px.length; i += 4) {
    const delta = o * m * (2 * Math.random() - 1);
    const a = delta > 0 ? delta / (1 - L) : -delta / L;
    px[i] = px[i + 1] = px[i + 2] = delta > 0 ? 255 : 0;
    px[i + 3] = Math.round(Math.min(1, a) * 255);
  }
  x.putImageData(d, 0, 0);
  grainUrl = c.toDataURL();
  el.style.backgroundImage = `url(${grainUrl})`;
}
function grainLater() { clearTimeout(grainT); grainT = setTimeout(() => grain(), settleMs()); }

/* ---------------------------------------------------------------- live, still, painted */
let mode = 'live', onNow = false, stillT = 0, resizeT = 0, stillUrl = '', token = 0, fadeUntil = 0;
let paintC = null, paintX = null, paintSrc = null;     // the painted picture: its canvas and what it is made of
const settleMs = () => {
  const tx = parseFloat(getComputedStyle(root).getPropertyValue('--tx')) || 1100;
  return Math.round(tx * 1.6 + 120);                    // the cover crossfade lasts --tx × 1.4
};
/** what the background should be once nothing fades: 'live' | 'still' | 'paint' */
function wanted() {
  const body = document.body;
  if (root.classList.contains('mica') || body.classList.contains('paused-bg')) return 'live';
  const drifting = !body.classList.contains('no-motion') && !body.classList.contains('no-ambient');
  if (onNow) return drifting ? 'paint' : 'still';
  return settings.crispText !== false ? 'still' : drifting ? 'paint' : 'still';
}
function setMode(m) {
  if (mode === m) return;
  mode = m;
  root.classList.toggle('still-bg', m === 'still');
  root.classList.toggle('paint-bg', m === 'paint');
  if (m !== 'paint') { paintSrc = null; if (paintC && paintC.width > 1) { paintC.width = paintC.height = 1; } }   // its memory let go
  if (m !== 'still' && !timer) tick();
}
/* the next picture once whatever fades has settled (a snapshot in the middle of a crossfade would freeze it there) */
function schedule(ms = Math.max(0, fadeUntil - performance.now())) {
  clearTimeout(stillT);
  if (!canvas) return;
  const want = wanted();
  if (want === 'live') { setMode('live'); return; }
  const my = ++token;
  stillT = setTimeout(async () => {
    if (my !== token || wanted() !== want) return;
    if (want === 'paint') {
      const src = await sources().catch(() => null);
      if (my !== token || !src || wanted() !== 'paint') return;
      paintSrc = src;
      paintSrc.top = veilAndGrain(src);
      readColours(performance.now(), true); draw(layout(clock / 1000, innerWidth, innerHeight));
      paintNow();
      setMode('paint');
      return;
    }
    const url = await renderStill().catch(() => '');
    if (my !== token || !url || wanted() !== 'still') return;
    const old = stillUrl; stillUrl = url;
    root.style.setProperty('--still', `url("${url}")`);
    setMode('still');
    if (old) setTimeout(() => URL.revokeObjectURL(old), 2000);
  }, ms);
}
/** colours or the cover changed: show the live background while they fade, then stand still (or painted) again */
export function changed() {
  grainLater();
  if (!canvas) return;
  token++;
  fadeUntil = performance.now() + settleMs();
  setMode('live');
  schedule();
}
/** the screen shown: «Now playing» keeps its drift (painted), every other screen stands still */
export function setView(view) {
  const now = view === 'now';
  if (now === onNow) return;
  onNow = now;
  if (mode === wanted()) return;
  token++;
  setMode('live');
  schedule();
}
/** a setting that affects it changed (sharp text, Mica, the background, its motion) */
export function refresh() { token++; setMode('live'); schedule(); }
/** the current way of showing it (for tests and the developer page) */
export const state = () => mode;

const loadImg = (src) => new Promise((res, rej) => { const i = new Image(); i.onload = () => res(i); i.onerror = rej; i.src = src; });
const urlOf = (el) => { const m = String(el && el.style.backgroundImage || '').match(/url\(["']?(.*?)["']?\)/); return m ? m[1] : ''; };
let artImg = null, grainImg = null;
/** the pictures the background is made of, loaded: the cover's blurred art (none without ambient) and the grain */
async function sources() {
  let art = null;
  if (!document.body.classList.contains('no-ambient')) {
    const src = urlOf(document.querySelector('#bg .bg-art.on'));
    if (src) { try { art = artImg && artImg.src === new URL(src, location.href).href ? artImg : (artImg = await loadImg(src)); } catch { art = null; } }
  }
  const gsrc = grainUrl || urlOf(document.querySelector('#bg .grain'));
  let gr = null;
  if (gsrc) { try { gr = grainImg && grainImg.src === gsrc ? grainImg : (grainImg = await loadImg(gsrc)); } catch {} }
  const cs = getComputedStyle(root);
  return { art, grain: gr, bg: rgb(cs.getPropertyValue('--bg').trim() || '#111'), light: root.dataset.scheme === 'light', ambient: !document.body.classList.contains('no-ambient') };
}
/* the layers in the order #bg stacks them */
function paintArt(x, W, H, s) {
  const [bR, bG, bB] = s.bg;
  x.globalAlpha = 1; x.fillStyle = `rgb(${bR},${bG},${bB})`; x.fillRect(0, 0, W, H);
  if (!s.ambient) return;
  const im = s.art;
  if (im) {
    // background-size cover over inset −6 %
    const bx = -0.06 * W, by = -0.06 * H, bw = W * 1.12, bh = H * 1.12;
    const sc = Math.max(bw / im.naturalWidth, bh / im.naturalHeight), dw = im.naturalWidth * sc, dh = im.naturalHeight * sc;
    x.globalAlpha = s.light ? 0.28 : 0.62;     // islands.css: .28 on a light page, app.css: .62
    x.imageSmoothingQuality = 'high';
    x.drawImage(im, bx + (bw - dw) / 2, by + (bh - dh) / 2, dw, dh);
    x.globalAlpha = 1;
  }
}
function paintBlobs(x, W, H, s) { if (!s.ambient) return; x.globalAlpha = s.light ? 0.55 : 1; x.drawImage(canvas, 0, 0, W, H); x.globalAlpha = 1; }
function paintVeil(x, W, H, s) {
  const [bR, bG, bB] = s.bg, bga = (a) => `rgba(${bR},${bG},${bB},${a})`;
  // radial-gradient(120% 90% at 30% 20%, transparent, bg 55% at 70%) + linear 180deg bg 20% → 70%
  x.save(); x.translate(W * 0.3, H * 0.2); x.scale(W * 1.2, H * 0.9);
  const rg = x.createRadialGradient(0, 0, 0, 0, 0, 1);
  rg.addColorStop(0, bga(0)); rg.addColorStop(0.7, bga(0.55)); rg.addColorStop(1, bga(0.55));
  x.fillStyle = rg; x.fillRect(-2, -2, 4, 4); x.restore();
  const lg = x.createLinearGradient(0, 0, 0, H);
  lg.addColorStop(0, bga(0.2)); lg.addColorStop(1, bga(0.7));
  x.fillStyle = lg; x.fillRect(0, 0, W, H);
  // the grain, which keeps large dark gradients from banding (its dots carry their own alpha: see grain)
  if (s.grain) { x.fillStyle = x.createPattern(s.grain, 'repeat'); x.fillRect(0, 0, W, H); }
}
/* the veil and the grain do not move: made once per picture, so a new picture is three draws, not five */
function veilAndGrain(s) {
  const W = Math.max(64, innerWidth), H = Math.max(64, innerHeight);
  const c = document.createElement('canvas'); c.width = W; c.height = H;
  paintVeil(c.getContext('2d'), W, H, s);
  return c;
}
/** the painted background, as the blobs stand now */
export const stats = { paints: 0, draws: 0 };
function paintNow() {
  if (!paintC || !paintSrc) return;
  stats.paints++;
  const W = Math.max(64, innerWidth), H = Math.max(64, innerHeight);
  if (paintC.width !== W || paintC.height !== H) { paintC.width = W; paintC.height = H; }
  if (!paintSrc.top || paintSrc.top.width !== W || paintSrc.top.height !== H) paintSrc.top = veilAndGrain(paintSrc);
  paintArt(paintX, W, H, paintSrc);
  paintBlobs(paintX, W, H, paintSrc);
  paintX.drawImage(paintSrc.top, 0, 0);
}
/** #bg painted into one opaque picture (what the live layers show, frozen) → an object URL */
async function renderStill() {
  const W = Math.max(64, innerWidth), H = Math.max(64, innerHeight);
  const c = document.createElement('canvas'); c.width = W; c.height = H;
  const x = c.getContext('2d', { alpha: false });
  const s = await sources();
  paintArt(x, W, H, s);
  if (s.ambient) { readColours(performance.now(), true); draw(layout(clock / 1000, innerWidth, innerHeight)); paintBlobs(x, W, H, s); }   // the blobs, as they stand now
  paintVeil(x, W, H, s);
  const blob = await new Promise((r) => c.toBlob(r, 'image/jpeg', 0.92));
  return blob ? URL.createObjectURL(blob) : '';
}
