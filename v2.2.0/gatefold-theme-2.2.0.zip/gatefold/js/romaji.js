/*
 * Gatefold · romaji.js — Japanese lyrics also in Latin letters, under each line (Reddit 14.11, as Apple Music does).
 *
 * The reading of kanji needs a dictionary: kuromoji's IPADIC, ~18 MB in 12 files, downloaded once when the setting
 * is turned on (jsDelivr, unpkg as a fallback), kept in IndexedDB and built in a worker (romaji-worker.js) the first
 * time a Japanese text is shown in a session. Lines are turned into romaji there and remembered per text.
 * Only texts with kana are taken for Japanese (Chinese has none).
 */
import { call, ok, log } from './bridge.js';
import * as IDB from './idb.js';

const FILES = ['base.dat.gz', 'check.dat.gz', 'tid.dat.gz', 'tid_pos.dat.gz', 'tid_map.dat.gz', 'cc.dat.gz',
  'unk.dat.gz', 'unk_pos.dat.gz', 'unk_map.dat.gz', 'unk_char.dat.gz', 'unk_compat.dat.gz', 'unk_invoke.dat.gz'];
const BASES = ['https://cdn.jsdelivr.net/npm/kuromoji@0.1.2/dict/', 'https://unpkg.com/kuromoji@0.1.2/dict/'];
const KEY = 'romaji.dict.v1:';

export const events = new EventTarget();
export const state = { phase: 'idle', done: 0, total: FILES.length, error: '' };   // idle | downloading | building | ready | failed
const tell = () => events.dispatchEvent(new Event('change'));

/** a text Japanese enough to read in romaji: it has kana */
export const isJapanese = (lines) => (lines || []).some((l) => /[぀-ヿ]/.test(String(l || '')));

function bytesOf(b64) {
  const s = atob(b64), out = new Uint8Array(s.length);
  for (let i = 0; i < s.length; i++) out[i] = s.charCodeAt(i);
  return out;
}
async function file(name) {
  const kept = await IDB.kvGet(KEY + name, null);
  if (kept && kept.byteLength) return kept;
  let last = '';
  for (const base of BASES) {
    const r = await call('gf:net.fetch', { url: base + name, encoding: 'base64', maxBytes: 16 * 1024 * 1024, timeoutMs: 180000 });
    if (!ok(r) || r.status !== 200) { last = ok(r) ? 'HTTP ' + r.status : r.error || r.code || '?'; continue; }
    const b = bytesOf(r.body);
    if (b[0] !== 0x1f || b[1] !== 0x8b) { last = 'not gzip'; continue; }   // a page of an error, not the file
    await IDB.kvSet(KEY + name, b.buffer);
    return b.buffer;
  }
  throw new Error(`${name}: ${last}`);
}

/** is the dictionary on this computer already (nothing to download)? */
export async function downloaded() {
  for (const n of FILES) { const k = await IDB.kvGet(KEY + n, null); if (!k || !k.byteLength) return false; }
  return true;
}
/** forget the dictionary (Settings: it takes ~18 MB) */
export async function remove() {
  for (const n of FILES) await IDB.kvDel(KEY + n);
  if (worker) { worker.terminate(); worker = null; }
  ready = null; state.phase = 'idle'; state.done = 0; tell();
}

let worker = null, ready = null, seq = 0;
const waits = new Map();
/** the dictionary downloaded (once) and built (once a session) */
export function prepare() {
  if (ready) return ready;
  ready = (async () => {
    state.phase = 'downloading'; state.done = 0; state.error = ''; tell();
    const files = {};
    for (const n of FILES) { files[n] = await file(n); state.done++; tell(); }
    state.phase = 'building'; tell();
    worker = new Worker('js/romaji-worker.js');
    await new Promise((res, rej) => {
      worker.onmessage = (e) => {
        const d = e.data || {};
        if (d.ready) { res(); return; }
        if (d.error && d.id == null) { rej(new Error(d.error)); return; }
        const w = waits.get(d.id); if (!w) return;
        waits.delete(d.id);
        if (d.error) w.rej(new Error(d.error)); else w.res(d.lines);
      };
      worker.onerror = (e) => rej(new Error(e.message || 'worker'));
      worker.postMessage({ init: files }, Object.values(files));
    });
    state.phase = 'ready'; tell();
  })().catch((e) => {
    log('romaji:', e && e.message);
    state.phase = 'failed'; state.error = String((e && e.message) || e); tell();
    if (worker) { worker.terminate(); worker = null; }
    ready = null;
    throw e;
  });
  return ready;
}

const memo = new Map();   // the text of a song → its lines in romaji
/** the lines in romaji (the same count; a line with nothing Japanese comes back as it was) */
export async function lines(texts) {
  const key = texts.join('\n');
  if (memo.has(key)) return memo.get(key);
  await prepare();
  const id = ++seq;
  const out = await new Promise((res, rej) => { waits.set(id, { res, rej }); worker.postMessage({ id, lines: texts }); });
  memo.set(key, out);
  if (memo.size > 40) memo.delete(memo.keys().next().value);
  return out;
}
