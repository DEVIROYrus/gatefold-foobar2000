/*
 * Gatefold · ringpull.js — every sample played since the last look, out of the host's live ring (viz.js → ring()),
 * in order: the analyzer (analyzer.js) and the small one under the track (minianalyzer.js) measure all of them.
 *
 * Ring header (Uint32): [2] channels, [3] sample rate, [6] capacity in frames, [7] sequence (odd while the host
 * writes), [8] frames written in all, [15] the next slot; the interleaved floats start at float 16.
 */
export function reader(getRing, { first = 16384 } = {}) {
  let epoch = -1, lastW = -1;
  /** → { frames: Float32Array interleaved, ch, sr } | null (nothing new, or the host mid-write); false: no ring */
  return function pull() {
    const r = getRing();
    if (!r) return false;
    const u = r.u32, f = r.f32;
    if (r.epoch !== epoch) { epoch = r.epoch; lastW = -1; }
    for (let attempt = 0; attempt < 2; attempt++) {
      const s1 = u[7]; if (s1 & 1) return null;
      const cap = u[6], ch = u[2] || r.ch, sr = u[3] || r.sr, written = u[8], slot = u[15];
      if (!cap) return null;
      if (lastW < 0) lastW = (written - Math.min(cap, first)) >>> 0;
      let n = (written - lastW) >>> 0;
      if (!n) return null;
      if (n > cap) n = cap;
      const out = new Float32Array(n * ch);
      let s = (slot - n) % cap; if (s < 0) s += cap;
      for (let i = 0; i < n; i++) {
        const base = 16 + ((s + i) % cap) * ch;
        for (let c = 0; c < ch; c++) out[i * ch + c] = f[base + c];
      }
      if (u[7] !== s1) continue;
      lastW = written;
      return { frames: out, ch, sr };
    }
    return null;
  };
}
