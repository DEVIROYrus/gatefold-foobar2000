/*
 * Gatefold · libfilter.js — filter chips over the album grid: genre, decade, quality.
 * One choice per kind; the chips say what is on and a × takes it off. Quality (lossless / Hi-Res /
 * lossy) comes from each album's first track, asked of foobar2000 once, in the background.
 */
import { esc, call } from './bridge.js';
import { h, icon, popupMenu, closeMenus, menuOpener, pressClosesMenu } from './ui.js';
import { $t, lang } from './i18n.js';
import { settings, setSetting } from './settings.js';
import { yearOf, albumKey } from './sorting.js';
import { albumKeyOf } from './bridge.js';
import * as Sound from './ml/sound.js';
import * as SoundUI from './ml/sound-ui.js';

export const F = { genre: '', decade: 0, quality: '', mood: '' };
let moodA = null, moodT = null;          // the chosen mood: albums by share, track keys
let onChange = () => {}, getAlbums = () => [];
const quality = new Map();          // first track path → 'hires' | 'lossless' | 'lossy'
let qLoading = null;

const QUAL = () => ({ lossless: $t('Без потерь'), hires: 'Hi-Res', lossy: $t('С потерями') });
const splitGenres = (s) => String(s || '').split(/\s*[;/,]\s*/).map((g) => g.trim()).filter(Boolean);
/* sub-genres (settings.genreParents: «House» → «Electronic», case-insensitive keys): an album of a genre belongs
   to its parent, and to the parent's parent, too — the parent's albums include its children's. A loop in the map
   (A → B → A) is walked once. A parent needs no album of its own: «Rock» can hold only «Grunge» and «Punk». */
const parents = () => settings.genreParents || {};
export const parentOf = (g) => { const p = parents(); return p[g] || p[Object.keys(p).find((k) => k.toLowerCase() === String(g).toLowerCase()) || ''] || ''; };
const ancestorsOf = (g) => { const out = [], seen = new Set([String(g).toLowerCase()]); for (let p = parentOf(g); p && !seen.has(p.toLowerCase()); p = parentOf(p)) { seen.add(p.toLowerCase()); out.push(p); } return out; };
export const childrenOf = (g) => Object.keys(parents()).filter((c) => String(parents()[c]).toLowerCase() === String(g).toLowerCase());
export const descendantsOf = (g) => { const out = [], seen = new Set([String(g).toLowerCase()]); const walk = (x) => { for (const c of childrenOf(x)) if (!seen.has(c.toLowerCase())) { seen.add(c.toLowerCase()); out.push(c); walk(c); } }; walk(g); return out; };
/** a genre text's genres with their parents («House» → House, Electronic) */
const withParents = (s) => { const vals = splitGenres(s), seen = new Set(vals.map((v) => v.toLowerCase())); for (const v of [...vals]) for (const p of ancestorsOf(v)) if (!seen.has(p.toLowerCase())) { seen.add(p.toLowerCase()); vals.push(p); } return vals; };
const genresOf = (a) => withParents(a.genre);
/** an album's own genres (without parents) */
export const ownGenres = (a) => splitGenres(a.genre);

export const active = () => !!(F.genre || F.decade || F.quality || F.mood);
const LOSSLESS = /^(flac|alac|wavpack|monkey's audio|ape|pcm|wav|aiff?|tak|tta|dsd|dsf|dff|mlp|true audio|optimfrog)/i;
/** quality of one track from the library's fields (no bit depth there: Hi-Res = lossless above 48 kHz) */
const trackQuality = (t) => (LOSSLESS.test(String(t.codec || '')) ? (+t.sampleRate > 48000 ? 'hires' : 'lossless') : t.codec ? 'lossy' : '');
function setMood(kind) {
  F.mood = kind; moodA = kind ? SoundUI.moodAlbums(kind, albumKeyOf) : null; moodT = kind ? SoundUI.moodKeys(kind) : null;
}

export function filter(list) {
  if (!active()) return list;
  const g = F.genre.toLowerCase();
  return list.filter((a) => (!F.genre || genresOf(a).some((x) => x.toLowerCase() === g))
    && (!F.decade || Math.floor(yearOf(a) / 10) * 10 === F.decade)
    && (!F.quality || quality.get(a.firstTrackAbsolutePath) === F.quality || (F.quality === 'lossless' && quality.get(a.firstTrackAbsolutePath) === 'hires'))
    && (!F.mood || (moodA && (moodA.get(albumKey(a)) || 0) >= 0.4)));
}
/** the same choices for one track of «Tracks» (tracks.js): its genre text, year and fields */
export function matchTrack(t, genre, year) {
  if (F.genre && !withParents(genre).some((x) => x.toLowerCase() === F.genre.toLowerCase())) return false;
  if (F.decade && Math.floor((year || 0) / 10) * 10 !== F.decade) return false;
  if (F.quality) { const q = trackQuality(t); if (!(q === F.quality || (F.quality === 'lossless' && q === 'hires'))) return false; }
  if (F.mood && !(moodT && moodT.has(Sound.keyOf(t)))) return false;
  return true;
}

async function loadQuality() {
  if (qLoading) return qLoading;
  qLoading = (async () => {
    const paths = getAlbums().map((a) => a.firstTrackAbsolutePath).filter((p) => p && !quality.has(p));
    for (let i = 0; i < paths.length; i += 400) {
      const part = paths.slice(i, i + 400);
      const r = await call('titleformat.evalFieldsBatch', { paths: part, fields: { enc: '%__encoding%', bits: '%__bitspersample%', sr: '%samplerate%' } });
      const rows = (r && r.success !== false && r.results) || [];
      part.forEach((p, k) => {
        const v = rows[k];
        if (!v || v.success === false) return;
        const enc = String(v.enc || '').toLowerCase();
        if (!enc || enc === '?') return;
        quality.set(p, enc === 'lossless' ? ((+v.bits > 16 || +v.sr > 48000) ? 'hires' : 'lossless') : 'lossy');
      });
    }
  })().finally(() => { qLoading = null; });
  return qLoading;
}

function counts(key) {
  const m = new Map();
  for (const a of getAlbums()) for (const k of key(a)) if (k) m.set(k, (m.get(k) || 0) + 1);
  return [...m].sort((x, y) => y[1] - x[1]);
}

/* ---------------------------------------------------------------- the genre list (#14)
   Every genre of the library, not the 30 biggest: a search field on top, A–Z or by album count (remembered), the
   list scrolls. From the chip over the grid, the «Жанры» item of the sidebar and a genre on an album page. */
const collator = new Intl.Collator(lang, { sensitivity: 'base', numeric: true });
/** all genres with their album counts, in the chosen order */
export function genreList(albums = getAlbums()) {
  const m = new Map();   // lower case → [shown name, albums]
  for (const a of albums) for (const g of genresOf(a)) { const k = g.toLowerCase(); const e = m.get(k); if (e) e[1]++; else m.set(k, [g, 1]); }
  const out = [...m.values()];
  return settings.genreSort === 'count' ? out.sort((x, y) => y[1] - x[1] || collator.compare(x[0], y[0])) : out.sort((x, y) => collator.compare(x[0], y[0]));
}
let gpop = null, genreMenu = null;
/** the menu of a genre (change it on every album, make it a sub-genre, pin it) — library.js gives it */
export const setGenreMenu = (fn) => { genreMenu = fn; };
/** the list as a popover under `rect`; `chosen(name)` gets the genre picked ('' when the chosen one is picked again) */
export function genrePopover(rect, chosen, albums) {
  if (gpop) { gpop.close(); return; }
  closeMenus();
  const opener = menuOpener();
  const el = h(`<div class="menu lf-gpop" role="dialog" aria-label="${esc($t('Жанры'))}">
    <div class="lf-ghead"><input class="st-input lf-gfind" spellcheck="false" placeholder="${esc($t('Найти жанр…'))}" aria-label="${esc($t('Найти жанр…'))}">
    <div class="seg lf-gsort"><button data-s="name">${esc($t('А–Я'))}</button><button data-s="count">${esc($t('По числу'))}</button></div></div>
    <div class="lf-glist" role="listbox"></div></div>`);
  const find = el.querySelector('.lf-gfind'), list = el.querySelector('.lf-glist');
  const draw = () => {
    el.querySelectorAll('.lf-gsort button').forEach((b) => b.classList.toggle('on', b.dataset.s === (settings.genreSort === 'count' ? 'count' : 'name')));
    const f = find.value.trim().toLowerCase();
    const rows = genreList(albums ? albums() : undefined).filter(([g]) => !f || g.toLowerCase().includes(f));
    list.innerHTML = rows.length ? '' : `<div class="sp-gnone">${esc($t('Нет такого жанра'))}</div>`;
    const cur = F.genre.toLowerCase();
    for (const [g, n] of rows) {
      const on = g.toLowerCase() === cur;
      const r = h(`<button class="mi lf-grow${on ? ' on' : ''}" role="option" aria-selected="${on}"><span class="chk">${on ? '✓' : ''}</span><span class="n"></span><span class="c num"></span></button>`);
      r.querySelector('.n').textContent = g;
      r.querySelector('.c').textContent = n.toLocaleString();
      r.onclick = () => { close(); chosen(on ? '' : g); };
      if (genreMenu) r.oncontextmenu = (e) => { e.preventDefault(); close(); genreMenu(g, e.clientX, e.clientY); };
      list.append(r);
    }
  };
  const outside = (e) => { if (!el.contains(e.target)) { pressClosesMenu(e, opener); close(); } };
  const key = (e) => {
    if (e.key === 'Escape') { e.preventDefault(); close(); return; }
    if (e.key === 'Enter' && e.target === find) { const first = list.querySelector('.lf-grow'); if (first) first.click(); return; }
    if (e.key === 'ArrowDown' && e.target === find) { e.preventDefault(); list.querySelector('.lf-grow')?.focus(); }
  };
  const close = () => {
    if (!gpop) return;
    gpop = null; el.remove();
    document.removeEventListener('pointerdown', outside, true); el.removeEventListener('keydown', key);
  };
  el.querySelectorAll('.lf-gsort button').forEach((b) => b.onclick = () => { setSetting('genreSort', b.dataset.s); draw(); });
  find.oninput = draw;
  find.addEventListener('keydown', (e) => e.stopPropagation(), false);
  el.addEventListener('keydown', key);
  draw();
  document.getElementById('layer').append(el);
  const W = innerWidth, H = innerHeight, b = el.getBoundingClientRect();
  el.style.left = Math.max(6, Math.min(rect.left, W - b.width - 6)) + 'px';
  el.style.top = (rect.bottom + 4 + b.height > H - 6 ? Math.max(6, rect.top - b.height - 4) : rect.bottom + 4) + 'px';
  gpop = { close };
  setTimeout(() => { if (gpop) document.addEventListener('pointerdown', outside, true); }, 0);
  find.focus();
}
/** only this genre or this mood (from Now Playing: its genre and mood chips), the other choices off */
export function only({ genre = '', mood = '' } = {}) { F.genre = genre || ''; F.decade = 0; F.quality = ''; setMood(mood || ''); render(); onChange(); }
/** a genre chosen elsewhere (the sidebar, an album page): the grid shows its albums */
export function setGenre(g) { F.genre = g || ''; render(); onChange(); }

async function pick(kind, btn) {
  const r = btn.getBoundingClientRect();
  let items = [];
  if (kind === 'genre') { genrePopover(r, (g) => { F.genre = g; render(); onChange(); }); return; }
  if (kind === 'decade') items = counts((a) => { const y = yearOf(a); return y ? [Math.floor(y / 10) * 10] : []; }).sort((x, y) => y[0] - x[0]).map(([d, n]) => ({ id: d, label: `${$t('{0}-е', d)} · ${n}`, checked: F.decade === d }));
  if (kind === 'quality') {
    btn.classList.add('busy'); await loadQuality(); btn.classList.remove('busy');
    const c = { lossless: 0, hires: 0, lossy: 0 };
    for (const a of getAlbums()) { const q = quality.get(a.firstTrackAbsolutePath); if (q) { c[q]++; if (q === 'hires') c.lossless++; } }
    items = Object.entries(QUAL()).filter(([k]) => c[k]).map(([k, label]) => ({ id: k, label: `${label} · ${c[k]}`, checked: F.quality === k }));
  }
  if (kind === 'mood') {
    const recipes = SoundUI.MOOD_RECIPES();
    items = recipes.map(([k, title]) => { const m = SoundUI.moodAlbums(k, albumKeyOf); const n = m ? [...m.values()].filter((v) => v >= 0.4).length : 0; return { id: k, label: `${title} · ${n}`, checked: F.mood === k, n }; }).filter((x) => x.n);
  }
  if (!items.length) return;
  const id = await popupMenu(items, r.left, r.bottom + 4);
  if (id == null) return;
  if (kind === 'mood') setMood(F.mood === id ? '' : id);
  else F[kind] = F[kind] === id ? (kind === 'decade' ? 0 : '') : id;
  render(); onChange();
}

let bar = null;
export function render() {
  if (!bar) return;
  const moodName = F.mood ? SoundUI.filterLabel(F.mood) : '';
  const label = { genre: F.genre, decade: F.decade ? $t('{0}-е', F.decade) : '', quality: F.quality ? QUAL()[F.quality] : '', mood: moodName };
  const names = { genre: $t('Жанр'), decade: $t('Десятилетие'), quality: $t('Качество'), mood: $t('Настроение') };
  bar.innerHTML = '';
  for (const k of ['genre', 'decade', 'quality', ...(Sound.ready() ? ['mood'] : [])]) {
    const on = !!label[k];
    const b = h(`<button class="lf-chip${on ? ' on' : ''}" data-k="${k}"><span></span>${on ? `<i class="x" role="button" aria-label="${esc($t('Сбросить'))}">${icon('x', 12)}</i>` : icon('chev', 12)}</button>`);
    b.querySelector('span').textContent = on ? label[k] : names[k];
    b.onclick = (e) => { if (e.target.closest('.x')) { if (k === 'mood') setMood(''); else F[k] = k === 'decade' ? 0 : ''; render(); onChange(); return; } pick(k, b); };
    bar.append(b);
  }
  if (active()) { const c = h(`<button class="lf-clear">${esc($t('Сбросить всё'))}</button>`); c.onclick = () => { F.genre = ''; F.decade = 0; F.quality = ''; setMood(''); render(); onChange(); }; bar.append(c); }
}

const listeners = new Set();
/** «Tracks» re-filters too when a chip changes */
export const onFilter = (fn) => listeners.add(fn);
export function init({ mount, albums, changed }) {
  bar = mount; getAlbums = albums; onChange = () => { changed(); for (const f of listeners) f(); };
  render();
  Sound.events.addEventListener('change', () => { if (!bar.querySelector('[data-k=mood]') && Sound.ready()) render(); });
}
