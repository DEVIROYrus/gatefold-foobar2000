/*
 * Gatefold · hostcheck.js — the interface newer than its component. An update inside Gatefold replaces the
 * interface only; fixes that live in foo_gatefold (the component) come with the installer. When the component is
 * older than this interface was built with, a note says so once a day, with the way to the installer.
 */
import { VERSION, REPO, HOST_MIN } from './version.js';
import { cmp } from './updater.js';
import { toast } from './ui.js';
import { call } from './bridge.js';
import { $t } from './i18n.js';

const KEY = 'gatefold.hostOld.v1';
export function check() {
  const gf = window.gf;
  if (!gf || typeof gf.call !== 'function' || window.fb2k || !gf.info || !HOST_MIN) return;
  const have = String(gf.info.version || '');
  if (!have || cmp(have, HOST_MIN) >= 0) return;
  try { const s = JSON.parse(localStorage.getItem(KEY) || 'null'); if (s && s.v === VERSION && Date.now() - s.at < 864e5) return; localStorage.setItem(KEY, JSON.stringify({ v: VERSION, at: Date.now() })); } catch {}
  const url = /^[\w.-]+\/[\w.-]+$/.test(REPO) ? `https://github.com/${REPO}/releases/tag/v${VERSION}` : `https://github.com/DEVIROYrus/gatefold-foobar2000/releases`;
  toast($t('Компонент Gatefold {0} старше интерфейса {1}: часть исправлений придёт только с установщиком.', have, VERSION), {
    ms: 20000, action: { label: $t('Скачать установщик'), fn: () => call('shell.openExternal', { url }) },
  });
}
