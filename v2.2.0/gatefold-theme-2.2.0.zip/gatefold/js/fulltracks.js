/*
 * Gatefold · fulltracks.js — an album's whole track list: your tracks, and in their places the ones you do not have,
 * greyed, each playing through YouTube (the album page, «Now playing» → «Tracklist»).
 *
 * The list comes from MusicBrainz (artistinfo.js: the release group of the album, found by its title and artist; a
 * release the artist's discography found on Deezer or iTunes comes from there). Of the release's editions the one your
 * tracks are on is taken — a deluxe edition when you have its bonus tracks — and it is shown only when it is surely
 * this album: at least one of your tracks is on it.
 *
 * Your tracks keep their own order; a missing track goes before the first of yours that comes after it on the
 * release, the rest after your last one.
 */
import * as Info from './artistinfo.js';
import { settings } from './settings.js';
import { router } from './ui.js';
import { isVarious as various } from './match.js';

const same = Info.sameTrack;

/** how well an edition fits your tracks: the number of them on it */
function fit(list, tracks) {
  const used = new Set(); let n = 0;
  for (const t of tracks) { const j = list.findIndex((x, k) => !used.has(k) && same(t.title, x.title)); if (j >= 0) { used.add(j); n++; } }
  return n;
}
/** your tracks paired with the edition's: local index → edition index (each used once, the nearest by number first) */
function pair(list, tracks) {
  const used = new Set(), at = new Map();
  tracks.forEach((t, i) => {
    const want = (+(t.trackNumber || t.track) || i + 1) - 1, disc = +(t.discNumber || t.disc) || 0;
    let best = -1, bestD = Infinity;
    list.forEach((x, k) => {
      if (used.has(k) || !same(t.title, x.title)) return;
      const d = Math.abs((x.pos ? x.pos - 1 : k) - want) + (disc && x.disc && disc !== x.disc ? 100 : 0);
      if (d < bestD) { bestD = d; best = k; }
    });
    if (best >= 0) { used.add(best); at.set(i, best); }
  });
  return at;
}
/* the pairs that keep both orders (the longest increasing run of edition indexes along yours) */
function keepOrder(at, n) {
  const idx = [...Array(n).keys()].filter((i) => at.has(i));
  const tails = [], prev = new Map();
  for (const i of idx) {
    const v = at.get(i);
    let lo = 0, hi = tails.length;
    while (lo < hi) { const m = (lo + hi) >> 1; if (at.get(tails[m]) < v) lo = m + 1; else hi = m; }
    if (lo > 0) prev.set(i, tails[lo - 1]);
    tails[lo] = i;
  }
  const keep = new Set();
  for (let i = tails[tails.length - 1]; i != null; i = prev.get(i)) keep.add(i);
  return keep;
}

/**
 * The whole list: { items: [{ i } | { g }], missing: [track…], have, total, title } where i is the index of your track
 * and g the index into missing; null when there is nothing to add (switched off, offline, not found, not surely this
 * album, or you have it all).
 */
export async function of(album, tracks) {
  if (settings.onlineInfo === false || settings.albumGhosts === false || !album || !tracks || !tracks.length) return null;
  const artist = album.albumArtist || album.artist || '', title = album.name || album.title || '';
  if (!artist || !title || various(artist)) return null;
  const id = await Info.releaseGroupFor(artist, title).catch(() => '');
  if (!id) return null;
  const rel = await Info.release(id).catch(() => null);
  if (!rel || !(rel.tracks || []).length) return null;
  // the edition your tracks are on (asked again once when some of yours are on none we know)
  let eds = [rel, ...(await Info.editions(id).catch(() => []))];
  let best = null, bestN = -1;
  const pick = () => { for (const e of eds) { const n = fit(e.tracks || [], tracks); if (n > bestN) { bestN = n; best = e; } } };
  pick();
  if (bestN < tracks.length && eds.length === 1) { eds = [rel, ...(await Info.editions(id, { fetch: true }).catch(() => []))]; pick(); }
  const list = best.tracks || [];
  if (bestN < 1) return null;
  const at = pair(list, tracks);
  const keep = keepOrder(at, tracks.length);
  const taken = new Set(at.values());
  const missing = [];
  const ghostOf = new Map();                         // edition index → index into missing
  list.forEach((x, k) => { if (!taken.has(k)) { ghostOf.set(k, missing.length); missing.push({ ...x, pos: x.pos || posIn(list, k) }); } });
  if (!missing.length) return null;
  const items = [];
  let next = 0;                                      // the next edition index whose ghost may be placed
  const ghostsBefore = (k) => { for (; next < k; next++) if (ghostOf.has(next)) items.push({ g: ghostOf.get(next) }); };
  tracks.forEach((t, i) => {
    if (keep.has(i)) { ghostsBefore(at.get(i)); next = Math.max(next, at.get(i) + 1); }
    items.push({ i });
  });
  ghostsBefore(list.length);
  return { items, missing, have: bestN, total: list.length, title, artist, id };
}
/** a track's number on its disc, from its place in the list */
function posIn(list, k) { const d = list[k].disc || 1; let n = 0; for (let j = 0; j <= k; j++) if ((list[j].disc || 1) === d) n++; return n; }

/** play the missing tracks on YouTube from the n-th of them, the way back leading to `route` */
export function playMissing(full, n = 0, route = null) {
  if (!full) return;
  const from = { album: full.title, artist: full.artist, artistArg: full.artist, route: route || ['library'] };
  router.go('youtube', { tracks: full.missing.map((t) => ({ artist: full.artist, title: t.title, sec: t.sec })), index: n, album: full.title, from });
}
