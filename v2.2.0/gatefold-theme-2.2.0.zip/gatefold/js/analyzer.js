/*
 * Gatefold · analyzer.js — the spectrum analyzer: what is playing, measured, the way studio analyzers show it.
 *
 *  · the spectrum from 20 Hz to 20 kHz on a log scale with its grid, in dBFS: a filled curve, the peaks held
 *    above it, a second curve for left/right or mid/side, a snapshot to compare with, and the curve of
 *    Gatefold's equalizer over it when it is on (its own scale on the right, as in a mixing plug-in);
 *  · under the pointer: the frequency, the note (A4 = 440 Hz) with its cents, the level of each curve;
 *    the loudest tone marked with its note;
 *  · beside it: peak and RMS per channel, true peak, loudness per EBU R128 (momentary, short-term, integrated,
 *    range), the stereo correlation and width, the crest factor.
 *
 * The samples come from the host's live ring (viz.js → ring()); the measuring is in analyzer-worker.js. Nothing
 * runs while the sheet is closed. Keys: Space freezes, S takes a snapshot, R starts the meters again, Esc closes.
 */
import { h, icon, toast } from './ui.js';
import { $t } from './i18n.js';
import { esc } from './bridge.js';
import { settings, setSetting } from './settings.js';
import { current, onPalette } from './theme.js';
import * as Viz from './viz.js';
import { reader } from './ringpull.js';
import * as Power from './power.js';

const DEF = { res: 'high', smooth: 12, speed: 'medium', tilt: 4.5, range: 90, mode: 'sum', peaks: true, eq: true };
const opt = () => ({ ...DEF, ...(settings.analyzer || {}) });
const setOpt = (patch) => setSetting('analyzer', { ...opt(), ...patch });
const DECAY = { slow: 12, medium: 28, fast: 70 };            // dB per second the curve falls
const NOTES = ['C', 'C♯', 'D', 'D♯', 'E', 'F', 'F♯', 'G', 'G♯', 'A', 'A♯', 'B'];
const F_LO = 20, F_HI = 20000;
const fx = (f, w) => (Math.log(f / F_LO) / Math.log(F_HI / F_LO)) * w;
const xf = (x, w) => F_LO * Math.pow(F_HI / F_LO, x / w);
export function noteOf(f) {
  if (!(f > 0)) return null;
  const n = 12 * Math.log2(f / 440) + 69, r = Math.round(n);
  return { name: NOTES[((r % 12) + 12) % 12] + (Math.floor(r / 12) - 1), cents: Math.round((n - r) * 100) };
}
export const fmtHz = (f) => (f >= 1000 ? (f / 1000).toFixed(f >= 10000 ? 1 : 2) + ' ' + $t('кГц') : (f >= 100 ? f.toFixed(0) : f.toFixed(1)) + ' ' + $t('Гц'));
const fmtDb = (v, d = 1) => (Number.isFinite(v) ? (v > 0 ? '+' : v < 0 ? '−' : '') + Math.abs(v).toFixed(d) : '−∞');
const fmtCents = (c) => (c === 0 ? '±0¢' : (c > 0 ? '+' : '−') + Math.abs(c) + '¢');

let sheet = null;
export const isOpen = () => !!sheet;

export async function open({ ring = null } = {}) {   // ring: another source of samples (the tests)
  if (sheet) return;
  const o = opt();
  const seg = (key, items) => `<div class="seg an-seg" data-k="${key}">${items.map(([v, l]) => `<button data-v="${v}"${String(o[key]) === String(v) ? ' class="on"' : ''}>${esc(l)}</button>`).join('')}</div>`;
  const veil = h(`<div class="eq-veil an-veil" role="dialog" aria-modal="true" aria-label="${esc($t('Анализатор спектра'))}">
    <div class="eq-sheet an-sheet">
      <div class="eq-head an-head">
        <div class="eq-title"><b>${esc($t('Анализатор спектра'))}</b><small class="an-st"></small></div>
        <button class="btn an-freeze" title="${esc($t('Заморозить картинку (пробел)'))}">${icon('pause', 15)}<span>${esc($t('Стоп-кадр'))}</span></button>
        <button class="btn an-snap" title="${esc($t('Запомнить кривую, чтобы сравнить с другим местом или треком (S)'))}">${icon('image', 15)}<span>${esc($t('Снимок'))}</span></button>
        <button class="btn icon an-reset" title="${esc($t('Начать измерения заново (R)'))}">${icon('refresh', 16)}</button>
        <button class="btn icon eq-close an-close" aria-label="${esc($t('Закрыть'))}">${icon('x', 18)}</button>
      </div>
      <div class="an-main">
        <div class="an-plot"><canvas></canvas><div class="an-read" hidden></div><div class="an-msg" hidden></div></div>
        <aside class="an-meters">
          <div class="an-bars"><canvas></canvas></div>
          <div class="an-lufs">
            <div class="an-big"><small>${esc($t('Интегральная'))}</small><b data-m="integrated">—</b><i>LUFS</i></div>
            <div class="an-kv"><span>${esc($t('Мгновенная'))}</span><b data-m="momentary">—</b></div>
            <div class="an-kv"><span>${esc($t('Краткосрочная'))}</span><b data-m="shortTerm">—</b></div>
            <div class="an-kv"><span>${esc($t('Диапазон (LRA)'))}</span><b data-m="lra">—</b></div>
            <div class="an-kv"><span>${esc($t('Истинный пик'))}</span><b data-m="truePeakMax">—</b></div>
            <div class="an-kv"><span>${esc($t('Пик-фактор'))}</span><b data-m="crest">—</b></div>
          </div>
          <div class="an-corr"><div class="an-kv"><span>${esc($t('Корреляция'))}</span><b data-m="correlation">—</b></div><div class="an-cbar"><i></i></div>
            <div class="an-cscale"><span>−1</span><span>0</span><span>+1</span></div>
            <div class="an-kv"><span>${esc($t('Ширина стерео'))}</span><b data-m="width">—</b></div></div>
          <div class="an-tone"><small>${esc($t('Самый громкий тон'))}</small><b data-m="tone">—</b></div>
        </aside>
      </div>
      <div class="an-foot">
        <label><span>${esc($t('Каналы'))}</span>${seg('mode', [['sum', $t('Сумма')], ['lr', 'L / R'], ['ms', 'M / S']])}</label>
        <label><span>${esc($t('Разрешение'))}</span>${seg('res', [['low', $t('Низк.')], ['medium', $t('Сред.')], ['high', $t('Высок.')], ['max', $t('Макс.')]])}</label>
        <label><span>${esc($t('Сглаживание'))}</span>${seg('smooth', [[0, $t('нет')], [24, '1/24'], [12, '1/12'], [6, '1/6'], [3, '1/3']])}</label>
        <label><span>${esc($t('Спад'))}</span>${seg('speed', [['slow', $t('медл.')], ['medium', $t('сред.')], ['fast', $t('быстр.')]])}</label>
        <label><span>${esc($t('Наклон'))}</span>${seg('tilt', [[0, '0'], [3, '3'], [4.5, '4.5']])}</label>
        <label><span>${esc($t('Диапазон'))}</span>${seg('range', [[60, '60'], [90, '90'], [120, '120']])}</label>
        <label class="an-tg"><input type="checkbox" data-k="peaks"${o.peaks ? ' checked' : ''}><span>${esc($t('Пики'))}</span></label>
        <label class="an-tg"><input type="checkbox" data-k="eq"${o.eq ? ' checked' : ''}><span>${esc($t('Кривая эквалайзера'))}</span></label>
      </div>
    </div></div>`);
  document.getElementById('layer').append(veil);
  sheet = veil;
  const $ = (q) => veil.querySelector(q);
  const plot = $('.an-plot'), cv = $('.an-plot canvas'), bars = $('.an-bars canvas'), read = $('.an-read'), msg = $('.an-msg');
  const st = { spec: null, spec2: null, disp: null, disp2: null, hold: null, snap: null, freeze: false, peak: null, meters: null, pending: false, lastPush: 0, lastFrame: 0,
    w: 0, h: 0, bw: 0, bh: 0, d: 1, hover: -1, lastT: 0, lastW: -1, epoch: -1, track: '', pkHold: [-Infinity, -Infinity], pkAt: [0, 0], eqCurve: null, eqKey: '' };

  // ---- the measuring, in its worker
  const worker = new Worker(new URL('./analyzer-worker.js', import.meta.url));
  worker.onmessage = (e) => {
    st.pending = false;
    const m = e.data;
    st.meters = m.meters;
    if (st.freeze) return;
    st.spec = m.spec; st.spec2 = m.spec2; st.peak = m.peak;
  };
  Viz.vizState.extra.add('analyzer');
  import('./app.js').then((m) => { m.refreshSpectrum && m.refreshSpectrum(); st.app = m; }).catch(() => {});

  // ---- what has been played since the last look, out of the host's ring, in order
  const takeRing = reader(() => (ring ? ring() : Viz.ring && Viz.ring()));
  function pull() {
    const got = takeRing();
    if (got === false) return false;
    if (got) { worker.postMessage({ type: 'push', frames: got.frames, ch: got.ch, sr: got.sr }, [got.frames.buffer]); st.sr = got.sr; st.ch = got.ch; }
    return true;
  }

  // ---- sizes
  const ro = new ResizeObserver(() => {
    st.d = Math.min(2, devicePixelRatio || 1);
    const r = plot.getBoundingClientRect(); st.w = Math.round(r.width * st.d); st.h = Math.round(r.height * st.d);
    if (cv.width !== st.w || cv.height !== st.h) { cv.width = st.w; cv.height = st.h; }
    const b = bars.getBoundingClientRect(); st.bw = Math.round(b.width * st.d); st.bh = Math.round(b.height * st.d);
    if (bars.width !== st.bw || bars.height !== st.bh) { bars.width = st.bw; bars.height = st.bh; }
  });
  ro.observe(plot); ro.observe(bars);

  // ---- colours of the interface, kept up to date. The second curve (R, side) and the equalizer's need a colour
  // of their own: the cover's second accent when it is far enough from the first, else the first turned round
  const hsl = (hex) => {
    const m = /^#?([0-9a-f]{6})$/i.exec(String(hex).trim()); if (!m) return null;
    const v = parseInt(m[1], 16), r = (v >> 16) / 255, g = ((v >> 8) & 255) / 255, b = (v & 255) / 255;
    const mx = Math.max(r, g, b), mn = Math.min(r, g, b), l = (mx + mn) / 2, dd = mx - mn;
    if (!dd) return [0, 0, l];
    const sat = dd / (1 - Math.abs(2 * l - 1));
    const hue = mx === r ? ((g - b) / dd) % 6 : mx === g ? (b - r) / dd + 2 : (r - g) / dd + 4;
    return [(hue * 60 + 360) % 360, sat, l];
  };
  const fromHsl = (hh, ss, ll) => {
    const c = (1 - Math.abs(2 * ll - 1)) * ss, x = c * (1 - Math.abs(((hh / 60) % 2) - 1)), m = ll - c / 2;
    const [r, g, b] = hh < 60 ? [c, x, 0] : hh < 120 ? [x, c, 0] : hh < 180 ? [0, c, x] : hh < 240 ? [0, x, c] : hh < 300 ? [x, 0, c] : [c, 0, x];
    return '#' + [r, g, b].map((v) => Math.round((v + m) * 255).toString(16).padStart(2, '0')).join('');
  };
  const distinct = (a, b) => {
    const A = hsl(a), B = hsl(b); if (!A || !B) return b;
    const dh = Math.min(Math.abs(A[0] - B[0]), 360 - Math.abs(A[0] - B[0]));
    return dh >= 45 && B[1] > 0.25 ? b : fromHsl((A[0] + 165) % 360, Math.max(0.55, A[1]), 0.66);
  };
  // ---- colours of the interface, kept up to date
  let col = null;
  const colors = () => {
    const cs = getComputedStyle(document.documentElement);
    const p = current.palette;
    const a = p ? p.accent.hex : cs.getPropertyValue('--accent').trim() || '#8fb4ff';
    col = { a, b: distinct(a, p ? p.accent2.hex : '#c49bff'), text: cs.getPropertyValue('--text').trim() || '#fff',
      t2: cs.getPropertyValue('--text-2').trim() || 'rgba(255,255,255,.7)', t3: cs.getPropertyValue('--text-3').trim() || 'rgba(255,255,255,.45)', dark: !p || p.dark !== false };
  };
  colors();
  const offPal = onPalette(() => colors());

  // ---- the equalizer's curve (when it is on), worked out again only when it changes
  let EQ = null;
  import('./eq.js').then((m) => { EQ = m; }).catch(() => {});
  function eqCurve(n) {
    if (!EQ || !opt().eq) return null;
    const s = EQ.state && EQ.state();
    if (!s || !s.enabled) return null;
    const key = JSON.stringify([s.mode, s.graphic, s.bands, s.preamp, n, st.sr || 48000]);
    if (key === st.eqKey) return st.eqCurve;
    const fr = []; for (let i = 0; i < n; i++) fr.push(F_LO * Math.pow(1000, i / (n - 1)));
    st.eqCurve = Float32Array.from(EQ.curve(EQ.bandsOf(s), fr, st.sr || 48000));
    st.eqKey = key;
    return st.eqCurve;
  }

  // ---- drawing
  const yOf = (db, top, range, h) => ((top - db) / range) * h;
  function drawPlot(now) {
    const c = cv.getContext('2d'), w = st.w, hh = st.h, d = st.d;
    if (!w || !hh) return;
    const o = opt(), top = 6, range = o.range + top;
    c.clearRect(0, 0, w, hh);
    const padB = 18 * d, ph = hh - padB;
    // grid: frequencies
    c.lineWidth = 1;
    c.font = `${10.5 * d}px var(--font, system-ui), system-ui, sans-serif`; c.textBaseline = 'alphabetic';
    const lines = [];
    for (const dec of [10, 100, 1000, 10000]) for (let k = 1; k < 10; k++) { const f = dec * k; if (f >= F_LO && f <= F_HI) lines.push(f); }
    lines.push(20000);
    for (const f of lines) {
      const x = Math.round(fx(f, w)) + 0.5, major = f === 100 || f === 1000 || f === 10000;
      c.strokeStyle = col.dark ? `rgba(255,255,255,${major ? 0.13 : 0.05})` : `rgba(0,0,0,${major ? 0.14 : 0.06})`;
      c.beginPath(); c.moveTo(x, 0); c.lineTo(x, ph); c.stroke();
    }
    c.fillStyle = col.t3; c.textAlign = 'center';
    for (const [f, l] of [[20, '20'], [50, '50'], [100, '100'], [200, '200'], [500, '500'], [1000, '1k'], [2000, '2k'], [5000, '5k'], [10000, '10k'], [20000, '20k']]) {
      const x = fx(f, w); c.textAlign = f === 20 ? 'left' : f === 20000 ? 'right' : 'center';
      c.fillText(l, f === 20 ? x + 3 * d : f === 20000 ? x - 3 * d : x, hh - 4 * d);
    }
    // grid: levels
    const step = o.range <= 60 ? 6 : 12;
    c.textAlign = 'left'; c.textBaseline = 'middle';
    for (let db = 0; db >= -o.range; db -= step) {
      const y = Math.round(yOf(db, top, range, ph)) + 0.5;
      c.strokeStyle = col.dark ? `rgba(255,255,255,${db === 0 ? 0.16 : 0.05})` : `rgba(0,0,0,${db === 0 ? 0.16 : 0.06})`;
      c.beginPath(); c.moveTo(0, y); c.lineTo(w, y); c.stroke();
      if (db > -o.range) { c.fillStyle = col.t3; c.fillText(String(db), 5 * d, y - 7 * d); }
    }
    // the curves
    const n = st.disp ? st.disp.length : 0;
    const path = (arr) => { c.beginPath(); for (let i = 0; i < arr.length; i++) { const x = (i / (arr.length - 1)) * w, y = Math.max(0, Math.min(ph, yOf(arr[i], top, range, ph))); if (i) c.lineTo(x, y); else c.moveTo(x, y); } };
    if (st.snap && st.snap.length) {
      c.save(); c.setLineDash([4 * d, 4 * d]); c.strokeStyle = col.t3; c.lineWidth = 1.25 * d; path(st.snap); c.stroke(); c.restore();
    }
    if (n) {
      // filled: the accent fading towards the floor
      path(st.disp); c.lineTo(w, ph); c.lineTo(0, ph); c.closePath();
      const g = c.createLinearGradient(0, 0, 0, ph);
      g.addColorStop(0, hexA(col.a, 0.5)); g.addColorStop(0.55, hexA(col.a, 0.16)); g.addColorStop(1, hexA(col.a, 0.02));
      c.fillStyle = g; c.fill();
      path(st.disp); c.strokeStyle = col.a; c.lineWidth = 1.6 * d; c.lineJoin = 'round'; c.stroke();
      if (st.disp2) { path(st.disp2); c.strokeStyle = hexA(col.b, 0.95); c.lineWidth = 1.3 * d; c.stroke(); }
      if (opt().peaks && st.hold) { c.save(); c.setLineDash([2 * d, 2 * d]); path(st.hold); c.strokeStyle = hexA(col.text, col.dark ? 0.32 : 0.4); c.lineWidth = 1 * d; c.stroke(); c.restore(); }
      // which curve is which
      const m = opt().mode;
      if (m !== 'sum' && st.disp2) {
        c.font = `600 ${11 * d}px var(--font, system-ui), system-ui, sans-serif`; c.textAlign = 'left'; c.textBaseline = 'middle';
        const lx = 36 * d, ly = 14 * d;
        c.fillStyle = col.a; c.fillRect(lx, ly - 1 * d, 14 * d, 3 * d); c.fillText(m === 'lr' ? 'L' : 'Mid', lx + 18 * d, ly);
        c.fillStyle = col.b; c.fillRect(lx + 52 * d, ly - 1 * d, 14 * d, 3 * d); c.fillText(m === 'lr' ? 'R' : 'Side', lx + 70 * d, ly);
      }
    }
    // the equalizer's curve on its own scale (±18 dB over the height, 0 in the middle)
    const eq = eqCurve(Math.max(64, Math.round(w / (3 * d))));
    if (eq) {
      const ey = (v) => ph / 2 - (v / 18) * (ph / 2);
      c.save(); c.beginPath();
      for (let i = 0; i < eq.length; i++) { const x = (i / (eq.length - 1)) * w, y = ey(eq[i]); if (i) c.lineTo(x, y); else c.moveTo(x, y); }
      // the equalizer in the text's colour with the accent's glow: apart from both curves
      c.shadowColor = hexA(col.a, 0.8); c.shadowBlur = 10 * d; c.strokeStyle = hexA(col.text, 0.92); c.lineWidth = 2 * d; c.stroke(); c.restore();
      c.fillStyle = col.t2; c.textAlign = 'right'; c.textBaseline = 'middle';
      for (const v of [12, 6, 0, -6, -12]) c.fillText((v > 0 ? '+' : '') + v, w - 5 * d, ey(v) - 7 * d);
      c.fillText('EQ', w - 5 * d, 10 * d);
    }
    // the loudest tone
    if (st.peak && st.peak.hz > F_LO && n && !st.freeze) st.tone = st.peak;
    if (st.tone && n) {
      const x = fx(st.tone.hz, w), i = Math.round((Math.log(st.tone.hz / F_LO) / Math.log(1000)) * (n - 1));
      const y = Math.max(10 * d, yOf(st.disp[Math.max(0, Math.min(n - 1, i))], top, range, ph));
      const nt = noteOf(st.tone.hz);
      c.fillStyle = col.text; c.beginPath(); c.moveTo(x, y - 4 * d); c.lineTo(x - 4 * d, y - 10 * d); c.lineTo(x + 4 * d, y - 10 * d); c.closePath(); c.fill();
      if (nt) { c.textAlign = 'center'; c.textBaseline = 'alphabetic'; c.font = `600 ${11 * d}px var(--font, system-ui), system-ui, sans-serif`; c.fillText(nt.name, Math.max(14 * d, Math.min(w - 14 * d, x)), y - 13 * d); }
    }
    // the pointer
    if (st.hover >= 0 && n) {
      const x = st.hover * d;
      c.strokeStyle = hexA(col.text, 0.35); c.lineWidth = 1; c.beginPath(); c.moveTo(Math.round(x) + 0.5, 0); c.lineTo(Math.round(x) + 0.5, ph); c.stroke();
      const f = xf(x, w), i = Math.round((Math.log(f / F_LO) / Math.log(1000)) * (n - 1));
      const v = st.disp[Math.max(0, Math.min(n - 1, i))], v2 = st.disp2 ? st.disp2[Math.max(0, Math.min(n - 1, i))] : null;
      c.fillStyle = col.a; c.beginPath(); c.arc(x, Math.max(0, Math.min(ph, yOf(v, top, range, ph))), 3.5 * d, 0, Math.PI * 2); c.fill();
      const nt = noteOf(f), m = opt().mode;
      const eqv = eq ? eq[Math.max(0, Math.min(eq.length - 1, Math.round((Math.log(f / F_LO) / Math.log(1000)) * (eq.length - 1))))] : null;
      read.innerHTML = `<b>${esc(fmtHz(f))}</b><span>${nt ? esc(nt.name) + ' <i>' + esc(fmtCents(nt.cents)) + '</i>' : ''}</span>`
        + `<span>${m === 'lr' ? 'L ' : m === 'ms' ? 'M ' : ''}${esc(fmtDb(v))} ${esc($t('дБ'))}${v2 != null ? ` · ${m === 'lr' ? 'R' : 'S'} ${esc(fmtDb(v2))}` : ''}</span>`
        + (eqv != null ? `<span class="eqv">EQ ${esc(fmtDb(eqv))} ${esc($t('дБ'))}</span>` : '');
      read.hidden = false;
      const rw = read.offsetWidth;
      read.style.transform = `translate(${Math.round(Math.min(st.w / d - rw - 8, st.hover + 12))}px, 8px)`;
    } else read.hidden = true;
  }
  const hexA = (hex, a) => {
    const m = /^#?([0-9a-f]{6})$/i.exec(String(hex).trim());
    if (!m) return hex;
    const v = parseInt(m[1], 16); return `rgba(${v >> 16},${(v >> 8) & 255},${v & 255},${a})`;
  };

  // ---- the meters beside
  const mEls = Object.fromEntries([...veil.querySelectorAll('[data-m]')].map((e) => [e.dataset.m, e]));
  const cbar = $('.an-cbar i');
  let metersAt = 0;
  function drawMeters(now, dt) {
    const m = st.meters; if (!m) return;
    // the bars: L and R, peak (bright) over RMS (deep), a held peak line, −60 … 0 dBFS
    const c = bars.getContext('2d'), w = st.bw, hh = st.bh, d = st.d;
    if (w && hh) {
      c.clearRect(0, 0, w, hh);
      const lo = -60, yv = (db) => hh - 14 * d - Math.max(0, Math.min(1, (db - lo) / -lo)) * (hh - 22 * d);
      const bw = Math.min(16 * d, (w - 40 * d) / 2), gap = 6 * d, x0 = (w - (bw * 2 + gap)) / 2 + 10 * d;
      c.font = `${9.5 * d}px var(--font, system-ui), system-ui, sans-serif`; c.fillStyle = col.t3; c.textAlign = 'right'; c.textBaseline = 'middle';
      for (const db of [0, -6, -12, -18, -24, -36, -48, -60]) { const y = yv(db); c.fillText(String(db), x0 - 6 * d, y); c.fillStyle = col.dark ? 'rgba(255,255,255,.06)' : 'rgba(0,0,0,.07)'; c.fillRect(x0 - 3 * d, Math.round(y), bw * 2 + gap + 3 * d, 1); c.fillStyle = col.t3; }
      ['L', 'R'].forEach((lab, k) => {
        const x = x0 + k * (bw + gap), pk = m.peak[k], rm = m.rms[k];
        if (pk > st.pkHold[k] || now - st.pkAt[k] > 1500) { st.pkHold[k] = pk; st.pkAt[k] = now; }
        c.fillStyle = col.dark ? 'rgba(255,255,255,.05)' : 'rgba(0,0,0,.05)'; c.fillRect(x, yv(0), bw, yv(lo) - yv(0));
        const g = c.createLinearGradient(0, yv(lo), 0, yv(0));
        g.addColorStop(0, hexA(col.a, 0.9)); g.addColorStop(0.8, col.b); g.addColorStop(0.95, '#ffb020'); g.addColorStop(1, '#ff4d4d');
        c.fillStyle = g; c.globalAlpha = 0.45; c.fillRect(x, yv(pk), bw, yv(lo) - yv(pk));
        c.globalAlpha = 1; c.fillRect(x, yv(rm), bw, yv(lo) - yv(rm));
        c.fillStyle = st.pkHold[k] > -0.1 ? '#ff4d4d' : col.text; c.fillRect(x, Math.round(yv(st.pkHold[k])), bw, 2 * d);
        c.fillStyle = col.t2; c.textAlign = 'center'; c.fillText(lab, x + bw / 2, hh - 5 * d);
      });
    }
    if (now - metersAt < 120) return;           // the numbers: eight times a second is all the eye reads
    metersAt = now;
    const L = (v) => (Number.isFinite(v) && v > -69.9 ? v.toFixed(1) : '—');
    mEls.integrated.textContent = L(m.integrated);
    mEls.momentary.textContent = L(m.momentary) + (Number.isFinite(m.momentary) && m.momentary > -69.9 ? ' LUFS' : '');
    mEls.shortTerm.textContent = L(m.shortTerm) + (Number.isFinite(m.shortTerm) && m.shortTerm > -69.9 ? ' LUFS' : '');
    mEls.lra.textContent = m.lra > 0 ? m.lra.toFixed(1) + ' LU' : '—';
    mEls.truePeakMax.textContent = Number.isFinite(m.truePeakMax) ? fmtDb(m.truePeakMax) + ' dBTP' : '—';
    mEls.truePeakMax.classList.toggle('hot', m.truePeakMax > -1);
    mEls.crest.textContent = m.crest != null ? m.crest.toFixed(1) + ' ' + $t('дБ') : '—';
    mEls.correlation.textContent = m.correlation != null ? (m.correlation >= 0 ? '+' : '−') + Math.abs(m.correlation).toFixed(2) : '—';
    mEls.correlation.classList.toggle('hot', m.correlation != null && m.correlation < 0);
    cbar.style.transform = `translateX(${((m.correlation ?? 0) * 50).toFixed(1)}%)`;
    cbar.parentElement.classList.toggle('neg', m.correlation != null && m.correlation < 0);
    mEls.width.textContent = m.ch < 2 ? $t('моно') : m.width != null ? Math.round(m.width * 100) + ' %' : '—';
    const nt = st.tone && noteOf(st.tone.hz);
    mEls.tone.innerHTML = st.tone ? `${esc(fmtHz(st.tone.hz))} · <em>${esc(nt.name)}</em> ${esc(fmtCents(nt.cents))}` : '—';
    $('.an-st').textContent = st.sr ? `${(st.sr / 1000).toFixed(st.sr % 1000 ? 1 : 0)} ${$t('кГц')} · ${st.ch === 1 ? $t('моно') : st.ch === 2 ? $t('стерео') : st.ch + ' ' + $t('кан.')}${st.freeze ? ' · ' + $t('стоп-кадр') : ''}` : '';
  }

  // ---- the loop: the ring read and a new picture asked for ~30 times a second; drawn every frame of the monitor
  let raf = 0, alive = true;
  const due = Power.limiter();
  function frame(now) {
    raf = 0; if (!alive) return;
    if (document.hidden || !due(now)) { raf = requestAnimationFrame(frame); return; }   // «Smoothness» (power.js)
    const dt = Math.min(0.1, (now - (st.lastT || now)) / 1000); st.lastT = now;
    // a new track: its own integrated loudness
    const tr = st.app && st.app.player && st.app.player().track;
    const tk = tr ? tr.handle || tr.path || '' : '';
    if (tk !== st.track) { st.track = tk; worker.postMessage({ type: 'reset' }); st.pkHold = [-Infinity, -Infinity]; }
    const live = pull();
    msg.hidden = live;
    if (!live) msg.textContent = $t('Живого звука нет: включите воспроизведение. Если звук играет, а здесь пусто — компонент Gatefold передаёт только спектр, без самих отсчётов.');
    const o = opt();
    if (live && !st.pending && now - st.lastFrame > 30) {
      st.pending = true; st.lastFrame = now;
      worker.postMessage({ type: 'frame', res: o.res, smooth: +o.smooth, tilt: +o.tilt, mode: o.mode, points: Math.max(200, Math.min(1400, Math.round(st.w / 2))) });
    }
    // ballistics: up at once, down at the chosen speed; the held peaks fall slowly after a moment
    if (st.spec && !st.freeze) {
      const n = st.spec.length, fall = DECAY[o.speed] * dt;
      if (!st.disp || st.disp.length !== n) { st.disp = Float32Array.from(st.spec); st.hold = Float32Array.from(st.spec); st.holdAt = new Float64Array(n).fill(now); }
      for (let i = 0; i < n; i++) {
        const v = st.spec[i];
        st.disp[i] = v > st.disp[i] ? v : Math.max(v, st.disp[i] - fall);
        if (st.disp[i] > st.hold[i]) { st.hold[i] = st.disp[i]; st.holdAt[i] = now; }
        else if (now - st.holdAt[i] > 1200) st.hold[i] -= 6 * dt;
      }
      if (st.spec2) {
        if (!st.disp2 || st.disp2.length !== n) st.disp2 = Float32Array.from(st.spec2);
        for (let i = 0; i < n; i++) { const v = st.spec2[i]; st.disp2[i] = v > st.disp2[i] ? v : Math.max(v, st.disp2[i] - fall); }
      } else st.disp2 = null;
    }
    drawPlot(now);
    drawMeters(now, dt);
    raf = requestAnimationFrame(frame);
  }
  raf = requestAnimationFrame(frame);

  // ---- controls
  veil.querySelectorAll('.an-seg').forEach((sg) => sg.querySelectorAll('button').forEach((b) => {
    b.onclick = () => {
      const k = sg.dataset.k, raw = b.dataset.v, v = /^-?\d+(\.\d+)?$/.test(raw) ? +raw : raw;
      setOpt({ [k]: v });
      sg.querySelectorAll('button').forEach((x) => x.classList.toggle('on', x === b));
      if (k === 'mode' || k === 'res' || k === 'smooth' || k === 'tilt') { st.disp = null; st.disp2 = null; st.snap = k === 'tilt' || k === 'smooth' ? null : st.snap; }
    };
  }));
  veil.querySelectorAll('.an-tg input').forEach((cb) => { cb.onchange = () => setOpt({ [cb.dataset.k]: cb.checked }); });
  const freeze = () => { st.freeze = !st.freeze; $('.an-freeze').classList.toggle('on', st.freeze); };
  const snap = () => { if (st.disp) { st.snap = Float32Array.from(st.disp); toast($t('Снимок кривой сохранён — он виден пунктиром')); } };
  const reset = () => { worker.postMessage({ type: 'reset' }); st.hold = st.disp ? Float32Array.from(st.disp) : null; st.pkHold = [-Infinity, -Infinity]; st.snap = null; };
  $('.an-freeze').onclick = freeze; $('.an-snap').onclick = snap; $('.an-reset').onclick = reset;
  plot.addEventListener('pointermove', (e) => { const r = plot.getBoundingClientRect(); st.hover = e.clientX - r.left; });
  plot.addEventListener('pointerleave', () => { st.hover = -1; });
  plot.addEventListener('dblclick', snap);

  const close = () => {
    if (!sheet) return;
    alive = false; cancelAnimationFrame(raf); ro.disconnect(); worker.terminate(); offPal && offPal();
    document.removeEventListener('keydown', onKey, true);
    Viz.vizState.extra.delete('analyzer');
    if (st.app && st.app.refreshSpectrum) st.app.refreshSpectrum();
    const s = sheet; sheet = null;
    s.classList.remove('in'); s.classList.add('out'); setTimeout(() => s.remove(), 220);
  };
  const onKey = (e) => {
    if (!sheet || e.target.closest?.('input, textarea')) return;
    if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); close(); }
    else if (e.key === ' ') { e.preventDefault(); e.stopPropagation(); freeze(); }
    else if (e.key === 's' || e.key === 'S' || e.key === 'ы' || e.key === 'Ы') { e.stopPropagation(); snap(); }
    else if (e.key === 'r' || e.key === 'R' || e.key === 'к' || e.key === 'К') { e.stopPropagation(); reset(); }
  };
  document.addEventListener('keydown', onKey, true);
  $('.an-close').onclick = close;
  veil.addEventListener('mousedown', (e) => { if (e.target === veil) close(); });
  requestAnimationFrame(() => veil.classList.add('in'));
}
